Story: 10755
Adding genesis zeroth address to the env variable.
GENESIS_ZERO_INDEX_ADDRESS=0xCbDCc527e7D22A54b25E57033f776f7bac94Afa2

Value will change for mnemonics for every environment 

Story: 8656
Deploy ul-multitoken repo and add the url to envs
UL_MULTITOKEN_URL: http://localhost:3004