#!/bin/sh

LGPL_FOUND_LIBS_CSV=$1
LGPL_OUTPUT_DIR=$2

LGPL_MANIFEST=$LGPL_OUTPUT_DIR/package.json
PACKAGE_JSON=/usr/src/app/package.json
NODE_MODULES_DIR=/usr/src/app/node_modules

# create an empty manifest file
echo '{ "dependencies" : {} }' >  $LGPL_MANIFEST

while read line; do
    # extract the lib name
    _lib=$(echo $line | awk -F '[,@]' '{print $1}' | sed 's/\"//g') 
    _version=$(echo $line | awk -F '[,@]' '{print $2}' | sed 's/\"//g')
    
    # add to workaround manifest 
    contents="$(jq '.dependencies += {"'$_lib'":"'$_version'"}' $LGPL_MANIFEST)" && \
        echo -E "${contents}" > $LGPL_MANIFEST

    # remove from node_modules directory
    rm -Rf  "${NODE_MODULES_DIR}/$_lib"

done < $LGPL_FOUND_LIBS_CSV