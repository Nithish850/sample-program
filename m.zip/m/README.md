Create Migration -
npx knex migrate:make test --migrations-directory src/db/migrations

Run migration script -
npx knex migrate:latest --knexfile src/db/knextfile.js

Create Seed Scirpt -
npx knex seed:make 01_users (Path issue is still there)

Run Seed script -
npx knex seed:run --knexfile src/db/knextfile.js
