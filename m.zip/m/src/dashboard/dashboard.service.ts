/* eslint-disable no-unused-expressions */
import { Injectable, Logger } from '@nestjs/common';
import { Transaction } from '../db/models/transaction';
import { Namespace } from '../db/models/namespace';
import { Tenants } from '../db/models/tenant';
import { getFilters } from '../tenant/helper';
import { decryptColumn, ERROR_TYPE, UNIVERSAL_LEDGER } from '../utils/constant';
import { OffchainTransaction } from '../db/models/offchain-transaction';
import { validateAndCreateDateRangeFilter, DateFilterType, getMonthName, getCurrentDateInYYYYMMDDFormat,  validateAndCreateDateRange, getPercentChangeWithZeroPastConsideration } from '../utils/util.service';
import { ApiLog } from '../db/models/api-logs';
import { raw } from 'objection';
import { CustomerAccounts } from '../db/models/customer-account';
import { ApprovePendingKYC, TenantFilters, UserMetricsFilters, WalletCategoryCount, WalletCountFilters, WalletCountFiltersUled } from './filter-helper';
import { BusinessUsers } from '../db/models/business_users';
import { BusinessUserNamespaces } from '../db/models/business_user_namespaces';
import countries from 'i18n-iso-countries';

@Injectable()
export class DashboardService {
  private readonly logger = new Logger(DashboardService.name);

  async fetchTenantMetrics(filters: TenantFilters): Promise<any> {
    try {
      this.logger.log(` fetchTenantMetricsForUledAdmin running`);
      const updatedFilter: any = getFilters(filters);
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const tenantCount  = await this.getTenantCount(updatedFilter, startDate, endDate);

        this.logger.log(` fetchTenantMetrics tenantCount :  ${tenantCount}`)

        return { tenantCount };
      }

      const [presentTenantCount] = await Promise.all([
        this.getTenantCount(updatedFilter, startDate, endDate),
        this.getTenantCount(updatedFilter, pastStartDate, pastEndDate)
      ])

      this.logger.log(` fetchTenantMetrics tenantCount :  ${presentTenantCount}`)

      return { tenantCount: presentTenantCount };

    } catch (error) {
      this.logger.log(`catchError - Fetching tenant details via tenantId: ` + error);

      if (error.message.includes('select')) {
        const err =  error.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: err[1] } ] }
      }

      return {
        errors: [
          {
            message: error.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchWalletMetrics(tenantId: any, filters: WalletCountFilters): Promise<any> {
    try {

      this.logger.log(' fetchWalletMetrics running');
      // const updatedFilter: any = getFilters(filters);
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      let  tenants = [];
      const tenantDetails = await Tenants.query().select('tenant_name').findOne({ tenantId });

      if(tenantDetails && tenantDetails.tenantName && tenantDetails.tenantName !== UNIVERSAL_LEDGER)
        tenants = [tenantId];

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const walletCount  = await this.getWalletCount(tenants, startDate, endDate);

        this.logger.log(` fetchWalletMetrics walletCount :  ${walletCount}`)

        return { walletCount };
      }

      const [presentwalletcount] = await Promise.all([
        this.getWalletCount(tenants, startDate, endDate),
        this.getWalletCount(tenants, pastStartDate, pastEndDate)
      ])

      this.logger.log(` fetchWalletMetrics walletCount :  ${presentwalletcount}`)

      return { walletCount: presentwalletcount };

    } catch (err) {
      this.logger.error(`ERROR :: fetchWalletMetrics While fetching wallet count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchWalletUsersPerTenantMetrics(filters): Promise<any> {
    try {
      let day = 365;

      if (filters?.days) {
        day = filters?.days;
      }
      const updatedFilter: any = getFilters(filters);

      const data = await Tenants.query()
        .select('tenants.tenant_name', 't2.wallet_user_count', 'tenants.tenant_id as tenant_id')
        .join(
          Tenants.query()
            .select('n.tenant_id', Namespace.raw('count(n.tenant_id) as wallet_user_count'))
            .from('namespaces as n')
            .whereNotNull('n.account_address')
            .where('n.is_deleted', false)
            .whereRaw('n.created_at > now() - interval ? day', [day]) // Parameterized 'day' value
            .groupBy('n.tenant_id')
            .as('t2'),
          'tenants.tenant_id',
          't2.tenant_id'
        )
        .where((builder) => {
          Object.keys(updatedFilter).forEach((key) => {
            if (updatedFilter[key].length > 0) {
              builder.whereIn(`tenants.${key}`, updatedFilter[key]);
            }
          });
        });

      return { data };
    } catch (err) {
      this.logger.error(`ERROR :: While fetching wallet count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchTransactedAmountMetrics(filters): Promise<any> {
    try {
      let day = '365';

      if (filters?.days) {
        day = filters?.days;
      }

      const offchain: any = await OffchainTransaction.query()
        .select(OffchainTransaction.raw('SUM(cast(transaction_amount as DECIMAL(10,2)))'))
        .where('status', 'COMPLETED')
        .andWhere('created_at', '>', OffchainTransaction.raw(`now() - interval ? day`, [day]))
        .as('offChainSum');

      const totalSumSubQuery: any = await Transaction.query()
        .select(Transaction.raw('SUM(cast(transaction_amount as DECIMAL(10,2)))'))
        .where('status', 'COMPLETED')
        .andWhere('created_at', '>', Transaction.raw(`now() - interval ? day`, [day]))
        .as('total_sum');

      const result = parseFloat(offchain[0].sum) + parseFloat(totalSumSubQuery[0].sum);

      return { data: { totalTransactionAmount: result, day } };
    } catch (error) {
      this.logger.error(`ERROR :: While fetching transacted amount ` + error.message);

      return {
        errors: [
          {
            message: 'error while fetching transacted amount',
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchTransactionMetrics(): Promise<any> {
    try {
      const [ noOfOnChainTransaction ]: any = await Transaction.query().count();

      const [ noOfOffChainTransaction ]: any = await OffchainTransaction.query().count();

      const totalTransactionCount = parseInt(noOfOnChainTransaction?.count) + parseInt(noOfOffChainTransaction?.count);

      return {
        data: {
          totalTransactionCount,
          onChainTransactionCount: parseInt(noOfOnChainTransaction?.count),
          offchainTransaction: parseInt(noOfOffChainTransaction?.count),
        },
      };
    } catch (error) {
      this.logger.error(`ERROR :: While fetching transaction count` + error);

      return {
        errors: [
          {
            message: 'error while fetching transaction count',
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchSubscriptionMetrics(tenantId: any, filters: WalletCountFilters): Promise<any> {
    try {
      this.logger.log(' fetchSubscriptionMetrics running');
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);
      let tenantIdList = tenantId ? [tenantId] : [];

      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      if(defaultTenant?.tenantId == tenantId) {
        tenantIdList = [];
      }

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const subscrptionData  = await this.getEventSubscriptionCount(tenantIdList, startDate, endDate);

        // const data = this.getSubscriptionChange(subscrptionData);

        // return { data };

        const newResponseData = await newSubscriptionCountResponse(subscrptionData);

        this.logger.log(' custom date subscription count: ', newResponseData);

        return newResponseData;
      }

      const [presentsubScrptionData, pastsubScrptionData] = await Promise.all([
        this.getEventSubscriptionCount(tenantIdList, startDate, endDate),
        this.getEventSubscriptionCount(tenantIdList, pastStartDate, pastEndDate)
      ]);

      // const data = await this.getSubscriptionChange(presentsubScrptionData, pastsubScrptionData);

      // return { data };

      const newResponseData = await newSubscriptionCountResponse(presentsubScrptionData, pastsubScrptionData);

      this.logger.log(' subscription count: ', newResponseData);

      return newResponseData;
    } catch (err) {
      this.logger.error(`ERROR :: While fetching subscription count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchTotalAmountAcrossWalletMetrics(filters): Promise<any> {
    try {
      const updatedFilter: any = getFilters(filters);

      const [ offChainCreditDebitSum ]: any = await OffchainTransaction.query()
        .select(OffchainTransaction.raw(`
          SUM(CASE WHEN transaction_type = 'CREDIT' THEN CAST(transaction_amount as DECIMAL(10,2)) Else 0 end) "creditTotal",
          SUM(CASE WHEN transaction_type = 'DEBIT' THEN CAST(transaction_amount as DECIMAL(10,2)) Else 0 end) "debitTotal"`))
        .where('status', 'COMPLETED')
        .where((builder) => {
          if (updatedFilter?.tenant_id) {
            builder.whereIn('tenant_id', updatedFilter.tenant_id);
          }
        })

      const [ totalSumSubQuery ]: any = await Transaction.query()
        .select(Transaction.raw(`
          SUM(CASE WHEN transaction_type = 'CREDIT' THEN CAST(transaction_amount as DECIMAL(10,2)) Else 0 end) "creditTotal",
          SUM(CASE WHEN transaction_type = 'DEBIT' THEN CAST(transaction_amount as DECIMAL(10,2)) Else 0 end) "debitTotal"`))
        .where('status', 'COMPLETED')
        .where((builder) => {
          if (updatedFilter?.tenant_id) {
            builder.whereIn('tenant_id', updatedFilter.tenant_id);
          }
        })

      const customersTotalAmount = (Number(offChainCreditDebitSum.creditTotal) - Number(offChainCreditDebitSum.debitTotal))
                                    + (Number(totalSumSubQuery.creditTotal) - Number(totalSumSubQuery.debitTotal));

      return {
        data: { totalAmount: customersTotalAmount }
      }

    } catch (err) {
      this.logger.error(`ERROR :: While fetching total amount ` + err);

      return {
        errors: [
          {
            message: 'error while fetching total amount across wallet',
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchTotalMintedToken(tenantId, filters,tenantName): Promise<any> {
    try{
      this.logger.debug(`inside fetchTotalMintedToken service:: ${tenantId}`);

      let tennatIdFilter, tenantNameFilter ;

      tenantNameFilter = (tenantName !== UNIVERSAL_LEDGER) ? tenantName : '';

      if(tenantId){
        const tenantExists : any = await Tenants.query().findById(tenantId).select('*');

        tennatIdFilter = (tenantExists.tenantName !== UNIVERSAL_LEDGER) ? tenantId : undefined;
        if(!tenantExists) {
          return {
            errors: [
              {
                message: `Tenant Id doesn't exist ${tenantId}`,
                type: ERROR_TYPE.TENANT,
              },
            ],
          };
        }
      }

      const { startDate, endDate } = await validateAndCreateDateRangeFilter(filters?.dateFilterType, tenantId, filters?.startDate, filters?.endDate);

      if(filters.dateFilterType === DateFilterType.TILL_DATE) {

        const mintedTokenCount  = await this.getTokenCount(tennatIdFilter, "0", "0", tenantNameFilter);

        this.logger.log(` fetchTotalMintedToken mintedTokenCount :  ${mintedTokenCount}`)

        return { data: mintedTokenCount } ;
      }

      const mintedTokenCount  = await this.getTokenCount(tennatIdFilter, startDate, endDate, tenantNameFilter);

      this.logger.log(` fetchTotalMintedToken mintedTokenCount :  ${mintedTokenCount}`)

      return { data: mintedTokenCount } ;

    }catch(error) {
      this.logger.error(`ERROR :: While fetching total minted tokens:: ${error}`);

      if (error.message.includes('select')) {
        const err =  error.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: err[1] } ] }
      }

      return {
        errors: [
          {
            message: `error while fetching total minted token: ${error.message}`,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async getTokenCount (tenantId: any, startDate: string, endDate: string, tenantName: any): Promise<any> {
    try {

      const offchain: any = await OffchainTransaction.query()
        .alias('o')
        .leftJoin('tenants as t', 'o.tenant_id', 't.tenant_id' )
        .select(
          'token_symbol',
          OffchainTransaction.raw('SUM(cast(transaction_amount as DECIMAL(20,2))) as total_amount'),
          'transaction_type'
        )
        .where({
          status: 'COMPLETED',
          origin_address: 'NA',
        })
        .where((builder) => {
          if(tenantId) {
            builder.where('o.tenant_id', tenantId)
          }
        })
        .where((builder) => {
          if(tenantName) {
            builder.where(decryptColumn('t.tenant_name'), tenantName)
          }
        })
        .where((builder) => {
          if(startDate !== "0" && endDate !== "0") {
            builder.where(raw(`date(o.created_at) >= '${startDate}'`)).andWhere(raw(`date(o.created_at) <= '${endDate}'`))
          }
        })
        .groupBy('transaction_type', 'token_symbol');

      if (offchain && offchain.length > 0) {
        const transformedResult = offchain.reduce((acc, item) => {
          const { totalAmount, transactionType, tokenSymbol } = item;

          if (transactionType === 'CREDIT') {
            acc[tokenSymbol] = {
              ...acc[tokenSymbol],
              mintedTokens: parseFloat(totalAmount)
            };
          } else if (transactionType === 'DEBIT') {
            acc[tokenSymbol] = {
              ...acc[tokenSymbol],
              burntTokens: parseFloat(totalAmount)
            };
          }

          return acc;
        }, {});

        for (const tokenSymbol in transformedResult) {
          const { mintedTokens = 0, burntTokens = 0 } = transformedResult[tokenSymbol];

          transformedResult[tokenSymbol].netTokens = mintedTokens - burntTokens;
        }

        return transformedResult;
      }

      return 0;
    } catch(error) {
      console.log(error ,"error")

      return 0;
    }
  }

  async getApiCount(tenantId, filters) {
    try{
      this.logger.log(`Inside getApiCount service: ${tenantId}, filters: ${JSON.stringify(filters)}`);

      const tenantExists = await Tenants.query().findById(tenantId);

      if(!tenantExists) {
        return {
          errors: [
            {
              message: `Tenant Id doesn't exist ${tenantId}`,
              type: ERROR_TYPE.TENANT,
            },
          ],
        };
      }
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRangeFilter(filters?.dateFilterType, tenantId, filters?.startDate, filters?.endDate);

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const apiCount  = await this.getAPICount(tenantId, startDate, endDate);

        this.logger.log(`getApiCount  apiCount :  ${apiCount}`)

        return { data: { apiCount } };
      }

      const [apiCount] = await Promise.all([
        this.getAPICount(tenantId, startDate, endDate),
        this.getAPICount(tenantId, pastStartDate, pastEndDate)
      ])

      this.logger.log(`getApiCount apiCount :  ${apiCount}`)

      return { data: { apiCount } };
    } catch(err) {
      this.logger.error(`ERROR :: While fetching total api call count :: ${err.message}`);

      return {
        errors: [
          {
            message: `error while fetching total api call count: ${err.message}`,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  getSubscriptionChange(presentData: any, pastData: any = undefined) {
    this.logger.log(' getSubscriptionChange running ');
    if(!pastData) {
      if(!presentData) {
        return [];
      }

      return presentData.map((val) => ({ ...val }))
    }
    const returnValue: any = [];

    for(const val of presentData) {
      pastData.map((pastVal, indeOfPastValue) => {
        if(val.tenantId === pastVal.tenantId) {

          pastData.splice(indeOfPastValue, 1);
        }
      })
      returnValue.push(val);
    }

    return returnValue
  }

  async getAPICount(tenantId, startDate, endDate) {
    try {
      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      let apiCount;

      if(defaultTenant?.tenantId == tenantId) {
        [apiCount]= await ApiLog.query()
          .count('tenant_id')
          .whereRaw('date(created_at) >= ?', [startDate])
          .andWhereRaw('date(created_at) <= ?', [endDate]);

        return apiCount?.count ? parseInt(apiCount?.count) : 0;
      }

      [apiCount] = await ApiLog.query()
        .count('tenant_id')
        .where({
          tenantId: tenantId
        }).whereRaw('date(created_at) >= ?', [startDate])
        .andWhereRaw('date(created_at) <= ?', [endDate]);

      return apiCount?.count ? parseInt(apiCount?.count) : 0;
    } catch(error) {
      return 0;
    }
  }

  async getTrxPercentagePerCategoryForTenants(tenantId: any, filters){
    try{
      this.logger.log(` getTrxPercentagePerCategoryForTenants service requested by ${tenantId}`);

      const { startDate, endDate } = await validateAndCreateDateRangeFilter(filters?.dateFilterType, tenantId, filters?.startDate, filters?.endDate);
      const transactionPercentagePerCategory: any  = await this.getTransactionPercentagePerCategoryForTenants(tenantId, startDate, endDate);

      this.logger.log(`getTransactionPercentagePerCategoryForTenants  transactionPercentagePerCategory :  ${transactionPercentagePerCategory}`)

      return { data: { transactionPercentagePerCategory } };
    }catch (err) {
      this.logger.error(`Catch error: getTrxPercentagePerCategoryForTenants: ${err} `);

      if(err?.message.includes('select')) {
        const error = err.message.split('- ');

        return {
          errors: [{
            type: ERROR_TYPE.CATCH,
            message: error[1]
          }]
        };
      }

      return {
        errors: [{
          type: ERROR_TYPE.CATCH,
          message: err?.message
        }]
      }
    }

  }

  async getTransactionPercentagePerCategoryForTenants(tenantId: any, startDate, endDate) {
    try {
      this.logger.log(` getTransactionPercentagePerCategoryForTenants service requested by ${tenantId}`);

      const offChainTrxQuery = OffchainTransaction.query()
        .alias('ot')
        .join('tenant_customer_accounts as tca', 'tca.tenant_customer_accounts_id', 'ot.tenant_customer_accounts_id')
        .leftJoin('badge as b', 'tca.badge_id', 'b.badge_id')
        .select('b.badge_name as category_name', raw('count(ot.tenant_id)'))
        .where('status', 'COMPLETED' )
        .whereRaw('date(ot.created_at) >= ?', [startDate])
        .andWhereRaw('date(ot.created_at) <= ?', [endDate]);

      const onChainTrxQuery = Transaction.query()
        .alias('trx')
        .join('namespaces as n','n.tenant_id', 'trx.tenant_id')
        .join('tenant_customer_accounts as tca', 'tca.customer_account_id', 'n.customer_account_id')
        .leftJoin('badge as b', 'tca.badge_id', 'b.badge_id')
        .select('b.badge_name as category_name', raw('count(trx.tenant_id)'))
        .where('trx.transaction_status', 'COMPLETED' )
        .whereRaw('date(trx.created_at) >= ?', [startDate])
        .andWhereRaw('date(trx.created_at) <= ?', [endDate]);

      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      if(defaultTenant?.tenantId == tenantId) {
        const [offChainResult, onChainResult] = await Promise.all([
          offChainTrxQuery.groupBy('b.badge_name'),
          onChainTrxQuery.groupBy('b.badge_name')
        ]);

        const result = await getCategoryTrxPercentage(offChainResult, onChainResult);

        this.logger.log(` ${process.env.DEFAULT_TENANT} tenant id: ${tenantId} transaction based on category is: `,result);

        return {
          type: "circularChart",
          title: "Transaction based on category",
          data: result
        };

      }

      const [offChainResult, onChainResult] = await Promise.all([
        offChainTrxQuery.where('ot.tenant_id', tenantId).groupBy('b.badge_name'),
        onChainTrxQuery.where('trx.tenant_id', tenantId).groupBy('b.badge_name')
      ]);

      const result = await getCategoryTrxPercentage(offChainResult, onChainResult);

      this.logger.log(` tenant id: ${tenantId} transaction based on category is: `,result);

      return {
        type: "circularChart",
        title: "Transaction based on category",
        data: result
      };
    } catch(error) {
      return 0;
    }
  }

  async getOffchainTrxByTransactionMethod(tenantId: any, filters){
    try{
      this.logger.log(` getOffchainTrxByTransactionMethod service requested by ${tenantId}`);

      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRangeFilter(filters?.dateFilterType, tenantId, filters?.startDate, filters?.endDate);

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const transactionPercentagePerCategory  = await this.getOffchainTrxByTxnMethodForTenants(tenantId, startDate, endDate);

        this.logger.log(`getOffchainTrxByTxnMethodForTenants  transactionPercentagePerCategory :  ${transactionPercentagePerCategory}`)

        return { data: { transactionPercentagePerCategory } };
      }

      const [transactionPercentagePerCategory, pastTransactionPercentagePerCategory] : any= await Promise.all([
        this.getOffchainTrxByTxnMethodForTenants(tenantId, startDate, endDate),
        this.getOffchainTrxByTxnMethodForTenants(tenantId, pastStartDate, pastEndDate)
      ])

      this.logger.log(`getOffchainTrxByTxnMethodForTenants  transactionPercentagePerCategory :  ${transactionPercentagePerCategory}`)
      this.logger.log(`getOffchainTrxByTxnMethodForTenants pastTransactionPercentagePerCategory :  ${pastTransactionPercentagePerCategory}`)

      return { data: { transactionPercentagePerCategory } };
    }catch (err) {
      this.logger.error(`Catch error: getOffchainTrxByTransactionMethod: ${err} `);

      if(err?.message.includes('select')) {
        const error = err.message.split('- ');

        return {
          errors: [{
            type: ERROR_TYPE.CATCH,
            message: error[1]
          }]
        };
      }

      return {
        errors: [{
          type: ERROR_TYPE.CATCH,
          message: err?.message
        }]
      }
    }

  }

  async getOffchainTrxByTxnMethodForTenants(tenantId: any, startDate, endDate) {
    try {
      this.logger.log(` getTransactionPercentagePerCategoryForTenants service requested by ${tenantId}`);

      const offChainTrxQuery = OffchainTransaction.query()
        .select(raw('LOWER(transfer_type) as "transferType"'), raw('count(offchain_transaction_id)'))
        .where('status', 'COMPLETED' )
        /* "card" transferType changed into "credit-card" or "debit-card", so removing it */
        .whereNotIn('transfer_type', ['offline', 'card', 'Utility Token Mint'])
        .whereRaw('date(created_at) >= ?', [startDate])
        .andWhereRaw('date(created_at) <= ?', [endDate]);
        
      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      if(defaultTenant?.tenantId == tenantId) {
        const [offChainResult] = await Promise.all([
          offChainTrxQuery.groupBy('transfer_type')
        ]);

        const result = await getTrxByTransferTypePercentage(offChainResult);

        this.logger.log(` ${process.env.DEFAULT_TENANT} tenant id: ${tenantId} transaction based on transfer type is: `,result);

        return {
          type: "circularChart",
          title: "Transaction based on transaction method",
          data: result
        };
      }

      const [offChainResult] = await Promise.all([
        offChainTrxQuery.where('tenant_id', tenantId).groupBy('transfer_type')
      ]);

      const result = await getTrxByTransferTypePercentage(offChainResult);

      this.logger.log(` tenant id: ${tenantId} transaction based on category is: `,result);

      return {
        type: "circularChart",
        title: "Transaction based on transaction method",
        data: result
      };
    } catch(error) {
      this.logger.log(`catchError - getOffchainTrxByTxnMethodForTenants: ` + error);

      return 0;
    }
  }

  async getUserCountBasedOnCountry(tenantId) {
    try{
      this.logger.log(`Inside getUserCountBasedOnCountry service: ${tenantId}`);

      const tenantExists = await Tenants.query().findById(tenantId);

      if(!tenantExists) {
        return {
          errors: [
            {
              message: `Tenant Id doesn't exist ${tenantId}`,
              type: ERROR_TYPE.TENANT,
            },
          ],
        };
      }

      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      // let country_list = await CustomerAccounts.query()
      //   .select(raw(`address->>'isoCountryCode' as country_code`), CustomerAccounts.raw(`count(tenant_id) as total_user`))
      //   .where((builder) => {
      //     if(defaultTenant.tenantId !== tenantId)
      //       builder.where('tenant_id', tenantId)
      //   })
      //   .groupBy(raw(`address->>'isoCountryCode'`));

      const countryList = async () => {
        const allData = await CustomerAccounts.query()
          .select('address', 'tenant_id')
          .where((builder) => {
            if (defaultTenant.tenantId !== tenantId) {
              builder.where('tenant_id', tenantId);
            }
          });

        const countryCountMap = allData.reduce((acc, account) => {
          const countryCode = account.address?.isoCountryCode;

          if (countryCode) {
            if (!acc[countryCode]) {
              acc[countryCode] = {
                total_user: 0,
              };
            }
            acc[countryCode].total_user += 1;
          }

          return acc;
        }, {});

        const response = Object.entries(countryCountMap).map(([countryCode, totalUser]:any) => ({
          countryCode,
          totalUser: totalUser?.total_user || 0,
        }));

        return response;
      };

      let country_list = await countryList()

      country_list = await this.getPercentageCountry(country_list);

      return { country_list };
    } catch(err) {
      this.logger.error(`ERROR :: While fetching total wallet user count :: ${err.message}`);

      return {
        errors: [
          {
            message: `error while fetching total wallet user count: ${err.message}`,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async getDebitCreditTransactions(tenantId) {
    try{
      this.logger.log(`Inside getDebitCreditTransactions service: ${tenantId}`);

      const tenantExists = await Tenants.query().findById(tenantId);

      if(!tenantExists) {
        return {
          errors: [
            {
              message: `Tenant Id doesn't exist ${tenantId}`,
              type: ERROR_TYPE.TENANT,
            },
          ],
        };
      }

      let creditTransactions , debitTransactions ;
      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      // const monthsDates = this.getMonthStartEndDateForYear();

      if(defaultTenant?.tenantId == tenantId) {
        // eslint-disable-next-line no-await-in-loop
        const transactionList = await OffchainTransaction.query()
          .select('type', OffchainTransaction.raw(`SUM(cast(transaction_amount as DECIMAL(30,2))) as amount`),
            OffchainTransaction.raw(`DATE_TRUNC('month',created_at) AS  month`))
          .groupBy('type', 'month');

        const credit: any = transactionList.filter((transaction) => transaction.type === 'deposit');
        const debit: any = transactionList.filter((transaction) => transaction.type === 'withdraw');

        creditTransactions = getNewDataObject(credit);
        debitTransactions = getNewDataObject(debit);

        return { debitTransactions: getCreditDebitResponse(debitTransactions,{}),  creditTransactions: getCreditDebitResponse(creditTransactions, {}) };
      }

      const transactionList = await OffchainTransaction.query()
        .select('type', OffchainTransaction.raw(`SUM(cast(transaction_amount as DECIMAL(30,2))) as amount`),
          OffchainTransaction.raw(`DATE_TRUNC('month',created_at) AS  month`))
        .groupBy('type', 'month')
        .where({ 'tenant_id': tenantId });

      const credit: any = transactionList.filter((transaction) => transaction.type === 'deposit');
      const debit: any = transactionList.filter((transaction) => transaction.type === 'withdraw');

      creditTransactions = getNewDataObject(credit);
      debitTransactions = getNewDataObject(debit);

      return { debitTransactions: getCreditDebitResponse(debitTransactions,{}),  creditTransactions: getCreditDebitResponse(creditTransactions, {}) };

    } catch(err) {
      this.logger.error(`ERROR :: While fetching total wallet user count :: ${err.message}`);

      return {
        errors: [
          {
            message: `error while fetching total wallet user count: ${err.message}`,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async getPercentageCountry(country_list) {
    try {
      if(country_list && country_list.length){

        const totalUserCount = country_list.reduce((sum, country) => sum + parseInt(country.totalUser), 0);

        const newCountryList = [];

        for(const country of country_list)  {
          const newCountry = country;

          newCountry.totalUser = Math.round((parseInt(country.totalUser) / totalUserCount) * 100);
          newCountry.countryName = countries.getName(newCountry.countryCode, 'en');
          newCountryList.push(newCountry);
        }

        return newCountryList;
      }

      return country_list;
    } catch (err)  {
      this.logger.error(`ERROR :: getPercentageCountry :: ${err.message}`);

      return {
        errors: [
          {
            message: `error while fetching total wallet user count: ${err.message}`,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async getTrxVolForTenantsPerMonth(tenantId: any, year: string | number): Promise<any> {
    try {
      this.logger.log(` getTrxPercentagePerCategoryForTenants service requested by ${tenantId} for year ${year}`);

      const offChainTrxQuery = OffchainTransaction.query()
        .alias('ot')
        .select(raw(`SUM(cast(ot.transaction_amount as DECIMAL(30,2))) as amount`),
          raw(`DATE_TRUNC('month',ot.created_at) AS  month`),
          raw('count(ot.tenant_id) as count'),
          raw(`AVG(cast(ot.transaction_amount as DECIMAL(30,2))) as average`))
        .where('status', 'COMPLETED' );

      const onChainTrxQuery = Transaction.query()
        .alias('trx')
        .select(raw(`SUM(cast(trx.transaction_amount as DECIMAL(30,2))) as amount`),
          raw(`DATE_TRUNC('month',trx.created_at) AS  month`),
          raw('count(trx.tenant_id) as count'),
          raw(`AVG(cast(trx.transaction_amount as DECIMAL(30,2))) as average`))
        .join('tenant_namespace as tn', 'tn.tenant_id', 'trx.tenant_id')
        // .join('namespaces as n','n.tenant_id', 'tn.tenant_id')
        .where('trx.transaction_status', 'COMPLETED' );

      const defaultTenant: any = await Tenants.query().findOne('tenant_name', process.env.DEFAULT_TENANT);

      if(defaultTenant?.tenantId == tenantId) {
        const [offChainResult, onChainResult] = await Promise.all([
          offChainTrxQuery.groupBy(raw(`DATE_TRUNC('month',ot.created_at)`)),
          onChainTrxQuery.groupBy(raw(`DATE_TRUNC('month',trx.created_at)`))
        ]);

        const result = await buildTrxVolResponse(offChainResult, onChainResult);

        this.logger.log(` ${process.env.DEFAULT_TENANT} tenant id: ${tenantId} transaction volume is: `,result);

        return result;
      }

      const [offChainResult, onChainResult] = await Promise.all([
        offChainTrxQuery.where('ot.tenant_id', tenantId).groupBy(raw(`DATE_TRUNC('month',ot.created_at)`)),
        onChainTrxQuery.where('trx.tenant_id', tenantId).groupBy(raw(`DATE_TRUNC('month',trx.created_at)`))
      ]);

      const result = await buildTrxVolResponse(offChainResult, onChainResult);

      this.logger.log(` tenant id: ${tenantId} transaction volume is: `,result);

      return result;
    } catch (err) {
      this.logger.error(`Catch error: getTrxPercentagePerCategoryForTenants: ${err} `);

      if(err?.message.includes('select')) {
        const error = err.message.split('- ');

        return {
          errors: [{
            type: ERROR_TYPE.CATCH,
            message: error[1]
          }]
        };
      }

      return {
        errors: [{
          type: ERROR_TYPE.CATCH,
          message: err?.message
        }]
      }
    }
  }

  getMonthStartEndDateForYear() {
    const monthsDates = [];

    for(let month = 0; month < 12; month++) {
      const date = new Date();
      const firstDay = getCurrentDateInYYYYMMDDFormat(new Date(date.getFullYear(), month, 1));
      const lastDay = getCurrentDateInYYYYMMDDFormat(new Date(date.getFullYear(), month + 1, 0));

      monthsDates.push({
        firstDay,
        lastDay,
        month: month+1
      });
    }

    return monthsDates;
  }

  async fetchWalletMetricsForUledAdmin(tenantId: any, filters: WalletCountFiltersUled): Promise<any> {
    try {

      this.logger.log(' fetchWalletMetricsForUled running');
      const updatedFilter: any = getFilters(filters);
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      const tenantFilter: string[] = updatedFilter?.tenant_id || [];

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const walletCount  = await this.getWalletCount(tenantFilter, startDate, endDate);

        this.logger.log(` fetchWalletMetricsForUled walletCount :  ${walletCount}`)

        return { walletCount };
      }

      const [presentWalletCount] = await Promise.all([
        this.getWalletCount(tenantFilter, startDate, endDate),
        this.getWalletCount(tenantFilter, pastStartDate, pastEndDate)
      ])

      this.logger.log(` fetchWalletMetricsForUled walletCount :  ${presentWalletCount}`)

      return { walletCount: presentWalletCount };

    } catch (err) {
      this.logger.error(`ERROR :: fetchWalletMetricsForUled While fetching wallet count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchWalletMetricsForCategory(tenantId: any, filters: WalletCategoryCount): Promise<any> {
    try {
      this.logger.log('fetchWalletMetricsForCategory running');
      const updatedFilter: any = getFilters(filters);
      const { startDate, endDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      const defaultTenant: any = await Tenants.query().findOne(decryptColumn('tenant_name'), process.env.DEFAULT_TENANT);

      const data: any = await Namespace.query()
        .alias('n')
        .leftJoin('tenant_customer_accounts as tca', function () {
          // eslint-disable-next-line no-invalid-this
          this.on('tca.customer_account_id', '=', 'n.customer_account_id')
            .andOn('tca.tenant_id', '=', 'n.tenant_id');
        })
        .join('customer_accounts as ca', 'ca.customer_account_id', 'n.customer_account_id')
        .select('ca.onboarding_status as wallet_status', 'b.badge_name as category_name')
        .join('badge as b', 'tca.badge_id', 'b.badge_id')
        .count('b.badge_name as count')
        .where({ 'n.is_global': false, 'tca.is_forgotten': false })
        .where((builder) => {
          Object.keys(updatedFilter).forEach((key) => {
            if (updatedFilter[key].length > 0 && key === 'onboarding_status') {
              builder.whereIn(`ca.${key}`, updatedFilter[key]);
            }
          });

          // Use parameterized bindings for date range to prevent SQL injection
          builder
            .andWhereRaw('date(n.created_at) >= ?', [startDate])
            .andWhereRaw('date(n.created_at) <= ?', [endDate]);

          if (defaultTenant?.tenantId !== tenantId) {
            builder.andWhere('n.tenant_id', tenantId);
          }
        })
        .groupBy('wallet_status', 'badge_name');

      let responseData = {}

      if(!data.length) {
        this.logger.log(' 1. wallet user category count: ',responseData);

        return responseData;
      }

      if(data.length == 1) {
        this.logger.log(' 2. wallet user category count: ',responseData);

        return {
          ...responseData,
          [data[0]?.categoryName]: data[0]?.count ? parseInt(data[0]?.count) : 0
        }
      }
      Array.from(data.reduce(
        (m, { categoryName, count }) => m.set(categoryName, (m.get(categoryName) || 0) + parseInt(count)), new Map
      ), ([categoryName, count]) => ({ categoryName, count })).forEach((val) => {
        if(responseData[val?.categoryName]) {
          responseData[val.categoryName] = responseData[val?.categoryName] + val?.count
        }

        responseData = {
          ...responseData,
          [val?.categoryName]: val?.count ? parseInt(val?.count) : 0
        }
      });

      this.logger.log(' 3. wallet user category count: ',responseData);

      return responseData;
    } catch (err) {
      this.logger.error(`ERROR :: While fetching category count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async fetchSubscriptionMetricsForUledAdmin(tenantId: any, filters: WalletCountFiltersUled): Promise<any> {
    try {

      this.logger.log(` fetchSubscriptionMetricsForUledAdmin running for admin tenant id ${tenantId}`);
      const updatedFilter: any = getFilters(filters);
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      const tenantFilter: string[] = updatedFilter?.tenant_id || [];

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const subscrptionData  = await this.getEventSubscriptionCount(tenantFilter, startDate, endDate);
        // const data = this.getSubscriptionChange(subscrptionData);

        // return { data };

        const newResponseData = await newSubscriptionCountResponse(subscrptionData);

        this.logger.log(' custom date subscription count: ', newResponseData);

        return newResponseData;
      }

      const [presentsubScrptionData, pastsubScrptionData] = await Promise.all([
        this.getEventSubscriptionCount(tenantFilter, startDate, endDate),
        this.getEventSubscriptionCount(tenantFilter, pastStartDate, pastEndDate)
      ]);

      // const data = await this.getSubscriptionChange(presentsubScrptionData, pastsubScrptionData);

      // return { data };

      const newResponseData = await newSubscriptionCountResponse(presentsubScrptionData, pastsubScrptionData);

      this.logger.log(' subscription count: ', newResponseData);

      return newResponseData;

    } catch (err) {
      this.logger.error(`ERROR :: fetchSubscriptionMetricsForUledAdmin While fetching event subscription count :: error : ${err}`);

      if (err.message.includes('select')) {
        const error =  err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] }
      }

      return {
        errors: [
          {
            message: err.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  async getWalletCount (tenantIdList: string[], startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getWalletCount running for tenant id list: ${tenantIdList} for date between: ${startDate} to ${endDate}`);
      const [noOfWallet]: any = await Namespace.query()
        .count('n.account_address')
        .alias('n')
        .leftJoin('tenant_customer_accounts as tca', function () {
          // eslint-disable-next-line no-invalid-this
          this.on('tca.customer_account_id', '=', 'n.customer_account_id')
            .andOn('tca.tenant_id', '=', 'n.tenant_id')
        })
        .where({ 'n.is_global': false, 'tca.is_forgotten': false })
        .where((builder) => {
          if(tenantIdList.length) {
            builder.whereIn('n.tenant_id', tenantIdList)
          }
        })
        .where(raw(`date(n.created_at) >= '${startDate}'`)).andWhere(raw(`date(n.created_at) <= '${endDate}'`));

      return noOfWallet?.count ? parseInt(noOfWallet.count) : 0;
    } catch(error) {
      this.logger.error(` getWalletCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async getEventSubscriptionCount (tenantIdList: string[], startDate: string, endDate: string): Promise<any> {
    try {
      this.logger.log(` getEventSubscriptionCount running for date between: ${startDate} to ${endDate}`);

      const subscrptionData: any = await Tenants.query()
        .alias('t')
        .join('tenant_event_subscription as tes', 'tes.tenant_id', 't.tenant_id')
        .select('t.tenant_id', 't.tenant_name as tenant_name')
        .count('t.tenant_id as subscriptionCount')
        .where((builder) => {
          if (tenantIdList.length) {
            builder.whereIn('t.tenant_id', tenantIdList);
          }
          builder.andWhere('tes.is_active', true);
        })
        // Use parameterized bindings for date range
        .andWhereRaw('date(tes.created_at) >= ?', [startDate])
        .andWhereRaw('date(tes.created_at) <= ?', [endDate])
        .groupBy('t.tenant_id');

      return subscrptionData;
    } catch(error) {
      this.logger.error(` getEventSubscriptionCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async getTenantCount (filter, startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getTenantCount running for date between: ${startDate} to ${endDate}`);
      const [noOfTenant]: any = await Tenants.query()
        .count()
        .where((builder) => {
          Object.keys(filter).forEach(function (key) {
            if (filter[key].length > 0) {
              if (key === 'dateFilterType') {
                builder.andWhereRaw('date(created_at) >= ?', [startDate])
                  .andWhereRaw('date(created_at) <= ?', [endDate]);
              } else {
                builder.whereIn(key, filter[key]);
              }
            }
          });
        });

      this.logger.log(` getTenantCount tenant count: ${noOfTenant?.count || 0}`);

      return noOfTenant?.count ? parseInt(noOfTenant.count) : 0;
    } catch(error) {
      this.logger.error(` getTenantCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async fetchApprovePendingKyc(tenantId: any, filters: ApprovePendingKYC) {
    try {
      this.logger.log(`fetchWalletMetricsForCategory running, query by tenant id: ${tenantId}`);
      // eslint-disable-next-line max-len
      // const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);
      const { startDate, endDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const presentTenantCount  = await getKYCData(tenantId, startDate, endDate);

        const { approvedUserForCustomer,
          pendingUserForCustomer,
          rejectedUserForCustomer,
          approvedUserForBusiness,
          pendingUserForBusiness,
          rejectedUserForBusiness,
          totalApprovedUser,
          totalPendingUser,
          totalRejectedUser } = presentTenantCount;

        const customerCount = {
          approved: approvedUserForCustomer,
          pending: pendingUserForCustomer,
          rejected: rejectedUserForCustomer
        };
        const businessCount = {
          approved: approvedUserForBusiness,
          pending: pendingUserForBusiness,
          rejected: rejectedUserForBusiness
        }

        const totalCount = {
          approved: totalApprovedUser,
          pending: totalPendingUser,
          rejected: totalRejectedUser
        }

        this.logger.debug(` ${filters?.dateFilterType} customerCount, businessCount, totalCount `,  customerCount, businessCount, totalCount);

        const kycPercentageForCustomer = await getApprovePendingPercentage(customerCount);
        const kycPercentageForBusiness = await getApprovePendingPercentage(businessCount);
        const kycPercentageForTotal = await getApprovePendingPercentage(totalCount);

        this.logger.debug(` ${filters?.dateFilterType} kycPercentage For Customer, Business, Total `,  kycPercentageForCustomer, kycPercentageForBusiness, kycPercentageForTotal);

        return { data: {
          kycPercentageForCustomer,
          kycPercentageForBusiness,
          kycPercentageForTotal
        } };
      }

      const presentTenantCount = await getKYCData(tenantId, startDate, endDate);

      const { approvedUserForCustomer,
        pendingUserForCustomer,
        rejectedUserForCustomer,
        approvedUserForBusiness,
        pendingUserForBusiness,
        rejectedUserForBusiness,
        totalApprovedUser,
        totalPendingUser,
        totalRejectedUser } = presentTenantCount;

      this.logger.debug(` ${filters?.dateFilterType} presentTenantCount `,  presentTenantCount);

      const customerCount = {
        approved: approvedUserForCustomer,
        pending: pendingUserForCustomer,
        rejected: rejectedUserForCustomer
      };
      const businessCount = {
        approved: approvedUserForBusiness,
        pending: pendingUserForBusiness,
        rejected: rejectedUserForBusiness
      }

      const totalCount = {
        approved: totalApprovedUser,
        pending: totalPendingUser,
        rejected: totalRejectedUser
      }

      this.logger.debug(` ${filters?.dateFilterType} customerCount, businessCount, totalCount `,  customerCount, businessCount, totalCount);

      const kycPercentageForCustomer = await getApprovePendingPercentage(customerCount);
      const kycPercentageForBusiness = await getApprovePendingPercentage(businessCount);
      const kycPercentageForTotal = await getApprovePendingPercentage(totalCount);

      this.logger.debug(` ${filters?.dateFilterType} kycPercentage For Customer, Business, Total `,  kycPercentageForCustomer, kycPercentageForBusiness, kycPercentageForTotal);

      return { data: {
        kycPercentageForCustomer,
        kycPercentageForBusiness,
        kycPercentageForTotal
      } };
    } catch (error) {
      this.logger.log(`catchError - Fetching approve pending KYC details via tenantId` + error);

      if (error.message.includes('select')) {
        const err =  error.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: err[1] } ] }
      }

      return {
        errors: [
          {
            message: error.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }

  /*Queries block started for user metrics data*/
  //business users metrics
  async getBusinessUserCount (tenantIdList: string[], startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getBusinessUserCount running for date between: ${startDate} to ${endDate}, ${tenantIdList}`);
      const [noOfBusinessUsers]: any = await BusinessUsers.query()
        .count('n.business_user_id')
        .alias('n')
        .where((builder) => {
          if(tenantIdList.length) {
            builder.whereIn('n.tenant_id', tenantIdList)
          }
        })
        .where((builder) => {
          if(startDate !== "0" && endDate !== "0") {
            builder.where(raw(`date(n.created_at) >= '${startDate}'`)).andWhere(raw(`date(n.created_at) <= '${endDate}'`))
          }
        })

      return noOfBusinessUsers?.count ? parseInt(noOfBusinessUsers.count) : 0;

    } catch(error) {
      this.logger.error(` getBusinessUserCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async getIndividualUserCount (tenantIdList: string[], startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getIndividualUserCount running for date between: ${startDate} to ${endDate}, ${tenantIdList}`);
      let query = `count(pri.*) as "count"
          from (select ca.account_status, tca.category from customer_accounts ca
          left join namespaces as n on n.customer_account_id = ca.customer_account_id
          left join tenant_customer_accounts as tca on tca.customer_account_id = ca.customer_account_id and tca.tenant_id = n.tenant_id
          join badge as b on b.badge_id = tca.badge_id
          where n.is_global = false and n.is_primary = true and n.is_deleted = false and tca.is_forgotten = false and date(n.created_at) >= '${startDate}' and date(n.created_at) <= '${endDate}'`;

      query = tenantIdList.length ? query + ` and tca.tenant_id = '${tenantIdList}') as pri` : query + ') as pri';

      const [noOfIndividualUsers] = await CustomerAccounts.knex().select(CustomerAccounts.knex().raw(query));

      return noOfIndividualUsers?.count ? parseInt(noOfIndividualUsers.count) : 0;

    } catch(error) {
      this.logger.error(` getIndividualUserCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async getIndividualWalletCount (tenantIdList: string[], startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getIndividualWalletCount running for date between: ${startDate} to ${endDate}, ${tenantIdList}`);

      const walletsData: any = await Namespace.query()
        .alias('n')
        .leftJoin('tenant_customer_accounts as tca', function (builder) {
          builder.on('tca.customer_account_id', '=', 'n.customer_account_id')
          builder.andOn('tca.tenant_id', '=', 'n.tenant_id')
        })
        .join('customer_accounts as ca', 'ca.customer_account_id', 'n.customer_account_id')
        .join('badge as b', 'b.badge_id', 'tca.badge_id')
        .select('ca.onboarding_status as wallet_status',
          Namespace.knex().raw("CASE WHEN tca.category IS NULL THEN b.badge_name ELSE tca.category_name END as category_name"),
        )
        .count('category_name as count')
        .where({ 'n.is_global': false, 'tca.is_forgotten': false })
        .where((builder) => {
          if(tenantIdList.length) {
            builder.whereIn('n.tenant_id', tenantIdList);
          }
        })
        .groupBy('wallet_status', 'category_name', 'category', 'badge_name') ;

      return walletsData.length ? walletsData.reduce((acc, currrentValue) => acc + Number(currrentValue.count), 0) : 0;

    } catch(error) {
      this.logger.error(` getIndividualWalletCount catch error: ${error?.message}`);

      return 0;
    }
  }

  async getBusinessWalletCount (tenantIdList: string[], startDate: string, endDate: string): Promise<number> {
    try {
      this.logger.log(` getBusinessWalletCount running for date between: ${startDate} to ${endDate}, ${tenantIdList}`);
      const [noOfBusinessUserWallets]: any = await BusinessUserNamespaces.query()
        .count('bn.business_user_namespace_id')
        .alias('bn')
        .leftJoin('business_users as bu', 'bn.business_user_id', 'bu.business_user_id')
        .leftJoin('business_user_namespace_mapper as bunm', 'bn.business_user_namespace_id', 'bunm.business_user_namespace_id')
        .where((builder) => {
          if(tenantIdList.length) {
            builder.whereIn('bu.tenant_id', tenantIdList)
          }
        })
        .where((builder) => {
          if(startDate !== "0" && endDate !== "0") {
            builder.where(raw(`date(bunm.created_at) >= '${startDate}'`)).andWhere(raw(`date(bunm.created_at) <= '${endDate}'`))
          }
        })

      return noOfBusinessUserWallets?.count ? parseInt(noOfBusinessUserWallets.count) : 0;

    } catch(error) {
      this.logger.error(` getBusinessWalletCount catch error: ${error?.message}`);

      return 0;
    }
  }

  //fetch metrics service
  async fetchUserMetrics(tenantId: any, filters: UserMetricsFilters) {
    try {
      const { startDate, endDate, pastStartDate, pastEndDate } = await validateAndCreateDateRange(filters?.dateFilterType, filters?.startDate, filters?.endDate);

      let businessUserPercentChange = 0,
        individualUserPercentChange = 0,
        businessWalletPercentChange = 0,
        individualWalletPercentChange = 0,
        tenants = [];

      const tenantDetails = await Tenants.query().select('tenant_name').modify((query)=>{
        if(tenantId){
          query.where({ tenantId })
        }
      }).first();

      if(tenantDetails && tenantDetails.tenantName && tenantDetails.tenantName !== UNIVERSAL_LEDGER)
        tenants = [tenantId];

      if(filters.dateFilterType === DateFilterType.TILL_DATE) {
        const businessUser = await this.getBusinessUserCount(tenants, "0", "0");
        const individualUser = await this.getIndividualUserCount(tenants, "0", "0");
        const businessWallet = await this.getBusinessWalletCount(tenants, "0", "0");
        const individualWallet = await this.getIndividualWalletCount(tenants, "0", "0");

        return { individualUserCount: individualUser, individualUserPercentChange, businessUserCount: businessUser, businessUserPercentChange, businessWalletCount: businessWallet, businessWalletPercentChange, individualWalletCount: individualWallet, individualWalletPercentChange };
      }

      if(filters?.dateFilterType === DateFilterType.CUSTOM) {
        const businessUser  = await this.getBusinessUserCount(tenants, startDate, endDate);
        const individualUser = await this.getIndividualUserCount(tenants, startDate, endDate);
        const businessWallet = await this.getBusinessWalletCount(tenants, startDate, endDate);
        const individualWallet = await this.getIndividualWalletCount(tenants, startDate, endDate);

        this.logger.log(` fetchBusinessMetrics businessUser :  ${businessUser}`)
        this.logger.log(` fetchBusinessMetrics percentChange :  ${businessUserPercentChange}`)

        return { individualUserCount: individualUser, individualUserPercentChange, businessUserCount: businessUser, businessUserPercentChange, businessWalletCount: businessWallet, businessWalletPercentChange, individualWalletCount: individualWallet, individualWalletPercentChange };
      }

      const [presentBusinessUsersCount, pastBusinessUserCount] = await Promise.all([
        this.getBusinessUserCount(tenants, startDate, endDate),
        this.getBusinessUserCount(tenants, pastStartDate, pastEndDate)
      ])
      const [presentIndividualUsersCount, pastIndividualUserCount] = await Promise.all([
        this.getIndividualUserCount(tenants, startDate, endDate),
        this.getIndividualUserCount(tenants, pastStartDate, pastEndDate)
      ])
      const [presentBusinessWalletsCount, pastBusinessWalletCount] = await Promise.all([
        this.getBusinessWalletCount(tenants, startDate, endDate),
        this.getBusinessWalletCount(tenants, pastStartDate, pastEndDate)
      ])
      const [presentIndividualWalletsCount, pastIndividualWalletCount] = await Promise.all([
        this.getIndividualWalletCount(tenants, startDate, endDate),
        this.getIndividualWalletCount(tenants, pastStartDate, pastEndDate)
      ])

      businessUserPercentChange = getPercentChangeWithZeroPastConsideration(presentBusinessUsersCount, pastBusinessUserCount);
      individualUserPercentChange = getPercentChangeWithZeroPastConsideration(presentIndividualUsersCount, pastIndividualUserCount);
      businessWalletPercentChange = getPercentChangeWithZeroPastConsideration(presentBusinessWalletsCount, pastBusinessWalletCount);
      individualWalletPercentChange = getPercentChangeWithZeroPastConsideration(presentIndividualWalletsCount, pastIndividualWalletCount);

      this.logger.log(` fetchTenantMetrics IndividualUserCount present :  ${presentIndividualUsersCount}`)
      this.logger.log(` fetchTenantMetrics IndividualUserCount past:  ${pastIndividualUserCount}`)
      this.logger.log(` fetchTenantMetrics percentChange :  ${individualUserPercentChange}`)
      this.logger.log(` fetchTenantMetrics BusinessUserCount present:  ${presentBusinessUsersCount}`)
      this.logger.log(` fetchTenantMetrics BusinessUserCount past:  ${pastBusinessUserCount}`)
      this.logger.log(` fetchTenantMetrics percentChange :  ${businessUserPercentChange}`)
      this.logger.log(` fetchTenantMetrics BusinessUserCount present:  ${presentBusinessWalletsCount}`)
      this.logger.log(` fetchTenantMetrics BusinessWalletCount past:  ${pastBusinessWalletCount}`)
      this.logger.log(` fetchTenantMetrics percentChange :  ${businessWalletPercentChange}`)
      this.logger.log(` fetchTenantMetrics IndividualUserCount present:  ${presentIndividualUsersCount}`)
      this.logger.log(` fetchTenantMetrics IndividualWalletCount past:  ${pastIndividualUserCount}`)
      this.logger.log(` fetchTenantMetrics percentChange :  ${individualWalletPercentChange}`)

      return {
        individualUserCount: presentIndividualUsersCount,
        individualUserPercentChange,
        businessUserCount: presentBusinessUsersCount,
        businessUserPercentChange,
        businessWalletCount: presentBusinessWalletsCount,
        businessWalletPercentChange,
        individualWalletCount: presentIndividualWalletsCount,
        individualWalletPercentChange
      };

    } catch(error) {
      this.logger.log(`catchError - Fetching tenant details via tenantId: ` + error);

      if (error.message.includes('select')) {
        const err =  error.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: err[1] } ] }
      }

      return {
        errors: [
          {
            message: error.message,
            type: ERROR_TYPE.CATCH,
          },
        ],
      };
    }
  }
}

const getCategoryTrxPercentage = async (offChainData, onChainData) => {
  let total = 0;
  const finalData = {};

  if(offChainData.length && onChainData.length) {
    offChainData.map((offChainVal) => {
      onChainData.map((onChainVal) => {
        if(offChainVal?.categoryName === onChainVal?.categoryName) {
          const sum = (parseInt(offChainVal?.count) || 0) + (parseInt(onChainVal?.count) || 0);

          finalData[offChainVal?.categoryName] = sum;
          total = total + sum;
        }
      })
    })

    return await calPerentage(finalData, total);
  }

  if(!offChainData.length && onChainData.length) {
    onChainData.map((onChainVal) => {
      const sum = parseInt(onChainVal?.count) || 0;

      finalData[onChainVal?.categoryName] = sum;
      total = total + sum;
    })

    return await calPerentage(finalData, total);
  }

  if(offChainData.length && !onChainData.length) {
    offChainData.map((offChainVal) => {
      const sum = parseInt(offChainVal?.count) || 0;

      finalData[offChainVal?.categoryName] = sum;
      total = total + sum;
    })

    return await calPerentage(finalData, total);
  }

  return [];
}

const getTrxByTransferTypePercentage = async (offChainData) => {
  let total = 0;
  const finalData = {};

  if(offChainData.length) {
    offChainData.map((offChainVal) => {
      const sum = parseInt(offChainVal?.count) || 0;
      const transferType = offChainVal?.transferType.replace('-', ' ');

      if(Object.keys(finalData).includes(transferType)) {
        finalData[transferType] = finalData[transferType] + sum;
      } else {
        finalData[transferType] = sum;
      }
      total = total + sum;
    })

    return await calPerentage(finalData, total);
  }

  return [];
}

/**
   * @param {object} data
   * @example data :  { silver: 95, bronze: 57, gold: 91 }
   * @param {number} total
   * @example total :  243
 */
const calPerentage = (data, total): any => {
  if(!total) {
    throw new Error(' Check your value for calculating percentage!');
  }
  const result = [];

  for(const key in data) {
    result.push({
      name: key,
      value: Math.round((((data[key] / total) * 100) + Number.EPSILON) * 100) / 100
      // value: Math.round((data[key] / total) * 100)
    })
  }

  return result;
}

const buildTrxVolResponse = async (offChainData, onChainData) => {

  if(offChainData.length && onChainData.length) {
    const [newOffChainData, newOnChainData] = await Promise.all([
      getNewDataObject(offChainData),
      getNewDataObject(onChainData),
    ]);

    return getTrxVolResponse(newOffChainData, newOnChainData);
  }

  if(offChainData.length && !onChainData.length) {
    const newOffChainData = getNewDataObject(offChainData);

    return getTrxVolResponse(newOffChainData);

  }

  if(!offChainData.length && onChainData.length) {
    const newOnChainData = getNewDataObject(onChainData);

    return getTrxVolResponse(newOnChainData);
  }

  return {
    title: "Transaction Volume",
    data: [],
    totalAverage: '0',
    totalAmount: '0',
    totalCount: '0'
  }
}

const getNewDataObject = (data) => {
  let newDataObject = {};

  data.map((val) => {
    const month = getMonthName(val?.month);

    if(newDataObject?.[month]) {
      newDataObject[month].amount = newDataObject?.[month].amount + val?.amount;
      newDataObject[month].count = newDataObject?.[month].count + val?.count;
      newDataObject[month].average = newDataObject?.[month].average + val?.average;
    }
    newDataObject = {
      ...newDataObject,
      [month]: {
        amount: val?.amount || '0',
        count: val?.count || '0',
        average: val?.average || '0'
      }
    }
  })

  return newDataObject || {};
}

const getTrxVolResponse = (mainData, data = undefined) => {
  const response = [];

  let totalCount  = 0, totalAmount = 0;

  for(const key in mainData) {
    const amount  = parseFloat(data?.[key]?.amount || '0') + parseFloat(mainData?.[key]?.amount || '0');
    const count  = parseFloat(data?.[key]?.count || '0') + parseFloat(mainData?.[key]?.count || '0');

    totalCount = totalCount + count;
    totalAmount = totalAmount + amount;
    response.push({
      month: key,
      amount: amount.toFixed(2),
      count: count.toFixed(2),
      average: (amount / count).toFixed(2)
    })
  }

  return {
    title: "Transaction Volume",
    data: response,
    totalAverage: (totalAmount / totalCount).toFixed(2),
    totalAmount: totalCount.toFixed(2),
    totalCount: totalCount.toFixed(2)
  }
}

const getCreditDebitResponse = (mainData, data = undefined) => {
  const response = [];

  let totalAmount = 0;

  for(const key in mainData) {
    const amount  = parseFloat(data?.[key]?.amount || '0') + parseFloat(mainData?.[key]?.amount || '0');

    totalAmount = totalAmount + amount;
    response.push({
      month: key,
      amount: amount.toFixed(2),
    })
  }

  return response;
}

const getKYCData = async (tenantId, startDate, endDate) => {
  const dataObj = {
    approvedUserForCustomer: 0,
    pendingUserForCustomer: 0,
    rejectedUserForCustomer: 0,
    approvedUserForBusiness: 0,
    pendingUserForBusiness: 0,
    rejectedUserForBusiness: 0,
    totalApprovedUser: 0,
    totalPendingUser: 0,
    totalRejectedUser: 0,
  };

  // const query = TenantCustomerAccounts.query()
  //   .alias('tca')
  //   .rightJoin('customer_accounts as ca', 'ca.customer_account_id', 'tca.customer_account_id')
  //   .select('ca.compliance_status')
  //   .count('ca.compliance_status as count')
  //   .where(raw(`date(ca.created_at) >= '${startDate}'`)).andWhere(raw(`date(ca.created_at) <= '${endDate}'`));

  // const defaultTenant: any = await Tenants.query().findOne('tenant_name', process.env.DEFAULT_TENANT);

  // if(defaultTenant?.tenantId != tenantId) {
  //   query.where('tca.tenant_id', tenantId)
  // }

  // const data = await query.groupBy('ca.compliance_status');

  const queryForCustomerData = CustomerAccounts.query()
    .select('compliance_status')
    .count('compliance_status as count')
    .whereRaw('date(created_at) >= ?', [startDate])
    .andWhereRaw('date(created_at) <= ?', [endDate]);    

  const defaultTenant: any = await Tenants.query().findOne('tenant_name', process.env.DEFAULT_TENANT);

  if(defaultTenant?.tenantId != tenantId) {
    queryForCustomerData.where('tenant_id', tenantId)
  }
  const customerData = await queryForCustomerData.groupBy('compliance_status');

  const queryForBusinessData: any = BusinessUsers.query()
    .select('compliance_status')
    .count('compliance_status as count')
    .whereRaw('date(created_at) >= ?', [startDate])
    .andWhereRaw('date(created_at) <= ?', [endDate]);

  if(defaultTenant?.tenantId != tenantId) {
    queryForBusinessData.where('tenant_id', tenantId)
  }
  const businessUserdata = await queryForBusinessData.groupBy('compliance_status');

  if(!customerData.length && !businessUserdata) {
    return dataObj;
  }

  if(customerData.length){
    for(const val of customerData) {
      if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'ACCEPTED') {
        dataObj.approvedUserForCustomer = dataObj.approvedUserForCustomer + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalApprovedUser = dataObj.totalApprovedUser + (val?.count ? parseInt(val?.count) : 0);
      } else if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'PENDING') {
        dataObj.pendingUserForCustomer = dataObj.pendingUserForCustomer + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalPendingUser = dataObj.totalPendingUser + (val?.count ? parseInt(val?.count) : 0);
      } else if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'REJECTED') {
        dataObj.rejectedUserForCustomer = dataObj.rejectedUserForCustomer + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalRejectedUser = dataObj.totalRejectedUser + (val?.count ? parseInt(val?.count) : 0);
      }
    }
  }

  if(businessUserdata.length){
    for(const val of businessUserdata) {
      if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'ACCEPTED') {
        dataObj.approvedUserForBusiness = dataObj.approvedUserForBusiness + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalApprovedUser = dataObj.totalApprovedUser + (val?.count ? parseInt(val?.count) : 0);
      } else if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'PENDING') {
        dataObj.pendingUserForBusiness = dataObj.pendingUserForBusiness + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalPendingUser = dataObj.totalPendingUser + (val?.count ? parseInt(val?.count) : 0);
      } else if (val?.complianceStatus && val?.complianceStatus.toUpperCase() == 'REJECTED') {
        dataObj.rejectedUserForBusiness = dataObj.rejectedUserForBusiness + (val?.count ? parseInt(val?.count) : 0),
        dataObj.totalRejectedUser = dataObj.totalRejectedUser + (val?.count ? parseInt(val?.count) : 0);
      }
    }
  }

  return dataObj;
}

const getApprovePendingPercentage = (data) => {
  const { approved, pending, rejected } = data;
  const total = approved + pending + rejected;

  const approvePercentageChange = parseFloat((((approved) / (total || 1) * 100)).toFixed(2));
  const pendingPercentageChange =  parseFloat((((pending) / (total || 1) * 100)).toFixed(2));
  const rejectedPercentageChange =  parseFloat((((rejected) / (total || 1) * 100)).toFixed(2));

  return {
    approved: approvePercentageChange,
    pending: pendingPercentageChange,
    rejected: rejectedPercentageChange
  }
}

const newSubscriptionCountResponse = (presentData: any, pastData: any = undefined): { subscriptionCount: number, percentageChange: number } => {

  let presentTotalSubscriptionCount = 0, pastTotalSubscriptionCount = 0;

  if(presentData && presentData.length) {

    if(presentData.length == 1) {
      presentTotalSubscriptionCount = presentData[0]?.subscriptionCount ? parseInt(presentData[0].subscriptionCount) : 0;
    }
    presentData.reduce((previousVal, nextVal) => {
      const valPre = previousVal?.subscriptionCount ? parseInt(previousVal.subscriptionCount) : 0;
      const valNext = nextVal?.subscriptionCount ? parseInt(nextVal.subscriptionCount) : 0;

      presentTotalSubscriptionCount = presentTotalSubscriptionCount + valPre + valNext;

      return presentTotalSubscriptionCount;
    })
  }

  if(pastData && pastData.length) {
    if(pastData.length == 1) {
      pastTotalSubscriptionCount = pastData[0]?.subscriptionCount ? parseInt(pastData[0].subscriptionCount) : 0;
    }
    pastData.reduce((previousVal, nextVal) => {
      const valPre = previousVal?.subscriptionCount ? parseInt(previousVal.subscriptionCount) : 0;
      const valNext = nextVal?.subscriptionCount ? parseInt(nextVal.subscriptionCount) : 0;

      pastTotalSubscriptionCount = pastTotalSubscriptionCount + valPre + valNext;

      return pastTotalSubscriptionCount;
    })
  }

  const percentageChange = parseFloat((((presentTotalSubscriptionCount - pastTotalSubscriptionCount) / (pastTotalSubscriptionCount || 1)) * 100).toFixed(2));

  return { subscriptionCount: presentTotalSubscriptionCount, percentageChange }
}