import { IsEnum, IsNotEmpty, IsOptional, IsString, ValidateIf } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { DateFilterType } from '../utils/util.service';

export class TenantFilters {
  @ApiPropertyOptional({ description: 'tenant compliance status', type: 'array', items: { type: 'string' },
    example: [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ], required: false })
  @IsOptional()
  readonly complianceStatus?: [string];

  @ApiPropertyOptional({ description: 'tenant onboarding status', type: 'array', items: { type: 'string' },
    example: [ 'PENDING', 'APPROVED', 'REJECTED', 'FAILED' ], required: false })
  @IsOptional()
  readonly onboardingStatus?: [string];

  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}

export class WalletFilters {
  @ApiPropertyOptional({ description: 'tenant id', example: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
    type: 'array', items: { type: 'string' } , required: false })
  @IsOptional()
  readonly tenantId?: [string];
}

export class TransactedAmountFilters {
  @ApiPropertyOptional({ description: 'no of days', example: 365, required: false })
  @IsOptional()
  readonly days?: number;
}

export class WalletPerTenantFilters {
  @ApiPropertyOptional({ description: 'tenant id', items: { type: 'string' },
    type: 'array' ,example: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ], required: false })
  @IsOptional()
  readonly tenantId?: [string];

  @ApiPropertyOptional({ description: 'no of days', example: 365, required: false })
  @IsOptional()
  readonly days?: number;
}

export class TotalAmountFilters {
  @ApiPropertyOptional({ description: 'tenant id', items: { type: 'string' },
    type: 'array', example: [ '4e6cb408-8a22-4edc-ba0f-e0f8071efc64' ], required: false })
  @IsOptional()
  readonly tenantId?: [string];
}
export class DateFilter {
  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases',
  })
  @IsEnum(DateFilterType)
    dateFilterType: string = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
    startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
    endDate: string;
}

export class WalletCountFiltersUled {
  @ApiPropertyOptional({ description: 'tenant id', example: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
    type: 'array', items: { type: 'string' } , required: false })
  @IsOptional()
  readonly tenantId?: [string];

  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}

export class WalletCategoryCount {
  // @ApiPropertyOptional({ description: 'tenant id', example: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
  //   type: 'array', items: { type: 'string' } , required: false })
  // @IsOptional()
  // readonly tenantId?: [string];

  @ApiPropertyOptional({ description: 'customer onboarding status', example: [ 'PENDING', 'APPROVED', 'ACCEPTED' ],
    type: 'array', items: { type: 'string' } , required: false })
  @IsOptional()
  readonly onboardingStatus?: [string];

  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}

export class UserMetricsFilters {
  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.TILL_DATE}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}

export class WalletCountFilters {
  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}

export class ApprovePendingKYC {
  @ApiProperty({
    enum: DateFilterType,
    example: `${DateFilterType.DAILY}, ${DateFilterType.WEEKLY}, ${DateFilterType.MONTHLY}, ${DateFilterType.CUSTOM}` ,
    description: 'date filter type, to get the data in that range and calculating % change on this bases: Default it will be set to daily',
  })
  @IsEnum(DateFilterType)
  readonly  dateFilterType: DateFilterType = DateFilterType.DAILY;

  @ApiProperty({
    type: 'string',
    description: 'start date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  startDate: string;

  @ApiProperty({
    type: 'string',
    description: 'end date for the custom date',
    example: 'yyyy-mm-dd' })
  @ValidateIf((method) => method.dateFilterType === DateFilterType.CUSTOM)
  @IsNotEmpty()
  @IsString()
  readonly  endDate: string;
}