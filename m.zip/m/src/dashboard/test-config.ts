import { ApiProperty } from '@nestjs/swagger';
import { ERROR_TYPE } from '../utils/constant';

export const HEADER_TENANT_ID = {
  headers: '76b5066f-5c7e-4231-b137-d8a6cffd77ec'
};

export const TENANT_COUNT_RESPONSE = {
  tenantCount: 23,
};

export const NO_TRANSACTED_AMOUNT_RESPONSE = {
  data: {
    totalTransactionAmount: 12247.15,
    day: '365',
  },
};

export class NO_TRANSACTED_AMOUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'object',
    description: 'number of transacted amount ',
    default: NO_TRANSACTED_AMOUNT_RESPONSE.data,
  })
    data: object;
}

export const NO_WALLET_USER_PER_TENANT_RESPONSE = {
  data: [
    {
      tenantName: 'NSE',
      walletUserCount: '3',
      tenantId: '75a9bf6a-a1f6-4314-8ebe-b791b473fe8b',
    },
    {
      tenantName: 'dow',
      walletUserCount: '1',
      tenantId: '1f58764e-a26b-420e-b786-d2a8412bd740',
    },
    {
      tenantName: 'MSV TECH INC',
      walletUserCount: '5',
      tenantId: '8d5bc6f2-0da3-4865-ae46-ceadefa16c82',
    },
    {
      tenantName: 'hdfc',
      walletUserCount: '2',
      tenantId: 'e913751b-f1c2-4b32-9306-6adf4bcc74e2',
    },
    {
      tenantName: 'kiginCo',
      walletUserCount: '8',
      tenantId: '04b62b97-b70b-4778-a5c0-2c550cd88ab0',
    },
    {
      tenantName: 'MKCO',
      walletUserCount: '7',
      tenantId: '6c25466e-369d-4a56-b083-864050c3240a',
    },
    {
      tenantName: 'WFH Wizards',
      walletUserCount: '97',
      tenantId: 'afb8720f-4b0f-4c4e-b4e0-c41f306aa161',
    },
    {
      tenantName: 'Htech',
      walletUserCount: '2',
      tenantId: 'dc7c06a2-2bf3-47c3-82ca-82bd372f149a',
    },
    {
      tenantName: 'universal ledger v0',
      walletUserCount: '2',
      tenantId: 'ca455941-3d8f-4148-92de-d4f43b102058',
    },
    {
      tenantName: 'UNS',
      walletUserCount: '1',
      tenantId: 'fb1cf97f-b001-448e-b87d-72e6af47bfd5',
    },
    {
      tenantName: 'ESS',
      walletUserCount: '5',
      tenantId: '418051d1-2aa1-4d69-8ad4-6fc6a427a38b',
    },
    {
      tenantName: 'Ztech',
      walletUserCount: '1',
      tenantId: '726c3a6b-5dc7-4a3c-a5ea-7d9ad80a0674',
    },
    {
      tenantName: 'ICICI',
      walletUserCount: '2',
      tenantId: 'af49eda5-3651-466b-8f4c-59545ccdeca2',
    },
  ],
};

export const TRANSACTION_COUNT_RESPONSE = {
  totalTransactionCount: 15,
  onChainTransactionCount: 15,
  offchainTransaction: 0,
};

export const SUBSCRIPTION_COUNT_RES = {
  data: [
    {
      tenantName: "Tech2023",
      subscriptionCount: "2",
      tenantId: "63954d45-b1b6-4c06-8eaf-1b6422d5d85d"
    }
  ]
}

export class TENANT_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'tenant count',
    default: 23,
  })
    tenantCount: 23;
}

export class WALLET_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'wallet count',
    default: 25,
  })
    tenantCount: number;
}
export class MINTED_COUNT_RESPONSE_DTO {
  @ApiProperty({
    description: 'minted count response',
    default: {
      "USBC": {
        "mintedTokens": 18073,
        "burntTokens": 93,
        "netTokens": 17980
      }
    },
  })
  data: object;
}

export class MINTED_COUNT_ERROR_RESPONSE_DTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;
}

const SUBSCRIPTION_COUNT_RESPONSE = {
  data: [
    {
      tenantName: 'MSV TECH INC',
      subscriptionCount: '3',
      tenantId: '8d5bc6f2-0da3-4865-ae46-ceadefa16c82',
    },
    {
      tenantName: 'hdfc',
      subscriptionCount: '3',
      tenantId: 'e913751b-f1c2-4b32-9306-6adf4bcc74e2',
    },
    {
      tenantName: 'kiginCo',
      subscriptionCount: '3',
      tenantId: '04b62b97-b70b-4778-a5c0-2c550cd88ab0',
    },
    {
      tenantName: 'MKCO',
      subscriptionCount: '3',
      tenantId: '6c25466e-369d-4a56-b083-864050c3240a',
    },
    {
      tenantName: 'ubs',
      subscriptionCount: '3',
      tenantId: 'b88476d9-5347-4104-96f0-1e948c6e2ac8',
    },
    {
      tenantName: 'Test_1',
      subscriptionCount: '3',
      tenantId: 'c1947028-b6ed-41d9-ac7d-60835bda5a03',
    },
    {
      tenantName: 'WFH Wizards',
      subscriptionCount: '1',
      tenantId: 'afb8720f-4b0f-4c4e-b4e0-c41f306aa161',
    },
    {
      tenantName: 'GSTECH',
      subscriptionCount: '3',
      tenantId: 'f51050d4-e815-4c8e-a448-0c65b0c9a2e8',
    },
    {
      tenantName: 'Htech',
      subscriptionCount: '3',
      tenantId: 'dc7c06a2-2bf3-47c3-82ca-82bd372f149a',
    },
    {
      tenantName: 'dgmclaren',
      subscriptionCount: '3',
      tenantId: '4123adb4-4df1-4b0e-8e80-d7b78e5097aa',
    },
    {
      tenantName: 'Test_2',
      subscriptionCount: '3',
      tenantId: 'd826c708-570f-4569-aa19-68c1aacbcb2d',
    },
    {
      tenantName: 'UNS',
      subscriptionCount: '3',
      tenantId: 'fb1cf97f-b001-448e-b87d-72e6af47bfd5',
    },
    {
      tenantName: 'XYZ',
      subscriptionCount: '3',
      tenantId: '299caf7d-6e50-4eae-bd46-9613ac3d7ae8',
    },
    {
      tenantName: 'ESS',
      subscriptionCount: '3',
      tenantId: '418051d1-2aa1-4d69-8ad4-6fc6a427a38b',
    },
    {
      tenantName: 'Test_3',
      subscriptionCount: '3',
      tenantId: '3d115924-f21a-4764-b4e6-dc68d664646f',
    },
    {
      tenantName: 'Ztech',
      subscriptionCount: '1',
      tenantId: '726c3a6b-5dc7-4a3c-a5ea-7d9ad80a0674',
    },
    {
      tenantName: 'CMKCO',
      subscriptionCount: '3',
      tenantId: '86edeae8-049b-4d2a-ab16-b2ca54aa9a7c',
    },
    {
      tenantName: 'ICICI',
      subscriptionCount: '3',
      tenantId: 'af49eda5-3651-466b-8f4c-59545ccdeca2',
    },
    {
      tenantName: 'Mclren Tech Co',
      subscriptionCount: '3',
      tenantId: '128375eb-0897-44c8-a2cb-3b1babfa7d5d',
    },
    {
      tenantName: 'Jhonny Depp',
      subscriptionCount: '3',
      tenantId: '68e0aa9c-f79f-4c0f-a023-5d36d8337c66',
    },
    {
      tenantName: 'Tenant Test Mclaren Co',
      subscriptionCount: '3',
      tenantId: '9ceadaf9-40c3-4dca-9597-d07f9a90f30e',
    },
    {
      tenantName: 'Sam13',
      subscriptionCount: '3',
      tenantId: '15a64ab5-08d3-4f2f-be34-279426f2ef16',
    },
    {
      tenantName: 'HSBC',
      subscriptionCount: '3',
      tenantId: 'aba976df-4e38-4c1c-934a-eb93184e8a25',
    },
    {
      tenantName: 'MSVCO',
      subscriptionCount: '3',
      tenantId: '2049be3e-6cac-4afa-98fb-ed46cc3faa0d',
    },
  ],
};

export class SUBSCRIPTION_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'object',
    description: 'total subscription count ',
    default: SUBSCRIPTION_COUNT_RESPONSE.data,
  })
    data: object;
}

export class NEW_SUBSCRIPTION_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'total subscription count of present filter',
    default: 21,
  })
    subscriptionCount: number;

  @ApiProperty({
    type: 'number',
    description: 'percentage change between filter time',
    default: 19.23,
  })
    percentageChange: number;
}

export class TRANSACTION_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'total transaction count',
    default: 25,
  })
    totalTransactionCount: number;

  @ApiProperty({
    type: 'number',
    description: 'total off chain transaction count',
    default: 1,
  })
    offChainTransaction: number;

  @ApiProperty({
    type: 'number',
    description: 'total on chain transaction count',
    default: 24,
  })
    onChainTransaction: number;
}
export class NO_WALLET_USER_PER_TENANT_RESPONSE_DTO {
  @ApiProperty({
    description: 'total wallet user count as per tenant',
    default: NO_WALLET_USER_PER_TENANT_RESPONSE.data,
  })
    data: [string];
}
export const WALLET_COUNT_RESPONSE = {
  walletCount: 23,
};

export const WALLET_REQUEST_PAYLOAD = {
  tenantId: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
};
export const WALLER_USER_PER_TENANT_REQUEST_PAYLOAD: any = {
  tenantId: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
  days: 7,
};

export const SUBSCRIPTION_COUNT_PER_TENANT_REQUEST_PAYLOAD: any = {
  tenantId: [ 'fed3d624-27e1-4de6-ae0d-5c3a067b4dfc' ],
};
export const NO_TRANSACTED_AMOUNT_FILTER: any = {
  days: '356',
};

export const TENANT_REQUEST_PAYLOAD: any = {
  tenantName: 'NSE',
  complianceStatus: [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ],
};

export const TOTAL_AMOUNT_ACROSS_WALLET_REQUEST_PAYLOAD: any = {
  tenantNamespace: [ 'WFHWizards.ul' ],
};

export const TOTAL_AMOUNT_ACROSS_WALLET_RES = {
  data: {
    totalAmount: 3444
  }
}

export const SUBSCRIPTION_COUNT_PAYLOAD: any = {
  tenantId: [ "63954d45-b1b6-4c06-8eaf-1b6422d5d85d" ]
}

export const CATCH_ERROR = {
  errors: [
    {
      type: "Catch",
      message: "shows the error message while API failed in execution"
    }
  ]
}
const GEO_DATA = {
  "country_list": [
    {
      "country": "es",
      "totalUser": 2
    },
    {
      "country": "ad",
      "totalUser": 2
    },
    {
      "country": "bo",
      "totalUser": 34
    },
    {
      "country": "USA",
      "totalUser": 2
    },
    {
      "country": "mx",
      "totalUser": 4
    },
    {
      "country": "us",
      "totalUser": 56
    }
  ]
}

export class GEO_OK_RESPONSE {
  @ApiProperty({
    type: 'object',
    description: 'number of users onboarded per country ',
    default: GEO_DATA.country_list,
  })
    country_list: object;
}

const CREDIT_DEBIT_DATA = {
  "debitTransactions": [
    {
      "month": "Feb",
      "amount": "51.00"
    },
    {
      "month": "May",
      "amount": "200.00"
    },
    {
      "month": "Mar",
      "amount": "23804.00"
    },
    {
      "month": "Apr",
      "amount": "48.00"
    }
  ],
  "creditTransactions": [
    {
      "month": "Feb",
      "amount": "29.00"
    },
    {
      "month": "Jul",
      "amount": "6444767.00"
    },
    {
      "month": "Apr",
      "amount": "16.00"
    },
    {
      "month": "Mar",
      "amount": "3.00"
    },
    {
      "month": "Jun",
      "amount": "8.00"
    }
  ]
}

export class CREDIT_DEBIT_OK_RESPONSE {
  @ApiProperty({
    type: 'object',
    description: 'amount transacted debit/ credit per month ',
    default: CREDIT_DEBIT_DATA.creditTransactions,
  })
    creditTransactions: object;

    @ApiProperty({
      type: 'object',
      description: 'amount transacted debit/ credit per month ',
      default: CREDIT_DEBIT_DATA.debitTransactions,
    })
      debitTransactions: object;
}

export class WALLET_CATEGORY_COUNT_RESPONSE {
  @ApiProperty({
    type: 'string',
    description: 'wallet category count',
    default: 25,
  })
    count: string;

  @ApiProperty({
    type: 'string',
    description: 'wallet category name',
    default: 25,
  })
    categoryName: string;

  @ApiProperty({
    type: 'string',
    description: 'wallet status',
    default: 25,
  })
    walletStatus: string;
}

export class WALLET_CATEGORY_COUNT_RESPONSE_DTO {
  @ApiProperty({ type: () =>  [WALLET_CATEGORY_COUNT_RESPONSE] })
    data: [WALLET_CATEGORY_COUNT_RESPONSE];
}

export class NEW_WALLET_CATEGORY_COUNT_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'category silver',
    default: 25,
  })
    silver: number;

  @ApiProperty({
    type: 'number',
    description: 'category bronze',
    default: 25,
  })
    bronze: number;

    @ApiProperty({
      type: 'number',
      description: 'category gold: Category list can increase based on the bata in database',
      default: 25,
    })
      gold: number;
}

export class KYC_RESPONSE_DTO {
  @ApiProperty({
    type: 'number',
    description: 'approved percent',
    default: 25,
  })
    approved: number;

  @ApiProperty({
    type: 'number',
    description: 'pending percent',
    default: 25,
  })
    pending: number;
}