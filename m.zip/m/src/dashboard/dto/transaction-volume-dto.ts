import { ApiProperty } from "@nestjs/swagger";
import { ERROR_MESSAGE, ERROR_TYPE } from "../../utils/constant";

export class VolumeData {
    @ApiProperty({
      type: 'string',
      description: 'month',
      default: 'Jul'
    })
      month: string;

    @ApiProperty({
      type: 'string',
      description: 'amount',
      default: '32.86'
    })
      amount: string;

    @ApiProperty({
      type: 'string',
      description: 'count',
      default: '32.86'
    })
      count: string;

    @ApiProperty({
      type: 'string',
      description: 'average',
      default: '32.86'
    })
      average: string;
}

export class TrxVolSuccessDTO {

    @ApiProperty({
      type: 'string',
      description: 'Transaction Volume',
      default: 'Transaction Volume'
    })
      title: string;

    @ApiProperty({ type: () => [VolumeData] })
      data: VolumeData

    @ApiProperty({
      type: 'string',
      description: 'Total Average',
      default: '32.86'
    })
      totalAverage: string;

    @ApiProperty({
      type: 'string',
      description: 'Total Amount',
      default: '32.86'
    })
      totalAmount: string;

    @ApiProperty({
      type: 'string',
      description: 'Total Count',
      default: '32.86'
    })
      totalCount: string;
}

export class TrxVolData {
    @ApiProperty({
      type: 'string',
      description: 'No data message',
      default: 'No data found',
    })
      message: string;

    @ApiProperty({
      type: 'string',
      description: 'No data type',
      default: 'No data',
    })
      type: string;
}

export class TrxVolDTO {
    @ApiProperty({
      type: () => [TrxVolData]
    })
      errors: TrxVolData;
}

export class TrxVolErrorDTO {
    @ApiProperty({
      type: 'string',
      description: 'Catch error message',
      default: [
        { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_DATA_FOUND },
        { type: ERROR_TYPE.CATCH, message: 'error[1]' },
        { type: ERROR_TYPE.CATCH, message: 'err.message' }
      ]
    })
      errors: string
}