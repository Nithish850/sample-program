import { ApiProperty } from "@nestjs/swagger";
import { ERROR_MESSAGE, ERROR_TYPE } from "../../utils/constant";

export class PercentageData {
    @ApiProperty({
      type: 'string',
      description: 'category',
      default: 'silver'
    })
      name: string;

    @ApiProperty({
      type: 'number',
      description: 'percentage of transaction',
      default: 32.86
    })
      value: number;
}

export class CategorTrxPercentageSuccessDTO {
    @ApiProperty({
      type: 'string',
      description: 'type of chart',
      default: 'circularChart'
    })
      type: string;

    @ApiProperty({
      type: 'string',
      description: 'Transaction based on category',
      default: 'Transaction based on category'
    })
      title: string;

    @ApiProperty({ type: () => [PercentageData] })
      data: PercentageData
}

export class NoCategoryTrxPercentageData {
    @ApiProperty({
      type: 'string',
      description: 'No data message',
      default: 'No data found',
    })
      message: string;

    @ApiProperty({
      type: 'string',
      description: 'No data type',
      default: 'No data',
    })
      type: string;
}

export class NoCategoryTrxPercentageDTO {
    @ApiProperty({
      type: () => [ NoCategoryTrxPercentageData ]
    })
      errors: NoCategoryTrxPercentageData;
}

export class CategoryTrxPercentageErrorDTO {
    @ApiProperty({
      type: 'string',
      description: 'Catch error message',
      default: [
        { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_DATA_FOUND },
        { type: ERROR_TYPE.CATCH, message: 'error[1]' },
        { type: ERROR_TYPE.CATCH, message: 'err.message' }
      ]
    })
      errors: string
}