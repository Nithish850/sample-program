import { ApiProperty } from "@nestjs/swagger";
import { ERROR_MESSAGE, ERROR_TYPE } from "../../utils/constant";

export class PercentageData {
    @ApiProperty({
      type: 'string',
      description: 'transaction method',
      default: 'ach'
    })
      name: string;

    @ApiProperty({
      type: 'number',
      description: 'percentage of transaction',
      default: 40
    })
      value: number;
}

export class TrxPercentageByTrxMethodSuccessDTO {
    @ApiProperty({
      type: 'string',
      description: 'type of chart',
      default: 'circularChart'
    })
      type: string;

    @ApiProperty({
      type: 'string',
      description: 'Transaction based on transaction method',
      default: 'Transaction based on transaction method'
    })
      title: string;

    @ApiProperty({ type: () => [PercentageData] })
      data: PercentageData
}

export class NoTrxByTrxMethodPercentageData {
    @ApiProperty({
      type: 'string',
      description: 'No data message',
      default: 'No data found',
    })
      message: string;

    @ApiProperty({
      type: 'string',
      description: 'No data type',
      default: 'No data',
    })
      type: string;
}

export class NoTrxByTrxMethodPercentageDTO {
    @ApiProperty({
      type: () => [ NoTrxByTrxMethodPercentageData ]
    })
      errors: NoTrxByTrxMethodPercentageData;
}

export class TrxByTrxMethodPercentageErrorDTO {
    @ApiProperty({
      type: 'string',
      description: 'Catch error message',
      default: [
        { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_DATA_FOUND },
        { type: ERROR_TYPE.CATCH, message: 'error[1]' },
        { type: ERROR_TYPE.CATCH, message: 'err.message' }
      ]
    })
      errors: string
}