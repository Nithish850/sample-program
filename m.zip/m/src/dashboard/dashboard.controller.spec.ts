import { Test } from '@nestjs/testing';
import { mockRequest, mockResponse } from 'jest-mock-req-res';

import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
import {
  TENANT_COUNT_RESPONSE,
  TENANT_REQUEST_PAYLOAD,
  WALLET_COUNT_RESPONSE,
  TRANSACTION_COUNT_RESPONSE,
  NO_WALLET_USER_PER_TENANT_RESPONSE,
  WALLER_USER_PER_TENANT_REQUEST_PAYLOAD,
  SUBSCRIPTION_COUNT_PER_TENANT_REQUEST_PAYLOAD,
  NO_TRANSACTED_AMOUNT_RESPONSE,
  TOTAL_AMOUNT_ACROSS_WALLET_RES,
  TOTAL_AMOUNT_ACROSS_WALLET_REQUEST_PAYLOAD,
  SUBSCRIPTION_COUNT_PAYLOAD,
  SUBSCRIPTION_COUNT_RES,
  NO_TRANSACTED_AMOUNT_FILTER,
  CATCH_ERROR,
  HEADER_TENANT_ID
} from './test-config';

const mockDashboardCustomerServiceSuccess = {
  fetchTenantMetrics: jest.fn(() => TENANT_COUNT_RESPONSE),
  fetchWalletMetrics: jest.fn(() => WALLET_COUNT_RESPONSE),
  fetchTransactionMetrics: jest.fn(() => TRANSACTION_COUNT_RESPONSE),
  fetchSubscriptionMetrics: jest.fn(() => SUBSCRIPTION_COUNT_RES),
  fetchWalletUsersPerTenantMetrics: jest.fn(() => NO_WALLET_USER_PER_TENANT_RESPONSE),
  fetchTransactedAmountMetrics: jest.fn(() => NO_TRANSACTED_AMOUNT_RESPONSE),
  fetchTotalAmountAcrossWalletMetrics: jest.fn(() => TOTAL_AMOUNT_ACROSS_WALLET_RES)
};

describe('Dashboard Controller /dashboard /success', () => {
  let dashboardController: DashboardController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ DashboardController ],
      providers: [ DashboardService ],
    })
      .overrideProvider(DashboardService)
      .useValue(mockDashboardCustomerServiceSuccess)
      .compile();

    dashboardController = moduleRef.get<DashboardController>(DashboardController);
  });
  describe('should be able to check controller success cases ', () => {
    const TENANT_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: TENANT_COUNT_RESPONSE,
    });

    const WALLET_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: WALLET_COUNT_RESPONSE,
    });

    const TRANSACTION_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: TRANSACTION_COUNT_RESPONSE,
    });

    const SUBSCRIPTION_COUNT_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: SUBSCRIPTION_COUNT_RES,
    });

    const TOTAL_TRANSACTION_AMOUNT_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: NO_TRANSACTED_AMOUNT_RESPONSE,
    });

    const WALLET_USER_PER_TENANT_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: NO_WALLET_USER_PER_TENANT_RESPONSE,
    });

    const TOTAL_AMOUNT_ACROSS_WALLET_RESPONSE = mockResponse({
      HttpStatus: 200,
      body: TOTAL_AMOUNT_ACROSS_WALLET_RES,
    });

    const REQUEST: any = mockRequest(HEADER_TENANT_ID);

    it('should be able to check if dashboard controller is defined or not', () => {
      expect(dashboardController).toBeDefined();
    });

    it('should check if we are able to fetch wallet count details successfully as a response', async () => {
      const res = await dashboardController.fetchTenantMetrics(TENANT_REQUEST_PAYLOAD, TENANT_RESPONSE);

      expect(res.body).toEqual(TENANT_COUNT_RESPONSE);
    });

    it('should check if we are able to fetch wallet count details successfully as a response', async () => {
      const res = await dashboardController.fetchWalletMetrics(TENANT_REQUEST_PAYLOAD, WALLET_RESPONSE, REQUEST);

      expect(res.body).toEqual(WALLET_COUNT_RESPONSE);
    });

    it('should check if we are able to fetch transaction count details successfully as a response', async () => {
      const res = await dashboardController.fetchTransactionMetrics(TRANSACTION_RESPONSE);

      expect(res.body).toEqual(TRANSACTION_COUNT_RESPONSE);
    });

    it('should check if we are able to fetch transaction count details successfully as a response', async () => {
      const res = await dashboardController.fetchSubscriptionMetrics(SUBSCRIPTION_COUNT_PAYLOAD, SUBSCRIPTION_COUNT_RESPONSE, REQUEST);

      expect(res.body).toEqual(SUBSCRIPTION_COUNT_RES);
    });

    it('should check if we are able to fetch total transaction amount as per tenant and within requested days successfully as a response', async () => {
      const res = await dashboardController.fetchTransactedAmountMetrics(NO_TRANSACTED_AMOUNT_FILTER, TOTAL_TRANSACTION_AMOUNT_RESPONSE);

      expect(res.body).toEqual(NO_TRANSACTED_AMOUNT_RESPONSE);
    });

    it('should check if we are able to fetch no of wallet user details as per tenant and within requested days successfully as a response', async () => {
      const res = await dashboardController.fetchWalletUsersPerTenantMetrics(WALLER_USER_PER_TENANT_REQUEST_PAYLOAD, WALLET_USER_PER_TENANT_RESPONSE);

      expect(res.body).toEqual(NO_WALLET_USER_PER_TENANT_RESPONSE);
    });

    it('should check if we are able to fetch no of subscription count per tenant successfully as a response', async () => {
      const res = await dashboardController.fetchWalletUsersPerTenantMetrics(SUBSCRIPTION_COUNT_PER_TENANT_REQUEST_PAYLOAD, WALLET_USER_PER_TENANT_RESPONSE);

      expect(res.body).toEqual(NO_WALLET_USER_PER_TENANT_RESPONSE);
    });

    it('should check if we are able to fetch no of token across all the wallet successfully as a response', async () => {
      const res = await dashboardController.fetchTotalAmountAcrossWalletMetrics(TOTAL_AMOUNT_ACROSS_WALLET_REQUEST_PAYLOAD, TOTAL_AMOUNT_ACROSS_WALLET_RESPONSE);

      expect(res.body).toEqual(TOTAL_AMOUNT_ACROSS_WALLET_RES);
    })
  });
});

const mockDashboardCustomerServiceCatchError = {
  fetchTenantMetrics: jest.fn(() => CATCH_ERROR),
  fetchWalletMetrics: jest.fn(() => CATCH_ERROR),
  fetchTransactionMetrics: jest.fn(() => CATCH_ERROR),
  fetchSubscriptionMetrics: jest.fn(() => CATCH_ERROR),
  fetchWalletUsersPerTenantMetrics: jest.fn(() => CATCH_ERROR),
  fetchTransactedAmountMetrics: jest.fn(() => CATCH_ERROR),
  fetchTotalAmountAcrossWalletMetrics: jest.fn(() => CATCH_ERROR)
};

describe('Dashboard Controller /dashboard /catch error', () => {
  let dashboardController: DashboardController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ DashboardController ],
      providers: [ DashboardService ],
    })
      .overrideProvider(DashboardService)
      .useValue(mockDashboardCustomerServiceCatchError)
      .compile();

    dashboardController = moduleRef.get<DashboardController>(DashboardController);
  });
  describe('should be able to check controller catch error cases ', () => {
    const TENANT_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const WALLET_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const TRANSACTION_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const SUBSCRIPTION_COUNT_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const TOTAL_TRANSACTION_AMOUNT_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const WALLET_USER_PER_TENANT_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const TOTAL_AMOUNT_ACROSS_WALLET_RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST: any = mockRequest(HEADER_TENANT_ID);

    it('should be able to check if dashboard controller is defined or not', () => {
      expect(dashboardController).toBeDefined();
    });

    it('should check if we are able to fetch wallet count details successfully as a response', async () => {
      const res = await dashboardController.fetchTenantMetrics(TENANT_REQUEST_PAYLOAD, TENANT_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch wallet count details successfully as a response', async () => {
      const res = await dashboardController.fetchWalletMetrics(TENANT_REQUEST_PAYLOAD, WALLET_RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch transaction count details successfully as a response', async () => {
      const res = await dashboardController.fetchTransactionMetrics(TRANSACTION_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch transaction count details successfully as a response', async () => {
      const res = await dashboardController.fetchSubscriptionMetrics(SUBSCRIPTION_COUNT_PAYLOAD, SUBSCRIPTION_COUNT_RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch total transaction amount as per tenant and within requested days successfully as a response', async () => {
      const res = await dashboardController.fetchTransactedAmountMetrics(NO_TRANSACTED_AMOUNT_FILTER, TOTAL_TRANSACTION_AMOUNT_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch no of wallet user details as per tenant and within requested days successfully as a response', async () => {
      const res = await dashboardController.fetchWalletUsersPerTenantMetrics(WALLER_USER_PER_TENANT_REQUEST_PAYLOAD, WALLET_USER_PER_TENANT_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch no of subscription count per tenant successfully as a response', async () => {
      const res = await dashboardController.fetchWalletUsersPerTenantMetrics(SUBSCRIPTION_COUNT_PER_TENANT_REQUEST_PAYLOAD, WALLET_USER_PER_TENANT_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if we are able to fetch no of token across all the wallet successfully as a response', async () => {
      const res = await dashboardController.fetchTotalAmountAcrossWalletMetrics(TOTAL_AMOUNT_ACROSS_WALLET_REQUEST_PAYLOAD, TOTAL_AMOUNT_ACROSS_WALLET_RESPONSE);

      expect(res.body).toEqual(CATCH_ERROR);
    })
  });
});
