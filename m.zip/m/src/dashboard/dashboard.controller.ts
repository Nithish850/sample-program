import { Response , Request } from 'express';
import { Controller, Get, HttpStatus, Logger, Query, Req, Res } from '@nestjs/common';
import { ApiBadRequestResponse, ApiHeader, ApiNotFoundResponse, ApiOkResponse, ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { KYCErrorDTO, TenantCountErrorDTO, TotalAmountAcrossWallet, TotalTransactedAmountErrorDTO, TransactionsCountErrorDTO, WalletCountErrorDTO } from '../console/dto/Activation';
import { DashboardService } from './dashboard.service';
import { ApiFilterQuery } from '../tenant/controller/api-filter-query';
import { ApprovePendingKYC, DateFilter, TenantFilters, TotalAmountFilters, TransactedAmountFilters, UserMetricsFilters, WalletCategoryCount, WalletCountFilters, WalletCountFiltersUled, WalletPerTenantFilters } from './filter-helper';
import { CREDIT_DEBIT_OK_RESPONSE, GEO_OK_RESPONSE, KYC_RESPONSE_DTO, MINTED_COUNT_ERROR_RESPONSE_DTO, MINTED_COUNT_RESPONSE_DTO, NEW_SUBSCRIPTION_COUNT_RESPONSE_DTO, NEW_WALLET_CATEGORY_COUNT_RESPONSE_DTO, NO_TRANSACTED_AMOUNT_RESPONSE_DTO, NO_WALLET_USER_PER_TENANT_RESPONSE_DTO,
  TENANT_COUNT_RESPONSE_DTO, TRANSACTION_COUNT_RESPONSE_DTO, WALLET_COUNT_RESPONSE_DTO } from './test-config';
import { ERROR_MESSAGE, ERROR_TYPE } from '../utils/constant';
import { CategorTrxPercentageSuccessDTO, CategoryTrxPercentageErrorDTO, NoCategoryTrxPercentageDTO } from './dto/category-transaction-percentage-dto';
import { TrxVolDTO, TrxVolErrorDTO, TrxVolSuccessDTO } from './dto/transaction-volume-dto';
import { NoTrxByTrxMethodPercentageDTO, TrxByTrxMethodPercentageErrorDTO, TrxPercentageByTrxMethodSuccessDTO } from './dto/offchain-trx-by-trx-method';
import { UserMetricsErrorDTO, UserMetricsResponseDTO } from 'src/tenant/dto/dashboard/user-metrics-response-dto';

@Controller()
@ApiTags('Dashboard')
export class DashboardController {
  private readonly logger = new Logger(DashboardController.name);

  constructor(private readonly dashboardService: DashboardService) {}

  @Get('/tenant-count')
  @ApiFilterQuery('filters', TenantFilters)
  @ApiOperation({ summary: 'API to get tenant metrics' })
  @ApiBadRequestResponse({
    description: 'Bad request response if tenant detail get failed',
    type: () => TenantCountErrorDTO,
    isArray: false,
  })
  @ApiOkResponse({
    description: 'Get tenant count success response ',
    type: () => TENANT_COUNT_RESPONSE_DTO,
  })
  async fetchTenantMetrics(@Query('filters') filters: TenantFilters, @Res() res: Response): Promise<any> {
    const response = await this.dashboardService.fetchTenantMetrics(filters);

    if (response && (response?.tenantCount || response?.tenantCount >= 0)) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/wallet-count')
  @ApiFilterQuery('filters', WalletCountFilters)
  @ApiOperation({ summary: 'API to get wallet metrics | Modifier: Guru' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: 'b9ee1c55-9838-45cd-84db-61c4c2f92216',
    required: true
  })
  @ApiOkResponse({
    description: 'Get wallet count success response ',
    type: () => WALLET_COUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => WalletCountErrorDTO,
    isArray: false,
  })
  async fetchWalletMetrics(@Query('filters') filters: WalletCountFilters, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchWalletMetrics(tenantId, filters);

    if (response && (response?.walletCount || response?.walletCount >= 0)) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/wallet-user-per-tenant')
  @ApiFilterQuery('filters', WalletPerTenantFilters)
  @ApiOperation({ summary: 'API to get wallet user count as per tenant metrics' })
  @ApiOkResponse({
    description: 'Get wallet user count as per tenant response ',
    type: () => NO_WALLET_USER_PER_TENANT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => WalletCountErrorDTO,
  })
  async fetchWalletUsersPerTenantMetrics(@Query('filters') filters: WalletPerTenantFilters, @Res() res: Response): Promise<any> {
    const response = await this.dashboardService.fetchWalletUsersPerTenantMetrics(filters);

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/transaction-count')
  @ApiOperation({ summary: 'API to get transaction metrics' })
  @ApiOkResponse({
    description: 'Get transaction count response ',
    type: () => TRANSACTION_COUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => TransactionsCountErrorDTO,
  })
  async fetchTransactionMetrics(@Res() res: Response): Promise<any> {
    const response = await this.dashboardService.fetchTransactionMetrics();

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response?.data);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/subscription-count')
  @ApiFilterQuery('filters', WalletCountFilters)
  @ApiOperation({ summary: 'API to get subscription count metrics' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: 'b9ee1c55-9838-45cd-84db-61c4c2f92216',
    required: true
  })
  @ApiOkResponse({
    description: 'Get subscription count response ',
    type: () => NEW_SUBSCRIPTION_COUNT_RESPONSE_DTO,
  })
  // @ApiOkResponse({
  //   description: 'Get subscription count response ',
  //   type: () => SUBSCRIPTION_COUNT_RESPONSE_DTO,
  // })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => WalletCountErrorDTO,
  })
  async fetchSubscriptionMetrics(@Query('filters') filters: WalletCountFilters, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchSubscriptionMetrics(tenantId, filters);

    if (response && !response?.errors) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/total-transacted-amount')
  @ApiFilterQuery('filters', TransactedAmountFilters)
  @ApiOperation({ summary: 'API to get total transacted amount' })
  @ApiOkResponse({
    description: 'Number of transacted amount response ',
    type: () => NO_TRANSACTED_AMOUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => TotalTransactedAmountErrorDTO,
  })
  async fetchTransactedAmountMetrics(@Query('filters') filters: TransactedAmountFilters, @Res() res: Response): Promise<any> {
    const response = await this.dashboardService.fetchTransactedAmountMetrics(filters);

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/total-amount-across-wallet')
  @ApiOperation({ summary: 'API to get total token/amount across all customers' })
  @ApiFilterQuery('filters', TotalAmountFilters)
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => TotalAmountAcrossWallet,
  })
  async fetchTotalAmountAcrossWalletMetrics(@Query('filters') filters: TotalAmountFilters,  @Res() res: Response): Promise<any> {
    const response = await this.dashboardService.fetchTotalAmountAcrossWalletMetrics(filters);

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/total-minted-token-count')
  @ApiOperation({ summary: 'API to get total minted count' })
  @ApiFilterQuery( 'filters', UserMetricsFilters)
  @ApiQuery({
    name: 'tenantName',
    description: 'Tenant Name',
    required: false,
    example: 'wizzit ltd'
  })
  @ApiHeader({
    name: 'tenant-id', 
    description: 'Tenant Id',
    example: 'e4c09d6f-0634-4ed3-9563-54e737a9418e',
    required: false,
  })
  @ApiOkResponse({
    description: 'Get wallet count success response ',
    type: () => MINTED_COUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => MINTED_COUNT_ERROR_RESPONSE_DTO,
    isArray: false,
  })
  async fetchTotalMintedToken(@Query('filters') filters: DateFilter,@Query('tenantName') tenantName: string, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers['tenant-id'];

    this.logger.debug(`Inside fetchTotalMintedToken:: [tenant-id]: ${tenantId}`);
    const response = await this.dashboardService.fetchTotalMintedToken(tenantId, filters, tenantName);

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/api-call-count')
  @ApiOperation({ summary: 'API to get API call count for tenant and UL' })
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant Id'
  })
  @ApiFilterQuery( 'filters', DateFilter)
  async getApiCount(@Query('filters') filters: DateFilter, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log('inside api-call-count:: ');
    const tenantId = req.headers['tenant-id'];

    this.logger.debug(`tenantId: ${tenantId}, filters: ${JSON.stringify(filters)}`);

    const response = await this.dashboardService.getApiCount(tenantId, filters);

    if (response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('transaction-percentage-category')
  @ApiOperation({ summary: 'API to get the successful transactions count as per category | Modifier: Guru' })
  @ApiOkResponse({
    description: 'It will fetch the total successful transactions based on category',
    type: () => CategorTrxPercentageSuccessDTO
  })
  @ApiNotFoundResponse({
    description: 'Error response when failed to fetch the total successful transactions based on category',
    type: () => NoCategoryTrxPercentageDTO
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if data fetching gets failed',
    type: () => CategoryTrxPercentageErrorDTO,
    isArray: false,
  })
  @ApiFilterQuery( 'filters', DateFilter)
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: '2b7bf392-c669-40fc-8b71-c87b0b314a60 ||  uled tenant: dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant id'
  })
  async getTrxPercentagePerCategoryForTenants(@Query('filters') filters: DateFilter, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log(`Inside getTrxPercentagePerCategoryForTenants: `);
    const tenantId = req.headers['tenant-id'];

    if(!tenantId) {
      return res.status(HttpStatus.BAD_REQUEST).send({
        errors: [{
          type: ERROR_TYPE.NO_VALUE,
          message: ERROR_MESSAGE.PROVIDE_VALID_TENANT_ID
        }]
      })
    }

    const response = await this.dashboardService.getTrxPercentagePerCategoryForTenants(tenantId, filters);

    if(response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if(response && response?.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

  @Get('/wallet-user-count-geo')
  @ApiOperation({ summary: 'API to get wallet user count for tenant and UL' })
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant Id'
  })
  @ApiOkResponse({
    description: 'Number of users onboarded per country response ',
    type: () => GEO_OK_RESPONSE,
  })
  async getUserCountBasedOnCountry(@Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log('inside wallet-user-count-geo:: ');
    const tenantId = req.headers['tenant-id'];

    this.logger.debug(`tenantId: ${tenantId}`);

    const response = await this.dashboardService.getUserCountBasedOnCountry(tenantId);

    if (response && response?.country_list) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('transaction-volume-per-month')
  // @Get('transaction-volume-per-month/:year')
  @ApiOperation({ summary: 'API to get the successful transactions volume for tenant per month' })
  @ApiOkResponse({
    description: 'It will fetch the total successful transactions volume for tenant per month',
    type: () => TrxVolSuccessDTO
  })
  @ApiNotFoundResponse({
    description: 'Error response when failed to fetch the successful transactions volume for tenant per month',
    type: () => TrxVolDTO
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if data fetching gets failed',
    type: () => TrxVolErrorDTO,
    isArray: false,
  })
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: '75018092-7186-4e67-908d-d25c446fd69f ||  uled tenant: dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant id'
  })
  // @ApiParam({
  //   name: 'year',
  //   description: 'year for which transaction volume will be shown',
  //   required: true,
  // })
  async getTrxVolForTenantsPerMonth(@Res() res: Response, @Req() req: Request): Promise<any> {
  // async getTrxVolForTenantsPerMonth(@Param('year') year: string, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log(`Inside getTrxVolForTenantsPerMonth: `);
    const tenantId = req.headers['tenant-id'];

    // Uncomment when year as parameter needs to be added
    const year = new Date().getFullYear();

    if(!tenantId) {
      return res.status(HttpStatus.BAD_REQUEST).send({
        errors: [{
          type: ERROR_TYPE.NO_VALUE,
          message: ERROR_MESSAGE.PROVIDE_VALID_TENANT_ID
        }]
      })
    }

    const response = await this.dashboardService.getTrxVolForTenantsPerMonth(tenantId, year);

    if(response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if(response && response?.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

  @Get('/debit-credit-transaction')
  @ApiOperation({ summary: 'API to get debit and credit transaction for tenant and UL' })
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant Id'
  })
  @ApiOkResponse({
    description: 'Number of debit credit transactions response ',
    type: () => CREDIT_DEBIT_OK_RESPONSE,
  })
  async getDebitCreditTransactions(@Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log('inside debit-credit-transaction:: ');
    const tenantId = req.headers['tenant-id'];

    this.logger.debug(`tenantId: ${tenantId}`);

    const response = await this.dashboardService.getDebitCreditTransactions(tenantId);

    if (response && response?.creditTransactions) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * Tenant Admin related  starts from here: -----------------------------------
   */

  @Get('/wallet-count-admin')
  @ApiFilterQuery('filters', WalletCountFiltersUled)
  @ApiOperation({ summary: 'API to get wallet metrics for uled admin, they can query filter other tenants by their tenant ids' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: '51537e62-a960-430d-b726-32bba26b9ff4',
    required: true
  })
  @ApiOkResponse({
    description: 'Get wallet count success response ',
    type: () => WALLET_COUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => WalletCountErrorDTO,
    isArray: false,
  })
  async fetchWalletMetricsForUledAdmin(@Query('filters') filters: WalletCountFiltersUled, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchWalletMetricsForUledAdmin(tenantId, filters);

    if (response && (response?.walletCount || response?.walletCount >= 0)) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/category/wallet-user-count')
  @ApiFilterQuery('filters', WalletCategoryCount)
  @ApiOperation({ summary: 'API to get wallet category metrics for uled admin based on category (bronze, silver), they can query filter by date, onboarding/wallet status | Modifier: Guru' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: 'b9ee1c55-9838-45cd-84db-61c4c2f92216',
    required: true
  })
  @ApiOkResponse({
    description: 'Get wallet category count success response ',
    type: () => NEW_WALLET_CATEGORY_COUNT_RESPONSE_DTO,
  })
  // @ApiOkResponse({
  //   description: 'Get wallet category count success response ',
  //   type: () => WALLET_CATEGORY_COUNT_RESPONSE_DTO,
  // })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet category detail get failed',
    type: () => WalletCountErrorDTO,
    isArray: false,
  })
  async fetchWalletMetricsForCategory(@Query('filters') filters: WalletCategoryCount, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchWalletMetricsForCategory(tenantId, filters);

    if (response && !response?.errors) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/subscription-count-admin')
  @ApiFilterQuery('filters', WalletCountFiltersUled)
  @ApiOperation({ summary: 'API to get subscription count metrics for uled admin, they can query filter other tenants by their tenant ids' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: '51537e62-a960-430d-b726-32bba26b9ff4',
    required: true
  })
  // @ApiOkResponse({
  //   description: 'Get subscription count success response ',
  //   type: () => WALLET_COUNT_RESPONSE_DTO,
  // })
  @ApiOkResponse({
    description: 'Get subscription count response ',
    type: () => NEW_SUBSCRIPTION_COUNT_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if wallet detail get failed',
    type: () => WalletCountErrorDTO,
    isArray: false,
  })
  async fetchSubscriptionMetricsForUledAdmin(@Query('filters') filters: WalletCountFiltersUled, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchSubscriptionMetricsForUledAdmin(tenantId, filters);

    if (response && !response?.errors) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('/approved-pending-kyc')
  @ApiFilterQuery('filters', ApprovePendingKYC)
  @ApiOperation({ summary: 'API to get KYC approve and pending status, for custom date it will directly give the count instead of percentage' })
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: '51537e62-a960-430d-b726-32bba26b9ff4',
    required: true
  })
  @ApiOkResponse({
    description: 'Get KYC approve and pending status success response ',
    type: () => KYC_RESPONSE_DTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if KYC approve and pending status detail get failed',
    type: () => KYCErrorDTO,
    isArray: false,
  })
  async fetchApprovePendingKyc(@Query('filters') filters: ApprovePendingKYC, @Res() res: Response, @Req() req: Request): Promise<any> {
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchApprovePendingKyc(tenantId, filters);

    if (response && response?.data ) {
      return res.status(HttpStatus.OK).send(response?.data);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  @Get('offchain-transaction-by-transaction-method')
  @ApiOperation({ summary: 'API to get the successful offchain transactions as per transaction category' })
  @ApiOkResponse({
    description: 'It will fetch the total successful transactions based on category',
    type: () => TrxPercentageByTrxMethodSuccessDTO
  })
  @ApiNotFoundResponse({
    description: 'Error response when failed to fetch the total successful transactions based on category',
    type: () => NoTrxByTrxMethodPercentageDTO
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if data fetching gets failed',
    type: () => TrxByTrxMethodPercentageErrorDTO,
    isArray: false,
  })
  @ApiFilterQuery( 'filters', DateFilter)
  @ApiHeader({
    name: 'tenant-id',
    required: true,
    example: '2b7bf392-c669-40fc-8b71-c87b0b314a60 ||  uled tenant: dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    description: 'Tenant id'
  })
  async getOffchainTrxByTransactionMethod(@Query('filters') filters: DateFilter, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log(`Inside getTrxPercentagePerCategoryForTenants: `);
    const tenantId = req.headers['tenant-id'];

    if(!tenantId) {
      return res.status(HttpStatus.BAD_REQUEST).send({
        errors: [{
          type: ERROR_TYPE.NO_VALUE,
          message: ERROR_MESSAGE.PROVIDE_VALID_TENANT_ID
        }]
      })
    }

    const response = await this.dashboardService.getOffchainTrxByTransactionMethod(tenantId, filters);

    if(response && response?.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if(response && response?.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

  /* onboard business user
   * @example Create business user onboard request
   * @param {BusinessUserOnboardDTO} payload
   * @returns Returns an object with updated details
   */
  @Get('/user-metrics')
  @ApiFilterQuery('filters', UserMetricsFilters)
  @ApiHeader({
    name: 'tenant-id',
    description: 'tenant-id',
    example: 'b9ee1c55-9838-45cd-84db-61c4c2f92216',
    required: false
  })
  @ApiHeader({
    name: 'api-key',
    description: 'api key',
    example: '76b5066f5c7e4231b137d8a6cffd77ec',
    required: false
  })
  @ApiOperation({ summary: 'API to get user metrics | Author : Ekamjit Singh' })
  @ApiBadRequestResponse({
    description: 'Bad request response if business user count detail get failed',
    type: () => UserMetricsErrorDTO,
    isArray: false,
  })
  @ApiOkResponse({
    description: 'Get business user count success response ',
    type: () => UserMetricsResponseDTO,
  })
  async getBusinessUsersCount(
    @Query('filters') filters: UserMetricsFilters, @Res() res: Response, @Req() req: Request
  ): Promise<any> {
    this.logger.log(`inside dashboard business user count controller :: {start}`);
    const tenantId = req.headers["tenant-id"];
    const response = await this.dashboardService.fetchUserMetrics(tenantId, filters);

    if (response && (response?.businessUserCount || response?.businessUserCount >= 0)) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }
}
