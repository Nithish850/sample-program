/* eslint-disable @typescript-eslint/no-var-requires */

import { Module } from '@nestjs/common';
/**
 * Import path from path
 */
const path = require('path');

import { DatabaseModule } from './db/database.module';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { getEnvPath } from './common/helper/env.helper';
import { RouterModule } from '@nestjs/core/router';
import { ConsoleModule } from './console/console.module';
import { TenantModule } from './tenant/tenant.module';
import { RoleModule } from './role/role.module';
import { OffchainTransactionModule } from './offchain-transaction/offchain-transaction.module';
import { TransactionModule } from './transaction/transaction.module';
import { WebhookModule } from './webhook/webhook.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { TenantWalletModule } from './tennat-wallet/tenant-wallet.module';
import { ReportsModule } from './reports/reports.module';
import { SchedulerModule } from './scheduler/scheduler.module';
import { ConsentModule } from './consent/consent.module';
import { LogsModule } from './log/logs.module';
import { TokenManagementModule } from './token-management/token-management.module';
import { CountryStateCityModule } from './country-state-city/country-state-city.module';
import { RulesModule } from './rules/rules.module';
import { DigitalWalletModule } from './digital-wallet/digital-wallet.module';
import { MigrationModule } from './migration/migration.module';

/**
 * Variable to define the path to env files
 */
const dirPath = path.join(__dirname, '../src/common/envs');
/**
 * Variable to load env file path
 */
const envFilePath: string = getEnvPath(dirPath);

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath,
    }),
    ScheduleModule.forRoot(),
    RouterModule.register([
      {
        path: 'console',
        module: ConsoleModule,
      },
      {
        path: 'tenant',
        module: TenantModule,
      },
      {
        path: 'role',
        module: RoleModule,
      },
      {
        path: 'offchainTransaction',
        module: OffchainTransactionModule,
      },
      {
        path: 'transaction',
        module: TransactionModule,
      },
      {
        path: 'dashboard',
        module: DashboardModule,
      },
      {
        path: 'tenant-wallet',
        module: TenantWalletModule,
      },
      {
        path: 'reports',
        module: ReportsModule,
      },
      {
        path: 'consent',
        module: ConsentModule,
      },
      {
        path: 'logs',
        module: LogsModule,
      },
      {
        path: 'tokenManagement',
        module: TokenManagementModule,
      },
      {
        path: 'places',
        module: CountryStateCityModule,
      },
      {
        path: 'migration',
        module: MigrationModule,
      },
    ]),
    DatabaseModule,
    ConsoleModule,
    CountryStateCityModule,
    TenantModule,
    RoleModule,
    OffchainTransactionModule,
    TransactionModule,
    TenantWalletModule,
    WebhookModule,
    DashboardModule,
    TenantWalletModule,
    ReportsModule,
    SchedulerModule,
    ConsentModule,
    LogsModule,
    TokenManagementModule,
    RulesModule,
    DigitalWalletModule,
    MigrationModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
