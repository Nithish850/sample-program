import { Injectable, Logger } from '@nestjs/common';
import {
  Country,
  State,
  City,
  IState,
  ICountry,
  ICity,
} from 'country-state-city';

@Injectable()
export class CountryStateCityService {
  private readonly logger = new Logger(CountryStateCityService.name);

  getCountryStateAndCities(
    countryCode: Array<string>,
    stateCode: Array<string>,
    cityName: string,
  ): any {
    this.logger.log( 'inside getCountryStateAndCities');

    if (countryCode && stateCode && cityName) {

      const cities = this.getCitiesOfMultipleStates(countryCode, stateCode);

      const currentCity = cities.find(
        ({ name }) => name.toLowerCase() === cityName.toLowerCase(),
      ) ;

      return currentCity;

    } else if (countryCode && stateCode) {

      const cities = this.getCitiesOfMultipleStates(countryCode , stateCode)

      return cities;

    } else if (countryCode) {
      const response = countryCode.reduce((allStates, currentCountryCode) => {
        const currentStates = this.getAllStates(currentCountryCode);

        return allStates.concat(currentStates);
      }, []);

      return response;

    } else {

      return this.getAllCountries();

    }
  }

  getCitiesOfMultipleStates(countryCode:Array<string> , stateCode : Array<string>) : any {
    const data = [];

    for (const currentCountryCode of countryCode) {
      const response = stateCode.reduce((allCities, currentStateCode) => {
        const currentCities = this.getAllCities(currentCountryCode, currentStateCode );

        return allCities.concat(currentCities);
      }, []);

      data.push(...response);
    }

    return data;
  }

  getAllCountries(): ICountry[] {
    const countries = Country.getAllCountries();

    return countries;
  }

  getAllStates(countryCode: string): IState[] {
    const states = State.getStatesOfCountry(countryCode);

    return states;
  }

  getAllCities(countryCode: string, stateCode: string): ICity[] {
    const cities = City.getCitiesOfState(countryCode, stateCode);

    return cities;
  }
}
