import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString } from 'class-validator';
import { ICountry } from 'country-state-city';

export class CountryStateCityResponseDTO {
  @ApiProperty({
    type: String,
    default: 'Data fetched successfully',
  })
    message: string;

  @ApiProperty({
    type: Array,
    default: [
      {
        name: 'India',
        isoCode: 'IN',
        flag: '🇮🇳',
        phonecode: '91',
        currency: 'INR',
        latitude: '20.00000000',
        longitude: '77.00000000',
        timezones: [
          {
            zoneName: 'Asia/Kolkata',
            gmtOffset: 19800,
            gmtOffsetName: 'UTC+05:30',
            abbreviation: 'IST',
            tzName: 'Indian Standard Time',
          },
        ],
      },
    ],
  })
    data: ICountry[];
}

export class CountryStateCityDTO {
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @ApiProperty({
    type: Array,
    description: 'country codes array',
    required: false,
    example: ['IN','PK']
  })
    countryCode: string[];

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @ApiProperty({
    type: Array,
    description: 'state codes array',
    required: false,
    example: [ 'PB','DL' ]
  })
    stateCode: string[];

  @IsOptional()
  @IsString()
  @ApiProperty({
    type: String,
    description: 'name of city',
    required: false,
    example: 'amritsar'
  })
    cityName: string;
}

export class ErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'error message',
    default: [
      {
        type: 'something went wrong',
        message: 'shows the error message while API failed in execution',
      },
    ],
  })
    errors: string;
}
