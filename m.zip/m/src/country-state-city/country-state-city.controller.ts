import {
  Body,
  Controller,
  HttpStatus,
  Logger,
  Post,
  Res,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBody,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { Response } from 'express';
import { CountryStateCityService } from './country-state-city.service';

import { CountryStateCityDTO, CountryStateCityResponseDTO, ErrorDTO } from './dto/country-state-city.dto';

@Controller()
@ApiTags('places')
export class CountryStateCityController {
  private readonly logger = new Logger(CountryStateCityController.name);

  constructor(
    private readonly countryStateCityService: CountryStateCityService,
  ) {}

  @Post()
 @ApiBody({ type: CountryStateCityDTO })
  @ApiOkResponse({
    description: 'will fetch all cities data',
    isArray: false,
    type: CountryStateCityResponseDTO,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if getAllCities get failed',
    isArray: false,
    type: ErrorDTO
  })
  @ApiOperation({ summary: 'Get data of country state and cities | Author : Ekamjit Singh' })
  getCountriesStateAndCities(
    @Body() body : CountryStateCityDTO,
    @Res()  res: Response,
  ): any {
    this.logger.log(`inside getAllCities controller`);
    const { countryCode , stateCode, cityName } = body
    const response = this.countryStateCityService.getCountryStateAndCities(
      countryCode,
      stateCode,
      cityName
    );

    if(!response  || response.length===0){
      return res.status(HttpStatus.NOT_FOUND).json({
        message: 'No data found',
        data: [],
      });
    }

    return res.status(HttpStatus.OK).json({
      message: 'Data fetched successfully',
      data: response,
    });
  }
}
