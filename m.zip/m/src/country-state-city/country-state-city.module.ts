import { Module } from '@nestjs/common';
import { CountryStateCityService } from './country-state-city.service';
import { CountryStateCityController } from './country-state-city.controller';

@Module({
  controllers: [CountryStateCityController],
  providers: [CountryStateCityService]
})
export class CountryStateCityModule {}
