const date = new Date();
const year = date.toLocaleString("default", { year: "numeric" });
const month = date.toLocaleString("default", { month: "2-digit" });
const day = date.toLocaleString("default", { day: "2-digit" });

// Generate yyyy-mm-dd date string
const start_date = `${year}-${month}-${day}`;

enum RuleName {
  'tier0' = 'tenant',
  'tier1'= 'bronze',
  'tier2'= 'silver',
  'tier3'='silver-plus'
}
export const defaultTenant = [
  {
    tenant_name: 'universal ledger',
    domain: 'ul-ledger',
    start_date,
    end_date: '2099-12-31',
    compliance_status: 'ACCEPTED',
    account_status: 'ACTIVE',
    onboarding_status: 'APPROVED'
  }
];

export const defaultUser = (tenant_id: string): any => [ {
  user_name: 'ul-default',
  email: 'default.user@ul.com',
  login_id: 'ulDefaultUser',
  tenant_id: tenant_id,
} ]

export const defaultAdminRoles = (tenant_id: string): any => [ {
  role_name: 'UL_ADMIN',
  tenant_id
} ]

export const defaultAdminUserRoles = (tenant_id: string, user_id: string, role_id: string): any => [ {
  role_id,
  tenant_id,
  user_id
} ]

export const createDefaultAttributes = (tenant_id: string, attributeData): any => {
  attributeData['tenant_id'] = tenant_id;

  return [ attributeData ]
}

export const createRuleConditions = (attribute_id: string, tenant_id: string, attribute_value: string, operator: string): any => [ {
  attribute_id,
  tenant_id,
  attribute_value,
  operator
} ]

export const createDefaultRule = (rule_json, rule_name: string, rule_group: string, tenant_id: string, user_id: string): any => [ {
  rule_name: RuleName[rule_name],
  rule_group,
  rule_description: `Default ${rule_group} ${rule_name} rule creation and mapping it to tenant ${tenant_id}`,
  rule_json,
  tenant_id,
  created_by: user_id,
  is_default_rule: true,
} ]

export const createDefaultTenantRuleMapping = (rule_id: string, rule_slug: string, rule_group: string, tenant_id: string, created_by: string, rule_version = 0): any => [ {
  rule_id,
  rule_slug,
  rule_group,
  start_date,
  end_date: '2099-12-31',
  tenant_id,
  rule_version: rule_version,
  is_default_rule: true,
  created_by,
  status: 'approved'
} ]

export const createDefaultDecisionTree = (decision_name: string, rule_id: string, tenant_id: string, decision_type: string, parent_decision_id: string): any => [ {
  decision_name,
  rule_id,
  tenant_id,
  decision_type: decision_type,
  parent_decision_id,
  message: 'Validated successfully',
  params: {
    message: 'Validated successfully'
  },
  editable: false
} ]

export const createRulesDecisionsConditions = (decision_id: string, condition_id: string, tenant_id: string, created_by: string): any => [ { decision_id, condition_id, tenant_id, created_by } ]