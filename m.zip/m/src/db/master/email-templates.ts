/* eslint-disable max-len */
export const emailTemplates = [
  {
    template_name: 'addWallet',
    subject: 'Notification For Additional Wallet Creation',
    text: '',
    html: 'Dear <%=full_name%>,<br>Wallet user <b><%=primary_wallet_namespace%></b> has created a new secondary wallet.<br><br>Secondary wallet Details : <br><br>Namespace : <%=secondary_namespace%>,<br>Created on : <%=time%><br>Category : <%=category%> <br><br>For support please write to <%=support_email%><br><br>Best Regards<br>UL Platform Admin'
  },
  {
    template_name: 'CategoryUpdate',
    subject: 'Category Update',
    text: 'Hi, This email is to notify about the user wallet category upgrade. Thanks!',
    html: 'Dear <%=namespace%>,<br>Wallet user <%=full_name%>, <%=cus_email%> has been upgraded to <%=new_category%> from <%=old_catgory%> on - <%=date%>, <%=time%>.<br>For support please write to <%=support_email%><br><br>Best Regards<br>UL Platform Admin'
  },
  {
    template_name: 'ComplianceStatus',
    subject: 'Compliance Status',
    text: 'Hi, This email is to let you know the modified Compliance Status. Thanks!',
    html: 'Hi, <br><br>The compliance status for the <%=wallet_user_name%> with <%=namespace%> has been changed from <%=pre_value%> to <%=new_value%>.  <br><br><br><br> <strong>Best Wishes, <br> The Universal Ledger Team</strong></p>'
  },
  {
    template_name: 'OnboardingActivationCode',
    subject: 'Universal Ledger Activation Code',
    text: 'Hi, This email is to let you know the Universal Ledger Activation Code. Thanks!',
    html: 'Hi, <br> Thank you for your interest to use our application. Use the unique activation code <%=activationCode%> during the onboarding.  <br><br><br><br> <strong>Best Wishes, <br> The Universal Ledger Team</strong></p>'
  },
  {
    template_name: 'PrescreeningComplianceCheck',
    subject: 'Reminder for compliance check',
    text: 'Hi, This email is a reminder for compliance check. Thanks!',
    html: 'Hi, <br><br> There is a new request for tenant pre-screening.<br>Please use the link below to review.<br> <%=link%><br><br>Best Regards<br> Team UL</p>'
  },
  {
    template_name: 'PrescreeningStatus',
    subject: 'Prescreening Status',
    text: 'Hi, This email is to let you know the status of your Pre screening status. Thanks!',
    html: 'Hi, <br><br> Pre-screening for <%=tenantName%> has been completed.<br>The status is: <%=status%>. <br><br> <strong>Regards</strong></p>'
  }
]