export const getRoleAndEntityFlagsUL = (roleName, entityName): any => {

  const flags = [
    // UL_ADMIN
    {
      role: 'UL_ADMIN',
      entity: 'Prescreening',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },

    // UL_USER_ADMINISTRATIVE
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Tenant Management',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'User Management',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Compliance Reports',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_USER_ADMINISTRATIVE',
      entity: 'Prescreening',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },

    // UL_READ_ONLY
    {
      role: 'UL_READ_ONLY',
      entity: 'Prescreening',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },

    //UL_COMPLIANCE
    {
      role: 'UL_COMPLIANCE',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Tenant Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'User Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Compliance Reports',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_COMPLIANCE',
      entity: 'Prescreening',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },

    //UL_MARKETING
    {
      role: 'UL_MARKETING',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Tenant Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'User Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Compliance Reports',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'UL_MARKETING',
      entity: 'Prescreening',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
  ]

  return flags.find((item) => {
    if(item.role === roleName && item.entity === entityName){
      return item.flag;
    }
  });
}