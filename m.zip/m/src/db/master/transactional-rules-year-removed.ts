export const transfer_tier1_default_rule = {
  "name": "transfer-tier1",
  "decisions": [
    {
      "event": {
        "type": "transfer-tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      },
      "conditions": {
        "all": [
          {
            "fact": "maxTransferLimit",
            "value": "500",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perMonthTransferOutwardLimit",
            "value": "100",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perDayTransferOutwardLimit",
            "value": "10",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "senderBalance",
            "value": "0",
            "operator": "greaterThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerMonth",
            "value": "1500",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerYear",
            "value": "15000",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "intraTenants",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "extraTenant",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantIntra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "receiverStoredValue",
            "value": "500",
            "operator": "lessThanInclusive"
          }
        ]
      }
    }
  ],
  "attributes": [
    {
      "name": "maxTransferLimit",
      "type": "number"
    },
    {
      "name": "perMonthTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "perDayTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "senderBalance",
      "type": "number"
    },
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerMonth",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerYear",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    }
  ]
}

export const transfer_tier2_default_rule = {
  "name": "transfer-tier2",
  "decisions": [
    {
      "event": {
        "type": "transfer-tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      },
      "conditions": {
        "all": [
          {
            "fact": "maxTransferLimit",
            "value": "500",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perMonthTransferOutwardLimit",
            "value": "100",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perDayTransferOutwardLimit",
            "value": "10",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "senderBalance",
            "value": "0",
            "operator": "greaterThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerMonth",
            "value": "1500",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerYear",
            "value": "15000",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "intraTenants",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "extraTenant",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantIntra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "receiverStoredValue",
            "value": "500",
            "operator": "lessThanInclusive"
          }
        ]
      }
    }
  ],
  "attributes": [
    {
      "name": "maxTransferLimit",
      "type": "number"
    },
    {
      "name": "perMonthTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "perDayTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "senderBalance",
      "type": "number"
    },
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerMonth",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerYear",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    }
  ]
}

export const deposit_tier1_default_rule = {
  "name": "deposit_tier1",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "storedValue",
      "type": "number"
    },
    {
      "name": "isDepositAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perYearMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "storedValue",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "isDepositAllowed",
            "operator": "equal",
            "value": false
          }
        ]
      },
      "event": {
        "type": "deposit_tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const deposit_tier2_default_rule = {
  "name": "deposit_tier2",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "storedValue",
      "type": "number"
    },
    {
      "name": "isDepositAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perYearMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "storedValue",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "isDepositAllowed",
            "operator": "equal",
            "value": false
          }
        ]
      },
      "event": {
        "type": "deposit_tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier1_default_rule = {
  "name": "withdraw_tier1",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayWithdrwalLimit",
      "type": "number"
    },
    {
      "name": "isWithdrawAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": "500"
          },
          {
            "fact": "perMonthWithdrawalTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perYearWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perDayWithdrwalLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "isWithdrawAllowed",
            "operator": "equal",
            "value": false
          }
        ]
      },
      "event": {
        "type": "withdraw_tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier2_default_rule = {
  "name": "withdraw_tier2",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayWithdrwalLimit",
      "type": "number"
    },
    {
      "name": "isWithdrawAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthWithdrawalTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perMonthWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perYearWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "perDayWithdrwalLimit",
            "operator": "lessThanInclusive",
            "value": "0"
          },
          {
            "fact": "isWithdrawAllowed",
            "operator": "equal",
            "value": false
          }
        ]
      },
      "event": {
        "type": "withdraw_tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}