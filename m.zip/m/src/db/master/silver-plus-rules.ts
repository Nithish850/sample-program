export const onboard_tier3_default_rule = {
  "name": "onboarding-tier3",
  "attributes": [
    {
      "name": "bankAccount",
      "type": "boolean"
    },
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "bankAccount",
            "operator": "equal",
            "value": true
          },
        ]
      },
      "event": {
        "type": "onboarding-tier3",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const transfer_tier3_default_rule = {
  "name": "transfer-tier3",
  "decisions": [
    {
      "event": {
        "type": "transfer-tier3",
        "params": {
          "messaged": "Validated successfully"
        }
      },
      "conditions": {
        "all": [
          {
            "fact": "maxTransferLimit",
            "value": "2500",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perMonthTransferOutwardLimit",
            "value": "200",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "perDayTransferOutwardLimit",
            "value": "20",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "senderBalance",
            "value": "0",
            "operator": "greaterThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerMonth",
            "value": "10000",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "maximumTransactionAmountPerYear",
            "value": "100000",
            "operator": "lessThanInclusive"
          },
          {
            "fact": "intraTenants",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "extraTenant",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantIntra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "WalletUserToTenantExtra",
            "value": false,
            "operator": "equal"
          },
          {
            "fact": "receiverStoredValue",
            "value": "5000",
            "operator": "lessThanInclusive"
          }
        ]
      }
    }
  ],
  "attributes": [
    {
      "name": "maxTransferLimit",
      "type": "number"
    },
    {
      "name": "perMonthTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "perDayTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "senderBalance",
      "type": "number"
    },
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerMonth",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerYear",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    }
  ]
}

export const deposit_tier3_default_rule = {
  "name": "deposit_tier3",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "storedValue",
      "type": "number"
    },
    {
      "name": "isDepositAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "5000"
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "50"
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "5"
          },
          {
            "fact": "perMonthMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "10000"
          },
          {
            "fact": "perYearMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "100000"
          },
          {
            "fact": "storedValue",
            "operator": "lessThanInclusive",
            "value": "5000"
          },
          {
            "fact": "isDepositAllowed",
            "operator": "equal",
            "value": true
          }
        ]
      },
      "event": {
        "type": "deposit_tier3",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier3_default_rule = {
  "name": "withdraw_tier3",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perYearWithdrawalAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayWithdrwalLimit",
      "type": "number"
    },
    {
      "name": "isWithdrawAllowed",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": "5000"
          },
          {
            "fact": "perMonthWithdrawalTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "50"
          },
          {
            "fact": "perMonthWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "10000"
          },
          {
            "fact": "perYearWithdrawalAmountLimit",
            "operator": "lessThanInclusive",
            "value": "100000"
          },
          {
            "fact": "perDayWithdrwalLimit",
            "operator": "lessThanInclusive",
            "value": "5"
          },
          {
            "fact": "isWithdrawAllowed",
            "operator": "equal",
            "value": true
          }
        ]
      },
      "event": {
        "type": "withdraw_tier3",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}