export const industryMaster = [
  {
    industry: 'Agriculture, veterinary, animal husbandry, fishing and hunting',
    risk: 'High Risk',
  },
  {
    industry: 'Art and antique dealers',
    risk: 'High Risk',
  },
  {
    industry: 'Auction houses',
    risk: 'High Risk',
  },
  {
    industry: 'Bars and nightclubs',
    risk: 'High Risk',
  },
  {
    industry: 'Beauty services (hairdressers, beauticians, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Cash intensive businesses (car wash, laundry services, parking, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Construction and real estate development',
    risk: 'High Risk',
  },
  {
    industry: 'Crypto mining (rigs, miners, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Customs broker or agent',
    risk: 'High Risk',
  },
  {
    industry: 'Entertainment services (play pens, bowling, adult entertainment clubs, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Estate agents (selling, buying & renting)',
    risk: 'High Risk',
  },
  {
    industry: 'Food and goods stores (convenience stores, supermarkets, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Gambling (sports betting, lottery, bingo, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'High value goods dealer (metals, jewelry, watches, vehicles, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Manufacturing (construction, vehicles, machinery, materials, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Mining (metals, precious stones, coal, gas, oil, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Other crypto related businesses (DAOs, NFTs, ATMs, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Prepaid, service and credit cards',
    risk: 'High Risk',
  },
  {
    industry: 'Religious services',
    risk: 'High Risk',
  },
  {
    industry: "Traveler's cheques",
    risk: 'High Risk',
  },
  {
    industry: 'Unregulated VASP',
    risk: 'High Risk',
  },
  {
    industry: 'Wholesale trade (food stuffs, raw materials, textile, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Precious Metals or Gem Dealers or Jewelers',
    risk: 'High Risk',
  },
  {
    industry: 'Professional Service Providers (accountants or attorneys) ',
    risk: 'High Risk',
  },
  {
    industry: 'ATM/Kiosk Operators',
    risk: 'High Risk',
  },
  {
    industry: 'Beverages and tobacco',
    risk: 'Medium Risk',
  },
  {
    industry: 'Catering services (restaurants, cafes, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Charities/donations',
    risk: 'Medium Risk',
  },
  {
    industry: 'Financial and insurance services',
    risk: 'Medium Risk',
  },
  {
    industry: 'Health care services and professionals (Doctor, nurses, dentists, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Hotels and hostals',
    risk: 'Medium Risk',
  },
  {
    industry: 'IT Services (developers, engineers, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Museums, recreational, cultural services',
    risk: 'Medium Risk',
  },
  {
    industry: 'Professional services (legal, accounting, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Public services (notaries, brokers, public servants, police officers, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Renewable energies',
    risk: 'Medium Risk',
  },
  {
    industry: 'Social media networks (influences, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Trade in health care products',
    risk: 'Medium Risk',
  },
  {
    industry: 'Transport services (airlines, bus, train, couriers, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Government or public agencies',
    risk: 'Low Risk',
  },
  {
    industry: 'Listed businesses (NYSE, LSE, etc)',
    risk: 'Low Risk',
  },
  {
    industry: 'Regulated businesses',
    risk: 'Low Risk',
  },
  {
    industry: 'Regulated VASP',
    risk: 'Low Risk',
  },
  {
    industry: 'Any other industry',
    risk: 'Low Risk',
  },
  {
    industry: 'Accommodation/Air BnB',
    risk: 'Medium Risk',
  },
  {
    industry: 'Auction houses, including operators, organizers, and promoters of online auctions',
    risk: 'High Risk',
  },
  {
    industry: 'Building Materials',
    risk: 'High Risk',
  },
  {
    industry: 'Chemical Manufacturing',
    risk: 'High Risk',
  },
  {
    industry: 'Clothing and Accessories',
    risk: 'Medium Risk',
  },
  {
    industry: 'Courier Services',
    risk: 'Medium Risk',
  },
  {
    industry: 'Crowdfunding platforms',
    risk: 'High Risk',
  },
  {
    industry: 'Economic citizenship or citizenship by investment programs, or advisory companies focused on economic citizenship',
    risk: 'High Risk',
  },
  {
    industry: 'Educational Services (not including online-only services)',
    risk: 'Low Risk',
  },
  {
    industry: 'Electrical Services, Equipment or Manufacturing',
    risk: 'Low Risk',
  },
  {
    industry: 'Electronic gaming platforms that facilitate the purchase of virtual gaming assets',
    risk: 'High Risk',
  },
  {
    industry: 'Engineering (Mechanical and electrical)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Entertainment services (play pens, bowling, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Financial Activities',
    risk: 'Medium Risk',
  },
  {
    industry: 'Food, drinks, tobacco and  goods stores (convenience stores, supermarkets, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Licenced Gaming business  (sports betting, lottery, bingo, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Information Services',
    risk: 'Medium Risk',
  },
  {
    industry: 'Insurance',
    risk: 'Medium Risk',
  },
  {
    industry: 'Payments involving transactions designed to achieve a particular tax treatment',
    risk: 'High Risk',
  },
  {
    industry: 'Payments involving government scholarship programs where the beneficiary is not an educational institution',
    risk: 'High Risk',
  },
  {
    industry: 'Publicly listed businesses (NYSE, LSE, etc)',
    risk: 'Low Risk',
  },
  {
    industry: 'Management of Companies and Enterprises',
    risk: 'Medium Risk',
  },
  {
    industry: 'Media',
    risk: 'Low Risk',
  },
  {
    industry: 'Medical Professional & Health Care Services',
    risk: 'Medium Risk',
  },
  {
    industry: 'Multi-level Marketing schemes: Pyramid schemes, network marketing, and referral marketing programs',
    risk: 'High Risk',
  },
  {
    industry: 'Natural Resources and Mining (metals, precious stones, coal, gas, oil, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Online-only universities and other online-only further education tuition solutions',
    risk: 'High Risk',
  },
  {
    industry: 'Real Estate agents (selling, buying & renting)',
    risk: 'High Risk',
  },
  {
    industry: 'Money Services Businesses (MSBs), virtual currency exchanges, or other money or value transfer services (MVTS) or virtual asset service providers (VASPs) as defined by the FATF',
    risk: 'High Risk',
  },
  {
    industry: 'Sales & Marketing',
    risk: 'Medium Risk',
  },
  {
    industry: 'Securities, Commodity Contracts, Digital Assets & Registered Exchanges and such other Financial Investments Related Activities',
    risk: 'Medium Risk',
  },
  {
    industry: 'Social media networks (influencers, etc)',
    risk: 'Medium Risk',
  },
  {
    industry: 'Telecommunications',
    risk: 'High Risk',
  },
  {
    industry: 'Trade, Transportation, and Utilities',
    risk: 'High Risk',
  },
  {
    industry: 'Travel Agent & Travel Services, including tour and travel companies with an international focus',
    risk: 'High Risk',
  },
  {
    industry: 'Used motor vehicles dealers or auctioneers',
    risk: 'High Risk',
  },
  {
    industry: 'Wholesale trade (food stuffs, raw materials, textile, etc)',
    risk: 'High Risk',
  },
  {
    industry: 'Companies engaged in the defense sector or the manufacture, production, or sale of arms,munition, weapons, and other military equipment designed for offensive purposes',
    risk: 'Prohibited',
  },
  {
    // eslint-disable-next-line max-len
    industry: 'Unfair, Predatory or Deceptive Practices: Investment opportunities or other services that promise high rewards; sale or resale of a service without added benefit to the buyer; resale of government offerings without authorization or added value; sites that we determine in our sole discretion to be unfair, deceptive, or predatory towards consumers',
    risk: 'Prohibited',
  },
  {
    industry: 'Alcoholic beverages, including the facilitation, sale, or distribution of alcoholic beverages',
    risk: 'Prohibited',
  },
  {
    industry: 'Bankruptcy services',
    risk: 'Prohibited',
  },
  {
    industry: 'Layaway systems and annuities',
    risk: 'Prohibited',
  },
  {
    industry: 'Miracle cures',
    risk: 'Prohibited',
  },
  {
    industry: 'Psychic services',
    risk: 'Prohibited',
  },
  {
    industry: 'Invoice Factoring or other Factoring companies',
    risk: 'Prohibited',
  },
  {
    industry: 'Shipping and general trading companies operating in free trade zones',
    risk: 'Prohibited',
  },
  {
    industry: 'Charities, non-profits, and non-governmental organizations',
    risk: 'Prohibited',
  },
  {
    industry: 'Third-party senders and companies offering payable-through accounts',
    risk: 'Prohibited',
  },
  {
    industry: 'Marijuana-related businesses (MRB) (such as manufacturers, dispensers, and those engaged in medical marijuana), including companies whose main source of revenue is derived from this type of activity',
    risk: 'Prohibited',
  },
  {
    industry: 'Illegal narcotics',
    risk: 'Prohibited',
  },
  {
    industry: 'Human trafficking',
    risk: 'Prohibited',
  },
  {
    industry: 'Illegal wildlife trade',
    risk: 'Prohibited',
  },
  {
    industry: 'Child sexual abuse material',
    risk: 'Prohibited',
  },
  {
    industry: 'Involvement in ransomware, scams, stolen funds',
    risk: 'Prohibited',
  },
  {
    industry: 'Involvement in other criminal activity, including, but not limited to, organised crime, money laundering, terrorist financing, proliferation financing or tax evasion',
    risk: 'Prohibited',
  },
  {
    industry: 'Transacting with sanctioned entities or crypto addresses and/or clusters identified by OFAC as sanctioned',
    risk: 'Prohibited',
  },
  {
    industry: 'Shell companies',
    risk: 'Prohibited',
  },
  {
    industry: 'Unregistered charities',
    risk: 'Prohibited',
  },
  {
    industry: 'Investment and Credit Services: Securities brokers; mortgage consulting or debt reduction services; credit counseling or repair; real estate opportunities; investment schemes; brokers or other firms focused on penny stocks or microcap securities',
    risk: 'Prohibited',
  },
  {
    industry: 'Restricted Financial Services: Check cashing, bail bonds; debt collections agencies',
    risk: 'Prohibited',
  },
  {
    industry: 'Intellectual Property or Proprietary Rights Infringement: Sales, distribution, or access to counterfeit music, movies, software, or other licensed materials without the appropriate authorization from the rights holder',
    risk: 'Prohibited',
  },
  {
    industry: 'Counterfeit or Unauthorized Goods: Unauthorized sale or resale of brand name or designer products or services; sale of goods or services that are illegally imported or exported or which are stolen',
    risk: 'Prohibited',
  },
  {
    // eslint-disable-next-line max-len
    industry: 'Regulated Products and Services: Sale of tobacco, e-cigarettes, and e-liquid; online prescription or pharmaceutical services; age restricted goods or services; weapons and munitions; gunpowder and other explosives; fireworks and related goods; toxic, flammable, and radioactive materials; products and services with varying legal status on a state-by-state basis',
    risk: 'Prohibited',
  },
  {
    industry: 'Drugs and Drug Paraphernalia: Sale of narcotics, controlled substances, and any equipment designed for making or using drugs, such as bongs, vaporizers, and hookahs',
    risk: 'Prohibited',
  },
  {
    industry: 'Pseudo-Pharmaceuticals: Pharmaceuticals and other products that make health claims that have not been approved or verified by the applicable local and/or national regulatory body',
    risk: 'Prohibited',
  },
  {
    industry: 'Substances designed to mimic illegal drugs: Sale of a legal substance that provides the same effect as an illegal drug (e.g., salvia, kratom)',
    risk: 'Prohibited',
  },
  {
    industry: 'Adult entertainment businesses, escort services and sexually oriented or pornographic products and services',
    risk: 'Prohibited',
  },
  {
    industry: 'Companies issuing bearer shares',
    risk: 'Prohibited',
  },
  {
    industry: 'Chemicals, including the facilitation, sale, or distribution of chemicals',
    risk: 'Prohibited',
  },
  {
    industry: 'Dietary supplements, including the facilitation, sale or distribution of dietary supplements',
    risk: 'Prohibited',
  },
  {
    industry: 'Embassies, consulates and diplomatic missions',
    risk: 'Prohibited',
  },
  {
    industry: 'Financial institutions, where Prime Trust does not maintain a direct relationship with the financial institution or bank and a nested relationship is established',
    risk: 'Prohibited',
  },
  {
    industry: 'Companies whose primary business involves currency handling (e.g., cash handling, bank note trading, casas de cambio, foreign bulk shipment of currency)',
    risk: 'Prohibited',
  },
  {
    industry: 'Unlicensed internet gambling services (e.g., daily fantasy sports, online poker) and gaming houses / brick and mortar casinos',
    risk: 'Prohibited',
  },
  {
    industry: 'Foreign offshore shell companies',
    risk: 'Prohibited',
  },
  {
    industry: 'Foreign shell banks',
    risk: 'Prohibited',
  },
  {
    industry: 'Unlicensed or unlawful facilitation, sale, distribution, or exhange of jewels, precious metals or stones',
    risk: 'Prohibited',
  },
  {
    industry: 'Medical devices and medications, including the facilitation, sale or distribution of drugs, prescription medications, or medical devices',
    risk: 'Prohibited',
  },
  {
    industry: 'Dating services',
    risk: 'Prohibited',
  },
  {
    industry: 'Payday lenders, as well as their owners and principals',
    risk: 'Prohibited',
  },
  {
    industry: 'Stocks and other security interests, including the sale of stocks and other security interests',
    risk: 'Prohibited',
  },
  {
    industry: 'Telemarketing companies',
    risk: 'Prohibited',
  },
  {
    industry: 'Tobaccos goods, including the facilitation, sale or distribution of tobacco goods',
    risk: 'Prohibited',
  },
  {
    industry: 'The creation, facilitation, sale or distribution of any prohibited or illegal good or service or an activity that requires a governmental license where the customer lacks such a license',
    risk: 'Prohibited',
  },
  {
    industry: 'The creation, facilitation, sale or distribution of goods or services that violate the intellectual property rights of a third party',
    risk: 'Prohibited',
  },
  {
    industry: 'Any Ponzi-scheme or pyramid selling',
    risk: 'Prohibited',
  },
  {
    industry: 'Violence related activities, including the creation, facilitation, sale, or distribution of any material that promotes violence or hatred',
    risk: 'Prohibited',
  },
  {
    industry: 'Weapons, including the facilitation, sale or distribution of firearms or other weapons, military or semi-military goods, military software, or technologies',
    risk: 'Prohibited',
  },
  {
    industry: 'Companies not in good standing and/or out of compliance with applicable laws and regulations (e.g., unlicensed money transmitters)',
    risk: 'Prohibited',
  },
  {
    industry: 'Any other unlawful or illegal activities',
    risk: 'Prohibited',
  },
];
