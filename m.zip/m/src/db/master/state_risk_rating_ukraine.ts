export const state_risk_rating_ukraine = [
  {
    country_code: 'UA',
    state: 'Crimea (Autonomous Republic of Crimea)',
    state_code: 'UA-43',
    risk_score: 0,
    risk_rating: 'High',
    ul_override: 'Prohibited',
    rationale: 'Sanctions/US ML Concern',
  },
  {
    country_code: 'UA',
    state: `Donetsk People's Republic (DNR)`,
    state_code: 'UA-14',
    risk_score: 0,
    risk_rating: 'High',
    ul_override: 'Prohibited',
    rationale: 'Sanctions/US ML Concern',
  },
  {
    country_code: 'UA',
    state: `Luhanska (LHK)`,
    state_code: 'UA-09',
    risk_score: 0,
    risk_rating: 'High',
    ul_override: 'Prohibited',
    rationale: 'Sanctions/US ML Concern',
  },
]
