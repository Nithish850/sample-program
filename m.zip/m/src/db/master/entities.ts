/* eslint-disable max-len */
export const entities = [
  {
    entity_name: 'Dashboard',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Tenant Management',
    entity_description: '',
    role_assigned: 'UL',
  },
  {
    entity_name: 'Rules Management',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Wallet User Management',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Role Management',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'User Management',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Tenant Wallet Managements',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Compliance Reports',
    entity_description: '',
    role_assigned: 'UL',
  },
  {
    entity_name: 'Subscriptions',
    entity_description: '',
    role_assigned: 'BOTH',
  },
  {
    entity_name: 'Feature Flagging',
    entity_description: '',
    role_assigned: 'BOTH',
  }
]

export const defaultRoles = (tenant_id: string): any => [
  {
    role_name: 'TENANT_ADMIN',
    tenant_id: tenant_id,
    is_active: true,
    type: 'DEFAULT'
  } ,
  {
    role_name: 'READ_ONLY',
    tenant_id: tenant_id,
    is_active: true,
    type: 'DEFAULT'
  }

]

export async function defaultRoleEntities(tenantId, entityData, roleData) {
  const roleEntities = [];

  for (const entity of entityData) {
    for (const role of roleData) {
      if (role.role_name === 'TENANT_ADMIN') {
        const roleEntity = {
          entity_id: entity.entity_id,
          role_id: role.role_id,
          tenant_id: tenantId,
          read: true,
          write: true,
          update: true,
          delete: true,
          manage: true,
        };

        roleEntities.push(roleEntity);
      }
      if (role.role_name === 'READ_ONLY') {
        const roleEntity = {
          entity_id: entity.entity_id,
          role_id: role.role_id,
          tenant_id: tenantId,
          read: true,
          write: false,
          update: false,
          delete: false,
          manage: false,
        };

        roleEntities.push(roleEntity);
      }
    }
  }

  return roleEntities;
}
