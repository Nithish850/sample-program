export const defaultRolesUL = (tenantId: string, createdBy: string): any => [ {
  role_name: 'UL_USER_ADMINISTRATIVE',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
},
{
  role_name: 'UL_COMPLIANCE',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
},
{
  role_name: 'UL_MARKETING',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
}];