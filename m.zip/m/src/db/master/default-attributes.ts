export const onboardAttributes = [
  {
    "attribute_name": "fullName",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "phoneNumber",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "countryCode",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "countryName",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "email",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "dob",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "residentialAddress",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "city",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "state",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "country",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "zipcode",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "ipAddress",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "latLong",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "cityLatLong",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "countryLatLong",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidName",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidDob",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidNumber",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidCountry",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidState",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidIssueDate",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidExpirationDate",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidAddress",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidGender",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "gidPhoto",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "pepScreening",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "sanctionScreeningGeo",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "sanctionScreeningName",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "selfPhoto",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "tin",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "taxId",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "driverLicense",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "stateIdLicense",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "passport",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "proffOfAddress",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "govId",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "alienIdCard",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "nationalId",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "isProhibitedCountry",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "isProhibitedState",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "bankAccount",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD"
  },
  {
    "attribute_name": "maxTransferLimit",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "perMonthTransferOutwardLimit",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "perDayTransferOutwardLimit",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "senderBalance",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "receiverStoredValue",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "intraTenants",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "extraTenant",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "tenantToTenantWalletUserExtra",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "WalletUserToTenantIntra",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "WalletUserToTenantExtra",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "monthlyStoreLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "minWalletBalance",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "maxWithdrawalLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "perMonthWithdrawalTransactionLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "perMonthWithdrawalAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "perYearWithdrawalAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "perYearWithdrawalTransactionLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "perDayMaxDepositAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perMonthMaxDepositTransactionLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perDayMaxDepositTransactionLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perMonthMaxDepositAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perYearMaxDepositAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perYearMaxDepositTransactionLimit",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "perDayWithdrwalLimit",
    "attribute_type": "NUMBER",
    "rule_group": "WITHDRAW"
  },
  {
    "attribute_name": "isBronzeReceiver",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER",
  },
  {
    "attribute_name": "isSilverReceiver",
    "attribute_type": "BOOLEAN",
    "rule_group": "TRANSFER",
  },
  {
    "attribute_name": "maximumTransactionAmountPerMonth",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maximumTransactionAmountPerYear",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maximumTransactionPerYear",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxDepositTrxAmountPerMonth",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxDepositTrxAmountPerYear",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxWithdrawalTrxAmountPerMonth",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxWithdrawalTrxAmountPerYear",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "dailyDepositTrxAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "dailyWithdrawalTrxAmountLimit",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxDepositTrxCountDaily",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxDepositTrxCountMonthly",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxWithdrawalTrxCountDaily",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "maxWithdrawalTrxCountMonthly",
    "attribute_type": "NUMBER",
    "rule_group": "TRANSFER"
  },
  {
    "attribute_name": "storedValue",
    "attribute_type": "NUMBER",
    "rule_group": "DEPOSIT"
  },
  {
    "attribute_name": "isWithdrawAllowed",
    "attribute_type": "BOOLEAN",
    "rule_group": "WITHDRAW"
  },
]
