export const dssDetails = [
  {
    dss_type: 'FINCLUSIVE',
    dss_description: 'Compliance type finclusive id',
  },
  {
    dss_type: 'PUBLIC_MINT',
    dss_description: 'identity type public mint id ',
  },
];
