export const getRoleAndEntityFlags = (roleName, entityName): any => {
  // TENANT_USER_ADMINISTRATIVE
  const flags = [
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'User Management',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'TENANT_USER_ADMINISTRATIVE',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },

    // TENANT_COMPLIANCE
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'User Management',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: false,
        update: true,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: true,
        update: true,
        delete: true,
        manage: true,
      }
    },
    {
      role: 'TENANT_COMPLIANCE',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },

    // MARKETING
    {
      role: 'MARKETING',
      entity: 'Dashboard',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Rules Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Wallet User Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Role Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'User Management',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Tenant Wallet Managements',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Subscriptions',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    },
    {
      role: 'MARKETING',
      entity: 'Feature Flagging',
      flag: {
        read: true,
        write: false,
        update: false,
        delete: false,
        manage: false,
      }
    }
  ]

  return flags.find((item) => {
    if(item.role === roleName && item.entity === entityName){
      return item.flag;
    }
  });
}