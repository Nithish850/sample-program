export const achReasonCodes = [
  {
    code: "A00",
    message: "Successfully processed; no error"
  },
  {
    code: "C01",
    message: "Incorrect DFI Account Number"
  },
  {
    code: "C02",
    message: "Incorrect Transit/Routing Number"
  },
  {
    code: "C03",
    message: "Incorrect Transit/Routing Number and Incorrect DFI Account Number"
  },
  {
    code: "C04",
    message: "Incorrect Individual Name/ Receiving Company Name"
  },
  {
    code: "C05",
    message: "Incorrect Transaction Code"
  },
  {
    code: "C06",
    message: "Incorrect DFI Account Number and Incorrect Transaction Code"
  },
  {
    code: "C07",
    message: "Incorrect Transit/Routing Number, Incorrect DFI Account Number, and Incorrect"
  },
  {
    code: "Tra",
    message: "saction Code"
  },
  {
    code: "C08",
    message: "Incorrect Foreign Receiving DFI Identification"
  },
  {
    code: "C09",
    message: "Incorrect Individual Identification Number"
  },
  {
    code: "C10",
    message: "Incorrect Company Name"
  },
  {
    code: "C11",
    message: "Incorrect Company Identification"
  },
  {
    code: "C12",
    message: "Incorrect Company Name and Company Identification"
  },
  {
    code: "C13",
    message: "Addenda Format Error"
  },
  {
    code: "C61",
    message: "Misrouted Notification of Change"
  },
  {
    code: "C62",
    message: "Incorrect Trace Number"
  },
  {
    code: "C63",
    message: "Incorrect Company Identification Number"
  },
  {
    code: "C64",
    message: "Incorrect Individual Identification Number"
  },
  {
    code: "C65",
    message: "Incorrectly Formatted Corrected Data"
  },
  {
    code: "C66",
    message: "Incorrect Discretionary Data"
  },
  {
    code: "C67",
    message: "Routing Number Not From Original Entry Detail Record"
  },
  {
    code: "C68",
    message: "DFI Account Number Not From Original Entry Detail Record"
  },
  {
    code: "C69",
    message: "Incorrect Transaction Code"
  },
  {
    code: "R01",
    message: "Insufficient Funds"
  },
  {
    code: "R02",
    message: "Account Closed"
  },
  {
    code: "R03",
    message: "No Account/Unable to Locate Account"
  },
  {
    code: "R04",
    message: "Invalid Account Number"
  },
  {
    code: "R05",
    message: "Unauthorized Debit to Consumer Account Using Corporate SEC Code"
  },
  {
    code: "R06",
    message: "Returned per ODFIs Request"
  },
  {
    code: "R07",
    message: "Authorization Revoked by Customer"
  },
  {
    code: "R08",
    message: "Payment Stopped or Stop Payment on Item"
  },
  {
    code: "R09",
    message: "Uncollected Funds"
  },
  {
    code: "R10",
    message: "Customer Advises Not Authorized, Notice Not Provided, Improper Source Document, Amount of Entry Not Accurately Obtained from Source Document"
  },
  {
    code: "R11",
    message: "Check Truncation Entry Return"
  },
  {
    code: "R12",
    message: "Account sold to another DFI"
  },
  {
    code: "R13",
    message: "Invalid ACH Routing Number"
  },
  {
    code: "R14",
    message: "Re-presentment payee deceased or unable to continue in that capacity"
  },
  {
    code: "R15",
    message: "Beneficiary of account holder deceased"
  },
  {
    code: "R16",
    message: "Account Frozen"
  },
  {
    code: "R17",
    message: "File record edit criteria"
  },
  {
    code: "R18",
    message: "Improper effective entry date"
  },
  {
    code: "R19",
    message: "Amount field error"
  },
  {
    code: "R20",
    message: "Non-Transaction Account"
  },
  {
    code: "R21",
    message: "Invalid company identification"
  },
  {
    code: "R22",
    message: "Invalid individual ID number"
  },
  {
    code: "R23",
    message: "Credit entry refused by receiver"
  },
  {
    code: "R24",
    message: "Duplicate entry"
  },
  {
    code: "R25",
    message: "Addenda error"
  },
  {
    code: "R26",
    message: "Mandatory field error"
  },
  {
    code: "R27",
    message: "Trace number error"
  },
  {
    code: "R28",
    message: "Routing number check digit error"
  },
  {
    code: "R29",
    message: "Corporate customer advises not authorized"
  },
  {
    code: "R30",
    message: "RDFI not participant in check truncation program"
  },
  {
    code: "R31",
    message: "Permissible return entry"
  },
  {
    code: "R32",
    message: "RDFI non-settlement"
  },
  {
    code: "R33",
    message: "Return of XCK entry"
  },
  {
    code: "R34",
    message: "Limited participation DFI"
  },
  {
    code: "R35",
    message: "Return of improper debit entry"
  },
  {
    code: "R36",
    message: "Return of improper credit entry"
  },
  {
    code: "R37",
    message: "Source Document Presented for Payment"
  },
  {
    code: "R38",
    message: "Stop Payment on Source Document"
  },
  {
    code: "R39",
    message: "Improper Source Document"
  },
  {
    code: "R40",
    message: "Return of ENR entry by Federal Government Agency (ENR Only)"
  },
  {
    code: "R41",
    message: "Invalid transaction code (ENR Only)"
  },
  {
    code: "R42",
    message: "Routing number/check digit error (ENR only)"
  },
  {
    code: "R43",
    message: "Invalid DFI account number (ENR only) "
  },
  {
    code: "R44",
    message: "Invalid individual ID number (ENR only)"
  },
  {
    code: "R45",
    message: "Invalid individual name/company name (ENR only)"
  },
  {
    code: "R46",
    message: "Invalid representative payee indicator (ENR only)"
  },
  {
    code: "R47",
    message: "Duplicate enrollment"
  },
  {
    code: "R50",
    message: "State Law Affecting RCK Acceptance"
  },
  {
    code: "R51",
    message: "Item is Ineligible, Notice Not Provided, Signature not genuine, Signature Not Genuine, Item Altered"
  },
  {
    code: "R52",
    message: "Stop Payment on Item"
  },
  {
    code: "R53",
    message: "Item and ACH Entry Presented for Payment"
  },
  {
    code: "R61",
    message: "Misrouted return"
  },
  {
    code: "R62",
    message: "Incorrect trace number"
  },
  {
    code: "R63",
    message: "Incorrect dollar amount"
  },
  {
    code: "R64",
    message: "Incorrect individual identification "
  },
  {
    code: "R65",
    message: "Incorrect transaction code"
  },
  {
    code: "R66",
    message: "Incorrect company identification"
  },
  {
    code: "R67",
    message: "Duplicate return"
  },
  {
    code: "R68",
    message: "Untimely Return"
  },
  {
    code: "R69",
    message: "Field Error(s)"
  },
  {
    code: "R70",
    message: "Permissible return entry not accepted/ Return Not Requested by ODFI"
  },
  {
    code: "R71",
    message: "Misrouted dishonored return"
  },
  {
    code: "R72",
    message: "Untimely dishonored return"
  },
  {
    code: "R73",
    message: "Timely original return"
  },
  {
    code: "R74",
    message: "Corrected return"
  },
  {
    code: "R75",
    message: "Original Return Not a Duplicate"
  },
  {
    code: "R76",
    message: "No Errors Found "
  },
  {
    code: "R80",
    message: "Cross-Border Payment Coding Error"
  },
  {
    code: "R81",
    message: "Non-Participant in Cross-Border Program"
  },
  {
    code: "R82",
    message: "Invalid Foreign Receiving DFI Identification"
  },
  {
    code: "R83",
    message: "Foreign Receiving DFI Unable to Settle"
  },
  {
    code: "R84",
    message: "Entry Not Processed by OGO"
  },
  {
    code: "X00",
    message: "Unknown Exception"
  },
  {
    code: "X01",
    message: "Invalid Merchant ID"
  },
  {
    code: "X02",
    message: "Merchant On Hold"
  },
  {
    code: "X03",
    message: "Merchant Batch On Hold"
  },
  {
    code: "X04",
    message: "Invalid Or Missing Customer Name"
  },
  {
    code: "X05",
    message: "Invalid Account Type (C/S)"
  },
  {
    code: "X06",
    message: "Invalid Direction (D/C)"
  },
  {
    code: "X07",
    message: "Invalid ABA"
  },
  {
    code: "X08",
    message: "Invalid Account Number (4 to 17 digits)"
  },
  {
    code: "X09",
    message: "Amount must be greater than zero"
  },
  {
    code: "X10",
    message: "Invalid Or Missing Reference Id"
  },
  {
    code: "X11",
    message: "Invalid Or Missing Input"
  },
  {
    code: "X12",
    message: "Future Use"
  },
  {
    code: "X13",
    message: "Future Use"
  },
  {
    code: "X14",
    message: "Future Use"
  },
  {
    code: "X15",
    message: "Future Use"
  },
  {
    code: "X16",
    message: "Future Use"
  },
  {
    code: "X17",
    message: "Matching payment not found"
  },
  {
    code: "X18",
    message: "Payment already refunded"
  },
  {
    code: "X19",
    message: "Duplicate payment found"
  },
  {
    code: "X20",
    message: "Future Use"
  },
  {
    code: "X21",
    message: "Future Use"
  },
  {
    code: "X22",
    message: "Failed to create payment"
  },
  {
    code: "X23",
    message: "Future Use"
  },
  {
    code: "X24",
    message: "Future Use"
  },
  {
    code: "X25",
    message: "Future Use"
  },
  {
    code: "X26",
    message: "Payment canceled not processed"
  },
  {
    code: "X27",
    message: "Invalid SEC Code (WEB/PPD/TEL/CCD)"
  },
  {
    code: "X28",
    message: "Total credit limit exceeded"
  },
  {
    code: "X29",
    message: "Future Use"
  },
  {
    code: "X30",
    message: "Future Use"
  },
  {
    code: "X31",
    message: "Future Use"
  },
  {
    code: "X32",
    message: "Future Use"
  },
  {
    code: "X33",
    message: "Future Use"
  },
  {
    code: "X34",
    message: "Invalid Service Source"
  },
  {
    code: "X35",
    message: "Invalid Service Type"
  },
  {
    code: "X36",
    message: "Invalid File Version"
  },
  {
    code: "X37",
    message: "Redundant Section"
  },
  {
    code: "X38",
    message: "Invalid Section"
  },
  {
    code: "X39",
    message: "Duplicate File"
  },
  {
    code: "X40",
    message: "Section Missing"
  },
  {
    code: "X41",
    message: "Element Count Error"
  },
  {
    code: "X42",
    message: "Invalid Transaction Type"
  },
  {
    code: "X43",
    message: "Invalid Amount"
  },
  {
    code: "X44",
    message: "Mismatch Merchandise"
  },
  {
    code: "X45",
    message: "Invalid input line"
  }
]