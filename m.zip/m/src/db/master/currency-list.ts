export const currencyList = [
  {
    "currency": "Argentine Peso",
    "code": "ARS",
  },
  {
    "currency": "Australian Dollar",
    "code": "AUD",
  },
  {
    "currency": "Bangladeshi Taka",
    "code": "BDT",
  },
  {
    "currency": "Brazilian Real",
    "code": "BRL",
  },
  {
    "currency": "Bulgarian Lev",
    "code": "BGN",
  },
  {
    "currency": "Canadian Dollar",
    "code": "CAD",
  },
  {
    "currency": "Chilean Peso",
    "code": "CLP",
  },
  {
    "currency": "Chinese Yuan",
    "code": "CNY",
  },
  {
    "currency": "Colombian Peso",
    "code": "COP",
  },
  {
    "currency": "Czech Koruna",
    "code": "CZK",
  },
  {
    "currency": "Danish Krone",
    "code": "DKK",
  },
  {
    "currency": "Egyptian Pound",
    "code": "EGP",
  },
  {
    "currency": "Euro",
    "code": "EUR",
  },
  {
    "currency": "Ghanaian Cedi",
    "code": "GHS",
  },
  {
    "currency": "Hong Kong Dollar",
    "code": "HKD",
  },
  {
    "currency": "Hungarian Forint",
    "code": "HUF",
  },
  {
    "currency": "Indian Rupee",
    "code": "INR",
  },
  {
    "currency": "Indonesian Rupiah",
    "code": "IDR",
  },
  {
    "currency": "Iranian Rial",
    "code": "IRR",
  },
  {
    "currency": "Israeli New Shekel",
    "code": "ILS",
  },
  {
    "currency": "Japanese Yen",
    "code": "JPY",
  },
  {
    "currency": "Malaysian Ringgit",
    "code": "MYR",
  },
  {
    "currency": "Mexican Peso",
    "code": "MXN",
  },
  {
    "currency": "Moroccan Dirham",
    "code": "MAD",
  },
  {
    "currency": "New Taiwan Dollar",
    "code": "TWD",
  },
  {
    "currency": "New Zealand Dollar",
    "code": "NZD",
  },
  {
    "currency": "Nigerian Naira",
    "code": "NGN",
  },
  {
    "currency": "Norwegian Krone",
    "code": "NOK",
  },
  {
    "currency": "Pakistani Rupee",
    "code": "PKR",
  },
  {
    "currency": "Philippine Peso",
    "code": "PHP",
  },
  {
    "currency": "Polish Złoty",
    "code": "PLN",
  },
  {
    "currency": "Pound Sterling",
    "code": "GBP",
  },
  {
    "currency": "Romanian Leu",
    "code": "RON",
  },
  {
    "currency": "Russian Ruble",
    "code": "RUB",
  },
  {
    "currency": "Saudi Riyal",
    "code": "SAR",
  },
  {
    "currency": "Singapore Dollar",
    "code": "SGD",
  },
  {
    "currency": "South African Rand",
    "code": "ZAR",
  },
  {
    "currency": "South Korean Won",
    "code": "KRW",
  },
  {
    "currency": "Sovereign Bolivar",
    "code": "VES",
  },
  {
    "currency": "Swedish Krona",
    "code": "SEK",
  },
  {
    "currency": "Swiss Franc",
    "code": "CHF",
  },
  {
    "currency": "Thai Baht",
    "code": "THB",
  },
  {
    "currency": "Turkish Lira",
    "code": "TRY",
  },
  {
    "currency": "Ukrainian Hryvnia",
    "code": "UAH",
  },
  {
    "currency": "United Arab Emirates Dirham",
    "code": "AED",
  },
  {
    "currency": "United States Dollar",
    "code": "USD",
  },
  {
    "currency": "Vietnamese Dong",
    "code": "VND",
  },
  {
    "currency": "None",
    "code": "NONE",
  }
]