export const attributeDisplayNames = [
  {
    attribute_name: 'storedValue',
    display_attribute_name: 'Balance',
  },
  {
    attribute_name: 'perMonthMaxDepositAmountLimit',
    display_attribute_name: 'Deposit Amount Per Month'
  },
  {
    attribute_name: 'perYearMaxDepositAmountLimit',
    display_attribute_name: 'Deposit Amount Per Year'
  },
  {
    attribute_name: 'perMonthWithdrawalTransactionLimit',
    display_attribute_name: 'Number of Withdrawals Per Month'
  },
  {
    attribute_name: 'perMonthWithdrawalAmountLimit',
    display_attribute_name: 'Withdrawal Amount Per Month'
  },
  {
    attribute_name: 'perYearWithdrawalAmountLimit',
    display_attribute_name: 'Withdrawal Amount Per Year'
  },
  {
    attribute_name: 'isWithdrawAllowed',
    display_attribute_name: 'Is Withdraw Allowed - Toggle'
  },
  {
    attribute_name: 'isDepositAllowed',
    display_attribute_name: 'Is Deposit Allowed - Toggle'
  },
  {
    attribute_name: 'perDayMaxDepositAmountLimit',
    display_attribute_name: 'Deposit Amount Per Day'
  },
  {
    attribute_name: 'tenantToTenantWalletUserExtra',
    display_attribute_name: 'Tenant to Tenant Wallet User Extra'
  },
  {
    attribute_name: 'extraTenant',
    display_attribute_name: 'Inter Tenant'
  },
  {
    attribute_name: 'maxTransferLimit',
    display_attribute_name: 'Transaction Amount Per Day'
  },
  {
    attribute_name: 'perDayWithdrwalLimit',
    display_attribute_name: 'Number of Withdrawals Per day'
  },
  {
    attribute_name: 'maxWithdrawalLimit',
    display_attribute_name: 'Withdrawal Amount Per Day'
  },
  {
    attribute_name: 'perDayMaxDepositTransactionLimit',
    display_attribute_name: 'Number of Deposits Per day'
  },
  {
    attribute_name: 'perMonthMaxDepositTransactionLimit',
    display_attribute_name: 'Number of Deposits Per Month'
  },
  {
    attribute_name: 'receiverStoredValue',
    display_attribute_name: 'Receiver Balance'
  },
  {
    attribute_name: 'WalletUserToTenantExtra',
    display_attribute_name: 'Wallet User to Tenant Extra'
  },
  {
    attribute_name: 'WalletUserToTenantIntra',
    display_attribute_name: 'Wallet User to Tenant Intra'
  },
  {
    attribute_name: 'intraTenants',
    display_attribute_name: 'Intra Tenant'
  },
  {
    attribute_name: 'senderBalance',
    display_attribute_name: 'Sender Balance'
  },
  {
    attribute_name: 'perDayTransferOutwardLimit',
    display_attribute_name: 'Number of Transfers Per Day'
  },
  {
    attribute_name: 'perMonthTransferOutwardLimit',
    display_attribute_name: 'Number of Transfers Per Month'
  },
  {
    attribute_name: 'maximumTransactionAmountPerYear',
    display_attribute_name: 'Transaction Amount Per Year'
  },
  {
    attribute_name: 'maximumTransactionAmountPerMonth',
    display_attribute_name: 'Transaction Amount Per Month'
  },
  {
    attribute_name: 'dob',
    display_attribute_name: 'Date of Birth'
  },
  {
    attribute_name: 'zipcode',
    display_attribute_name: 'Postal Code'
  },
  {
    attribute_name: 'zipcode',
    display_attribute_name: 'Postal Code'
  }
]
export const gidAttributesList = ['gidName', 'gidDob', 'gidPhoto', 'gidNumber',
  'gidState', 'gidCountry', 'gidIssueDate', 'gidExpirationDate', 'gidAddress', 'gidGender',
  'gidAge', 'gidStateList', 'gidCountryList', 'gidExpirationDateList', 'gidIssueDateList']
  
export const mappingOfGidAttributes = {
  gidName: 'verifiedIdName',
  gidDob: 'verifiedIdDob',
  gidPhoto: 'verifiedIdPhoto',
  gidNumber: 'verifiedIdNumber',
  gidState: 'verifiedIdState',
  gidCountry: 'verifiedIdCountry',
  gidIssueDate: 'verifiedIdIssueDate',
  gidExpirationDate: 'verifiedIdExpirationDate',
  gidAddress: 'verifiedIdAddress',
  gidGender: 'verifiedIdGender',
  gidAge: 'verifiedIdAge',
  gidStateList: 'verifiedIdStateList',
  gidCountryList: 'verifiedIdCountryList',
  gidExpirationDateList: 'verifiedIdExpirationDateList',
  gidIssueDateList: 'verifiedIdIssueDateList',
  gidGenderIs: 'verifiedIdGenderIs'
}
export const mappingOfTransferAttributes = {
  intraTenants: 'intraTenant',
  extraTenant: 'interTenant',
  tenantToTenantWalletUserExtra: 'tenantToInterTenantWalletUser',
  WalletUserToTenantIntra: 'walletUserToIntraTenant',
  WalletUserToTenantExtra: 'walletUserToInterTenantWallet'
}
export const gidAttributes = [
  {
    attribute_name: 'gidName',
    new_attribute_name: 'verifiedIdName',
    display_attribute_name: 'Verified Name'
  },
  {
    attribute_name: 'gidDob',
    new_attribute_name: 'verifiedIdDob',
    display_attribute_name: 'Verified DOB'
  },
  {
    attribute_name: 'gidPhoto',
    new_attribute_name: 'verifiedIdPhoto',
    display_attribute_name: 'Verified Photo'
  },
  {
    attribute_name: 'gidNumber',
    new_attribute_name: 'verifiedIdNumber',
    display_attribute_name: 'Verified ID Number'
  },
  {
    attribute_name: 'gidState',
    new_attribute_name: 'verifiedIdPhoto',
    display_attribute_name: 'Verified State'
  },
  {
    attribute_name: 'gidCountry',
    new_attribute_name: 'verifiedIdCountry',
    display_attribute_name: 'Verified Country'
  },
  {
    attribute_name: 'gidIssueDate',
    new_attribute_name: 'verifiedIdIssueDate',
    display_attribute_name: 'Verified ID Issue Date'
  },
  {
    attribute_name: 'gidExpirationDate',
    new_attribute_name: 'verifiedIdExpirationDate',
    display_attribute_name: 'Verified ID Expiration Date'
  },
  {
    attribute_name: 'gidAddress',
    new_attribute_name: 'verifiedIdAddress',
    display_attribute_name: 'Verified Address'
  },
  {
    attribute_name: 'gidGender',
    new_attribute_name: 'verifiedIdGender',
    display_attribute_name: 'Verified Gender'
  },
  {
    attribute_name: 'gidGenderIs',
    new_attribute_name: 'verifiedIdGenderIs',
    display_attribute_name: 'Verified Gender'
  },
  {
    attribute_name: 'gidAge',
    new_attribute_name: 'verifiedIdAge',
    display_attribute_name: 'Verified Age'
  },
  {
    attribute_name: 'gidStateList',
    new_attribute_name: 'verifiedIdStateList',
    display_attribute_name: 'Verified State'
  },
  {
    attribute_name: 'gidCountryList',
    new_attribute_name: 'verifiedIdCountryList',
    display_attribute_name: 'Verified Country'
  },
  {
    attribute_name: 'gidExpirationDateList',
    new_attribute_name: 'verifiedIdExpirationDateList',
    display_attribute_name: 'Verified ID Expiration Date'
  },
  {
    attribute_name: 'gidIssueDateList',
    new_attribute_name: 'verifiedIdIssueDateList',
    display_attribute_name: 'Verified ID Issue Date'
  },
]

export const transferAttributes  = [
  {
    attribute_name: 'extraTenant',
    new_attribute_name: 'interTenant',
    display_attribute_name: 'Inter Tenant'
  },
  {
    attribute_name: 'intraTenants',
    new_attribute_name: 'intraTenant',
    display_attribute_name: 'Intra Tenant'
  },
  {
    attribute_name: 'tenantToTenantWalletUserExtra',
    new_attribute_name: 'tenantToInterTenantWalletUser',
    display_attribute_name: 'Tenant Wallet to Inter Tenant Wallet User'
  },
  {
    attribute_name: 'WalletUserToTenantIntra',
    new_attribute_name: 'walletUserToIntraTenant',
    display_attribute_name: 'Wallet User to Intra Tenant'
  },
  {
    attribute_name: 'WalletUserToTenantExtra',
    new_attribute_name: 'walletUserToInterTenantWallet',
    display_attribute_name: 'Wallet User to Inter Tenant Wallet'
  }
]