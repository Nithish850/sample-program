export const financialBadgeAttributeDescriptionMap = {
  
    perMonthTransferOutwardLimit: 'Determines the monthly limit on the number of transfers allowed per wallet user.',
    perDayTransferOutwardLimit: 'Determines the daily limit on the number of transfers allowed per wallet user.',
    
    maxTransferLimit: 'Determines the daily transfer limit amount per wallet user.',
    maximumTransactionAmountPerMonth: `Determines the monthly transfer limit amount per wallet user.`,
    maximumTransactionAmountPerYear: `Determines the yearly transfer limit amount per wallet user.`,
  
    storedValue: `Determines the maximum balance limit of a user wallet.`,
    senderBalance: `Determines the minimum balance required in sender's wallet after a transfer.`,
    receiverStoredValue: "Determines the maximum balance limit of a receiver's wallet.",
  
    intraTenant: 'Determines whether a wallet user can send money to another wallet user within the same tenant.',
    interTenant: `Determines whether a wallet user can send money to another wallet user of a different tenant.`,
  
    perDayMaxDepositAmountLimit: 'Determines the daily deposit limit amount per wallet user.',
    perMonthMaxDepositAmountLimit: `Determines the monthly deposit limit amount per wallet user.`,
    perYearMaxDepositAmountLimit: `Determines the yearly deposit limit amount per wallet user.`,
  
    perMonthMaxDepositTransactionLimit: 'Determines the monthly limit on the number of deposits allowed per wallet user.',
    perDayMaxDepositTransactionLimit: 'Determines the daily limit on the number of deposits allowed per wallet user.',
    
    isDepositAllowed: 'Determines whether a wallet user can initiate a deposit.',
    isWithdrawAllowed: 'Determines whether a wallet user can initiate a withdrawal.',
  
    maxWithdrawalLimit: 'Determines the daily withdrawal limit amount per wallet user.',
    perMonthWithdrawalAmountLimit: `Determines the monthly withdrawal limit amount per wallet user.`,
    perYearWithdrawalAmountLimit: `Determines the yearly withdrawal limit amount per wallet user.`,
  
    perDayWithdrwalLimit: 'Determines the daily limit on the number of withdrawals allowed per wallet user.',
    perMonthWithdrawalTransactionLimit: `Determines the monthly limit on the number of withdrawals allowed per wallet user.`,
   
  }
  