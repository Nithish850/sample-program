export const onboardTier1DefaultRuleList = [ 'fullName', 'phoneNumber', 'countryCode', 'countryName', 'email', 'dob', 'residentialAddress', 'city', 'state', 'country', 'zipcode', 'ipAddress', 'latLong', 'cityLatLong', 'countryLatLong', "isProhibitedCountry", 'isProhibitedState' ];
export const onboardTier2DefaultRuleList = [ 'gidName', 'gidDob', 'gidPhoto', 'pepScreening', 'sanctionScreeningGeo',
  'sanctionScreeningName', 'selfPhoto', 'tin', 'driverLicense', 'stateIdLicense', 'passport', 'proffOfAddress',
  'govId', 'alienIdCard', 'nationalId', 'isProhibitedCountry', 'isProhibitedState' ];
export const transferDefaultRuleList = [ 'maxTransferLimit', 'perMonthTransferOutwardLimit', 'perDayTransferOutwardLimit', 'senderBalance', 'receiverStoredValue', 'intraTenants', 'extraTenant', 'tenantToTenantWalletUserExtra', 'WalletUserToTenantIntra', 'WalletUserToTenantExtra' ];
const commonDepositWithdrawKeys = [ 'minWalletBalance', 'senderAccountAddress', 'receiverAccountAddress', 'amount', 'counterParty', 'currency', 'transactionMethod' ];

export const depositDefaultRule = [ 'monthlyStoreLimit', ...commonDepositWithdrawKeys ];
export const withdrawDefaultRule = [ 'maxWithdrawalLimit', ...commonDepositWithdrawKeys ];

export const onboard_tier1_default_rule = {
  "name": "onboarding-tier1",
  "attributes": [
    {
      "name": "fullName",
      "type": "boolean"
    },
    {
      "name": "phoneNumber",
      "type": "boolean"
    },
    {
      "name": "countryCode",
      "type": "boolean"
    },
    {
      "name": "countryName",
      "type": "boolean"
    },
    {
      "name": "email",
      "type": "boolean"
    },
    {
      "name": "dob",
      "type": "boolean"
    },
    {
      "name": "residentialAddress",
      "type": "boolean"
    },
    {
      "name": "city",
      "type": "boolean"
    },
    {
      "name": "state",
      "type": "boolean"
    },
    {
      "name": "country",
      "type": "boolean"
    },
    {
      "name": "ipAddress",
      "type": "boolean"
    },
    {
      "name": "latLong",
      "type": "boolean"
    },
    {
      "name": "cityLatLong",
      "type": "boolean"
    },
    {
      "name": "countryLatLong",
      "type": "boolean"
    },
    {
      "name": "selfPhoto",
      "type": "boolean"
    },
    {
      "name": "isProhibitedCountry",
      "type": "boolean"
    },
    {
      "name": "isProhibitedState",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "fullName",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "phoneNumber",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "countryCode",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "countryName",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "email",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "dob",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "residentialAddress",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "city",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "state",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "country",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "ipAddress",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "selfPhoto",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "isProhibitedCountry",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "isProhibitedState",
            "operator": "equal",
            "value": false
          },
        ]
      },
      "event": {
        "type": "onboarding-tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const onboard_tier2_default_rule = {
  "name": "onboarding-tier2",
  "attributes": [
    {
      "name": "govId",
      "type": "boolean"
    },
    {
      "name": "gidName",
      "type": "boolean"
    },
    {
      "name": "gidDob",
      "type": "boolean"
    },
    {
      "name": "gidPhoto",
      "type": "boolean"
    },
    {
      "name": "gidNumber",
      "type": "boolean"
    },
    {
      "name": "gidCountry",
      "type": "boolean"
    },
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "govId",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "gidName",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "gidDob",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "gidPhoto",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "gidNumber",
            "operator": "equal",
            "value": true
          },
          {
            "fact": "gidCountry",
            "operator": "equal",
            "value": true
          },
        ]
      },
      "event": {
        "type": "onboarding-tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const transfer_tier0_default_rule = {
  "name": "transfer-tier0",
  "attributes": [
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "receiverStoredValue",
            "operator": "lessThanInclusive",
            "value": 5000
          },
          {
            "fact": "intraTenants",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "extraTenant",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantIntra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantExtra",
            "operator": "equal",
            "value": false
          }
        ]
      },
      "event": {
        "type": "transfer-tier0",
        "params": {
          "message": "Validated successfully"
        }
      }
    }
  ]
}

export const transfer_tier1_default_rule = {
  "name": "transfer-tier1",
  "attributes": [
    {
      "name": "maxTransferLimit",
      "type": "number"
    },
    {
      "name": "perMonthTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "perDayTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "senderBalance",
      "type": "number"
    },
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerMonth",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerYear",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    },
    {
      "name": "isBronzeReceiver",
      "type": "boolean"
    },
    {
      "name": "isSilverReceiver",
      "type": "boolean"
    },
    {
      "name": "isTenantReceiver",
      "type": 'boolean',
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxTransferLimit",
            "operator": "lessThanInclusive",
            "value": "500"
          },
          {
            "fact": "perMonthTransferOutwardLimit",
            "operator": "lessThanInclusive",
            "value": "100"
          },
          {
            "fact": "perDayTransferOutwardLimit",
            "operator": "lessThanInclusive",
            "value": "10"
          },
          {
            "fact": "senderBalance",
            "operator": "greaterThanInclusive",
            "value": "100"
          },
          {
            "fact": "maximumTransactionAmountPerMonth",
            "operator": "lessThanInclusive",
            "value": "1500"
          },
          {
            "fact": "maximumTransactionAmountPerYear",
            "operator": "lessThanInclusive",
            "value": "15000"
          },
          {
            "fact": "intraTenants",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "extraTenant",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantIntra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantExtra",
            "operator": "equal",
            "value": false
          },
          {
            "any": [
              {
                "all": [
                  {
                    "fact": "receiverStoredValue",
                    "operator": "lessThanInclusive",
                    "value": "500"
                  },
                  {
                    "fact": "isBronzeReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ],
              },
              {
                "all": [
                  {
                    "fact": "receiverStoredValue",
                    "operator": "lessThanInclusive",
                    "value": "5000"
                  },
                  {
                    "fact": "isSilverReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ]
              },
              {
                "all": [
                  {
                    "fact": "isTenantReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ]
              },
            ]
          }
        ]
      },
      "event": {
        "type": "transfer-tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const transfer_tier2_default_rule = {
  "name": "transfer-tier2",
  "attributes": [
    {
      "name": "maxTransferLimit",
      "type": "number"
    },
    {
      "name": "perMonthTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "perDayTransferOutwardLimit",
      "type": "number"
    },
    {
      "name": "senderBalance",
      "type": "number"
    },
    {
      "name": "receiverStoredValue",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerMonth",
      "type": "number"
    },
    {
      "name": "maximumTransactionAmountPerYear",
      "type": "number"
    },
    {
      "name": "intraTenants",
      "type": "boolean"
    },
    {
      "name": "extraTenant",
      "type": "boolean"
    },
    {
      "name": "tenantToTenantWalletUserExtra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantIntra",
      "type": "boolean"
    },
    {
      "name": "WalletUserToTenantExtra",
      "type": "boolean"
    },
    {
      "name": "isBronzeReceiver",
      "type": "boolean"
    },
    {
      "name": "isSilverReceiver",
      "type": "boolean"
    },
    {
      "name": "isTenantReceiver",
      "type": 'boolean',
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxTransferLimit",
            "operator": "lessThanInclusive",
            "value": "14999"
          },
          {
            "fact": "perMonthTransferOutwardLimit",
            "operator": "lessThanInclusive",
            "value": "200"
          },
          {
            "fact": "perDayTransferOutwardLimit",
            "operator": "lessThanInclusive",
            "value": "20"
          },
          {
            "fact": "senderBalance",
            "operator": "greaterThanInclusive",
            "value": "100"
          },
          {
            "fact": "maximumTransactionAmountPerMonth",
            "operator": "lessThanInclusive",
            "value": "10000"
          },
          {
            "fact": "maximumTransactionAmountPerYear",
            "operator": "lessThanInclusive",
            "value": "100000"
          },
          {
            "fact": "intraTenants",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "extraTenant",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "tenantToTenantWalletUserExtra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantIntra",
            "operator": "equal",
            "value": false
          },
          {
            "fact": "WalletUserToTenantExtra",
            "operator": "equal",
            "value": false
          },
          {
            "any": [
              {
                "all": [
                  {
                    "fact": "receiverStoredValue",
                    "operator": "lessThanInclusive",
                    "value": "500"
                  },
                  {
                    "fact": "isBronzeReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ],
              },
              {
                "all": [
                  {
                    "fact": "receiverStoredValue",
                    "operator": "lessThanInclusive",
                    "value": "5000"
                  },
                  {
                    "fact": "isSilverReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ]
              },
              {
                "all": [
                  {
                    "fact": "isTenantReceiver",
                    "operator": "equal",
                    "value": true,
                  }
                ]
              },
            ]
          }
        ]
      },
      "event": {
        "type": "transfer-tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const deposit_tier0_default_rule = {
  "name": "deposit_tier0",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": 14999
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": 10
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": 5
          }
        ]
      },
      "event": {
        "type": "deposit_tier0",
        "params": {
          "message": "Validated successfully"
        }
      }
    }
  ]
}

export const deposit_tier1_default_rule = {
  "name": "deposit_tier1",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "2000"
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "10"
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "5"
          }
        ]
      },
      "event": {
        "type": "deposit_tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const deposit_tier2_default_rule = {
  "name": "deposit_tier2",
  "attributes": [
    {
      "name": "perDayMaxDepositAmountLimit",
      "type": "number"
    },
    {
      "name": "perDayMaxDepositTransactionLimit",
      "type": "number"
    },
    {
      "name": "perMonthMaxDepositTransactionLimit",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "perDayMaxDepositAmountLimit",
            "operator": "lessThanInclusive",
            "value": "14999"
          },
          {
            "fact": "perMonthMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "10"
          },
          {
            "fact": "perDayMaxDepositTransactionLimit",
            "operator": "lessThanInclusive",
            "value": "5"
          }
        ]
      },
      "event": {
        "type": "deposit_tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier0_default_rule = {
  "name": "withdraw_tier0",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "minWalletBalance",
      "type": "number"
    },
    {
      "name": "perDayWithdrwalLimit",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": 14999
          },
          {
            "fact": "minWalletBalance",
            "operator": "greaterThanInclusive",
            "value": 100
          },
          {
            "fact": "perDayWithdrwalLimit",
            "operator": "lessThanInclusive",
            "value": 20000
          }
        ]
      },
      "event": {
        "type": "withdraw_tier0",
        "params": {
          "message": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier1_default_rule = {
  "name": "withdraw_tier1",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "minWalletBalance",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": "500"
          },
          {
            "fact": "minWalletBalance",
            "operator": "greaterThanInclusive",
            "value": "100"
          }
        ]
      },
      "event": {
        "type": "withdraw_tier1",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const withdraw_tier2_default_rule = {
  "name": "withdraw_tier2",
  "attributes": [
    {
      "name": "maxWithdrawalLimit",
      "type": "number"
    },
    {
      "name": "minWalletBalance",
      "type": "number"
    },
    {
      "name": "perDayWithdrwalLimit",
      "type": "number"
    }
  ],
  "decisions": [
    {
      "conditions": {
        "all": [
          {
            "fact": "maxWithdrawalLimit",
            "operator": "lessThanInclusive",
            "value": "14999"
          },
          {
            "fact": "minWalletBalance",
            "operator": "greaterThanInclusive",
            "value": "100"
          },
          {
            "fact": "perDayWithdrwalLimit",
            "operator": "lessThanInclusive",
            "value": "20000"
          }
        ]
      },
      "event": {
        "type": "withdraw_tier2",
        "params": {
          "messaged": "Validated successfully"
        }
      }
    }
  ]
}

export const rule_names = {
  onboard_tier1: 'Bronze Wallet user onboarding rule',
  onboard_tier2: 'Silver Wallet user onboarding rule',
  transfer_tier1: 'Bronze Wallet user onchain transfer rule',
  transfer_tier2: 'Silver Wallet user onchain transfer rule',
  deposit_tier1: 'Bronze Wallet User deposit rule',
  deposit_tier2: 'Silver Wallet User deposit rule',
  withdraw_tier1: 'Bronze Wallet User withdrawal rule',
  withdraw_tier2: 'Silver Wallet User withdrawal rule',
  transfer_tier0: 'Tenant wallet operational rule',
  deposit_tier0: 'Tenant wallet deposit rule',
  withdraw_tier0: 'Tenant wallet withdrawal rule'
}

export const rule_descriptions = {
  onboard_tier1: 'Rule defining onboarding conditions for Bronze wallet users',
  onboard_tier2: 'Rule defining onboarding conditions for Silver wallet users',
  transfer_tier1: 'Rules defining onchain transfer rules along with operational rules and conditions for bronze wallet user.',
  transfer_tier2: 'Rules defining onchain transfer rules along with operational rules and conditions for silver wallet user.',
  deposit_tier1: 'Rules defining deposit limits, wallet balance and daily deposit limits for silver wallet user',
  deposit_tier2: 'Rules defining deposit limits, wallet balance and daily deposit limits for silver wallet user',
  withdraw_tier1: 'Rules defining withdrawal limits, wallet balance and daily withdrawal limits for Bronze Wallet Users',
  withdraw_tier2: 'Rules defining withdrawal limits, wallet balance and daily withdrawal limits for Silver Wallet Users',
  transfer_tier0: 'Rules defining operational limits like receiver stored value, transfer rights to other tenants, tenant to wallet users etc.',
  deposit_tier0: 'Rules defining deposit limits, wallet balance and daily deposit limits for tenant wallet',
  withdraw_tier0: 'Rules defining withdrawal limits, wallet balance and daily withdrawal limits for tenant wallet',
}