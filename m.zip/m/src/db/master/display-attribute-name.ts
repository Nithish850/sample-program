export const display_attribute_name:object = {

  fullName: {
    display_attribute_name: 'Full Name',
    attribute_type: 'BOOLEAN'
  },
  maxTransferLimit: {
    display_attribute_name: 'Maximum Transfer Limit',
    attribute_type: 'NUMBER'
  },
  perDayMaxDepositAmountLimit: {
    display_attribute_name: 'Maximum Deposit Amount per Day',
    attribute_type: 'NUMBER'
  },
  maxWithdrawalLimit: {
    display_attribute_name: 'Maximum Withdrawal Limit',
    attribute_type: 'NUMBER'
  },
  gidName: {
    display_attribute_name: 'GID Name',
    attribute_type: 'BOOLEAN'
  },
  phoneNumber: {
    display_attribute_name: 'Phone Number',
    attribute_type: 'BOOLEAN'
  },
  perMonthTransferOutwardLimit: {
    display_attribute_name: 'Outward Transfer Limit per Month',
    attribute_type: 'NUMBER'
  },
  perMonthMaxDepositTransactionLimit: {
    display_attribute_name: 'Maximum Transaction Limit per Month',
    attribute_type: 'NUMBER'
  },
  minWalletBalance: {
    display_attribute_name: 'Minimum Wallet Balance',
    attribute_type: 'NUMBER'
  },
  gidDob: {
    display_attribute_name: 'GID DOB',
    attribute_type: 'BOOLEAN'
  },
  countryCode: {
    display_attribute_name: 'Country Code',
    attribute_type: 'BOOLEAN'
  },
  perDayTransferOutwardLimit: {
    display_attribute_name: 'Number of Outward Transactions Per Day',
    attribute_type: 'NUMBER'
  },
  perDayMaxDepositTransactionLimit: {
    display_attribute_name: 'Maximum Transaction Deposit Limit per Day',
    attribute_type: 'NUMBER'
  },
  perDayWithdrwalLimit: {
    display_attribute_name: 'Withdrawal Limit per Day',
    attribute_type: 'NUMBER'
  },
  gidPhoto: {
    display_attribute_name: 'GID Photo',
    attribute_type: 'BOOLEAN'
  },
  countryName: {
    display_attribute_name: 'Country Name',
    attribute_type: 'BOOLEAN'
  },
  senderBalance: {
    display_attribute_name: 'Sender Balance',
    attribute_type: 'NUMBER'
  },
  pepScreening: {
    display_attribute_name: 'PEP Screening',
    attribute_type: 'BOOLEAN'
  },
  email: {
    display_attribute_name: 'Email',
    attribute_type: 'BOOLEAN'
  },
  intraTenants: { display_attribute_name: 'Intra Tenant',
    attribute_type: 'BOOLEAN'
  },
  sanctionScreeningGeo: {
    display_attribute_name: 'Sanction Screening Geo',
    attribute_type: 'BOOLEAN'
  },
  dob: {
    display_attribute_name: 'DOB',
    attribute_type: 'BOOLEAN'
  },
  extraTenant: {
    display_attribute_name: 'Extra Tenant',
    attribute_type: 'BOOLEAN'
  },
  residentialAddress: {
    display_attribute_name: 'Residential Address',
    attribute_type: 'BOOLEAN'
  },
  selfPhoto: {
    display_attribute_name: 'Self Captured Photo',
    attribute_type: 'BOOLEAN'
  },
  tenantToTenantWalletUserExtra: {
    display_attribute_name: 'Tenant to Tenant Wallet Extra',
    attribute_type: 'BOOLEAN'
  },
  city: {
    display_attribute_name: 'City',
    attribute_type: 'BOOLEAN'
  },
  WalletUserToTenantIntra: {
    display_attribute_name: 'Wallet user to tenant Intra',
    attribute_type: 'BOOLEAN'
  },
  state: {
    display_attribute_name: 'State',
    attribute_type: 'BOOLEAN'
  },
  tin: {
    display_attribute_name: 'TIN',
    attribute_type: 'BOOLEAN'
  },
  WalletUserToTenantExtra: {
    display_attribute_name: 'Wallet User to Tenant Extra',
    attribute_type: 'BOOLEAN'
  },
  country: {
    display_attribute_name: 'Country',
    attribute_type: 'BOOLEAN'
  },
  driverLicense: {
    display_attribute_name: 'Driving License',
    attribute_type: 'BOOLEAN'
  },
  zipcode: {
    display_attribute_name: 'Zipcode',
    attribute_type: 'BOOLEAN'
  },
  stateIdLicense: {
    display_attribute_name: 'State ID License',
    attribute_type: 'BOOLEAN'
  },
  ipAddress: {
    display_attribute_name: 'IP Address',
    attribute_type: 'BOOLEAN'
  },
  passport: {
    display_attribute_name: 'Passport',
    attribute_type: 'BOOLEAN'
  },
  receiverStoredValue: {
    display_attribute_name: 'Receiver Stored Value',
    attribute_type: 'NUMBER'
  },
  latLong: {
    display_attribute_name: 'Lat-Long',
    attribute_type: 'BOOLEAN'
  },
  proffOfAddress: {
    display_attribute_name: 'Proof of Address',
    attribute_type: 'BOOLEAN'
  },
  isBronzeReceiver: {
    display_attribute_name: 'Is Bronze Receiver',
    attribute_type: 'BOOLEAN'
  },
  cityLatLong: {
    display_attribute_name: 'City Lat-Long',
    attribute_type: 'BOOLEAN'
  },
  countryLatLong: {
    display_attribute_name: 'Country Lat-Long',
    attribute_type: 'BOOLEAN'
  },
  isSilverReceiver: {
    display_attribute_name: 'Is Silver Receiver',
    attribute_type: 'BOOLEAN'
  },
  govId: {
    display_attribute_name: 'Government ID',
    attribute_type: 'BOOLEAN'
  },
  alienIdCard: {
    display_attribute_name: 'Alien ID Card',
    attribute_type: 'BOOLEAN'
  },
  nationalId: {
    display_attribute_name: 'National ID',
    attribute_type: 'BOOLEAN'
  },
  sanctionScreeningName: {
    display_attribute_name: 'Sanction Screening Name',
    attribute_type: 'BOOLEAN'
  },
  maxDepositTrxAmountPerMonth: {
    display_attribute_name: 'Maximum Deposit Transaction Amount per Month',
    attribute_type: 'NUMBER'
  },
  maxDepositTrxAmountPerYear: {
    display_attribute_name: 'Maximum Deposit Transaction Amount per Year',
    attribute_type: 'NUMBER'
  },
  maxWithdrawalTrxAmountPerMonth: {
    display_attribute_name: 'Maximum Withdrawal Transaction Amount per Month',
    attribute_type: 'NUMBER'
  },
  maxWithdrawalTrxAmountPerYear: {
    display_attribute_name: 'Maximum Withdrawal Transaction Amount per Year',
    attribute_type: 'NUMBER'
  },
  dailyDepositTrxAmountLimit: {
    display_attribute_name: 'Daily Deposit Transaction Limit',
    attribute_type: 'NUMBER'
  },
  dailyWithdrawalTrxAmountLimit: {
    display_attribute_name: 'Daily Withdrawal Transaction Limit',
    attribute_type: 'NUMBER'
  },
  maxDepositTrxCountDaily: {
    display_attribute_name: 'Maximum Deposit Transactions Daily',
    attribute_type: 'NUMBER'
  },
  maxDepositTrxCountMonthly: {
    display_attribute_name: 'Maximum Deposit Transactions Monthly',
    attribute_type: 'NUMBER'
  },
  maxWithdrawalTrxCountDaily: {
    display_attribute_name: 'Maximum Withdrawal Transactions Daily',
    attribute_type: 'NUMBER'
  },
  maxWithdrawalTrxCountMonthly: {
    display_attribute_name: 'Maximum Withdrawal Transactions Monthly',
    attribute_type: 'NUMBER'
  },
  storedValue: {
    display_attribute_name: 'Stored Value',
    attribute_type: 'NUMBER'
  },
}