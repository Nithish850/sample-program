/** Error codes to rep
 * resent rule_slug, rule_group */
export const errorCode = [ 'ULWT1001', 'ULWT1002', 'ULWT2003', 'ULWT2004', 'ULWT2005',
  'ULDT1001', 'ULDT1002', 'ULDT1003', 'ULDT2004', 'ULDT2005', 'ULDT2006',
  'ULTT1001', 'ULTT1002', 'ULTT1003', 'ULTT1004', 'ULTT1005', 'ULTT2006', 'ULTT2007', 'ULTT2008', 'ULTT2009', 'ULTT2010',
  'ULOT1001', 'ULOT1002', 'ULOT1003', 'ULOT1004', 'ULOT1005', 'ULOT1006', 'ULOT1007', 'ULOT1008', 'ULOT1009', 'ULOT1010', 'ULOT1011', 'ULOT1012', 'ULOT10013', 'ULOT1014', 'ULOT1015',
  'ULOT2016', 'ULOT2017', 'ULOT2018', 'ULOT2019', 'ULOT2020', 'ULOT2021', 'ULOT2022', 'ULOT2023', 'ULOT2024', 'ULOT2025', 'ULOT2026', 'ULOT2027', 'ULOT2028', 'ULOT2029', 'ULOT2030',
  'ULAC001', 'ULAC002', 'ULAC003', 'ULDB001', 'ULDB002', 'ULT002', 'ULT003', 'ULRULEGROUP001', 'ULNAMESPACE001', 'ULNAMESPACE002', 'ULTENANTACCOUNT001', 'ULTENANTACCOUNT002', 'ULACCOUNT001', 'ULACCOUNT002', 'ULGENERIC001' ];

/** Error group as per rule_group */
export const errorGroup = [ 'ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW', 'GENERAL', 'RULE', 'CHAIN', 'NAMESPACE', 'ACCOUNT' ];

/** Error tier as per rule_group */
export const errorSlug = [ 'tier0', 'tier1', 'tier2', 'tier3', 'generic', 'rule', 'account', 'namespace' ];

/** Error Code Seed Data */
export const businessErrorCodes = [
  {
    error_code: 'ULRULEGROUP001',
    error_reason: 'Not a valid rule group',
    error_group: 'RULE',
    error_slug: 'rule',
    error_attribute: 'invalidRuleGroup',
    error_description: 'Not a valid rule group',
  },
  {
    error_code: 'ULNAMESPACE001',
    error_reason: `Namespace not found for the sender address`,
    error_group: 'NAMESPACE',
    error_slug: 'namespace',
    error_attribute: 'senderNamespace',
    error_description: `Namespace not found for the sender address`,
  },
  {
    error_code: 'ULNAMESPACE002',
    error_reason: `Namespace not found for the receiver address`,
    error_group: 'NAMESPACE',
    error_slug: 'namespace',
    error_attribute: 'receiverNamespace',
    error_description: `Namespace not found for the receiver address`,
  },
  {
    error_code: 'ULTENANTACCOUNT001',
    error_reason: `Sender's tenant account status is blocked`,
    error_group: 'ACCOUNT',
    error_slug: 'account',
    error_attribute: 'senderTenantAccount',
    error_description: `Sender's tenant account status is blocked`,
  },
  {
    error_code: 'ULTENANTACCOUNT002',
    error_reason: `Receiver's tenant account status is blocked`,
    error_group: 'ACCOUNT',
    error_slug: 'account',
    error_attribute: 'receiverTenantAccount',
    error_description: `Receiver's tenant account status is blocked`,
  },
  {
    error_code: 'ULACCOUNT001',
    error_reason: `Sender's account is blocked`,
    error_group: 'ACCOUNT',
    error_slug: 'account',
    error_attribute: 'senderUserAccount',
    error_description: `Sender's account is blocked`,
  },
  {
    error_code: 'ULACCOUNT002',
    error_reason: `Receiver's account is blocked`,
    error_group: 'ACCOUNT',
    error_slug: 'account',
    error_attribute: 'receiverUserAccount',
    error_description: `Receiver's account is blocked`,
  },
  {
    error_code: 'ULGENERIC001',
    error_reason: 'Technical issue occured',
    error_group: 'GENERAL',
    error_slug: 'generic',
    error_attribute: 'genericTechnical',
    error_description: 'Technical issue occured',
  }
];
