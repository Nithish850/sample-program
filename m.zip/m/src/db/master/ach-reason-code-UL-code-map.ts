/* eslint-disable no-useless-escape */
export const achReasonCodeULCodeMap =
[
  {
    "code": "A00",
    "cliq_description": "Transaction Submitted for Settlment",
    "ul_response_code": "ULACH1",
    "ul_description": "Transaction Submitted for Settlment"
  },
  {
    "code": "X00",
    "cliq_description": "Unknown Exception",
    "ul_response_code": "ULACH2",
    "ul_description": "Unknown Exception"
  },
  {
    "code": "X01",
    "cliq_description": "Invalid Merchant ID",
    "ul_response_code": "ULACH3",
    "ul_description": "Invalid UL Credentials Passed"
  },
  {
    "code": "X02",
    "cliq_description": "Merchant On Hold",
    "ul_response_code": "ULACH4",
    "ul_description": "Merchant On Hold"
  },
  {
    "code": "X03",
    "cliq_description": "Merchant Batch On Hold",
    "ul_response_code": "ULACH5",
    "ul_description": "Merchant Batch On Hold"
  },
  {
    "code": "X04",
    "cliq_description": "Invalid Or Missing Customer Name",
    "ul_response_code": "ULACH6",
    "ul_description": "Invalid Or Missing Customer Name"
  },
  {
    "code": "X05",
    "cliq_description": "Invalid Account Type (C\/S)",
    "ul_response_code": "ULACH7",
    "ul_description": "Invalid Account Type "
  },
  {
    "code": "X06",
    "cliq_description": "Invalid Direction (D\/C)",
    "ul_response_code": "ULACH8",
    "ul_description": "Invalid Direction "
  },
  {
    "code": "X07",
    "cliq_description": "Invalid ABA",
    "ul_response_code": "ULACH9",
    "ul_description": "Invalid Routing Number"
  },
  {
    "code": "X08",
    "cliq_description": "Invalid Account Number (4 to 17 digits)",
    "ul_response_code": "ULACH10",
    "ul_description": "Invalid Account Number "
  },
  {
    "code": "X09",
    "cliq_description": "Amount must be greater than zero",
    "ul_response_code": "ULACH11",
    "ul_description": "Amount must be greater than zero"
  },
  {
    "code": "X10",
    "cliq_description": "Invalid Or Missing Reference Id",
    "ul_response_code": "ULACH12",
    "ul_description": "Invalid Or Missing Reference Id"
  },
  {
    "code": "X11",
    "cliq_description": "Invalid Or Missing Input",
    "ul_response_code": "ULACH13",
    "ul_description": "Invalid Or Missing Input"
  },
  {
    "code": "X17",
    "cliq_description": "Matching payment not found",
    "ul_response_code": "ULACH14",
    "ul_description": "Matching payment not found"
  },
  {
    "code": "X18",
    "cliq_description": "Payment already refunded",
    "ul_response_code": "ULACH15",
    "ul_description": "Payment already refunded"
  },
  {
    "code": "X19",
    "cliq_description": "Duplicate payment found",
    "ul_response_code": "ULACH16",
    "ul_description": "Duplicate payment found"
  },
  {
    "code": "X22",
    "cliq_description": "Failed to create payment",
    "ul_response_code": "ULACH17",
    "ul_description": "Failed to create payment"
  },
  {
    "code": "X26",
    "cliq_description": "Payment canceled not processed",
    "ul_response_code": "ULACH18",
    "ul_description": "Payment canceled not processed"
  },
  {
    "code": "X27",
    "cliq_description": "Invalid SEC Code (WEB\/PPD\/TEL\/CCD)",
    "ul_response_code": "ULACH19",
    "ul_description": "Invalid SEC Code "
  },
  {
    "code": "X28",
    "cliq_description": "Total credit limit exceeded",
    "ul_response_code": "ULACH20",
    "ul_description": "Total credit limit exceeded"
  },
  {
    "code": "X34",
    "cliq_description": "Invalid Service Source",
    "ul_response_code": "ULACH21",
    "ul_description": "Invalid Service Source"
  },
  {
    "code": "X35",
    "cliq_description": "Invalid Service Type",
    "ul_response_code": "ULACH22",
    "ul_description": "Invalid Service Type"
  },
  {
    "code": "X36",
    "cliq_description": "Invalid File Version",
    "ul_response_code": "ULACH23",
    "ul_description": "Invalid File Version"
  },
  {
    "code": "X37",
    "cliq_description": "Redundant Section",
    "ul_response_code": "ULACH24",
    "ul_description": "Redundant Section"
  },
  {
    "code": "X38",
    "cliq_description": "Invalid Section",
    "ul_response_code": "ULACH25",
    "ul_description": "Invalid Section"
  },
  {
    "code": "X39",
    "cliq_description": "Duplicate File",
    "ul_response_code": "ULACH26",
    "ul_description": "Duplicate File"
  },
  {
    "code": "X40",
    "cliq_description": "Section Missing",
    "ul_response_code": "ULACH27",
    "ul_description": "Section Missing"
  },
  {
    "code": "X41",
    "cliq_description": "Element Count Error",
    "ul_response_code": "ULACH28",
    "ul_description": "Element Count Error"
  },
  {
    "code": "X42",
    "cliq_description": "Invalid Transaction Type",
    "ul_response_code": "ULACH29",
    "ul_description": "Invalid Transaction Type"
  },
  {
    "code": "X43",
    "cliq_description": "Invalid Amount",
    "ul_response_code": "ULACH30",
    "ul_description": "Invalid Amount"
  },
  {
    "code": "X44",
    "cliq_description": "Mismatch Merchandise",
    "ul_response_code": "ULACH31",
    "ul_description": "Mismatch Merchandise"
  },
  {
    "code": "X99",
    "cliq_description": "Invalid input line",
    "ul_response_code": "ULACH32",
    "ul_description": "Invalid input line"
  },
  {
    "code": "C01",
    "cliq_description": "Incorrect DFI Account Number ",
    "ul_response_code": "ULACH33",
    "ul_description": "Incorrect DFI Account Number "
  },
  {
    "code": "C02",
    "cliq_description": "Incorrect Transit\/Routing Number ",
    "ul_response_code": "ULACH34",
    "ul_description": "Incorrect Transit\/Routing Number "
  },
  {
    "code": "C03",
    "cliq_description": "Incorrect Transit\/Routing Number and Incorrect DFI Account Number",
    "ul_response_code": "ULACH35",
    "ul_description": "Incorrect Transit\/Routing Number and Incorrect DFI Account Number"
  },
  {
    "code": "C04",
    "cliq_description": "Incorrect Individual Name\/ Receiving Company Name ",
    "ul_response_code": "ULACH36",
    "ul_description": "Incorrect Individual Name\/ Receiving Company Name "
  },
  {
    "code": "C05",
    "cliq_description": "Incorrect Transaction Code ",
    "ul_response_code": "ULACH37",
    "ul_description": "Incorrect Transaction Code "
  },
  {
    "code": "C06",
    "cliq_description": "Incorrect DFI Account Number and Incorrect Transaction Code",
    "ul_response_code": "ULACH38",
    "ul_description": "Incorrect DFI Account Number and Incorrect Transaction Code"
  },
  {
    "code": "C07",
    "cliq_description": "Incorrect Transit\/Routing Number, Incorrect DFI Account Number, and Incorrect",
    "ul_response_code": "ULACH39",
    "ul_description": "Incorrect Transit\/Routing Number, Incorrect DFI Account Number, and Incorrect"
  },
  {
    "code": "C08",
    "cliq_description": "Incorrect Foreign Receiving DFI Identification ",
    "ul_response_code": "ULACH40",
    "ul_description": "Incorrect Foreign Receiving DFI Identification "
  },
  {
    "code": "C09",
    "cliq_description": "Incorrect Individual Identification Number ",
    "ul_response_code": "ULACH41",
    "ul_description": "Incorrect Individual Identification Number "
  },
  {
    "code": "C10",
    "cliq_description": "Incorrect Company Name ",
    "ul_response_code": "ULACH42",
    "ul_description": "Incorrect Company Name "
  },
  {
    "code": "C11",
    "cliq_description": "Incorrect Company Identification ",
    "ul_response_code": "ULACH43",
    "ul_description": "Incorrect Company Identification "
  },
  {
    "code": "C12",
    "cliq_description": "Incorrect Company Name and Company Identification ",
    "ul_response_code": "ULACH44",
    "ul_description": "Incorrect Company Name and Company Identification "
  },
  {
    "code": "C13",
    "cliq_description": "Addenda Format Error ",
    "ul_response_code": "ULACH45",
    "ul_description": "Addenda Format Error "
  },
  {
    "code": "C61",
    "cliq_description": "Misrouted Notification of Change ",
    "ul_response_code": "ULACH46",
    "ul_description": "Misrouted Notification of Change "
  },
  {
    "code": "C62",
    "cliq_description": "Incorrect Trace Number ",
    "ul_response_code": "ULACH47",
    "ul_description": "Incorrect Trace Number "
  },
  {
    "code": "C63",
    "cliq_description": "Incorrect Company Identification Number ",
    "ul_response_code": "ULACH48",
    "ul_description": "Incorrect Company Identification Number "
  },
  {
    "code": "C64",
    "cliq_description": "Incorrect Individual Identification Number ",
    "ul_response_code": "ULACH49",
    "ul_description": "Incorrect Individual Identification Number "
  },
  {
    "code": "C65",
    "cliq_description": "Incorrectly Formatted Corrected Data ",
    "ul_response_code": "ULACH50",
    "ul_description": "Incorrectly Formatted Corrected Data "
  },
  {
    "code": "R36",
    "cliq_description": "Return of improper credit entry ",
    "ul_response_code": "ULACH51",
    "ul_description": "Return of improper credit entry "
  },
  {
    "code": "R37",
    "cliq_description": "Source Document Presented for Payment ",
    "ul_response_code": "ULACH52",
    "ul_description": "Source Document Presented for Payment "
  },
  {
    "code": "R38",
    "cliq_description": "Stop Payment on Source Document ",
    "ul_response_code": "ULACH53",
    "ul_description": "Stop Payment on Source Document "
  },
  {
    "code": "R39",
    "cliq_description": "Improper Source Document ",
    "ul_response_code": "ULACH54",
    "ul_description": "Improper Source Document "
  },
  {
    "code": "R40",
    "cliq_description": "Return of ENR entry by Federal Government Agency (ENR Only)",
    "ul_response_code": "ULACH55",
    "ul_description": "Return of ENR entry by Federal Government Agency (ENR Only)"
  },
  {
    "code": "R41",
    "cliq_description": "Invalid transaction code (ENR Only) ",
    "ul_response_code": "ULACH56",
    "ul_description": "Invalid transaction code (ENR Only) "
  },
  {
    "code": "R42",
    "cliq_description": "Routing number\/check digit error (ENR only) ",
    "ul_response_code": "ULACH57",
    "ul_description": "Routing number\/check digit error (ENR only) "
  },
  {
    "code": "R43",
    "cliq_description": "Invalid DFI account number (ENR only) ",
    "ul_response_code": "ULACH58",
    "ul_description": "Invalid DFI account number (ENR only) "
  },
  {
    "code": "R44",
    "cliq_description": "Invalid individual ID number (ENR only) ",
    "ul_response_code": "ULACH59",
    "ul_description": "Invalid individual ID number (ENR only) "
  },
  {
    "code": "R45",
    "cliq_description": "Invalid individual name\/company name (ENR only) ",
    "ul_response_code": "ULACH60",
    "ul_description": "Invalid individual name\/company name (ENR only) "
  },
  {
    "code": "R46",
    "cliq_description": "Invalid representative payee indicator (ENR only) ",
    "ul_response_code": "ULACH61",
    "ul_description": "Invalid representative payee indicator (ENR only) "
  },
  {
    "code": "R47",
    "cliq_description": "Duplicate enrollment ",
    "ul_response_code": "ULACH62",
    "ul_description": "Duplicate enrollment "
  },
  {
    "code": "R50",
    "cliq_description": "State Law Affecting RCK Acceptance ",
    "ul_response_code": "ULACH63",
    "ul_description": "State Law Affecting RCK Acceptance "
  },
  {
    "code": "R51",
    "cliq_description": "Item is Ineligible, Notice Not Provided, Signature not genuine, Signature Not Genuine, Item Altered,",
    "ul_response_code": "ULACH64",
    "ul_description": "Item is Ineligible, Notice Not Provided, Signature not genuine, Signature Not Genuine, Item Altered,"
  },
  {
    "code": "R52",
    "cliq_description": "Stop Payment on Item ",
    "ul_response_code": "ULACH65",
    "ul_description": "Stop Payment on Item "
  },
  {
    "code": "R53",
    "cliq_description": "Item and ACH Entry Presented for Payment ",
    "ul_response_code": "ULACH66",
    "ul_description": "Item and ACH Entry Presented for Payment "
  },
  {
    "code": "R61",
    "cliq_description": "Misrouted return ",
    "ul_response_code": "ULACH67",
    "ul_description": "Misrouted return "
  },
  {
    "code": "R62",
    "cliq_description": "Incorrect trace number ",
    "ul_response_code": "ULACH68",
    "ul_description": "Incorrect trace number "
  },
  {
    "code": "R63",
    "cliq_description": "Incorrect dollar amount ",
    "ul_response_code": "ULACH69",
    "ul_description": "Incorrect dollar amount "
  },
  {
    "code": "R64",
    "cliq_description": "Incorrect individual identification ",
    "ul_response_code": "ULACH70",
    "ul_description": "Incorrect individual identification "
  },
  {
    "code": "R65",
    "cliq_description": "Incorrect transaction code ",
    "ul_response_code": "ULACH71",
    "ul_description": "Incorrect transaction code "
  },
  {
    "code": "R66",
    "cliq_description": "Incorrect company identification ",
    "ul_response_code": "ULACH72",
    "ul_description": "Incorrect company identification "
  },
  {
    "code": "R67",
    "cliq_description": "Duplicate return ",
    "ul_response_code": "ULACH73",
    "ul_description": "Duplicate return "
  },
  {
    "code": "R68",
    "cliq_description": "Untimely Return ",
    "ul_response_code": "ULACH74",
    "ul_description": "Untimely Return "
  },
  {
    "code": "R69",
    "cliq_description": "Field Error(s) ",
    "ul_response_code": "ULACH75",
    "ul_description": "Field Error(s) "
  },
  {
    "code": "R70",
    "cliq_description": "Permissible return entry not accepted\/ Return Not Requested by ODFI",
    "ul_response_code": "ULACH76",
    "ul_description": "Permissible return entry not accepted\/ Return Not Requested by ODFI"
  },
  {
    "code": "R71",
    "cliq_description": "Misrouted dishonored return ",
    "ul_response_code": "ULACH77",
    "ul_description": "Misrouted dishonored return "
  },
  {
    "code": "R72",
    "cliq_description": "Untimely dishonored return ",
    "ul_response_code": "ULACH78",
    "ul_description": "Untimely dishonored return "
  },
  {
    "code": "R73",
    "cliq_description": "Timely original return ",
    "ul_response_code": "ULACH79",
    "ul_description": "Timely original return "
  },
  {
    "code": "R74",
    "cliq_description": "Corrected return ",
    "ul_response_code": "ULACH80",
    "ul_description": "Corrected return "
  },
  {
    "code": "R75",
    "cliq_description": "Original Return Not a Duplicate ",
    "ul_response_code": "ULACH81",
    "ul_description": "Original Return Not a Duplicate "
  },
  {
    "code": "R76",
    "cliq_description": "No Errors Found ",
    "ul_response_code": "ULACH82",
    "ul_description": "No Errors Found "
  },
  {
    "code": "R80",
    "cliq_description": "Cross‐Border Payment Coding Error ",
    "ul_response_code": "ULACH83",
    "ul_description": "Cross‐Border Payment Coding Error "
  },
  {
    "code": "R81",
    "cliq_description": "Non‐Participant in Cross‐Border Program ",
    "ul_response_code": "ULACH84",
    "ul_description": "Non‐Participant in Cross‐Border Program"
  },
  {
    "code": "R82",
    "cliq_description": "Invalid Foreign Receiving DFI Identification ",
    "ul_response_code": "ULACH85",
    "ul_description": "Invalid Foreign Receiving DFI Identification "
  },
  {
    "code": "R83",
    "cliq_description": "Foreign Receiving DFI Unable to Settle ",
    "ul_response_code": "ULACH86",
    "ul_description": "Foreign Receiving DFI Unable to Settle "
  },
  {
    "code": "R84",
    "cliq_description": "Entry Not Processed by OGO ",
    "ul_response_code": "ULACH87",
    "ul_description": "Entry Not Processed by OGO "
  }
]