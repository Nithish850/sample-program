export const entities = [
  {
    business_entity_name: 'Sole proprietorship',
    description: 'Business type and Id',
    is_active: true
  },
  {
    business_entity_name: 'A partnership or unincorporated business',
    description: 'Business type and Id',
    is_active: true
  },
  {
    business_entity_name: 'Company or corporation',
    description: 'Business type and Id',
    is_active: true
  },
  {
    business_entity_name: 'Public sector bodies, state owned companies and supranationals',
    description: 'Business type and Id',
    is_active: true
  },
  {
    business_entity_name: 'Non-profit organization',
    description: 'Business type and Id',
    is_active: true
  },
  {
    business_entity_name: 'Trusts or foundations',
    description: 'Business type and Id',
    is_active: true
  },
]