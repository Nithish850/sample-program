export const financialBadgeAttributeDisplayNames = [
   
    {
      attribute_name: 'isWithdrawAllowed',
      display_attribute_name: 'Is Withdrawal Allowed'
    },

    {
      attribute_name: 'isDepositAllowed',
      display_attribute_name: 'Is Deposit Allowed'
    },
   
    {
      attribute_name: 'maxTransferLimit',
      display_attribute_name: 'Transfer Amount Per Day'
    },
   
    {
      attribute_name: 'receiverStoredValue',
      display_attribute_name: 'Receiver Maximum Wallet Balance'
    },
   
    {
      attribute_name: 'senderBalance',
      display_attribute_name: 'Sender Minimum Wallet Balance'
    },
   
    {
      attribute_name: 'maximumTransactionAmountPerYear',
      display_attribute_name: 'Transfer Amount Per Year'
    },

    {
      attribute_name: 'maximumTransactionAmountPerMonth',
      display_attribute_name: 'Transfer Amount Per Month'
    }

  ]