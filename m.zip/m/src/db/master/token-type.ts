export const tokenTypeList = [
  {
    "token_type": "DEPOSIT TOKEN",
    "description": "Deposit Token",
    "display_name": "Deposit Token",
  },
  {
    "token_type": "STABLECOIN",
    "description": "Stablecoin",
    "display_name": "Stablecoin",
  },
  {
    "token_type": "UTILITY TOKEN",
    "description": "Utility Token",
    "display_name": "Utility Token",
  },
  {
    "token_type": "DIGITAL ASSET",
    "description": "Digital Asset",
    "display_name": "Digital Asset",
  },
]