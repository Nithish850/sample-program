export const defaultRoles = (tenantId: string, createdBy: string): any => [ {
  role_name: 'TENANT_USER_ADMINISTRATIVE',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
},
{
  role_name: 'TENANT_COMPLIANCE',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
},
{
  role_name: 'MARKETING',
  tenant_id: tenantId,
  is_active: true,
  type: 'DEFAULT',
  created_by: createdBy
}];