/* eslint-disable no-console */
exports.seed = async function (knex) {
  console.log('seed running: 002-default-tenant-rule-status-approved');
  const tenantData = await knex('tenants').select('tenant_id').where({ domain: 'ul-ledger' });
  const ruleIdList = await knex('rules').select('rule_id').where({ tenant_id: tenantData[0].tenant_id });

  for(const { rule_id } of ruleIdList) {
    /* eslint-disable no-await-in-loop */
    await knex('tenant_rules').where({ rule_id })
      .update({
        status: 'approved'
      })
  }
  console.log('seed completed: 002-default-tenant-rule-status-approved');
};
