/* eslint-disable @typescript-eslint/no-var-requires */
/**
 * import path from path
 */
const path = require('path');

import { getEnvPath } from '../common/helper/env.helper';
/**
 * get the path to env files defined
 */
const dirPath = path.join(__dirname, '../common/envs');
/**
 * get the env file path loaded
 */
const envFilePath: string = getEnvPath(dirPath);

import * as dotenv from 'dotenv';
dotenv.config({ path: envFilePath });
module.exports[process.env.NODE_ENV] = {
  client: 'postgresql',
  connection: `postgres://${process.env.DB_USER}:${process.env.DB_PWD}@${process.env.DB_HOST}/${process.env.DB_NAME}?sslmode=require`,
  seeds: {
    directory: './seeds',
  },
  pool: {
    min: 2,
    max: 10,
  },
  migrations: {
    tableName: 'knex_migrations',
    directory: './migrations',
  },
};
