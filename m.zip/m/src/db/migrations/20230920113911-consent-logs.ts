exports.up = function (knex) {
  return knex.schema.createTable('consent_logs', (table) => {
    table.uuid('consent_log_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('customer_account_id');
    table.string('partner_name').notNullable();
    table.string('namespace').notNullable();
    table.string('consent_version').notNullable();
    table.string('status').notNullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('consent_logs')
}