/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'offchain_transaction';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter table columns to text for encryption
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN full_name TYPE text,
      ALTER COLUMN sender_namespace TYPE text,
      ALTER COLUMN receiver_namespace TYPE text,
      ALTER COLUMN ip_address TYPE text,
      ALTER COLUMN tenant_namespace TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 2: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          full_name = encrypt(full_name::bytea, '${val}'::bytea, 'aes'::text),
          sender_namespace = encrypt(sender_namespace::bytea, '${val}'::bytea, 'aes'::text),
          receiver_namespace = encrypt(receiver_namespace::bytea, '${val}'::bytea, 'aes'::text),
          ip_address = encrypt(ip_address::bytea, '${val}'::bytea, 'aes'::text),
          tenant_namespace = encrypt(tenant_namespace::bytea, '${val}'::bytea, 'aes'::text);
    `);

    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 3: Insert entries into encryption_decryption for recipient_list column
    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'full_name' },
      { table_name: tableName , column_name: 'sender_namespace' },
      { table_name: tableName , column_name: 'receiver_namespace' },
      { table_name: tableName , column_name: 'ip_address' },
      { table_name: tableName , column_name: 'tenant_namespace' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        full_name = convert_from(decrypt(full_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        sender_namespace = convert_from(decrypt(sender_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        receiver_namespace = convert_from(decrypt(receiver_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        ip_address = convert_from(decrypt(ip_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tenant_namespace = convert_from(decrypt(tenant_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 3: Remove entries from encryption_decryption for recipient_list column
    console.log(`Removing entries from encryption_decryption for ${tableName} column...`);
    await knex('encryption_decryption')
      .where({ table_name: tableName })
      .whereIn('column_name', ['full_name', 'sender_namespace', 'receiver_namespace', 'ip_address', 'tenant_namespace'])
      .delete();
    console.log(`Entries removed from encryption_decryption for ${tableName} column.`);

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
