exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.jsonb('business_industries');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.jsonb('business_industries');
  });
}