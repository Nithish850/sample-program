exports.up = function (knex) {
  return knex.schema.createTable('badge', (table) => {
    table
      .uuid('badge_id')
      .primary()
      .defaultTo(knex.raw('gen_random_uuid()'))
      .notNullable();
    table.string('badge_name').notNullable().unique();
    table.string('badge_type').notNullable();
    table.string('badge_description');
    table.string('user_group');
    table.string('badge_symbol_ref');
    table.string('created_by');
    table.timestamps(true, true);
  }).alterTable('tenant_customer_accounts', (table) => {
    table.uuid('badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('badge').dropTable('tenant_customer_accounts');
};