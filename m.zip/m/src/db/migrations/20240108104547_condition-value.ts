exports.up = async function (knex) {
  await knex.schema.alterTable('rules_conditions', (table) => {
    table.text('attribute_value').notNullable().alter();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('rules_conditions', (table) => {
    table.string('attribute_value').alter();
  });};
