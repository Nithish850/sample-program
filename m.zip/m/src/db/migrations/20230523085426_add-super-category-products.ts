exports.up = async function(knex) {
  await knex.schema.alterTable('products', (table) => {
    table.string('super_category');
  });

  await knex('products').where('category', 'Tenant Wallet').update({
    'super_category': 'Tenant Wallet',
    'default_flag': true,
  });

  await knex('products').whereNot('category', 'Tenant Wallet').update({
    'super_category': 'Customer Wallet',
    'default_flag': true,
  });

  await knex('products').where({
    'super_category': 'Tenant Wallet',
    'sub_category': 'Transfers',
  })
    .update({
      'category': 'Onchain Transfers',
    });

  await knex('products').where({
    'super_category': 'Tenant Wallet',
  })
    .whereNot({
      'sub_category': 'Transfers',
    })
    .update({
      'category': 'Offchain Transactions',
    });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('products', (table) => {
    table.dropColumn('super_category');
  });
};
