/* eslint-disable no-console */
/* eslint-disable no-invalid-this */

const filterBySymbol = (query) => {
  query.where('symbol', 'FEEMANAGER').orWhere('symbol', 'EVENTEMITTER');
};

exports.up = async function (knex) {
  try {
    await knex('token_type').insert({
      token_type: 'UTILITY CONTRACT',
      description:
        'All utility contracts like fee manager, event emitter will have this type',
      display_name: 'UTILITY CONTRACT',
    });

    await knex.schema.table('contract_store', (table) => {
      table.boolean('is_visible').defaultTo(true);
    });

    await knex('contract_store').where(filterBySymbol).update({
      is_visible: false,
      token_type: 'UTILITY CONTRACT',
    });
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
};

exports.down = async function (knex) {
  try {
    await knex('contract_store').where(filterBySymbol).update({
      token_type: 'STABLECOIN',
    });

    await knex.schema.table('contract_store', (table) => {
      table.dropColumn('is_visible');
    });

    await knex('token_type').where({ token_type: 'UTILITY CONTRACT' }).delete();
  } catch (error) {
    console.error('Rollback failed:', error);
    throw error;
  }
};
