exports.up = function (knex) {
  return knex.schema.createTable('compliance_details', (table) => {
    table
      .uuid('compliance_details_id')
      .primary()
      .defaultTo(knex.raw('gen_random_uuid()'))
      .notNullable();
    table
      .uuid('customer_account_id')
      .references('customer_account_id')
      .inTable('customer_accounts')
      .onDelete('CASCADE')
      .onUpdate('CASCADE');
    table.jsonb('risk_profile');
    table.jsonb('finclusive_risk_profile');
    table.jsonb('risk_score');
    table.jsonb('reasons');
    table.jsonb('rules');
    table.uuid('compliance_risk_assessment_reference_id');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('compliance_details');
};
