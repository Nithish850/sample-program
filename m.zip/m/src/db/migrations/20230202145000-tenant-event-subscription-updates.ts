/** function to create errors DB */
exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_event_subscription', (table) => {
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
  });
};

/** function to bring down errors DB */
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_event_subscription');
};
