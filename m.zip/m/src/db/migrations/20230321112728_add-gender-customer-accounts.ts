exports.up = async function(knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.enu('gender', [ 'MALE', 'FEMALE', 'OTHERS', 'UNKNOWN' ]).defaultTo('UNKNOWN');
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('gender');
  });
};
