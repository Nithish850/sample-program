exports.up = function (knex) {
  return knex.schema.createTable('agreements', (table) => {
    table.uuid('agreement_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.uuid('customer_account_id');
    table.string('id').notNullable();
    table.text('content').notNullable();
    table.enu('status', [ 'PENDING', 'ACCEPTED', 'REJECTED' ]).notNullable().defaultTo('PENDING');
    table.jsonb('payload').notNullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('agreements')
}