import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
    await knex.schema.alterTable('required_attributes', function(table) {
        table.dropColumn('mandatory_attribute');
        table.boolean('mandatory_badge').defaultTo(false);
        table.boolean('mandatory_onboard').defaultTo(false);
    });
    
    return await knex.schema.renameTable('required_attributes', 'unique_identifiers');
}



export async function down(knex: Knex): Promise<void> {
    return knex.schema.dropTableIfExists('mandatory_onboard');
}

