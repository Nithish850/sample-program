exports.up = function (knex) {
  return knex.schema.alterTable('bulk_transactions', (table) => {
    table.boolean('is_recurring').defaultTo(false);
    table.date('recurring_start_date');
    table.date('recurring_end_date');
    table.string('recurring_frequency');
  })
    .createTable('recurring_transactions', (table) => {
      table.uuid('recurring_transaction_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('bulk_transaction_id').references('bulk_transaction_id').inTable('bulk_transactions').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.enu('occurrence_status', [ 'PROCESSED', 'PENDING', 'CANCELLED', 'REVERSAL', 'REJECTED', 'FAILED', 'COMPLETED' ]).defaultTo('PENDING');
      table.string('reject_reason');
      table.date('scheduled_time');
      table.date('processed_time');
      table.integer('freezed_amount').notNullable().defaultTo(0);
      table.boolean('is_fund_freezed').notNullable().defaultTo(false);
      table.dateTime('fund_freezed_time');
      table.dateTime('fund_unfreezed_time');
      table.timestamps(true, true);
    })
    .createTable('config_parameters', (table) => {
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('name').primary();
      table.string('value').notNull();
      table.string('unit').notNull();
      table.string('type').notNull();
      table.string('description');
      table.timestamps(true, true);
    })
};

exports.down = function (knex) {
  return knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('is_recurring');
    table.dropColumn('start_date');
    table.dropColumn('end_date');
    table.dropColumn('recurring_frequency');
  })
    .dropTable('recurring_transactions')
    .dropTable('config_parameters');
};