exports.up = async function (knex) {
  await knex.schema.alterTable('namespaces', (table) => {
    table.boolean('is_deleted').notNullable().defaultTo(false);
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('namespaces', (table) => {
    table.boolean('is_deleted').notNullable().defaultTo(false);
  });
};
