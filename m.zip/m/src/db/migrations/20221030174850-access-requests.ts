exports.up = function (knex) {
  return knex.schema.createTable('access_requests', function (table) {
    table.uuid('access_requests_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('email').notNullable().unique();
    table.enu('lead_status', [ 'PENDING', 'ACCEPTED', 'DECLINED' ]).notNullable().defaultTo('PENDING');
    table.string('activation_code').unique();
    table.boolean('is_activated').notNullable().defaultTo(false);
    table.string('device_type');
    table.text('device_token');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('access_requests');
};
