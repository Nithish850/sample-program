exports.up = async function (knex) {
    await knex.schema.alterTable('offchain_transaction', (table) => {
      table.string('burn_status', [ 'PENDING', 'COMPLETED', 'FAILED' ]).notNullable().defaultTo('PENDING');
    })
  }
  
  exports.down = async function (knex) {
    await knex.schema.dropColumn('burn_status')
  }