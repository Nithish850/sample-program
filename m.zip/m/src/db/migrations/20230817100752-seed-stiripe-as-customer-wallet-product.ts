const stripeDetails = [
  {
    category: 'Offchain Transactions',
    sub_category: 'Deposits',
    type: 'Credit Card',
    type_desc: 'Enable Deposit using Credit Card by toggling ON. By toggling OFF ACH, only Deposits using Credit Card will be disabled.',
    default_flag: false,
    super_category: 'Customer Wallet',
    partner: 'STRIPE'
  },
  {
    category: 'Offchain Transactions',
    sub_category: 'Deposits',
    type: 'Debit Card',
    type_desc: 'Enable Deposit using Debit Card by toggling ON. By toggling OFF Debit Card, only Deposits using Debit Card will be disabled.',
    default_flag: false,
    super_category: 'Customer Wallet',
    partner: 'STRIPE'
  },
]

exports.up = async function (knex) {
  await knex('products').insert(stripeDetails);
};

exports.down = async function (knex) {
  await knex('products').where('partner', 'STRIPE').delete();
};