exports.up = async function(knex) {
  return knex.schema
    .createTable('event_subscription_logs', (table) => {
      table.uuid('event_subscription_log_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('event_name').notNullable();
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('subscribed_by').notNullable();
      table.string('subscriber').notNullable();
      table.string('updated_by').notNullable();
      table.boolean('is_subscribed').notNullable().defaultTo(false);
      table.timestamps(true, true);
    })
};

exports.down = function(knex) {
  return knex.schema.dropTable('event_subscription_logs');
};
