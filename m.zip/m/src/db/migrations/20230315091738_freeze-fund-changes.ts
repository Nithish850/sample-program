/** function to bring up bulk_transactions table */
exports.up = async function (knex) {
  await knex.schema
    .alterTable('bulk_transactions', function (table) {
      table.integer('freezed_amount').notNullable().defaultTo(0);
      table.boolean('is_fund_freezed').notNullable().defaultTo(false);
      table.boolean('is_static_recipients').notNullable().defaultTo(false);
      table.dateTime('fund_freezed_time');
      table.dateTime('fund_unfreezed_time');
    })
};

/** function to bring down bulk_transactions table */
exports.down = function (knex) {
  return knex.schema.dropTable('bulk_transactions');
};
