exports.up = async function (knex) {
  await knex.schema.alterTable('compliance_details', (table) => {
    table.dropColumn('metro_area_location_confidence');
    table.jsonb('user_risk_rating_components');
    table.string('email_fraudscore');
    table.renameColumn('ip_trust_score', 'ip_fraudscore');
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('compliance_details', (table) => {
    table.string('metro_area_location_confidence');
    table.dropColumn('user_risk_rating_components');
    table.dropColumn('email_fraudscore');
    table.renameColumn('ip_fraudscore', 'ip_trust_score');
  })
};
