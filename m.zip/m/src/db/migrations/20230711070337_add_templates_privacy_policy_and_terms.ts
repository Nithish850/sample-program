import { UL_PRIVACY_POLICY, UL_TERMS_CONDITIONS } from "../master/agreement-template";

exports.up = async function(knex) {
  await knex('agreement_template').insert({ template: UL_PRIVACY_POLICY, type: 'UL_PRIVACY_POLICY' });
  await knex('agreement_template').insert({ template: UL_TERMS_CONDITIONS, type: 'UL_TERMS_CONDITIONS' });
};

exports.down = async function(knex) {
  await knex('agreement_template').delete().whereIn({ type: [ 'UL_PRIVACY_POLICY', 'UL_TERMS_CONDITIONS' ] });
};
