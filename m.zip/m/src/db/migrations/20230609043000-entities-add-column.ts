exports.up = async function(knex) {
  await knex.schema.alterTable('entities', (table) => {
    table.enu('role_assigned', [ 'BOTH', 'UL', 'TENANT' ]).notNullable();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('entities', (table) => {
    table.enu('role_assigned', [ 'BOTH', 'UL', 'TENANT' ]).notNullable();
  });
};
