const template = [{
  html: `Hi All,<br><br>
    Please find attached finclusive compliance report for the month of "<%=currentMonth%>".<br><br>
    
    Compliance Status Summary :<br>
    
    <html>
    <head>
        <style>
            table,
            th,
            td {
                border: 1px solid black;
                border-collapse: collapse;
            }
          th {
          background-color: #D9E1F2
          }
        </style>
    </head>
    
    <body>
        <table style="width:30%">
            <tr>
                <th>Compliance status</th>
                <th>Count</th>
            </tr>
            <tr>
                <td>Accepted</td>
                <td><%=accepted%></td>
            </tr>
            <tr>
                <td>Pending</td>
                <td><%=pending%></td>
            </tr>
            <tr>
                <td>Rejected</td>
                <td><%=rejected%></td>
            </tr>
        </table>
    </body>
    </html>
    <br>
    Please find attached file for the detailed report.<br><br>
    Thanks<br>
    UL Team`,
  subject: 'Finclusive Compliance Report',
  template_name: 'ComplianceReport'
}]

exports.up = async function(knex) {
  await knex('email_templates').insert(template)
};

exports.down = async function(knex) {
  await knex('email_templates').delete().orderBy('created_at', 'desc').first()
};
