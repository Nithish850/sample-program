exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_event_subscription', (table) => {
    table.string('secret_key', 128);
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_event_subscription', (table) => {
    table.dropColumn('secret_key');
  });
};
