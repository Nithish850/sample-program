exports.up = function (knex) {
  return knex.schema.createTable('code_tenant_mapper', (table) => {
    table.uuid('code_tenant_mapper_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('code_master_id').references('code_master_id').inTable('code_master').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('tenant_message');
    table.boolean('is_active');
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('code_tenant_mapper');
};
