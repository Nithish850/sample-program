import { defaultTenant } from "../master/tenant-data";

/* eslint-disable no-await-in-loop */
const wallets = [
  {
    "wallet_type_name": "DISBURSEMENT WALLET",
    "deposit": true,
    "withdraw": true,
    "transfer": true,
    "multi_wallet": true,
  },
  {
    "wallet_type_name": "PROCESSING FEE WALLET",
    "deposit": false,
    "withdraw": true,
    "transfer": false,
    "multi_wallet": false,
  },
];

const getDefaultTenantId = async (knex) =>{
  const defaultTenantData = await knex('tenants').select('tenant_id').where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain })

  return defaultTenantData[0]?.tenant_id;
}

exports.up = async (knex) => {

  const tenantId= await getDefaultTenantId(knex)

  for(const wallet of wallets) {
    await knex.transaction(async (trx) => {

      const id = await trx('wallet_type')
        .insert({
          wallet_type_name: wallet?.wallet_type_name
        }, 'wallet_type_id')

      const wallet_capability = await trx('wallet_capabilities').insert({
        deposit: wallet?.deposit,
        withdraw: wallet?.withdraw,
        transfer: wallet?.transfer,
        multi_wallet: wallet?.multi_wallet,
        wallet_type_id: id[0]?.wallet_type_id,
        tenant_id: tenantId
      });
    });
  }
};
exports.down = function (knex) {
  return knex.truncate('wallet_type').truncate('wallet_capabilities');
};
