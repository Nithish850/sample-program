exports.up = async function (knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.string('tenant_namespace');
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('offchain_transaction', (table) => {
    table.dropColumn('tenant_namespace');
  });
};
