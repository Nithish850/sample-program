exports.up = async function(knex) {
  await knex.schema.alterTable('users', (table) => {
    table.date('last_login');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('users', (table) => {
    table.dropColumn('last_login');
  });
};
