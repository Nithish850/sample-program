exports.up = function (knex) {
  return knex.schema.createTable('tenant_customer_documents', (table) => {
    table.uuid('tenant_customer_document_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('name').notNullable();
    table.string('side').notNullable();
    table.string('type').notNullable();
    table.text('content').notNullable();
    table.string('description').notNullable();
    table.string('number');
    table.string('issued_country');
    table.boolean('expired').defaultTo(false);
    table.string('valid_from');
    table.string('valid_till');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('tenant_customer_documents');
};
