exports.up = function (knex) {
  return knex.schema.createTable('namespaces', (table) => {
    table.uuid('namespace_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('namespace').notNullable().unique();
    table.string('account_address').unique();
    table.boolean('is_global').notNullable().defaultTo(false);
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('namespaces');
};
