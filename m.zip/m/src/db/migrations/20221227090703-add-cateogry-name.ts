exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.string('category_name').default('NONE');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('tenant_customer_accounts');
};
