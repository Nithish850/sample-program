exports.up = function (knex) {
  return knex.schema.alterTable('ach_reason_codes', (table) => {
    table.string('error_group').defaultTo('DEPOSIT')
  })
}

exports.down = function (knex) {
  return knex.schema.alterTable('ach_reason_codes', (table) => {
    table.dropColumn('error_group');
  })
}