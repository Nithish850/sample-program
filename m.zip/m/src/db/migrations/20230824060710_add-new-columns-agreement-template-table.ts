exports.up = async function(knex) {
  await knex.schema.alterTable('agreement_template', (table) => {
    table.string('id')
    table.string('version')
    table.string('current_active_version')
    table.enu('active_status', [ 'ACTIVE', 'INACTIVE' ]).defaultTo('ACTIVE')
    table.string('dss_vendor_id')
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('agreement_template', (table) => {
    table.dropColumn('id')
    table.dropColumn('version')
    table.dropColumn('current_active_version')
    table.dropColumn('active_status')
    table.dropColumn('dss_vendor_id')
  });
};
