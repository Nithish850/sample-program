exports.up = async function(knex) {
    await knex('dss_vendor').insert({ name: 'BANK-BOOK-TRANSFER', status: 'ACTIVE' })
  };
  
  exports.down = async function(knex) {
    await knex('dss_vendor').where('name', 'BANK-BOOK-TRANSFER').del();
  };
  