exports.up = async function(knex) {
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.boolean('is_forgotten').notNullable().defaultTo(false);
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.boolean('is_forgotten').notNullable().defaultTo(false);
  });
};
