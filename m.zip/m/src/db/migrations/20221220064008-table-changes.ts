/** Adding new fields to tenant_rule and removing fields from rules table */
exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('category');
  });
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.dropColumn('namespace');
    table.dropColumn('public_key');
    table.dropColumn('is_primary');
    table.dropColumn('namespace_provider');
    table.dropColumn('namespace_alias');
  });
  await knex.schema.table('tenant_customer_accounts', (table) => {
    table.string('category', 128).notNullable().defaultTo('NONE');
  });
  await knex.schema.table('tenant_customer_accounts', (table) => {
    table.string('risk_level', 10).notNullable().defaultTo('NONE');
  });
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('account_status').notNullable().defaultTo('ACTIVE');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('customer_accounts');
  await knex.schema.dropTable('tenant_customer_accounts');
};
