exports.up = function (knex) {
  return knex.schema.alterTable('bulk_transactions_receipts', (table) => {
    table.uuid('recurring_transaction_id').references('recurring_transaction_id').inTable('recurring_transactions');
  })
}

exports.down = function (knex) {
  return knex.schema.alterTable('bulk_transactions_receipts', (table) => {
    table.dropColumn('recurring_transaction_id');
  })
}