exports.up = async function (knex) {
  await knex.schema.alterTable('rules_conditions', (table) => {
    table.boolean('removable').notNullable().defaultTo(true);
  });
  await knex.schema.alterTable('rules_decisions_tree', (table) => {
    table.boolean('removable').notNullable().defaultTo(true);
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('rules_conditions');
  await knex.schema.dropTable('rules_decisions_tree');
};
