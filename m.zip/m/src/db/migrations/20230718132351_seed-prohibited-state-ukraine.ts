
// import { state_risk_rating_ukraine } from "../master/state_risk_rating_ukraine";

// exports.up = async function (knex) {
//   return await knex('state_risk_rating').insert(state_risk_rating_ukraine);
// }

// exports.down = async function (knex) {
//   return await knex('state_risk_rating').delete('country_code', '=', 'UA');
// }

exports.up = async function (knex) {}
exports.down = async function (knex) {}