// import { attributeDescriptionMap } from "../master/attributes-description";

// exports.up = async (knex) => {
//   const defaultTenantName = process.env.DEFAULT_TENANT;

//   const defaultTenant = await knex('tenants').select('tenant_id').where({
//     tenant_name: defaultTenantName,
//   })

//   if(defaultTenant && defaultTenant.length > 0 ) {
//     const defaultAttributes = await knex('attributes').select().where({
//       tenant_id: defaultTenant[0].tenant_id
//     })
//       .whereNot({
//         rule_group: 'ONBOARD'
//       });

//     if(defaultAttributes && defaultAttributes.length > 0) {
//       for( const attribute of defaultAttributes){
//         // eslint-disable-next-line no-await-in-loop
//         await knex('attributes').where({ attribute_id: attribute.attribute_id }).update({
//           attribute_desc: attributeDescriptionMap[attribute.attribute_name]
//         })
//       }
//     }
//   }
// }

// exports.down =async (knex) => {
//   const defaultTenantName = process.env.DEFAULT_TENANT;

//   const defaultTenant = await knex('tenants').select('tenant_id').where({
//     tenant_name: defaultTenantName,
//   })

//   if(defaultTenant && defaultTenant.length > 0 ) {
//     const defaultAttributes = await knex('attributes').select().where({
//       tenant_id: defaultTenant[0].tenant_id
//     });

//     if(defaultAttributes && defaultAttributes.length > 0) {
//       for( const attribute of defaultAttributes){
//         // eslint-disable-next-line no-await-in-loop
//         await knex('attributes').where({ attribute_id: attribute.attribute_id }).update({
//           attribute_desc: attributeDescriptionMap[attribute.attribute_name]
//         })
//       }
//     }
//   }
// }


exports.up = async function (knex) {}
exports.down = async function (knex) {}