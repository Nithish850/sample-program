exports.up = async function (knex) {
    // await knex.schema.alterTable('contract_store', (table) => {
    //   table.renameColumn('contract_address', 'implementation_address');
    //   table.string('proxy_address');
    //   table.string('storage_address');

    // })
  }
  
  exports.down = async function (knex) {
    // await knex.schema.column('implementation_address')
    // .dropTable('proxy_address')
    // .dropTable('storage_address')
  }