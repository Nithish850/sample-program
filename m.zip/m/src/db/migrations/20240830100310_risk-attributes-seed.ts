exports.up = async function(knex) {
  await knex.schema.table('attributes', function(table) {
    table.enu('rule_group_new', ['ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW', 'RISK']);
  });

  await knex.raw('UPDATE attributes SET rule_group_new = rule_group');

  await knex.schema.table('attributes', function(table) {
    table.dropColumn('rule_group');
  });

  await knex.schema.table('attributes', function(table) {
    table.renameColumn('rule_group_new', 'rule_group');
  });
};

exports.down = async function(knex) {
  await knex.schema.table('attributes', function(table) {
      table.enu('rule_group_old', ['ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW']).notNullable();
  });

  await knex.raw('UPDATE attributes SET rule_group_old = rule_group');

  await knex.schema.table('attributes', function(table) {
      table.dropColumn('rule_group');
  });

  await knex.schema.table('attributes', function(table) {
      table.renameColumn('rule_group_old', 'rule_group');
  });
};
