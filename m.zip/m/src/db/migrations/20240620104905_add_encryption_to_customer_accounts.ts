/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'customer_accounts';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN email TYPE text,
      ALTER COLUMN phone TYPE text,
      ALTER COLUMN dob TYPE text,
      ALTER COLUMN address TYPE text,
      ALTER COLUMN customer_metadata TYPE text,
      ALTER COLUMN identity_provider_metadata TYPE text,
      ALTER COLUMN first_name TYPE text,
      ALTER COLUMN middle_name TYPE text,
      ALTER COLUMN last_name TYPE text,
      ALTER COLUMN nationality TYPE text,
      ALTER COLUMN ip_address TYPE text,
      ALTER COLUMN lat_long TYPE text,
      ALTER COLUMN ssn TYPE text,
      ALTER COLUMN tax_id TYPE text,
      ALTER COLUMN additional_address TYPE text,
      ALTER COLUMN geo_location_details TYPE text,
      ALTER COLUMN metro_area_details TYPE text,
      ALTER COLUMN country_details TYPE text,
      ALTER COLUMN gid_name TYPE text,
      ALTER COLUMN gid_dob TYPE text,
      ALTER COLUMN gid_photo TYPE text,
      ALTER COLUMN gid_id_number TYPE text,
      ALTER COLUMN gid_country TYPE text,
      ALTER COLUMN gid_state TYPE text,
      ALTER COLUMN gid_issue_date TYPE text,
      ALTER COLUMN gid_expiration_date TYPE text,
      ALTER COLUMN gid_address TYPE text,
      ALTER COLUMN gid_gender TYPE text,
      ALTER COLUMN bank_account_details TYPE text,
      ALTER COLUMN name_combination TYPE text,
      ALTER COLUMN name_combination_index TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          email = encrypt(email::bytea, '${val}'::bytea, 'aes'::text),
          dob = encrypt(dob::bytea, '${val}'::bytea, 'aes'::text),
          phone = encrypt(phone::bytea, '${val}'::bytea, 'aes'::text),
          address = encrypt(address::bytea, '${val}'::bytea, 'aes'::text),
          customer_metadata = encrypt(customer_metadata::bytea, '${val}'::bytea, 'aes'::text),
          identity_provider_metadata = encrypt(identity_provider_metadata::bytea, '${val}'::bytea, 'aes'::text),
          first_name = encrypt(first_name::bytea, '${val}'::bytea, 'aes'::text),
          middle_name = encrypt(middle_name::bytea, '${val}'::bytea, 'aes'::text),
          last_name = encrypt(last_name::bytea, '${val}'::bytea, 'aes'::text),
          nationality = encrypt(nationality::bytea, '${val}'::bytea, 'aes'::text),
          ip_address = encrypt(ip_address::bytea, '${val}'::bytea, 'aes'::text),
          lat_long = encrypt(lat_long::bytea, '${val}'::bytea, 'aes'::text),
          ssn = encrypt(ssn::bytea, '${val}'::bytea, 'aes'::text),
          tax_id = encrypt(tax_id::bytea, '${val}'::bytea, 'aes'::text),
          additional_address = encrypt(additional_address::bytea, '${val}'::bytea, 'aes'::text),
          geo_location_details = encrypt(geo_location_details::bytea, '${val}'::bytea, 'aes'::text),
          metro_area_details = encrypt(metro_area_details::bytea, '${val}'::bytea, 'aes'::text),
          country_details = encrypt(country_details::bytea, '${val}'::bytea, 'aes'::text),
          gid_name = encrypt(gid_name::bytea, '${val}'::bytea, 'aes'::text),
          gid_dob = encrypt(gid_dob::bytea, '${val}'::bytea, 'aes'::text),
          gid_photo = encrypt(gid_photo::bytea, '${val}'::bytea, 'aes'::text),
          gid_id_number = encrypt(gid_id_number::bytea, '${val}'::bytea, 'aes'::text),
          gid_country = encrypt(gid_country::bytea, '${val}'::bytea, 'aes'::text),
          gid_state = encrypt(gid_state::bytea, '${val}'::bytea, 'aes'::text),
          gid_issue_date = encrypt(gid_issue_date::bytea, '${val}'::bytea, 'aes'::text),
          gid_expiration_date = encrypt(gid_expiration_date::bytea, '${val}'::bytea, 'aes'::text),
          gid_address = encrypt(gid_address::bytea, '${val}'::bytea, 'aes'::text),
          gid_gender = encrypt(gid_gender::bytea, '${val}'::bytea, 'aes'::text),
          bank_account_details = encrypt(bank_account_details::bytea, '${val}'::bytea, 'aes'::text),
          name_combination = encrypt(name_combination::bytea, '${val}'::bytea, 'aes'::text),
          name_combination_index = encrypt(name_combination_index::bytea, '${val}'::bytea, 'aes'::text);
    `);
    console.log(`Existing data in ${tableName} table encrypted.`);

    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'email' },
      { table_name: tableName, column_name: 'phone' },
      { table_name: tableName, column_name: 'dob' },
      { table_name: tableName, column_name: 'address' },
      { table_name: tableName, column_name: 'customer_metadata' },
      { table_name: tableName, column_name: 'identity_provider_metadata' },
      { table_name: tableName, column_name: 'first_name' },
      { table_name: tableName, column_name: 'middle_name' },
      { table_name: tableName, column_name: 'last_name' },
      { table_name: tableName, column_name: 'nationality' },
      { table_name: tableName, column_name: 'ip_address' },
      { table_name: tableName, column_name: 'lat_long' },
      { table_name: tableName, column_name: 'ssn' },
      { table_name: tableName, column_name: 'tax_id' },
      //   { table_name: tableName, column_name: 'gender' },
      //   { table_name: tableName, column_name: 'marital_status' },
      { table_name: tableName, column_name: 'additional_address' },
      { table_name: tableName, column_name: 'geo_location_details' },
      { table_name: tableName, column_name: 'metro_area_details' },
      { table_name: tableName, column_name: 'country_details' },
      { table_name: tableName, column_name: 'gid_name' },
      { table_name: tableName, column_name: 'gid_dob' },
      { table_name: tableName, column_name: 'gid_photo' },
      { table_name: tableName, column_name: 'gid_id_number' },
      { table_name: tableName, column_name: 'gid_country' },
      { table_name: tableName, column_name: 'gid_state' },
      { table_name: tableName, column_name: 'gid_issue_date' },
      { table_name: tableName, column_name: 'gid_expiration_date' },
      { table_name: tableName, column_name: 'gid_address' },
      { table_name: tableName, column_name: 'gid_gender' },
      //   { table_name: tableName, column_name: 'bank_account' },
      { table_name: tableName, column_name: 'bank_account_details' },
      { table_name: tableName, column_name: 'name_combination' },
      { table_name: tableName, column_name: 'name_combination_index' },
      { table_name: tableName, column_name: 'metro_location_details' }
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Dropping trigger for encrypting ${tableName} ...`);
    await knex.raw(`DROP TRIGGER IF EXISTS before_insert_update_${tableName} ON ${tableName};`);
    console.log(`Trigger for encrypting ${tableName} dropped.`);

    console.log(`Dropping trigger function for encrypting ${tableName} ...`);
    await knex.raw(`DROP FUNCTION IF EXISTS encrypt_${tableName};`);
    console.log(`Trigger function for encrypting ${tableName} dropped.`);

    console.log(`Decrypting existing data in ${tableName} table...`);

    await knex.raw(`
      UPDATE ${tableName}
      SET
        email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        dob = convert_from(decrypt(dob::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        address = convert_from(decrypt(address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        customer_metadata =convert_from(decrypt(customer_metadata::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        identity_provider_metadata = convert_from(decrypt(identity_provider_metadata::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        first_name = convert_from(decrypt(first_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        middle_name = convert_from(decrypt(middle_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        last_name = convert_from(decrypt(last_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        nationality = convert_from(decrypt(nationality::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        lat_long = convert_from(decrypt(lat_long::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        phone = convert_from(decrypt(phone::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        ip_address = convert_from(decrypt(ip_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        ssn = convert_from(decrypt(ssn::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tax_id = convert_from(decrypt(tax_id::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        additional_address = convert_from(decrypt(additional_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        geo_location_details = convert_from(decrypt(geo_location_details::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        metro_area_details = convert_from(decrypt(metro_area_details::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        country_details = convert_from(decrypt(country_details::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_name = convert_from(decrypt(gid_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_dob = convert_from(decrypt(gid_dob::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_id_number = convert_from(decrypt(gid_id_number::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_country = convert_from(decrypt(gid_country::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_state = convert_from(decrypt(gid_state::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_issue_date = convert_from(decrypt(gid_issue_date::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_expiration_date = convert_from(decrypt(gid_expiration_date::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_address = convert_from(decrypt(gid_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gid_gender = convert_from(decrypt(gid_gender::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        bank_account_details = convert_from(decrypt(bank_account_details::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        name_combination = convert_from(decrypt(name_combination::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        name_combination_index = convert_from(decrypt(name_combination_index::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    console.log('Removing entries from encryption_decryption for customer accounts column...');
    await knex('encryption_decryption').whereIn('column_name',[
      'email',
      'phone',
      'dob',
      'address',
      'customer_metadata',
      'first_name',
      'middle_name',
      'last_name',
      'nationality',
      'identity_provider_metadata',
      'ip_address',
      'lat_long',
      'ssn',
      'tax_id',
      'additional_address',
      'geo_location_details',
      'metro_area_details',
      'country_details',
      'gid_name',
      'gid_dob',
      'gid_id_number',
      'gid_country',
      'gid_state',
      'gid_issue_date',
      'gid_expiration_date',
      'gid_address',
      'gid_gender',
      'gid_photo',
      'bank_account_details',
      'name_combination',
      'name_combination_index',
      'metro_location_details'
    ]).where({ table_name: tableName }).delete();
    console.log('Entries removed from encryption_decryption for customer accounts column.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
