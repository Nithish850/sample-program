exports.up = async function (knex) {
  await knex.raw('DELETE FROM transaction WHERE created_at NOT IN (     SELECT MIN(created_at)     FROM transaction     GROUP BY transaction_hash );')
  await knex.schema.alterTable('transaction', (table) => {
    table.string('transaction_hash').notNullable().unique().alter();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('transaction', (table) => {
    table.string('transaction_hash').notNullable().alter();
  });
};
