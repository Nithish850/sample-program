exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.boolean('bank_account');
    table.jsonb('bank_account_details');
  });
};

exports.down = async function (knex) {
  return knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('bank_account');
    table.dropColumn('bank_account_details');
  });
};
