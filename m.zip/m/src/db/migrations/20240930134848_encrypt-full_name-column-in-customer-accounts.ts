/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'customer_accounts';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter column full_name to text for encryption
    console.log(`Altering full_name column type to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN full_name TYPE text;
    `);
    console.log(`full_name column type in ${tableName} table altered to text.`);

    // Step 2: Encrypt existing data in the full_name column
    console.log(`Encrypting existing full_name data in ${tableName} table ...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET 
        full_name = encrypt(full_name::bytea, '${val}'::bytea, 'aes'::text);
    `);
    console.log(`Existing full_name data in ${tableName} table encrypted.`);

    // Step 3: Insert entry into encryption_decryption table for the full_name column
    console.log('Inserting entry into encryption_decryption for full_name column in customer_accounts table...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'full_name' }
    ]);
    console.log('Insert into encryption_decryption for full_name column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Decrypt existing data in the full_name column
    console.log(`Decrypting full_name data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        full_name = convert_from(decrypt(full_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`full_name data in ${tableName} table decrypted.`);

    // Step 2: Delete the entry from encryption_decryption table
    console.log('Deleting entry from encryption_decryption for full_name column...');
    await knex('encryption_decryption')
      .where({ table_name: tableName, column_name: 'full_name' })
      .del();
    console.log('Deletion from encryption_decryption for full_name column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
