exports.up = function(knex) {
    return knex.schema.createTable('tenant_business_users', (table) => {
        table.uuid('tenant_business_user_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
        table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
        table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
        table.boolean('is_forgotten').notNullable().defaultTo(false);
        table.uuid('badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
        table.timestamps(true, true);
    })
};

exports.down = function(knex) {
    return knex.schema.dropTable('tenant_business_users');
};
