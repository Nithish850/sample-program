exports.up = function (knex) {
  return knex.schema.createTable('code_master', (table) => {
    table.uuid('code_master_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('code').unique().notNullable()
    table.string('description')
    table.string('group').notNullable()
    table.string('category').notNullable()
    table.string('ul_code')
    table.string('ul_description')
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('code_master');
};
