exports.up = function(knex) {
  return knex.schema.createTable('state_risk_rating', (table) => {
    table.string('country_code').references('country_code').inTable('country_risk_rating').onDelete('CASCADE').onUpdate('CASCADE');
    table.text('state').notNullable();
    table.string('state_code');
    table.primary(['country_code', 'state_code']);
    table.string('risk_score').notNullable();
    table.string('risk_rating');
    table.string('ul_override');
    table.text('rationale');
    table.timestamps(true, true);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('state_risk_rating');
};
