exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    // table.dropColumn('lat_long');
    table.jsonb('attachment');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('customer_accounts');
};
