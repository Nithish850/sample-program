exports.up = async function (knex) {
  await knex.schema
    .alterTable('tenant_namespace', function (table) {
      table.enu('disbursement_status', [ 'ACTIVE', 'INACTIVE' ]).defaultTo('ACTIVE').notNullable();
    })
};
exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_namespace',(table)=>{
    table.dropColumn('disbursement_status');
  })
};