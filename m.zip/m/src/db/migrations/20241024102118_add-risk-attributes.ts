exports.up = async function (knex) {
  await knex.schema.alterTable('compliance_details', (table) => {
    table.dropColumn('compliance_response');
    table.string('pep_status');
    table.string('sanction_screening');
    table.string('user_risk_rating');
    table.string('country_risk');
    table.string('country_location_confidence');
    table.string('metro_area_location_confidence');
    table.string('ip_trust_score');
    table.string('phone_number_trust_score');
  });

  await knex.schema.createTable('compliance_details_mapper', (table) => {
    table.uuid('compliance_details_mapper_id').defaultTo(knex.raw('gen_random_uuid()')).notNullable().primary();
    table.uuid('compliance_details_id').references('compliance_details_id').inTable('compliance_details').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
    table.unique([ 'compliance_details_id', 'customer_account_id' ]);
    table.timestamps(true, true);
  });

  await knex.schema.createTable('compliance_logs', (table) => {
    table.uuid('compliance_logs_id').defaultTo(knex.raw('gen_random_uuid()')).notNullable().primary();
    table.uuid('compliance_details_id').references('compliance_details_id').inTable('compliance_details').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
    table.jsonb('compliance_response');
    table.timestamps(true, true);
  })
};

exports.down = function (knex) {
  return knex.schema.alterTable('compliance_details', (table) => {
    table.dropColumn('pep_status');
    table.dropColumn('sanction_screening');
    table.dropColumn('user_risk_rating');
    table.dropColumn('country_risk');
    table.dropColumn('country_location_confidence');
    table.dropColumn('metro_area_location_confidence');
    table.dropColumn('ip_trust_score');
    table.dropColumn('phone_number_trust_score');
  })
  .dropTable('compliance_details_mapper')
  .dropTable('compliance_logs')
};
