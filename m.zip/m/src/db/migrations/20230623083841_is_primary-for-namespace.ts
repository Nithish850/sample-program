exports.up = async function (knex) {
  await knex.schema.alterTable('namespaces', (table) => {
    table.boolean('is_primary').defaultTo(false);
  })
}

exports.down = async function (knex) {
  await knex.schema.dropColumn('is_primary')
  await knex.schema.boolean('is_primary').defaultTo(false);
}