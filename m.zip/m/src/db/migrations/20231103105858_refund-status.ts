exports.up = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.string('refund_status').defaultTo(null);
    table.date('refund_date').defaultTo(null);
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('refund_status');
    table.string('refund_date');
  })
}