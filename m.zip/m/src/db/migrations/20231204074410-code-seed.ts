/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unused-vars */
exports.up = function (knex) {
  return knex.transaction(async (trx) => {

    await trx.raw(`
        INSERT INTO code_master (code, description, "group", category, ul_code, ul_description)
        SELECT code, cliq_description, error_group, 'ACH', ul_response_code, ul_description
        FROM ach_reason_codes
      `);

    await trx.raw(`
        INSERT INTO code_master (code, description, "group", category, ul_code, ul_description, attribute)
        SELECT error_code, error_reason, error_group, 'RULE', 'NA', error_description, error_attribute
        FROM errors
      `);
  });
};

// eslint-disable-next-line no-unused-vars
exports.down = function (knex) {

};