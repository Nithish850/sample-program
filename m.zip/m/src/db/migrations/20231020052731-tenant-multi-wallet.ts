exports.up = function (knex) {
  return knex.schema.createTable('tenant_multi_wallet', (table) => {
    table.uuid('tenant_multi_wallet_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_namespace_id').references('tenant_namespace_id').inTable('tenant_namespace').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('wallet_alias')
    table.string('wallet_description')
    table.string('wallet_namespace').notNullable().unique();
    table.string('wallet_address').notNullable().unique();
    table.string('wallet_token').notNullable()
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_multi_wallet');
};
