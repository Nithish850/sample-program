
exports.up = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.string('display_attribute_name', 128);
    table.boolean('reusable').notNullable().defaultTo(true);
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.dropColumn('display_attribute_name');
    table.dropColumn('reusable');
  });
};
