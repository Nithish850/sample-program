exports.up = function (knex) {
  return knex.schema.createTable('industry_master', (table) => {
    table.uuid('industry_master_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.text('industry');
    table.string('risk');
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('industry_master');
};
