exports.up = function (knex) {
  return knex.schema.alterTable('tenant_namespace', (table) => {
    table.string('token').defaultTo('USBC');
    table.string('wallet_name');
    table.string('wallet_type').references('wallet_type_name').inTable('wallet_type').onDelete('CASCADE').onUpdate('CASCADE');
    table.boolean('is_active').defaultTo(true);
    table.timestamps(true, true);
    table.dropColumn('wallet_alias');
  });
}

exports.down = function (knex) {
  return knex.schema.alterTable('tenant_namespace', (table) => {
    table.dropColumn('token');
    table.dropColumn('wallet_name');
    table.dropColumn('wallet_type_id');
  })
}