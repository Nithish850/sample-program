exports.up = async function (knex) {
  return knex.schema
    .createTable('bulk_transactions', function (table) {
      table.uuid('bulk_transaction_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.text('memo');
      table.jsonb('criteria');
      table.string('transaction_amount').notNullable();
      table.boolean('is_scheduled_transaction').notNullable().defaultTo(false);
      table.date('scheduled_time');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.timestamps(true, true);
    })
    .createTable('bulk_transactions_receipts', function (table) {
      table.uuid('receipt_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('bulk_transaction_id').references('bulk_transaction_id').inTable('bulk_transactions').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.string('fromNamespace').notNullable();
      table.string('toNamespace').notNullable();
      table.string('transaction_hash');
      table.enu('transaction_status', [ 'PROCESSED', 'PENDING', 'CANCELLED' ]).defaultTo('PENDING').notNullable();
      table.timestamps(true, true);
    });
};

/** function to bring down bulk_transactions table */
exports.down = function (knex) {
  return knex.schema.dropTable('bulk_transactions').dropTable('bulk_transactions_receipts');
};
