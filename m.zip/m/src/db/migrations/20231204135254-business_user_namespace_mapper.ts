exports.up = function (knex) {
  return knex.schema.createTable('business_user_namespace_mapper', (table) => {
    table.uuid('mapper_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('custom_namespace');
    table.uuid('business_user_namespace_id').references('business_user_namespace_id').inTable('business_user_namespaces').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('provider');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('business_user_namespace_mapper');
};
