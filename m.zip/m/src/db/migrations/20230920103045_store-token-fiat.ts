exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_token_request', (table) => {
    table.string('currency').references('code').inTable('currency_list').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('USD');
  }).alterTable('contract_store', (table) => {
    table.string('currency').references('code').inTable('currency_list').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('USD');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('contract_store', (table) => {
    table.dropColumn('currency');
  }).alterTable('tenant_token_request', (table) => {
    table.dropColumn('currency');
  })
}