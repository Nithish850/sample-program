// /* eslint-disable no-await-in-loop */
// exports.up = async function (knex) {

//   const [{ tenant_id }] = await knex('tenants').select('tenant_id').where({ tenant_name: 'universal ledger' });
//   const roles = [ 'UL_READ_ONLY', 'TENANT_READ_ONLY' ];
//   let entities = [];

//   await knex('roles').insert([{
//     role_name: roles[0],
//     tenant_id: tenant_id,
//     is_active: true,
//     type: 'DEFAULT'
//   },{
//     role_name: roles[1],
//     tenant_id: tenant_id,
//     is_active: true,
//     type: 'DEFAULT'
//   }]);

//   for (const role of roles) {
//     const [{ role_id }] = await knex('roles').where({ role_name: role, tenant_id: tenant_id });

//     if (role === 'UL_READ_ONLY') {
//       entities = await knex('entities').select('*').whereIn('role_assigned', ['UL', 'BOTH']);
//     } else {
//       entities = await knex('entities').select('*').whereIn('role_assigned', ['TENANT', 'BOTH']);
//     }

//     for (const { entity_id } of entities) {
//       await knex('role_entities').insert({
//         role_id: role_id,
//         entity_id: entity_id,
//         tenant_id: tenant_id,
//         read: true,
//         write: false,
//         update: false,
//         delete: false,
//         manage: false
//       });
//     }
//   }

// }

// exports.down = async function (knex) {

//   const [{ tenant_id }] = await knex('tenants').select('tenant_id').where({ tenant_name: 'universal ledger' });

//   await knex('roles').delete({ tenant_id: tenant_id, role_name: 'UL_READ_ONLY' });
//   await knex('roles').delete({ tenant_id: tenant_id, role_name: 'TENANT_READ_ONLY' });

// }

exports.up = async function (knex) {}
exports.down = async function (knex) {}