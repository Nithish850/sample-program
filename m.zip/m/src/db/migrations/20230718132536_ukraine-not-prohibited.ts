
exports.up = async function (knex) {
  return knex('country_risk_rating')
    .where({
      'country_code': 'UA',
    })
    .update({ ul_override: 'High' });
}

exports.down = async function (knex) {
  return knex('country_risk_rating')
    .where({
      'country_code': 'UA',
    })
    .update({ ul_override: 'Prohibited' });
}