exports.up = function (knex) {
  return knex.schema
    .createTable('dss_event', (table) => {
      table.uuid('dss_event_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('event').notNullable();
      table.timestamps(true, true);
    })
    .createTable('tenant_event_subscription', (table) => {
      table.uuid('tenant_event_subscription_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('dss_event_id').references('dss_event_id').inTable('dss_event').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('endpoint').notNullable();
      table.boolean('is_active').notNullable().defaultTo(false);
      table.timestamps(true, true);
    }).then(() => knex("dss_event").insert([
      { event: 'BADGE UPDATE' },
      { event: 'COMPLIANCE' },
      { event: 'ONBOARDING' }
    ]));
};
exports.down = function (knex) {
  return knex.schema.dropTable('dss_event').dropTable('tenant_event_subscription');
};
