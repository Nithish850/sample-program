
exports.up = async function (knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.string('additional_fees', 128);
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.dropColumn('additional_fees');
  });
};
