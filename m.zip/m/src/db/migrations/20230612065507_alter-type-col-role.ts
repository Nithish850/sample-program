exports.up = async function(knex) {
  await knex.schema.alterTable('roles', (table) => {
    table.specificType('type', 'text')
      .alter()
      .checkIn(['CUSTOM', 'DEFAULT']);
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('roles', (table) => {
    table.string('type').alter();
  });
};
