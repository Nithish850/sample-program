exports.up = async function (knex) {
  await knex.schema.alterTable('transaction', (table) => {
    table.string('tenant_namespace');
  });
};
exports.down = function (knex) {
  return knex.schema.alterTable('transaction', (table) => {
    table.dropColumn('tenant_namespace');
  });
};