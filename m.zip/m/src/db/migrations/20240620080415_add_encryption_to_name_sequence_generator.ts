/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'namespace_sequence_generator';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter table columns to text for encryption
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN first_name TYPE text,
      ALTER COLUMN last_name TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          first_name = encrypt(first_name::bytea, '${val}'::bytea, 'aes'::text),
          last_name = encrypt(last_name::bytea, '${val}'::bytea, 'aes'::text);
    `);
    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 5: Insert entries into encryption_decryption for recipient_list column
    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'first_name' },
      { table_name: tableName , column_name: 'last_name' }
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        first_name = convert_from(decrypt(first_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        last_name = convert_from(decrypt(last_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 4: Revert column types back to their original types
    console.log(`Reverting column types back to their original types in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN first_name TYPE varchar(255),
      ALTER COLUMN last_name TYPE varchar(255);
    `);
    console.log(`Column types in ${tableName} table reverted to their original types.`);

    // Step 5: Remove entries from encryption_decryption for recipient_list column
    console.log('Removing entries from encryption_decryption for recipient_list column...');
    await knex('encryption_decryption')
      .where({ table_name: tableName })
      .whereIn('column_name', ['first_name', 'last_name'])
      .delete();
    console.log('Entries removed from encryption_decryption for recipient_list column.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
