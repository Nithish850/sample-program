exports.up = function (knex) {
  return knex.schema.createTable('business_user_documents', (table) => {
    table.uuid('business_user_document_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
    table.enu('document_type', [ 'DriversLicense', 'Passport', 'IdCard', 'ResidencePermit', 'Jurisdiction', 'Incorporation', 'None', 'Other', 'Selfie' ]).notNullable().defaultTo('Other');
    table.string('file_name').notNullable();
    table.text('content').notNullable();
    table.string('country_code').notNullable();
    table.string('type').notNullable();
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('business_user_documents');
};