/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'business_identity_owner';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // first_name, last_name, email, phone_number, dob, address, tax, gender,
    // Step 1: Alter table columns to text for encryption
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN first_name TYPE text,
      ALTER COLUMN last_name TYPE text,
      ALTER COLUMN email TYPE text,
      ALTER COLUMN phone_number TYPE text,
      ALTER COLUMN dob TYPE text,
      ALTER COLUMN address TYPE text,
      ALTER COLUMN tax TYPE text,
      ALTER COLUMN gender TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          first_name = encrypt(first_name::bytea, '${val}'::bytea, 'aes'::text),
          last_name = encrypt(last_name::bytea, '${val}'::bytea, 'aes'::text),
          email = encrypt(email::bytea, '${val}'::bytea, 'aes'::text),
          phone_number = encrypt(phone_number::bytea, '${val}'::bytea, 'aes'::text),
          dob = encrypt(dob::bytea, '${val}'::bytea, 'aes'::text),
          address = encrypt(address::bytea, '${val}'::bytea, 'aes'::text),
          tax = encrypt(tax::bytea, '${val}'::bytea, 'aes'::text),
          gender = encrypt(gender::bytea, '${val}'::bytea, 'aes'::text);
    `);

    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 5: Insert entries into encryption_decryption for recipient_list column
    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'first_name' },
      { table_name: tableName , column_name: 'last_name' },
      { table_name: tableName , column_name: 'email' },
      { table_name: tableName , column_name: 'phone_number' },
      { table_name: tableName , column_name: 'dob' },
      { table_name: tableName , column_name: 'address' },
      { table_name: tableName , column_name: 'tax' },
      { table_name: tableName , column_name: 'gender' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        first_name = convert_from(decrypt(first_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        last_name = convert_from(decrypt(last_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        phone_number = convert_from(decrypt(phone_number::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        dob =convert_from(decrypt(dob::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        address = convert_from(decrypt(address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tax = convert_from(decrypt(tax::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        gender =convert_from(decrypt(gender::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 4: Delete entries from encryption_decryption for recipient_list column
    console.log('Deleting entries from encryption_decryption for recipient_list column...');
    await knex('encryption_decryption')
      .whereIn('column_name', ['first_name','last_name','email','phone_number','dob','address','tax','gender'])
      .where({ table_name: tableName })
      .del();
    console.log('Deletion from encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
