exports.up = async function (knex) {
  await knex.schema
    .alterTable('bulk_transactions', function (table) {
      table.dateTime('processed_time');
      table.enu('bulk_transfer_status', [ 'PROCESSED', 'PENDING', 'CANCELLED' ]).defaultTo('PENDING').notNullable();
      table.jsonb('reject_reasons');
    })
};

/** function to bring down bulk_transactions table */
exports.down = function (knex) {
  return knex.schema.dropTable('bulk_transactions');
};
