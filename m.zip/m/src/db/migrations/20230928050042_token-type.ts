/* eslint-disable no-console */
import { currencyList } from "../master/currency-list";
import { tokenTypeList } from "../master/token-type";

exports.up = async function (knex) {
  await knex('currency_list').insert(currencyList).returning('code').onConflict().ignore();

  const requestData = await knex('tenant_token_request').select('request_id', 'currency');
  const contractData = await knex('contract_store').select('contract_id', 'currency');

  await knex.schema.alterTable('tenant_token_request', (table) => {
    table.dropColumn('currency');
  }).alterTable('contract_store', (table) => {
    table.dropColumn('currency');
  });

  await knex.schema.alterTable('tenant_token_request', (table) => {
    table.string('currency').references('code').inTable('currency_list').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('NONE');
  }).alterTable('contract_store', (table) => {
    table.string('currency').references('code').inTable('currency_list').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('NONE');
  });

  if (requestData.length) {
    const updateList = requestData.map((val) => {
      const { request_id, currency } = val;

      return knex('tenant_token_request').where({
        request_id,
      }).update({ currency: currency }).onConflict().ignore();
    })

    if (updateList.length) {
      console.log(' updating currency for tenant token request ');
      await Promise.all(updateList);
    }
  }

  if (contractData.length) {
    const updateList = contractData.map((val) => {
      const { contract_id, currency } = val;

      return knex('contract_store').where({
        contract_id,
      }).update({ currency: currency }).onConflict().ignore();
    })

    if (updateList.length) {
      console.log(' updating currency for contract store ');
      await Promise.all(updateList);
    }
  }

  console.log(' Creatng Token Type Table');
  await knex.schema.createTable('token_type', (table) => {
    table.string('token_type');
    table.primary('token_type');
    table.string('description');
    table.string('display_name');
  });

  const tokenTypeData = await knex('token_type').insert(tokenTypeList).returning('token_type').onConflict().ignore();

  if (tokenTypeData.length) {
    console.log(' Updating token type for Tokens');
    await knex.schema.alterTable('tenant_token_request', (table) => {
      table.string('token_type').references('token_type').inTable('token_type').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('STABLECOIN');
    }).alterTable('contract_store', (table) => {
      table.string('token_type').references('token_type').inTable('token_type').onDelete('CASCADE').onUpdate('CASCADE').defaultTo('STABLECOIN');
    });
  }

}

exports.down = async function (knex) {
  await knex.schema.dropTable('token_type')
    .alterTable('contract_store', (table) => {
      table.dropColumn('token_type');
    }).alterTable('tenant_token_request', (table) => {
      table.dropColumn('token_type');
    });
}