exports.up = function(knex) {
  return knex('transaction')
    .update({
      rule_id_array: knex.raw('ARRAY[??]', ['rule_id'])
    })
  .then(() => {
    return knex.schema.table('transaction', (table) => { table.dropColumn('rule_id');});
  });
};

exports.down = function(knex) {
  return knex.schema.table('transaction', (table) => {
    table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE');
  })
  .then(() => {
    return knex('transaction')
    .update({
      rule_id_array: knex.raw('rule_id', 'rule_id_array[1]')
    })
  });
};
