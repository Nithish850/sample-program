import { Knex } from "knex";


export async function up(knex: Knex): Promise<void> {
    console.log('migration running: 052-dss-oscilar');
    await knex('dss').insert(
      {
        dss_type: 'OSCILAR',
        dss_description: 'Compliance type oscilar id',
      }
    );
    console.log('migration completed: 052-dss-oscilar');
}


export async function down(knex: Knex): Promise<void> {
    console.log('rolling back migration: 052-dss-oscilar');
    await knex('dss')
        .where({ dss_type: 'OSCILAR' })
        .del();
    console.log('rollback completed: 052-dss-oscilar');
}

