exports.up = function (knex) {
  return knex.schema.createTable('tenant_namespace_sequence_generator', (table) => {
    table.uuid('t_namespace_sequence_generator_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('tenant_namespace').notNullable().unique();
    table.integer('count').notNullable().defaultTo(0);
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_namespace_sequence_generator');
};
