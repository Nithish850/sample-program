exports.up = async function(knex) {
  await knex.schema.alterTable('roles', (table) => {
    table.string('type');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('roles', (table) => {
    table.dropColumn('type');
  });
};
