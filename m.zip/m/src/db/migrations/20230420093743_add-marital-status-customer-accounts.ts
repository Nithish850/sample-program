exports.up = async function(knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.enu('marital_status', [ 'MARRIED', 'UNMARRIED' ]);
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('marital_status');
  });
};
