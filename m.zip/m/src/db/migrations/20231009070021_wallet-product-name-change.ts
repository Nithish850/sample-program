import { productsList, updateWallet2WalletProduct } from "../master/products";

exports.up = async function(knex) {
  await knex('products').update(updateWallet2WalletProduct)
    .where({ type: 'UL wallet to UL wallet' })
};

exports.down = async function(knex) {
  const oldData:any = productsList.filter((product) => product.type === 'UL wallet to UL wallet')

  if(oldData && oldData.length) {
    await knex('products').update(...oldData[0])
      .where({ type: updateWallet2WalletProduct.type })
  }
};
