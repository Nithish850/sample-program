exports.up = async function(knex) {
  await knex.schema.alterTable('users', (table) => {
    table.string('user_reference_id');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('users', (table) => {
    table.dropColumn('user_reference_id');
  });
};
