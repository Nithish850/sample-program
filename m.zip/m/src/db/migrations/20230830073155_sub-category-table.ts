exports.up = function (knex) {
  return knex.schema.createTable('account_category', (table) =>{
    table.string('account_category_id').primary().notNullable();
    table.string('subcategory_name').notNullable().unique();
    table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true);
  });
}
exports.down = function(knex) {
  return knex.schema.dropTable('account_category');
}