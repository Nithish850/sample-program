import { achReasonCodeULCodeMap } from "../master/ach-reason-code-UL-code-map";

exports.up = function(knex) {
  return knex.schema.createTable('ach_reason_codes', function(table) {
    table.uuid('ach_reason_code_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('code').notNullable();
    table.string('cliq_description').notNullable();
    table.string('ul_response_code').notNullable();
    table.string('ul_description').notNullable();
  }).then(() => knex('ach_reason_codes').insert(achReasonCodeULCodeMap));
};

exports.down = function(knex) {
  return knex.schema.dropTable('ach_reason_codes');
};