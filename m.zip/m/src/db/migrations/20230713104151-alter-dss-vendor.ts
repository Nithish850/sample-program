exports.up = async function(knex) {
  await knex.schema.alterTable('dss_vendor', (table) => {
    table.jsonb('logo');
  }).alterTable('dss_vendor_consent', (table) => {
    table.dropColumn('logo');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('dss_vendor', (table) => {
    table.dropColumn('logo');
  });
};
