exports.up = async function (knex) {
  await knex.schema.raw(`ALTER TABLE badge_rules DROP CONSTRAINT IF EXISTS badge_rules_rule_group_1`);
  await knex.schema.raw(`ALTER TABLE badge_rules DROP CONSTRAINT IF EXISTS badge_rules_rule_group_check`);
  await knex.schema.alterTable('badge_rules', (table) => {
    table.string('rule_group').checkIn([ 'ONBOARD', 'DEPOSIT', 'TRANSFER', 'WITHDRAW', 'INFORMATION' ]).notNullable().alter();
  });
  await knex.schema.raw(`ALTER TABLE rules DROP CONSTRAINT IF EXISTS rules_rule_group_1`);
  await knex.schema.raw(`ALTER TABLE rules DROP CONSTRAINT IF EXISTS rules_rule_group_check`);
  await knex.schema.alterTable('rules', (table) => {
    table.string('rule_group').checkIn([ 'ONBOARD', 'DEPOSIT', 'TRANSFER', 'WITHDRAW', 'INFORMATION' ]).notNullable().alter();
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('badge_rules', (table) => {
    table.string('rule_group').checkIn([ 'ONBOARD', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable().alter();
  });
  await knex.schema.alterTable('rules', (table) => {
    table.string('rule_group').checkIn([ 'ONBOARD', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable().alter();
  });
};
