const payPalPartners = [
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Digital Payment',
    'type_desc': 'Enable Deposit using Digital Payment by toggling ON. By toggling OFF Digital Payment, only Deposits using Digital Payment will be disabled.',
    'partner': 'PAYPAL',
    'partner_desc': 'Payment gateway partner PAYPAL',
    'super_category': 'Tenant Wallet',
    'default_flag': true
  },
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Digital Payment',
    'type_desc': 'Enable Deposit using Digital Payment by toggling ON. By toggling OFF Digital Payment, only Deposits using Digital Payment will be disabled.',
    'partner': 'PAYPAL',
    'partner_desc': 'Payment gateway partner PAYPAL',
    'super_category': 'Customer Wallet',
    'default_flag': true
  }
];

exports.up = async function (knex) {
  await knex('products').insert(payPalPartners).onConflict().ignore();
};

exports.down = async function (knex) {
  await knex('products').where('partner', 'PAYPAL').del();
}