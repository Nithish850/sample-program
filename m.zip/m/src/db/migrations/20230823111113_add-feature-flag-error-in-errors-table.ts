exports.up = async function(knex) {
  const error = [{
    error_code: 'ULTFF001',
    error_group: 'TRANSFER',
    error_slug: 'feature_flagging',
    error_attribute: 'disabledFeature',
    error_reason: 'Admin has disable the on-chain transfers',
    error_description: 'Admin has disable the on-chain transfers'
  }]

  await knex('errors').insert(error);
};

exports.down = async function(knex) {
  await knex('errors').delete().where({ error_code: 'ULTFF001' });
};
