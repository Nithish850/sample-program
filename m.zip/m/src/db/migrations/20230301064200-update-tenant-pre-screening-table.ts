exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.dropColumn('tax_id');
    table.dropColumn('commencement');
    table.dropColumn('marketing_role');
    table.dropColumn('compliance_role');
    table.jsonb('tax').notNullable();
    table.string('commencement_date').notNullable();
    table.string('business_entity_type');
    table.string('region_of_formation');
    table.string('attestation_question');
    table.string('sanctioned_country_attestation');
  });
}

exports.down = async function (knex) {
  await knex.schema.dropTable('tenant_pre_screening');
}