import { businessErrorCodes } from '../master/errors-revised';
exports.up = async function (knex) {
  await knex.schema.alterTable('errors', (table) => {
    table.dropColumn('error_slug');
  });

  await knex('errors').truncate();
  await knex('errors').insert(businessErrorCodes);
};

exports.down = async function (knex) {
  return await knex.schema.alterTable('errors', (table) => {
    table.string('error_slug');
  });
};
