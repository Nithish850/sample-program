/** Adding new fields to tenant_rule and removing fields from rules table */
exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_rules', (table) => {
    table.string('rule_slug').alter();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_rules', (table) => {
    table.enu('rule_slug', [ 'tier1', 'tier2', 'tier3', 'tier4' ]).alter();
  });
};
