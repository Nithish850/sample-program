/* eslint-disable line-comment-position */
/* eslint-disable no-await-in-loop */

// import { defaultTenant } from "../master/tenant-data";

// const wallets = [
//   {
//     "wallet_type_name": "SETTLEMENT WALLET",
//     "deposit": false,
//     "withdraw": false,
//     "transfer": false,
//     "multi_wallet": false,
//   },
// ];

// const getDefaultTenantId = async (knex) => {
//   const defaultTenantData = await knex('tenants').select('tenant_id')
//     .where({
//       'tenant_name': defaultTenant[0]?.tenant_name,
//       domain: defaultTenant[0]?.domain
//     });

//   return defaultTenantData[0]?.tenant_id;
// }

exports.up = async function (knex) {

  await knex.schema.alterTable('contract_store', (table) => {
    table.renameColumn('contract_address', 'implementation_address');
    table.string('proxy_address');
    table.string('storage_address');

  });

  await knex.schema.createTable('deposit_utility_tokens_map', (table) => {
    table.string('utility_token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('deposit_token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE').unique();
    table.primary([ 'utility_token_symbol', 'deposit_token_symbol' ]);
    table.string('percentage_value');
    table.timestamps(true, true);
  });

  await knex.schema.alterTable('tenant_namespace', (table) => {
    table.uuid('settlement_tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
  });

  // const tenantId = await getDefaultTenantId(knex)

  // await knex.transaction(async (trx) => {

  //   const id = await trx('wallet_type')
  //     .insert({
  //       wallet_type_name: wallets[0]?.wallet_type_name
  //     }, 'wallet_type_id')

  //   await trx('wallet_capabilities').insert({
  //     deposit: wallets[0]?.deposit,
  //     withdraw: wallets[0]?.withdraw,
  //     transfer: wallets[0]?.transfer,
  //     multi_wallet: wallets[0]?.multi_wallet,
  //     wallet_type_id: id[0]?.wallet_type_id,
  //     tenant_id: tenantId
  //   });
  // });

  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.string('parent_transaction_id');
    table.string('settlement_tenant_id');
    table.string('deposit_token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');

  });

  await knex.schema.alterTable('transaction', (table) => {
    table.string('parent_transaction_id');
    table.string('settlement_tenant_id');
    table.string('deposit_token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
  });

  await knex.schema.createTable('transactions_subscribed', (table) => {
    table.uuid('transactions_subscription_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('from');
    table.string('to');
    table.string('amount').notNullable();
    table.string('transaction_hash').notNullable();
    table.string('token_symbol').notNullable();
    table.string('input');
    table.jsonb('transaction_details');
    table.string('status').defaultTo('PENDING');
    table.string('transaction_type');
    table.string('proxy_address');
    table.string('transfer_method_id');
    table.string('reject_reason');
    table.timestamps(true, true);
  });
}

exports.down = async function (knex) {
  await knex.schema.column('implementation_address')
    .dropTable('proxy_address')
    .dropTable('storage_address');

  await knex.schema.dropTable('deposit_utility_tokens_map');

  await knex.schema.alterTable('tenant_namespace', (table) => {
    table.dropColumn('settlement_tenant_id');
  });

  // await knex.truncate('wallet_type').truncate('wallet_capabilities');

  await knex.schema.column('offchain_transaction')
    .dropTable('parent_transaction_id')
    .dropTable('settlement_tenant_id')
    .dropTable('deposit_token_symbol');

  await knex.schema.column('transaction')
    .dropTable('parent_transaction_id')
    .dropTable('settlement_tenant_id')
    .dropTable('deposit_token_symbol');

  await knex.schema.dropTable('transactions_subscribed');
}