exports.up = function(knex) {
  return knex.schema.alterTable('customer_accounts', function(table) {
    table.string('risk_level').default('NONE');
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('customer_accounts', function(table) {
    table.dropColumn('risk_level').default('NONE');
  });
};