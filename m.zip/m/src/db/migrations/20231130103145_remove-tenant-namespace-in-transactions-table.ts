exports.up = async function (knex) {
  await knex.schema.alterTable('transaction', (table) => {
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
  });
  const transactionData = await knex.raw(`
    SELECT tr.id, tr.tenant_namespace, tn.tenant_id
    FROM transaction tr
    LEFT JOIN tenant_namespace tn on tn.tenant_namespace = tr.tenant_namespace
  `);

  if(transactionData && transactionData?.rows.length) {
    transactionData.rows.forEach(async (data) => {
      await knex('transaction').update({ tenant_id: data.tenant_id })
        .where({ tenant_namespace: data.tenant_namespace, id: data.id });
    });
  }

  await knex.schema.alterTable('transaction', (table) => {
    table.dropColumn('tenant_namespace');
  });

  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.dropColumn('tenant_namespace');
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('transaction', (table) => {
    table.dropColumn('tenant_id');
  });
};
