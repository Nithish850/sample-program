exports.up = function (knex) {
  return knex.schema.createTable('namespace_sequence_generator', (table) => {
    table
      .uuid('namespace_sequence_generator_id')
      .primary()
      .defaultTo(knex.raw('gen_random_uuid()'))
      .notNullable();
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('base_namespace').notNullable();
    table.integer('count').notNullable();
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('namespace_sequence_generator');
};