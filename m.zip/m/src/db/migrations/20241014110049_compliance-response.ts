exports.up = async function (knex) {
    await knex.schema.alterTable('compliance_details', (table) => {
      table.jsonb('compliance_response').defaultTo(null);
    });
  };
  
  exports.down = function (knex) {
    return knex.schema.alterTable('compliance_details', (table) => {
      table.dropColumn('compliance_response');
    });
  };
  