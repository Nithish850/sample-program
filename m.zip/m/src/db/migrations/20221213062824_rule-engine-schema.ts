/** Adding new fields to tenant_rule and removing fields from rules table */
exports.up = async function (knex) {

  await knex.schema.alterTable('rules', (table) => {
    table.dropColumn('rule_version');
    table.dropColumn('is_active');
    table.dropColumn('is_global');
  })
    .alterTable('tenant_rules', (table) => {
      table.dropPrimary()
      table.enu('rule_group', [ 'ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable().defaultTo('NONE');
      table.enu('rule_slug', [ 'tier1', 'tier2', 'tier3', 'tier4' ]);
      table.integer('rule_version').notNullable().defaultTo(1);
      table.primary([ 'tenant_id', 'rule_id', 'rule_version' ]);
      table.boolean('is_default_rule').notNullable().defaultTo(false);
      table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    })
    .alterTable('attributes', (table) => {
      table.enu('rule_group', [ 'ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable();
    })
    .createTable('rules_conditions', (table) => {
      table.uuid('condition_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
      table.uuid('attribute_id').references('attribute_id').inTable('attributes').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.string('operator').notNullable();
      table.string('attribute_value').notNullable();
      table.boolean('editable').notNullable().defaultTo(true);
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.timestamps(true, true);
    })
    .createTable('rules_decisions_tree', (table) => {
      table.uuid('decision_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
      table.string('decision_name');
      table.enu('decision_type', [ 'all', 'any' ]);
      table.uuid('parent_decision_id').references('decision_id').inTable('rules_decisions_tree').onDelete('CASCADE').onUpdate('CASCADE');
      table.text('message');
      table.jsonb('params');
      table.boolean('editable').notNullable().defaultTo(true);
      table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.timestamps(true, true);
    })
    .createTable('rules_decisions_conditions', (table) => {
      table.primary([ 'decision_id', 'condition_id' ]);
      table.uuid('decision_id').references('decision_id').inTable('rules_decisions_tree').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('condition_id').references('condition_id').inTable('rules_conditions').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
      table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    });
};

exports.down = async function (knex) {
  await knex.schema
    .dropTable('rules')
    .dropTable('tenant_rules')
    .dropTable('attributes')
    .dropTable('rules_conditions')
    .dropTable('rules_decisions_tree')
    .dropTable('rules_decisions_conditions');
};
