exports.up = function(knex) {
  return knex.schema.createTable('country_risk_rating', (table) => {
    table.uuid('country_risk_rating_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.text('country').notNullable();
    table.string('country_code').notNullable();
    table.string('risk_score').notNullable();
    table.string('risk_rating');
    table.string('ul_override');
    table.string('rationale');
    table.timestamps(true, true);
  });
};

exports.down = function(knex) {
  return knex.schema.dropTable('country_risk_rating');
};
