// /* eslint-disable no-await-in-loop */

// import { defaultRolesUL } from "../master/roles-UL";
// import { getRoleAndEntityFlagsUL } from "../master/role-entities-UL";

// exports.up = async function (knex) {
//   const entityVal = {
//     entity_name: 'Prescreening',
//     entity_description: '',
//     role_assigned: 'BOTH',
//   };

//   await knex('entities').insert(entityVal);

//   const tenantData = await knex('tenants').select('tenant_id').where({ domain: 'ul-ledger' });
//   const userData = await knex('users').select('user_id').where({ user_name: 'ul-default' });

//   // migration for role= UL_READ_ONLY and UL_ADMIN , entity = prescreening
//   const roleData = await knex('roles')
//     .select('*')
//     .whereIn('role_name', ['UL_READ_ONLY', 'UL_ADMIN']);
//   const entityPrescreening = await knex('entities').select('*').where({ entity_name: 'Prescreening' });

//   const roleEntities: any = [];

//   for (const role of roleData) {

//     const flag = await getRoleAndEntityFlagsUL(role.role_name, entityPrescreening[0].entity_name);

//     const roleEntity = {
//       entity_id: entityPrescreening[0].entity_id,
//       role_id: role.role_id,
//       tenant_id: tenantData[0].tenant_id,
//       ...flag.flag
//     };

//     roleEntities.push(roleEntity);

//   }
//   await knex('role_entities').insert(roleEntities);

//   // migration for new roles of UL with the entities
//   const entityData = await knex('entities').select('*').whereIn('role_assigned', ['BOTH', 'UL']);

//   await knex('roles').insert(await defaultRolesUL(tenantData[0].tenant_id, userData[0].user_id)).returning('*').then(async function (roleData) {
//     const roleEntities: any = [];

//     for (const role of roleData) {
//       for (const entity of entityData) {
//         const flag = await getRoleAndEntityFlagsUL(role.role_name, entity.entity_name);

//         const roleEntity = {
//           entity_id: entity.entity_id,
//           role_id: role.role_id,
//           tenant_id: tenantData[0].tenant_id,
//           ...flag.flag
//         };

//         roleEntities.push(roleEntity);
//       }
//     }
//     await knex('role_entities').insert(roleEntities);
//   });

// };

// exports.down = async function (knex) {
//   const tenantData = await knex('tenants').select('tenant_id').where({ domain: 'ul-ledger' });
//   const userData = await knex('users').select('user_id').where({ user_name: 'ul-default' });
//   const roles = await defaultRolesUL(tenantData[0].tenant_id, userData[0].user_id);

//   const roleNames = await roles.map((item) => item.role_name);

//   const roleIds = await knex('roles').find().whereIn({ role_name: roleNames }).select('role_id');

//   await knex('roles').delete().whereIn({ role_id: roleIds });
//   await knex('role_entities').delete().whereIn({ role_id: roleIds });
//   await knex('entities').delete().where({ entity_name: 'Prescreening' });

// }

exports.up = async function (knex) {}
exports.down = async function (knex) {}