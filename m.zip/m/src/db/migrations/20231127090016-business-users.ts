exports.up = function (knex) {
  return knex.schema.createTable('business_users', (table) => {
    table.uuid('business_user_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('business_user_name').notNullable();
    table.string('domain').notNullable().unique();
    table.date('start_date').notNullable();
    table.date('end_date').notNullable();
    table.enu('compliance_status', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
    table.enu('account_status', [ 'ACTIVE', 'INACTIVE', 'BLOCKED' ]).notNullable().defaultTo('ACTIVE');
    table.enu('onboarding_status', [ 'PENDING', 'APPROVED', 'REJECTED', 'ACTION REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
    table.enu('identity_provider_status', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('business_users')
}