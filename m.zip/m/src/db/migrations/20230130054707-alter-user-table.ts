exports.up = async function (knex) {
  await knex.schema.alterTable('users', (table) => {
    table.string('dob ');
    table.string('nationality ');
    table.string('ip_address');
    table.string('lat_long');
    table.boolean('notification').notNullable().defaultTo(false);
    table.enu('account_status', [ 'ACTIVE', 'INACTIVE', 'BLOCKED' ]).notNullable().defaultTo('ACTIVE');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('users');
};
