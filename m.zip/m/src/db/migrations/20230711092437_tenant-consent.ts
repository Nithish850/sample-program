exports.up = function (knex) {
  return knex.schema.alterTable('customer_consent', (table) => {
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
  })
    .createTable('tenant_consent', (table) => {
      table.uuid('tenant_consent_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('dss_vendor_id').references('dss_vendor_id').inTable('dss_vendor_consent').onDelete('CASCADE').onUpdate('CASCADE');
      table.enu('consent_status', [ 'PENDING', 'ACCEPTED', 'REJECTED' ]).notNullable().defaultTo('PENDING');
      table.string('consent_version').notNullable();
      table.timestamps(true, true);
    })
};

exports.down = function (knex) {
  return knex.schema.alterTable('customer_consent', (table) => {
    table.dropColumn('tenant_id');
  })
    .dropTable('tenant_consent');
};