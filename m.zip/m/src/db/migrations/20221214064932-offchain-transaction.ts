exports.up = function (knex) {
  return knex.schema
    .createTable('offchain_transaction', (table) => {
      table.uuid('offchain_transaction_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_customer_accounts_id').references('tenant_customer_accounts_id').inTable('tenant_customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('id').notNullable();
      table.string('address_id');
      table.string('app_id').notNullable();
      table.string('transaction_amount').notNullable();
      table.string('code').notNullable();
      table.timestamps(true, true);
      table.timestamp('deleted_at');
      table.string('currency').notNullable();
      table.string('identity_id').notNullable();
      table.string('transfer_method_id');
      table.string('origin_address');
      table.string('destination_address').notNullable();
      table.string('external_reference').notNullable();
      table.jsonb('metadata').notNullable();
      table.string('status').notNullable();
      table.jsonb('transaction_details');
      table.string('transaction_hash');
      table.string('type').notNullable();
      // transfer_type- wire/internationalWire
      table.string('transfer_type').notNullable();
      // transaction_type- credit/debit
      table.string('transaction_type').notNullable();
      table.string('full_name').notNullable();
      table.string('transaction_method').defaultTo('OFF_CHAIN');
      table.string('sender_namespace', 128);
      table.string('receiver_namespace', 128);
      table.string('tenant_namespace', 128);
      table.string('rule_status', 128);
    });
};
exports.down = function (knex) {
  return knex.schema.dropTable('offchain_transaction');
};