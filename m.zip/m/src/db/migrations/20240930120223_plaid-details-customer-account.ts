exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.jsonb('plaid_details').defaultTo(null);
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('plaid_details');
  });
};
