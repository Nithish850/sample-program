exports.up = async function (knex) {
  await knex.schema.table('transaction', (table) => {
    table.enu('transaction_method', [ 'ON_CHAIN', 'ACH', 'WIRE', 'BANK', 'CREDIT' ]);
    table.string('sender_namespace', 128);
    table.string('receiver_namespace', 128);
    table.string('source_currency', 128);
    table.string('target_currency', 128);
    table.enu('screening_status', [ 'HIGH', 'MEDIUM', 'LOW', 'ACCEPTED', 'PENDING' ]);
    table.enu('transaction_status', [ 'COMPLETED', 'PENDING', 'CANCELED', 'REVERSAL' ]);
    table.string('exchange_rate', 128);
    table.string('fees', 128);
    table.string('action', 128);
  });
};

exports.down = async function (knex) {
  await knex.schema.table('transaction', (table) => {
    table.enu('transaction_method', [ 'ON_CHAIN', 'ACH', 'WIRE', 'BANK', 'CREDIT' ]);
    table.string('sender_namespace', 128);
    table.string('receiver_namespace', 128);
    table.string('source_currency', 128);
    table.string('target_currency', 128);
    table.enu('screening_status', [ 'HIGH', 'MEDIUM', 'LOW', 'ACCEPTED', 'PENDING' ]);
    table.enu('transaction_status', [ 'COMPLETED', 'PENDING', 'CANCELED', 'REVERSAL' ]);
    table.string('exchange_rate', 128);
    table.string('fees', 128);
    table.string('action', 128);
  });
};
