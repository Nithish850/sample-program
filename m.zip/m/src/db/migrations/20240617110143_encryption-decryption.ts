/* eslint-disable no-console */
import { Knex } from 'knex';

const logger = (message: string) => {
  console.log(`[encryption-decryption] ${message}`);
};

export const up = async (knex: Knex): Promise<void> => {
  logger('Running migration:up');

  await knex.schema.createTable('encryption_decryption', (table) => {
    table.string('table_name').notNullable();
    table.string('column_name').notNullable();
    table.string('extension').defaultTo('pgcrypto')
    table.primary(['table_name', 'column_name']);
    table.timestamps(true, true);
  });

  logger('Migration up complete');
};

export const down = async (knex: Knex): Promise<void> => {
  logger('Running migration: down');

  await knex.schema.dropTable('encryption_decryption');

  logger('Migration down complete');
};
