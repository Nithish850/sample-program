import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  return knex.schema.createTable('required_attributes', (table) => {
    table
      .uuid('attribute_id')
      .primary()
      .references('attribute_id')
      .inTable('attributes')
      .onDelete('CASCADE')
      .onUpdate('CASCADE')
      .notNullable();
    table.boolean('mandatory_attribute').defaultTo(false);
    table
      .uuid('tenant_id')
      .references('tenant_id')
      .inTable('tenants')
      .onDelete('CASCADE')
      .onUpdate('CASCADE')
      .notNullable();
    table.timestamps(true, true);
  });
}

export async function down(knex: Knex): Promise<void> {
  return knex.schema.dropTableIfExists('required_attributes');
}
