exports.up = async function (knex) {
  await knex('entities').insert({
    entity_name: 'Error Messages',
    role_assigned: 'TENANT',
  })
};

exports.down = async function (knex) {
  await knex('entities').delete().where({ entity_name: 'Error Messages' });
}