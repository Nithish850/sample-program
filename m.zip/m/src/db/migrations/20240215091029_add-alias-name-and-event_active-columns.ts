exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_event_subscription',(table)=>{
    table.string('alias_name');
    table.boolean('event_active').notNullable().defaultTo(true);
  });

  await knex.schema.alterTable('event_subscription_logs',(table)=>{
    table.uuid('tenant_event_subscription_id').references('tenant_event_subscription_id')
      .inTable('tenant_event_subscription').onDelete('CASCADE').onUpdate('CASCADE');
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_event_subscription',(table)=>{
    table.dropColumn('alias_name').alter();
    table.dropColumn('event_active').alter();
  })

  await knex.schema.alterTable('event_subscription_logs',(table)=>{
    table.dropColumn('tenant_event_subscription_id');
  })
};
