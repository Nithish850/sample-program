exports.up = async function(knex) {
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.string('freezed_amount').notNullable().defaultTo('0').alter();
  })
    .alterTable('recurring_transactions', (table) => {
      table.string('freezed_amount').notNullable().defaultTo('0').alter();
    });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.integer('freezed_amount').notNullable().defaultTo(0).alter();
  })
    .alterTable('recurring_transactions', (table) => {
      table.integer('freezed_amount').notNullable().defaultTo(0).alter();
    });
};