exports.up = async function (knex) {
  await knex.schema.alterTable('tenants', (table) => {
    table.enu('identity_provider_status', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('tenants');
};
