exports.up = async function (knex) {

  await knex.schema.createTable('activity_logs', (table) => {
    table.uuid('activity_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('entity_id');
    table.string('entity');
    table.string('entity_table_name');
    table.string('activity_type');
    table.enu('db_operation', [ 'CREATE', 'READ', 'UPDATE', 'DELETE' ]);
    table.jsonb('data');
    table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate("CASCADE");
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true);
  })
};

exports.down = async function (knex) {
  return knex.schema.dropTable('activity_logs');
}