exports.up = async function (knex) {
  await knex.schema.alterTable('users', (table) => {
    table.string('phone_number');
    table.string('address');
    table.string('employee_id');
  })
}

exports.down = async function (knex) {
  await knex.schema.dropTable('users')
}