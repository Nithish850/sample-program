exports.up = async function (knex) {

  await knex.schema.createTable('business_entities', (table) => {
    table.uuid('business_entity_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('business_entity_name');
    table.string('description');
    table.boolean('is_active').notNullable().defaultTo(true);
    table.timestamps(true, true);
  })

  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.dropColumn('business_entity_type');
    table.uuid('business_entity_id').references('business_entity_id').inTable('business_entities').onDelete('CASCADE').onUpdate('CASCADE').notNullable();
  });

};

exports.down = async function (knex) {
  await knex.schema.dropTable('business_entities');
  await knex.schema.dropTable('tenant_pre_screening');
}