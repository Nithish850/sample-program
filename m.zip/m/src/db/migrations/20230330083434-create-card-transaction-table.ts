exports.up = function (knex) {
  return knex.schema.createTable('card_transaction', (table) => {
    table.uuid('card_transaction_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('transaction_id').notNullable();
    table.uuid('offchain_transaction_id').references('offchain_transaction_id').inTable('offchain_transaction').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('auth_code').notNullable();
    table.string('reference_id').notNullable();
    table.string('status').notNullable();
    table.jsonb('response').notNullable();

    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('card_transaction');
};
