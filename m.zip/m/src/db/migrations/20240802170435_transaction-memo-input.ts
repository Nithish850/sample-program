/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = function(knex) {
    return knex.schema.alterTable('transaction', (table) => {
        table.text('input');
        table.text('memo');
        table.text('memo_hex');
    });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = function(knex) {
    return knex.schema.alterTable('transaction', (table) => {
        table.dropColumn('input');
        table.dropColumn('memo');
        table.dropColumn('memo_hex');
    });
};
  