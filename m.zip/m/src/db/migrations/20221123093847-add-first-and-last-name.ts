exports.up = async function (knex) {
  await knex.schema.table('customer_accounts', (table) => {
    table.string('first_name', 128).notNullable().defaultTo('');
    table.string('middle_name', 128).notNullable().defaultTo('');
    table.string('last_name', 128).notNullable().defaultTo('');
    table.dropColumn('full_legal_name');
  });
};

exports.down = async function (knex) {
  await knex.schema.table('customer_accounts', (table) => {
    table.string('first_name', 128).notNullable().defaultTo('');
    table.string('middle_name', 128).notNullable().defaultTo('');
    table.string('last_name', 128).notNullable().defaultTo('');
    table.dropColumn('full_legal_name');
  });
};
