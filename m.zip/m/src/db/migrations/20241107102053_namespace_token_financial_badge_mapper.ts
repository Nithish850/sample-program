exports.up = function (knex) {
  return knex.schema.createTable('namespace_token_financial_badge_mapper', (table) => {
    table.uuid('namespace_id').notNullable();
    table.string('token_symbol').notNullable().references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('financial_badge_id').notNullable().references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
    table.unique(['namespace_id', 'token_symbol']);
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('namespace_token_financial_badge_mapper');
};