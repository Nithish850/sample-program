/* eslint-disable no-console */
exports.up = async function (knex) {
  await knex.raw(`
    DROP SEQUENCE IF EXISTS abc_sequence
  `);
  await knex.raw(`
    DROP TRIGGER IF EXISTS custom_key_trigger ON account_category
  `)
  await knex.schema.alterTable('tenant_customer_accounts', async (table) => {
    // const hasCategoryName = await knex.schema.hasColumn('tenant_customer_accounts', 'category_name');
    // if(!hasCategoryName) {
    //   table.dropColumn('category_name');
    // }
    // const hasCategory = await knex.schema.hasColumn('tenant_customer_accounts', 'category');

    // if(hasCategory) {
    table.string('category').references('account_category_id').inTable('account_category').onDelete('CASCADE').onUpdate('CASCADE').alter();
    // }
  });
}
exports.down = async function(knex) {
  console.log(`down log ${knex.name}`);
  await knex.schema.alterTable('tenant_customer_accounts', async (table) => {
    const hasCategoryName = await knex.schema.hasColumn('tenant_customer_accounts', 'category_name');

    if(!hasCategoryName) {
      table.string('category_name');
    }
    const hasCategory = await knex.schema.hasColumn('tenant_customer_accounts', 'category');

    if(hasCategory) {
      table.dropForeign('category')
      table.string('category').alter();
    }
  });
}