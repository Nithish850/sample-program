exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('name_combination');
    table.string('name_combination_index');
  });
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = async function (knex) {
  return await knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('name_combination');
    table.dropColumn('name_combination_index');
  });
};
