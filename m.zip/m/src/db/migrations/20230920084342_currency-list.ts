import { currencyList } from "../master/currency-list";

exports.up = async function (knex) {
  await knex.schema.createTable('currency_list', (table) =>{
    table.string('currency').notNullable();
    table.string('code');
    table.primary('code');
  });

  await knex('currency_list').insert(currencyList).returning('code').onConflict().ignore();

}

exports.down = async function(knex) {
  await knex.schema.dropTable('account_category');
}