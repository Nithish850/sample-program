/* eslint-disable no-console */

import { Knex } from 'knex';

const tableName = 'tenants';
import { getSecret } from '../../utils/util.service';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter table columns to text for encryption
    // console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN tenant_name TYPE text;
    `);
    // console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);

    await knex.raw(`
    UPDATE ${tableName}
    SET 
      tenant_name = encrypt(tenant_name::bytea, '${val}'::bytea, 'aes'::text);
  `);
    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 5: Insert entries into encryption_decryption for tenant_name column
    console.log('Inserting entries into encryption_decryption for tenant_name column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'tenant_name' }
    ]);
    console.log('Insert into encryption_decryption for tenant_name column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        tenant_name = convert_from(decrypt(tenant_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 4: Delete entries from encryption_decryption for tenant_name column
    console.log('Deleting entries from encryption_decryption for tenant_name column...');
    await knex('encryption_decryption')
      .where({ table_name: tableName, column_name: 'tenant_name' })
      .del();
    console.log('Deletion from encryption_decryption for tenant_name column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
