/* eslint-disable max-len */

/**
 * This has all the table required for multitoken flow
 */
exports.up = async function (knex) {
  const fees = { ach: 0, wire: 0, iwire: 0, debitCard: 0, creditCard: 0 };

  await knex.schema.createTable('contract_store', function (table) {
    table.uuid('contract_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('contract_address').notNullable().unique();
    table.string('symbol').notNullable().unique();
    table.jsonb('abi').notNullable();
    table.string('token_name').notNullable();
    table.integer('version').defaultTo(0);
    table.enu('status', ['ACTIVE', 'INACTIVE']).notNullable().defaultTo('ACTIVE');
    table.string('updated_by');
    table.timestamps(true, true);
  })
    .createTable('tenant_contract_mapper', function (table) {
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('contract_id').references('contract_id').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary(['contract_id', 'tenant_id']);
      table.jsonb('withdraw_fee').defaultTo(fees);
      table.jsonb('deposit_fee').defaultTo(fees);
      table.integer('onchain_fee').defaultTo(0);
      table.integer('gas_fee').defaultTo(0);
      table.enu('status', ['ACTIVE', 'INACTIVE']).notNullable().defaultTo('ACTIVE');
      table.timestamps(true, true);
    })
    .createTable('fee_history', function (table) {
      table.uuid('fee_history_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('contract_id').references('contract_id').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('updated_by');
      table.string('token_symbol').notNullable();
      table.jsonb('withdraw_fee').defaultTo(fees);
      table.jsonb('deposit_fee').defaultTo(fees);
      table.integer('onchain_fee').defaultTo(0);
      table.integer('gas_fee').defaultTo(0);
      table.timestamps(true, true);
    })
    .createTable('tenant_token_request', function (table) {
      table.uuid('request_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('symbol').notNullable().unique();
      table.jsonb('withdraw_fee').defaultTo(fees);
      table.jsonb('deposit_fee').defaultTo(fees);
      table.integer('onchain_fee').defaultTo(0);
      table.integer('gas_fee').defaultTo(0);
      table.string('name').notNullable();
      table.jsonb('logo_details');
      table.string('status').notNullable().defaultTo('REQUEST SUBMITTED');
      table.timestamps(true, true);
    });

  // insert USBC contract details
  // const genensisContract = [{
  //   contract_address: '0x0000000000000000000000000000000000002070',
  //   symbol: 'USBC',
  //   abi: {
  //     "_format": "hh-sol-artifact-1",
  //     "contractName": "ERC20PlusV8",
  //     "sourceName": "contracts/v5/ERC20PlusV8.sol",
  //     "abi": [
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "feeTypeWireInt",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "custodialHash",
  //             "type": "bytes32"
  //           },
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "calcCustodialPoolPerc",
  //         "outputs": [
  //           {
  //             "name": "result",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "chainId",
  //             "type": "int256"
  //           },
  //           {
  //             "name": "chainCode",
  //             "type": "string"
  //           }
  //         ],
  //         "name": "addUsdcChain",
  //         "outputs": [],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "name",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "string"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "max",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "setUSDCmaxWithdrawAllowed",
  //         "outputs": [],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "amountToWithdraw",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "validateMaxPoolPercentageToWithdrawalUSDC",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "totalSupply",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "getUSDCmaxPoolPercentage",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "account",
  //             "type": "address"
  //           },
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "name": "deposit",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "decimals",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint8"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "pure",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "custodialImplementation",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "address"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "feeTypeAchUS",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "sig",
  //             "type": "bytes4"
  //           },
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "estimateCosts",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "string"
  //           }
  //         ],
  //         "name": "withdrawAchUS",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "version",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "pure",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "feeTypeWireUS",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "string"
  //           }
  //         ],
  //         "name": "withdrawWireInt",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "amountToWithdraw",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "validateMaxPoolToWithdrawal",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "chainId",
  //             "type": "int256"
  //           }
  //         ],
  //         "name": "removeUsdcChain",
  //         "outputs": [],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "string"
  //           }
  //         ],
  //         "name": "withdrawUL",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "chainId",
  //             "type": "int256"
  //           }
  //         ],
  //         "name": "getUsdcChainCode",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "string"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "account",
  //             "type": "address"
  //           }
  //         ],
  //         "name": "balanceOf",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "getUSDCmaxWithdrawAllowed",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "uint256"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "account",
  //             "type": "address"
  //           },
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "name": "depositFromUSDC",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "transferMethodId",
  //             "type": "string"
  //           },
  //           {
  //             "name": "chainId",
  //             "type": "int256"
  //           }
  //         ],
  //         "name": "withdrawToUSDC",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "symbol",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "string"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "ref",
  //             "type": "string"
  //           }
  //         ],
  //         "name": "withdrawWireUS",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [
  //           {
  //             "name": "account",
  //             "type": "address"
  //           }
  //         ],
  //         "name": "balanceOfAndSymbol",
  //         "outputs": [
  //           {
  //             "name": "balance_",
  //             "type": "uint256"
  //           },
  //           {
  //             "name": "symbol_",
  //             "type": "string"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "recipient",
  //             "type": "address"
  //           },
  //           {
  //             "name": "amount",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "transfer",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bool"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": false,
  //         "inputs": [
  //           {
  //             "name": "perc",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "setUSDCmaxPoolPercentage",
  //         "outputs": [],
  //         "payable": false,
  //         "stateMutability": "nonpayable",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "getERC20storage",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "address"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "feeTypeUSDC",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "feeTypeUL",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "view",
  //         "type": "function"
  //       },
  //       {
  //         "constant": true,
  //         "inputs": [],
  //         "name": "getGasManager",
  //         "outputs": [
  //           {
  //             "name": "",
  //             "type": "address"
  //           }
  //         ],
  //         "payable": false,
  //         "stateMutability": "pure",
  //         "type": "function"
  //       },
  //       {
  //         "anonymous": false,
  //         "inputs": [
  //           {
  //             "indexed": true,
  //             "name": "to",
  //             "type": "address"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "indexed": true,
  //             "name": "ref",
  //             "type": "bytes32"
  //           },
  //           {
  //             "indexed": true,
  //             "name": "custodial",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "name": "Deposit",
  //         "type": "event"
  //       },
  //       {
  //         "anonymous": false,
  //         "inputs": [
  //           {
  //             "indexed": true,
  //             "name": "from",
  //             "type": "address"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "ref",
  //             "type": "string"
  //           },
  //           {
  //             "indexed": true,
  //             "name": "feeType",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "name": "Withdraw",
  //         "type": "event"
  //       },
  //       {
  //         "anonymous": false,
  //         "inputs": [
  //           {
  //             "indexed": true,
  //             "name": "from",
  //             "type": "address"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "amount",
  //             "type": "uint256"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "transferMethodId",
  //             "type": "string"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "chainId",
  //             "type": "int256"
  //           },
  //           {
  //             "indexed": true,
  //             "name": "feeType",
  //             "type": "bytes32"
  //           }
  //         ],
  //         "name": "WithdrawUSDC",
  //         "type": "event"
  //       },
  //       {
  //         "anonymous": false,
  //         "inputs": [
  //           {
  //             "indexed": false,
  //             "name": "sender",
  //             "type": "address"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "receipient",
  //             "type": "address"
  //           },
  //           {
  //             "indexed": false,
  //             "name": "amount",
  //             "type": "uint256"
  //           }
  //         ],
  //         "name": "Transfer",
  //         "type": "event"
  //       }
  //     ],
  //     "bytecode": "0x608060405234801561001057600080fd5b506151cf806100206000396000f3fe608060405234801561001057600080fd5b5060043610610223576000357c0100000000000000000000000000000000000000000000000000000000900480635e5c89211161013757806395d89b41116100ca578063af1a265311610099578063af1a265314610df4578063ba7271e514610e22578063bb63cd8114610e6c578063da264ce214610e8a578063f16f6ab414610ea857610223565b806395d89b4114610b6a57806397e4f20f14610bed578063a7a7ee9c14610cca578063a9059cbb14610d8e57610223565b806370a082311161010657806370a082311461099d578063881847a1146109f557806390ff3b7b14610a13578063955da6d414610a8357610223565b80635e5c8921146107a55780636019f899146107eb5780636074e8fe146108195780637031e121146108f657610223565b806326b3293f116101ba578063474eeb7d11610189578063474eeb7d14610544578063497715a9146105af57806354fd4d501461068c57806357553287146106aa5780635af05b16146106c857610223565b806326b3293f14610448578063313ce567146104b857806337140fac146104dc57806338a11a4e1461052657610223565b80630ac3f6c4116101f65780630ac3f6c41461039857806315498cb1146103c657806318160ddd1461040c57806320f02b9f1461042a57610223565b8063031abf7014610228578063033e063214610246578063044b50081461029257806306fdde0314610315575b600080fd5b610230610ef2565b6040518082815260200191505060405180910390f35b61027c6004803603604081101561025c57600080fd5b810190808035906020019092919080359060200190929190505050610f19565b6040518082815260200191505060405180910390f35b610313600480360360408110156102a857600080fd5b8101908080359060200190929190803590602001906401000000008111156102cf57600080fd5b8201836020820111156102e157600080fd5b8035906020019184600183028401116401000000008311171561030357600080fd5b90919293919293905050506110f6565b005b61031d61144e565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561035d578082015181840152602081019050610342565b50505050905090810190601f16801561038a5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6103c4600480360360208110156103ae57600080fd5b8101908080359060200190929190505050611569565b005b6103f2600480360360208110156103dc57600080fd5b81019080803590602001909291905050506117e1565b604051808215151515815260200191505060405180910390f35b61041461190a565b6040518082815260200191505060405180910390f35b6104326119cf565b6040518082815260200191505060405180910390f35b61049e6004803603606081101561045e57600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050611ac2565b604051808215151515815260200191505060405180910390f35b6104c0611ccf565b604051808260ff1660ff16815260200191505060405180910390f35b6104e4611cd8565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b61052e611dcb565b6040518082815260200191505060405180910390f35b6105996004803603604081101561055a57600080fd5b8101908080357bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916906020019092919080359060200190929190505050611df2565b6040518082815260200191505060405180910390f35b610672600480360360408110156105c557600080fd5b8101908080359060200190929190803590602001906401000000008111156105ec57600080fd5b8201836020820111156105fe57600080fd5b8035906020019184600183028401116401000000008311171561062057600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f820116905080830192505050505050509192919290505050612055565b604051808215151515815260200191505060405180910390f35b61069461214a565b6040518082815260200191505060405180910390f35b6106b2612156565b6040518082815260200191505060405180910390f35b61078b600480360360408110156106de57600080fd5b81019080803590602001909291908035906020019064010000000081111561070557600080fd5b82018360208201111561071757600080fd5b8035906020019184600183028401116401000000008311171561073957600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929050505061217d565b604051808215151515815260200191505060405180910390f35b6107d1600480360360208110156107bb57600080fd5b8101908080359060200190929190505050612272565b604051808215151515815260200191505060405180910390f35b6108176004803603602081101561080157600080fd5b810190808035906020019092919050505061236a565b005b6108dc6004803603604081101561082f57600080fd5b81019080803590602001909291908035906020019064010000000081111561085657600080fd5b82018360208201111561086857600080fd5b8035906020019184600183028401116401000000008311171561088a57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929050505061272a565b604051808215151515815260200191505060405180910390f35b6109226004803603602081101561090c57600080fd5b810190808035906020019092919050505061281f565b6040518080602001828103825283818151815260200191508051906020019080838360005b83811015610962578082015181840152602081019050610947565b50505050905090810190601f16801561098f5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6109df600480360360208110156109b357600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919050505061299b565b6040518082815260200191505060405180910390f35b6109fd612a99565b6040518082815260200191505060405180910390f35b610a6960048036036060811015610a2957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050612b8c565b604051808215151515815260200191505060405180910390f35b610b5060048036036060811015610a9957600080fd5b810190808035906020019092919080359060200190640100000000811115610ac057600080fd5b820183602082011115610ad257600080fd5b80359060200191846001830284011164010000000083111715610af457600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929080359060200190929190505050612f55565b604051808215151515815260200191505060405180910390f35b610b7261333b565b6040518080602001828103825283818151815260200191508051906020019080838360005b83811015610bb2578082015181840152602081019050610b97565b50505050905090810190601f168015610bdf5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b610cb060048036036040811015610c0357600080fd5b810190808035906020019092919080359060200190640100000000811115610c2a57600080fd5b820183602082011115610c3c57600080fd5b80359060200191846001830284011164010000000083111715610c5e57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f820116905080830192505050505050509192919290505050613456565b604051808215151515815260200191505060405180910390f35b610d0c60048036036020811015610ce057600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919050505061354b565b6040518083815260200180602001828103825283818151815260200191508051906020019080838360005b83811015610d52578082015181840152602081019050610d37565b50505050905090810190601f168015610d7f5780820380516001836020036101000a031916815260200191505b50935050505060405180910390f35b610dda60048036036040811015610da457600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190505050613761565b604051808215151515815260200191505060405180910390f35b610e2060048036036020811015610e0a57600080fd5b8101908080359060200190929190505050613778565b005b610e2a6139f0565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b610e74613a19565b6040518082815260200191505060405180910390f35b610e92613a40565b6040518082815260200191505060405180910390f35b610eb0613a67565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b7f36a13075929114fbd68f561666bd80a9b3410abe3680529c18fd79133ea9ef1960010281565b6000806000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015610fcd57600080fd5b505afa158015610fe1573d6000803e3d6000fd5b505050506040513d6020811015610ff757600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff166355f7e2af856040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561107457600080fd5b505afa158015611088573d6000803e3d6000fd5b505050506040513d602081101561109e57600080fd5b810190808051906020019092919050505090506110b961501c565b6020604051908101604052808581525090506110ec6110e78260206040519081016040528086815250613a71565b613ac5565b9250505092915050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b1580156111e957600080fd5b505afa1580156111fd573d6000803e3d6000fd5b505050506040513d602081101561121357600080fd5b81019080805190602001909291905050501515611298576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b60006112a38461281f565b51141515611319576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b60008360405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16636e8995508285856040518463ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180848152602001806020018281038252848482818152602001925080828437600081840152601f19601f820116905080830192505050945050505050600060405180830381600087803b15801561143057600080fd5b505af1158015611444573d6000803e3d6000fd5b5050505050505050565b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166317d7de7c6040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156114d357600080fd5b505afa1580156114e7573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561151157600080fd5b81019080805164010000000081111561152957600080fd5b8281019050602081018481111561153f57600080fd5b815185600182028301116401000000008211171561155c57600080fd5b5050929190505050905090565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561165c57600080fd5b505afa158015611670573d6000803e3d6000fd5b505050506040513d602081101561168657600080fd5b8101908080519060200190929190505050151561170b576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e2a4853a7f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd48600102836040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b1580156117c657600080fd5b505af11580156117da573d6000803e3d6000fd5b5050505050565b6000806118117fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa60010284610f19565b90506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e9256346001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b1580156118c457600080fd5b505afa1580156118d8573d6000803e3d6000fd5b505050506040513d60208110156118ee57600080fd5b8101908080519060200190929190505050811115915050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b15801561198f57600080fd5b505afa1580156119a3573d6000803e3d6000fd5b505050506040513d60208110156119b957600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e9256346001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015611a8257600080fd5b505afa158015611a96573d6000803e3d6000fd5b505050506040513d6020811015611aac57600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b158015611bb757600080fd5b505afa158015611bcb573d6000803e3d6000fd5b505050506040513d6020811015611be157600080fd5b81019080805190602001909291905050501515611c66576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b611c708484613ad3565b6000600102828573ffffffffffffffffffffffffffffffffffffffff167fa3ac334776aca8fe808f5c1634b30338e4789e218a9f82700019b6647df54d5e866040518082815260200191505060405180910390a4600190509392505050565b60006012905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015611d8b57600080fd5b505afa158015611d9f573d6000803e3d6000fd5b505050506040513d6020811015611db557600080fd5b8101908080519060200190929190505050905090565b7f4645cf90fee20a69cd1263264587e6cc736f2421478dc836b8c275d5e6b18b4060010281565b60008061407073ffffffffffffffffffffffffffffffffffffffff1663961006716040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b158015611e5957600080fd5b505afa158015611e6d573d6000803e3d6000fd5b505050506040513d6020811015611e8357600080fd5b8101908080519060200190929190505050905060008061407073ffffffffffffffffffffffffffffffffffffffff166385bc67f230886040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19167bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191681526020019250505060606040518083038186803b158015611f7a57600080fd5b505afa158015611f8e573d6000803e3d6000fd5b505050506040513d6060811015611fa457600080fd5b8101908080519060200190929190805190602001909291908051906020019092919050505050915091506000821515611fdf57819050611fe4565b600090505b600080851115612008576120018588613fbd90919063ffffffff16565b905061200d565b600090505b8181111561203457612028818861400790919063ffffffff16565b9550505050505061204f565b612047828861400790919063ffffffff16565b955050505050505b92915050565b60006120613384614091565b7f4645cf90fee20a69cd1263264587e6cc736f2421478dc836b8c275d5e6b18b406001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156121055780820151818401526020810190506120ea565b50505050905090810190601f1680156121325780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b6000600860ff16905090565b7f829127e4aac99498548e3e4e797af4fd752333e432a480161e9c19f9e5fbd28060010281565b60006121893384614091565b7f36a13075929114fbd68f561666bd80a9b3410abe3680529c18fd79133ea9ef196001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b8381101561222d578082015181840152602081019050612212565b50505050905090810190601f16801561225a5780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd486001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561232557600080fd5b505afa158015612339573d6000803e3d6000fd5b505050506040513d602081101561234f57600080fd5b81019080805190602001909291905050508211159050919050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561245d57600080fd5b505afa158015612471573d6000803e3d6000fd5b505050506040513d602081101561248757600080fd5b8101908080519060200190929190505050151561250c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b8060606125188261281f565b905060008151111515612593576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b600061259e8461281f565b5114151515612615576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b60008360405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16636e899550826040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808281526020018060200182810382526000815260200160200192505050600060405180830381600087803b15801561270c57600080fd5b505af1158015612720573d6000803e3d6000fd5b5050505050505050565b60006127363384614091565b7ff6c2bbbf0706ecea18fbee769bdc0dddc1c1724a6c82c466ef6744a3a8dd3e926001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156127da5780820151818401526020810190506127bf565b50505050905090810190601f1680156128075780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b606060008260405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663986e791a826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060006040518083038186803b15801561290257600080fd5b505afa158015612916573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561294057600080fd5b81019080805164010000000081111561295857600080fd5b8281019050602081018481111561296e57600080fd5b815185600182028301116401000000008211171561298b57600080fd5b5050929190505050915050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f836040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015612a5757600080fd5b505afa158015612a6b573d6000803e3d6000fd5b505050506040513d6020811015612a8157600080fd5b81019080805190602001909291905050509050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd486001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015612b4c57600080fd5b505afa158015612b60573d6000803e3d6000fd5b505050506040513d6020811015612b7657600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b158015612c8157600080fd5b505afa158015612c95573d6000803e3d6000fd5b505050506040513d6020811015612cab57600080fd5b81019080805190602001909291905050501515612d30576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b612d3a8484613ad3565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015612deb57600080fd5b505afa158015612dff573d6000803e3d6000fd5b505050506040513d6020811015612e1557600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff1663d65145687fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102856040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b158015612ebf57600080fd5b505af1158015612ed3573d6000803e3d6000fd5b505050507fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102828573ffffffffffffffffffffffffffffffffffffffff167fa3ac334776aca8fe808f5c1634b30338e4789e218a9f82700019b6647df54d5e866040518082815260200191505060405180910390a4600190509392505050565b600083612f6181612272565b1515612fb8576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252604b8152602001806150f2604b913960600191505060405180910390fd5b612fc1816117e1565b1515613018576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252605681526020018061509c6056913960600191505060405180910390fd5b8260606130248261281f565b90506000815111151561309f576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b6130a93388614091565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561315a57600080fd5b505afa15801561316e573d6000803e3d6000fd5b505050506040513d602081101561318457600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff16633bdb6da57fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102896040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b15801561322e57600080fd5b505af1158015613242573d6000803e3d6000fd5b505050507fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa6001023373ffffffffffffffffffffffffffffffffffffffff167f915e9c919ca1cc4448a49096146257a7e88dd44c1209012518e12c9922893bf18989896040518084815260200180602001838152602001828103825284818151815260200191508051906020019080838360005b838110156132f15780820151818401526020810190506132d6565b50505050905090810190601f16801561331e5780820380516001836020036101000a031916815260200191505b5094505050505060405180910390a3600193505050509392505050565b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663150704016040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156133c057600080fd5b505afa1580156133d4573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f8201168201806040525060208110156133fe57600080fd5b81019080805164010000000081111561341657600080fd5b8281019050602081018481111561342c57600080fd5b815185600182028301116401000000008211171561344957600080fd5b5050929190505050905090565b60006134623384614091565b7f829127e4aac99498548e3e4e797af4fd752333e432a480161e9c19f9e5fbd2806001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156135065780820151818401526020810190506134eb565b50505050905090810190601f1680156135335780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b600060606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f846040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561360957600080fd5b505afa15801561361d573d6000803e3d6000fd5b505050506040513d602081101561363357600080fd5b81019080805190602001909291905050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663150704016040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156136c757600080fd5b505afa1580156136db573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561370557600080fd5b81019080805164010000000081111561371d57600080fd5b8281019050602081018481111561373357600080fd5b815185600182028301116401000000008211171561375057600080fd5b505092919050505091509150915091565b600061376e3384846146ad565b6001905092915050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561386b57600080fd5b505afa15801561387f573d6000803e3d6000fd5b505050506040513d602081101561389557600080fd5b8101908080519060200190929190505050151561391a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e2a4853a7f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e925634600102836040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b1580156139d557600080fd5b505af11580156139e9573d6000803e3d6000fd5b5050505050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16905090565b7fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa60010281565b7ff6c2bbbf0706ecea18fbee769bdc0dddc1c1724a6c82c466ef6744a3a8dd3e9260010281565b6000614070905090565b613a7961501c565b602060405190810160405280613aba8460000151613aac670de0b6b3a76400008860000151614dbc90919063ffffffff16565b613fbd90919063ffffffff16565b815250905092915050565b600081600001519050919050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1614151515613b78576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601f8152602001807f45524332303a206d696e7420746f20746865207a65726f20616464726573730081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc83613cbd846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015613c7457600080fd5b505afa158015613c88573d6000803e3d6000fd5b505050506040513d6020811015613c9e57600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015613d4257600080fd5b505af1158015613d56573d6000803e3d6000fd5b505050506040513d6020811015613d6c57600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f7ea7a3d613e8b836000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b158015613e4257600080fd5b505afa158015613e56573d6000803e3d6000fd5b505050506040513d6020811015613e6c57600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180828152602001915050602060405180830381600087803b158015613edd57600080fd5b505af1158015613ef1573d6000803e3d6000fd5b505050506040513d6020811015613f0757600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60008383604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a15050565b6000613fff83836040805190810160405280601a81526020017f536166654d6174683a206469766973696f6e206279207a65726f000000000000815250614e46565b905092915050565b6000808284019050838110151515614087576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601b8152602001807f536166654d6174683a206164646974696f6e206f766572666c6f77000000000081525060200191505060405180910390fd5b8091505092915050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1614151515614119576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602181526020018061515e6021913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f836040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b1580156141d357600080fd5b505afa1580156141e7573d6000803e3d6000fd5b505050506040513d60208110156141fd57600080fd5b81019080805190602001909291905050508111151515614268576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260228152602001806150546022913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc836143ad846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561436457600080fd5b505afa158015614378573d6000803e3d6000fd5b505050506040513d602081101561438e57600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b15801561443257600080fd5b505af1158015614446573d6000803e3d6000fd5b505050506040513d602081101561445c57600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f7ea7a3d61457b836000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b15801561453257600080fd5b505afa158015614546573d6000803e3d6000fd5b505050506040513d602081101561455c57600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180828152602001915050602060405180830381600087803b1580156145cd57600080fd5b505af11580156145e1573d6000803e3d6000fd5b505050506040513d60208110156145f757600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef82600083604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a15050565b600073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff1614151515614735576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602581526020018061517f6025913960400191505060405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff16141515156147bd576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260238152602001806150316023913960400191505060405180910390fd5b806000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f856040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561487857600080fd5b505afa15801561488c573d6000803e3d6000fd5b505050506040513d60208110156148a257600080fd5b81019080805190602001909291905050501015151561490c576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260268152602001806150766026913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc84614a51846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f896040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015614a0857600080fd5b505afa158015614a1c573d6000803e3d6000fd5b505050506040513d6020811015614a3257600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015614ad657600080fd5b505af1158015614aea573d6000803e3d6000fd5b505050506040513d6020811015614b0057600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc83614c57846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015614c0e57600080fd5b505afa158015614c22573d6000803e3d6000fd5b505050506040513d6020811015614c3857600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015614cdc57600080fd5b505af1158015614cf0573d6000803e3d6000fd5b505050506040513d6020811015614d0657600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef838383604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a1505050565b600080831415614dcf5760009050614e40565b60008284029050828482811515614de257fe5b04141515614e3b576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602181526020018061513d6021913960400191505060405180910390fd5b809150505b92915050565b600080831182901515614ef4576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b83811015614eb9578082015181840152602081019050614e9e565b50505050905090810190601f168015614ee65780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b5060008385811515614f0257fe5b049050809150509392505050565b6000614f5283836040805190810160405280601e81526020017f536166654d6174683a207375627472616374696f6e206f766572666c6f770000815250614f5a565b905092915050565b60008383111582901515615009576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b83811015614fce578082015181840152602081019050614fb3565b50505050905090810190601f168015614ffb5780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b5060008385039050809150509392505050565b60206040519081016040528060008152509056fe45524332303a207472616e7366657220746f20746865207a65726f206164647265737345524332303a206275726e20616d6f756e7420657863656564732062616c616e636545524332303a207472616e7366657220616d6f756e7420657863656564732062616c616e6365697356616c6964416d6f756e74466f725769746864726177616c546f555344433a2063616c6c65722065786365656473206d6178696d756d20706f6f6c2070657263656e7461676520746f207769746864726177616c697356616c6964416d6f756e74466f725769746864726177616c546f555344433a2063616c6c65722065786365656473206d6178696d756d20706f6f6c20746f207769746864726177616c536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f7745524332303a206275726e2066726f6d20746865207a65726f206164647265737345524332303a207472616e736665722066726f6d20746865207a65726f2061646472657373a165627a7a723058204f191a9360492a0590a26895786c55f6cccf55496c639ac338d28e625f06b28d0029",
  //     "deployedBytecode": "0x608060405234801561001057600080fd5b5060043610610223576000357c0100000000000000000000000000000000000000000000000000000000900480635e5c89211161013757806395d89b41116100ca578063af1a265311610099578063af1a265314610df4578063ba7271e514610e22578063bb63cd8114610e6c578063da264ce214610e8a578063f16f6ab414610ea857610223565b806395d89b4114610b6a57806397e4f20f14610bed578063a7a7ee9c14610cca578063a9059cbb14610d8e57610223565b806370a082311161010657806370a082311461099d578063881847a1146109f557806390ff3b7b14610a13578063955da6d414610a8357610223565b80635e5c8921146107a55780636019f899146107eb5780636074e8fe146108195780637031e121146108f657610223565b806326b3293f116101ba578063474eeb7d11610189578063474eeb7d14610544578063497715a9146105af57806354fd4d501461068c57806357553287146106aa5780635af05b16146106c857610223565b806326b3293f14610448578063313ce567146104b857806337140fac146104dc57806338a11a4e1461052657610223565b80630ac3f6c4116101f65780630ac3f6c41461039857806315498cb1146103c657806318160ddd1461040c57806320f02b9f1461042a57610223565b8063031abf7014610228578063033e063214610246578063044b50081461029257806306fdde0314610315575b600080fd5b610230610ef2565b6040518082815260200191505060405180910390f35b61027c6004803603604081101561025c57600080fd5b810190808035906020019092919080359060200190929190505050610f19565b6040518082815260200191505060405180910390f35b610313600480360360408110156102a857600080fd5b8101908080359060200190929190803590602001906401000000008111156102cf57600080fd5b8201836020820111156102e157600080fd5b8035906020019184600183028401116401000000008311171561030357600080fd5b90919293919293905050506110f6565b005b61031d61144e565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561035d578082015181840152602081019050610342565b50505050905090810190601f16801561038a5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6103c4600480360360208110156103ae57600080fd5b8101908080359060200190929190505050611569565b005b6103f2600480360360208110156103dc57600080fd5b81019080803590602001909291905050506117e1565b604051808215151515815260200191505060405180910390f35b61041461190a565b6040518082815260200191505060405180910390f35b6104326119cf565b6040518082815260200191505060405180910390f35b61049e6004803603606081101561045e57600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050611ac2565b604051808215151515815260200191505060405180910390f35b6104c0611ccf565b604051808260ff1660ff16815260200191505060405180910390f35b6104e4611cd8565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b61052e611dcb565b6040518082815260200191505060405180910390f35b6105996004803603604081101561055a57600080fd5b8101908080357bffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916906020019092919080359060200190929190505050611df2565b6040518082815260200191505060405180910390f35b610672600480360360408110156105c557600080fd5b8101908080359060200190929190803590602001906401000000008111156105ec57600080fd5b8201836020820111156105fe57600080fd5b8035906020019184600183028401116401000000008311171561062057600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f820116905080830192505050505050509192919290505050612055565b604051808215151515815260200191505060405180910390f35b61069461214a565b6040518082815260200191505060405180910390f35b6106b2612156565b6040518082815260200191505060405180910390f35b61078b600480360360408110156106de57600080fd5b81019080803590602001909291908035906020019064010000000081111561070557600080fd5b82018360208201111561071757600080fd5b8035906020019184600183028401116401000000008311171561073957600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929050505061217d565b604051808215151515815260200191505060405180910390f35b6107d1600480360360208110156107bb57600080fd5b8101908080359060200190929190505050612272565b604051808215151515815260200191505060405180910390f35b6108176004803603602081101561080157600080fd5b810190808035906020019092919050505061236a565b005b6108dc6004803603604081101561082f57600080fd5b81019080803590602001909291908035906020019064010000000081111561085657600080fd5b82018360208201111561086857600080fd5b8035906020019184600183028401116401000000008311171561088a57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929050505061272a565b604051808215151515815260200191505060405180910390f35b6109226004803603602081101561090c57600080fd5b810190808035906020019092919050505061281f565b6040518080602001828103825283818151815260200191508051906020019080838360005b83811015610962578082015181840152602081019050610947565b50505050905090810190601f16801561098f5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b6109df600480360360208110156109b357600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919050505061299b565b6040518082815260200191505060405180910390f35b6109fd612a99565b6040518082815260200191505060405180910390f35b610a6960048036036060811015610a2957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050612b8c565b604051808215151515815260200191505060405180910390f35b610b5060048036036060811015610a9957600080fd5b810190808035906020019092919080359060200190640100000000811115610ac057600080fd5b820183602082011115610ad257600080fd5b80359060200191846001830284011164010000000083111715610af457600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f82011690508083019250505050505050919291929080359060200190929190505050612f55565b604051808215151515815260200191505060405180910390f35b610b7261333b565b6040518080602001828103825283818151815260200191508051906020019080838360005b83811015610bb2578082015181840152602081019050610b97565b50505050905090810190601f168015610bdf5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b610cb060048036036040811015610c0357600080fd5b810190808035906020019092919080359060200190640100000000811115610c2a57600080fd5b820183602082011115610c3c57600080fd5b80359060200191846001830284011164010000000083111715610c5e57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600081840152601f19601f820116905080830192505050505050509192919290505050613456565b604051808215151515815260200191505060405180910390f35b610d0c60048036036020811015610ce057600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919050505061354b565b6040518083815260200180602001828103825283818151815260200191508051906020019080838360005b83811015610d52578082015181840152602081019050610d37565b50505050905090810190601f168015610d7f5780820380516001836020036101000a031916815260200191505b50935050505060405180910390f35b610dda60048036036040811015610da457600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190505050613761565b604051808215151515815260200191505060405180910390f35b610e2060048036036020811015610e0a57600080fd5b8101908080359060200190929190505050613778565b005b610e2a6139f0565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b610e74613a19565b6040518082815260200191505060405180910390f35b610e92613a40565b6040518082815260200191505060405180910390f35b610eb0613a67565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b7f36a13075929114fbd68f561666bd80a9b3410abe3680529c18fd79133ea9ef1960010281565b6000806000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015610fcd57600080fd5b505afa158015610fe1573d6000803e3d6000fd5b505050506040513d6020811015610ff757600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff166355f7e2af856040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561107457600080fd5b505afa158015611088573d6000803e3d6000fd5b505050506040513d602081101561109e57600080fd5b810190808051906020019092919050505090506110b961501c565b6020604051908101604052808581525090506110ec6110e78260206040519081016040528086815250613a71565b613ac5565b9250505092915050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b1580156111e957600080fd5b505afa1580156111fd573d6000803e3d6000fd5b505050506040513d602081101561121357600080fd5b81019080805190602001909291905050501515611298576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b60006112a38461281f565b51141515611319576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b60008360405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16636e8995508285856040518463ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180848152602001806020018281038252848482818152602001925080828437600081840152601f19601f820116905080830192505050945050505050600060405180830381600087803b15801561143057600080fd5b505af1158015611444573d6000803e3d6000fd5b5050505050505050565b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166317d7de7c6040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156114d357600080fd5b505afa1580156114e7573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561151157600080fd5b81019080805164010000000081111561152957600080fd5b8281019050602081018481111561153f57600080fd5b815185600182028301116401000000008211171561155c57600080fd5b5050929190505050905090565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561165c57600080fd5b505afa158015611670573d6000803e3d6000fd5b505050506040513d602081101561168657600080fd5b8101908080519060200190929190505050151561170b576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e2a4853a7f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd48600102836040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b1580156117c657600080fd5b505af11580156117da573d6000803e3d6000fd5b5050505050565b6000806118117fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa60010284610f19565b90506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e9256346001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b1580156118c457600080fd5b505afa1580156118d8573d6000803e3d6000fd5b505050506040513d60208110156118ee57600080fd5b8101908080519060200190929190505050811115915050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b15801561198f57600080fd5b505afa1580156119a3573d6000803e3d6000fd5b505050506040513d60208110156119b957600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e9256346001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015611a8257600080fd5b505afa158015611a96573d6000803e3d6000fd5b505050506040513d6020811015611aac57600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b158015611bb757600080fd5b505afa158015611bcb573d6000803e3d6000fd5b505050506040513d6020811015611be157600080fd5b81019080805190602001909291905050501515611c66576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b611c708484613ad3565b6000600102828573ffffffffffffffffffffffffffffffffffffffff167fa3ac334776aca8fe808f5c1634b30338e4789e218a9f82700019b6647df54d5e866040518082815260200191505060405180910390a4600190509392505050565b60006012905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015611d8b57600080fd5b505afa158015611d9f573d6000803e3d6000fd5b505050506040513d6020811015611db557600080fd5b8101908080519060200190929190505050905090565b7f4645cf90fee20a69cd1263264587e6cc736f2421478dc836b8c275d5e6b18b4060010281565b60008061407073ffffffffffffffffffffffffffffffffffffffff1663961006716040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b158015611e5957600080fd5b505afa158015611e6d573d6000803e3d6000fd5b505050506040513d6020811015611e8357600080fd5b8101908080519060200190929190505050905060008061407073ffffffffffffffffffffffffffffffffffffffff166385bc67f230886040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001827bffffffffffffffffffffffffffffffffffffffffffffffffffffffff19167bffffffffffffffffffffffffffffffffffffffffffffffffffffffff191681526020019250505060606040518083038186803b158015611f7a57600080fd5b505afa158015611f8e573d6000803e3d6000fd5b505050506040513d6060811015611fa457600080fd5b8101908080519060200190929190805190602001909291908051906020019092919050505050915091506000821515611fdf57819050611fe4565b600090505b600080851115612008576120018588613fbd90919063ffffffff16565b905061200d565b600090505b8181111561203457612028818861400790919063ffffffff16565b9550505050505061204f565b612047828861400790919063ffffffff16565b955050505050505b92915050565b60006120613384614091565b7f4645cf90fee20a69cd1263264587e6cc736f2421478dc836b8c275d5e6b18b406001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156121055780820151818401526020810190506120ea565b50505050905090810190601f1680156121325780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b6000600860ff16905090565b7f829127e4aac99498548e3e4e797af4fd752333e432a480161e9c19f9e5fbd28060010281565b60006121893384614091565b7f36a13075929114fbd68f561666bd80a9b3410abe3680529c18fd79133ea9ef196001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b8381101561222d578082015181840152602081019050612212565b50505050905090810190601f16801561225a5780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd486001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561232557600080fd5b505afa158015612339573d6000803e3d6000fd5b505050506040513d602081101561234f57600080fd5b81019080805190602001909291905050508211159050919050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561245d57600080fd5b505afa158015612471573d6000803e3d6000fd5b505050506040513d602081101561248757600080fd5b8101908080519060200190929190505050151561250c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b8060606125188261281f565b905060008151111515612593576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b600061259e8461281f565b5114151515612615576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b60008360405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16636e899550826040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808281526020018060200182810382526000815260200160200192505050600060405180830381600087803b15801561270c57600080fd5b505af1158015612720573d6000803e3d6000fd5b5050505050505050565b60006127363384614091565b7ff6c2bbbf0706ecea18fbee769bdc0dddc1c1724a6c82c466ef6744a3a8dd3e926001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156127da5780820151818401526020810190506127bf565b50505050905090810190601f1680156128075780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b606060008260405160200180807f636f6d2e7075626c69636d696e742e555344432e636861696e2e000000000000815250601a018281526020019150506040516020818303038152906040528051906020012090506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663986e791a826040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060006040518083038186803b15801561290257600080fd5b505afa158015612916573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561294057600080fd5b81019080805164010000000081111561295857600080fd5b8281019050602081018481111561296e57600080fd5b815185600182028301116401000000008211171561298b57600080fd5b5050929190505050915050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f836040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015612a5757600080fd5b505afa158015612a6b573d6000803e3d6000fd5b505050506040513d6020811015612a8157600080fd5b81019080805190602001909291905050509050919050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663bd02d0f57f70e2c166c7d1c8c4993c45050f63b15239859ee203443dcceb908d0a62a2bd486001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015612b4c57600080fd5b505afa158015612b60573d6000803e3d6000fd5b505050506040513d6020811015612b7657600080fd5b8101908080519060200190929190505050905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b158015612c8157600080fd5b505afa158015612c95573d6000803e3d6000fd5b505050506040513d6020811015612cab57600080fd5b81019080805190602001909291905050501515612d30576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b612d3a8484613ad3565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b158015612deb57600080fd5b505afa158015612dff573d6000803e3d6000fd5b505050506040513d6020811015612e1557600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff1663d65145687fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102856040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b158015612ebf57600080fd5b505af1158015612ed3573d6000803e3d6000fd5b505050507fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102828573ffffffffffffffffffffffffffffffffffffffff167fa3ac334776aca8fe808f5c1634b30338e4789e218a9f82700019b6647df54d5e866040518082815260200191505060405180910390a4600190509392505050565b600083612f6181612272565b1515612fb8576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252604b8152602001806150f2604b913960600191505060405180910390fd5b612fc1816117e1565b1515613018576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252605681526020018061509c6056913960600191505060405180910390fd5b8260606130248261281f565b90506000815111151561309f576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f455243323076343a20496e76616c696420636861696e2069640000000000000081525060200191505060405180910390fd5b6130a93388614091565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166321f8a7217f6d9eaf50dbbf248f4c5b7ab05d699e46af461ecc0c9856c853a4387be4f3d8646001026040518263ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018082815260200191505060206040518083038186803b15801561315a57600080fd5b505afa15801561316e573d6000803e3d6000fd5b505050506040513d602081101561318457600080fd5b810190808051906020019092919050505073ffffffffffffffffffffffffffffffffffffffff16633bdb6da57fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa600102896040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b15801561322e57600080fd5b505af1158015613242573d6000803e3d6000fd5b505050507fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa6001023373ffffffffffffffffffffffffffffffffffffffff167f915e9c919ca1cc4448a49096146257a7e88dd44c1209012518e12c9922893bf18989896040518084815260200180602001838152602001828103825284818151815260200191508051906020019080838360005b838110156132f15780820151818401526020810190506132d6565b50505050905090810190601f16801561331e5780820380516001836020036101000a031916815260200191505b5094505050505060405180910390a3600193505050509392505050565b60606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663150704016040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156133c057600080fd5b505afa1580156133d4573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f8201168201806040525060208110156133fe57600080fd5b81019080805164010000000081111561341657600080fd5b8281019050602081018481111561342c57600080fd5b815185600182028301116401000000008211171561344957600080fd5b5050929190505050905090565b60006134623384614091565b7f829127e4aac99498548e3e4e797af4fd752333e432a480161e9c19f9e5fbd2806001023373ffffffffffffffffffffffffffffffffffffffff167f104dd8d72c1c8780e819b6b48fc0aaaa09c4a381b01207c719f99303427910a485856040518083815260200180602001828103825283818151815260200191508051906020019080838360005b838110156135065780820151818401526020810190506134eb565b50505050905090810190601f1680156135335780820380516001836020036101000a031916815260200191505b50935050505060405180910390a36001905092915050565b600060606000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f846040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561360957600080fd5b505afa15801561361d573d6000803e3d6000fd5b505050506040513d602081101561363357600080fd5b81019080805190602001909291905050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663150704016040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160006040518083038186803b1580156136c757600080fd5b505afa1580156136db573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f82011682018060405250602081101561370557600080fd5b81019080805164010000000081111561371d57600080fd5b8281019050602081018481111561373357600080fd5b815185600182028301116401000000008211171561375057600080fd5b505092919050505091509150915091565b600061376e3384846146ad565b6001905092915050565b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663065f593b336040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180806020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828103825260068152602001807f77616c6c657400000000000000000000000000000000000000000000000000008152506020019250505060206040518083038186803b15801561386b57600080fd5b505afa15801561387f573d6000803e3d6000fd5b505050506040513d602081101561389557600080fd5b8101908080519060200190929190505050151561391a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f43616c6c6572206973206e6f74204d756c74695369672077616c6c657400000081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e2a4853a7f28109d4fac8befed708630a8ee03cbcf4f5dc92ba58ae799452daa057e925634600102836040518363ffffffff167c01000000000000000000000000000000000000000000000000000000000281526004018083815260200182815260200192505050600060405180830381600087803b1580156139d557600080fd5b505af11580156139e9573d6000803e3d6000fd5b5050505050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16905090565b7fd6aca1be9729c13d677335161321649cccae6a591554772516700f986f942eaa60010281565b7ff6c2bbbf0706ecea18fbee769bdc0dddc1c1724a6c82c466ef6744a3a8dd3e9260010281565b6000614070905090565b613a7961501c565b602060405190810160405280613aba8460000151613aac670de0b6b3a76400008860000151614dbc90919063ffffffff16565b613fbd90919063ffffffff16565b815250905092915050565b600081600001519050919050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1614151515613b78576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601f8152602001807f45524332303a206d696e7420746f20746865207a65726f20616464726573730081525060200191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc83613cbd846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015613c7457600080fd5b505afa158015613c88573d6000803e3d6000fd5b505050506040513d6020811015613c9e57600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015613d4257600080fd5b505af1158015613d56573d6000803e3d6000fd5b505050506040513d6020811015613d6c57600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f7ea7a3d613e8b836000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b158015613e4257600080fd5b505afa158015613e56573d6000803e3d6000fd5b505050506040513d6020811015613e6c57600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180828152602001915050602060405180830381600087803b158015613edd57600080fd5b505af1158015613ef1573d6000803e3d6000fd5b505050506040513d6020811015613f0757600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef60008383604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a15050565b6000613fff83836040805190810160405280601a81526020017f536166654d6174683a206469766973696f6e206279207a65726f000000000000815250614e46565b905092915050565b6000808284019050838110151515614087576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601b8152602001807f536166654d6174683a206164646974696f6e206f766572666c6f77000000000081525060200191505060405180910390fd5b8091505092915050565b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff1614151515614119576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602181526020018061515e6021913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f836040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b1580156141d357600080fd5b505afa1580156141e7573d6000803e3d6000fd5b505050506040513d60208110156141fd57600080fd5b81019080805190602001909291905050508111151515614268576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260228152602001806150546022913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc836143ad846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561436457600080fd5b505afa158015614378573d6000803e3d6000fd5b505050506040513d602081101561438e57600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b15801561443257600080fd5b505af1158015614446573d6000803e3d6000fd5b505050506040513d602081101561445c57600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f7ea7a3d61457b836000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663c4e41b226040518163ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040160206040518083038186803b15801561453257600080fd5b505afa158015614546573d6000803e3d6000fd5b505050506040513d602081101561455c57600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518263ffffffff167c010000000000000000000000000000000000000000000000000000000002815260040180828152602001915050602060405180830381600087803b1580156145cd57600080fd5b505af11580156145e1573d6000803e3d6000fd5b505050506040513d60208110156145f757600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef82600083604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a15050565b600073ffffffffffffffffffffffffffffffffffffffff168373ffffffffffffffffffffffffffffffffffffffff1614151515614735576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602581526020018061517f6025913960400191505060405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff16141515156147bd576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260238152602001806150316023913960400191505060405180910390fd5b806000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f856040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b15801561487857600080fd5b505afa15801561488c573d6000803e3d6000fd5b505050506040513d60208110156148a257600080fd5b81019080805190602001909291905050501015151561490c576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260268152602001806150766026913960400191505060405180910390fd5b6000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc84614a51846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f896040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015614a0857600080fd5b505afa158015614a1c573d6000803e3d6000fd5b505050506040513d6020811015614a3257600080fd5b8101908080519060200190929190505050614f1090919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015614ad657600080fd5b505af1158015614aea573d6000803e3d6000fd5b505050506040513d6020811015614b0057600080fd5b8101908080519060200190929190505050506000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e30443bc83614c57846000809054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663f8b2cb4f886040518263ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b158015614c0e57600080fd5b505afa158015614c22573d6000803e3d6000fd5b505050506040513d6020811015614c3857600080fd5b810190808051906020019092919050505061400790919063ffffffff16565b6040518363ffffffff167c0100000000000000000000000000000000000000000000000000000000028152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015614cdc57600080fd5b505af1158015614cf0573d6000803e3d6000fd5b505050506040513d6020811015614d0657600080fd5b8101908080519060200190929190505050507fddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef838383604051808473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001828152602001935050505060405180910390a1505050565b600080831415614dcf5760009050614e40565b60008284029050828482811515614de257fe5b04141515614e3b576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602181526020018061513d6021913960400191505060405180910390fd5b809150505b92915050565b600080831182901515614ef4576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b83811015614eb9578082015181840152602081019050614e9e565b50505050905090810190601f168015614ee65780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b5060008385811515614f0257fe5b049050809150509392505050565b6000614f5283836040805190810160405280601e81526020017f536166654d6174683a207375627472616374696f6e206f766572666c6f770000815250614f5a565b905092915050565b60008383111582901515615009576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b83811015614fce578082015181840152602081019050614fb3565b50505050905090810190601f168015614ffb5780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b5060008385039050809150509392505050565b60206040519081016040528060008152509056fe45524332303a207472616e7366657220746f20746865207a65726f206164647265737345524332303a206275726e20616d6f756e7420657863656564732062616c616e636545524332303a207472616e7366657220616d6f756e7420657863656564732062616c616e6365697356616c6964416d6f756e74466f725769746864726177616c546f555344433a2063616c6c65722065786365656473206d6178696d756d20706f6f6c2070657263656e7461676520746f207769746864726177616c697356616c6964416d6f756e74466f725769746864726177616c546f555344433a2063616c6c65722065786365656473206d6178696d756d20706f6f6c20746f207769746864726177616c536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f7745524332303a206275726e2066726f6d20746865207a65726f206164647265737345524332303a207472616e736665722066726f6d20746865207a65726f2061646472657373a165627a7a723058204f191a9360492a0590a26895786c55f6cccf55496c639ac338d28e625f06b28d0029",
  //     "linkReferences": {},
  //     "deployedLinkReferences": {}
  //   },
  //   token_name: 'Platform Token',
  //   updated_by: 'Platform Admin',
  // }]

  // const result = await knex('contract_store').insert(genensisContract).onConflict().ignore().returning('contract_id');

  // if (result.length && result[0]?.contract_id) {
  //   const defaultTenantName = process.env.DEFAULT_TENANT;

  //   const defaultTenant = await knex('tenants').select('tenant_id').where({
  //     tenant_name: defaultTenantName,
  //   })

  //   const tenant_id = defaultTenant[0]?.tenant_id;

  //   if (tenant_id) {

  //     // insert USBC contract in tenant token request
  //     const platformTokenData = [{
  //       tenant_id: tenant_id,
  //       symbol: 'USBC',
  //       logo_details: {},
  //       name: 'Platform Token',
  //       withdraw_fee: fees,
  //       deposit_fee: fees,
  //       onchain_fee: 0,
  //       gas_fee: 0,
  //       status: 'ACTIVE'
  //     }]

  //     await knex('tenant_token_request').insert(platformTokenData).onConflict().ignore().returning('request_id');

  //     const defaultTenantContractMapper = [{
  //       tenant_id: tenant_id,
  //       contract_id: result[0]?.contract_id
  //     }];

  //     await knex('tenant_contract_mapper').insert(defaultTenantContractMapper).onConflict().ignore();

  //     const defaultFeeHistory = [{
  //       tenant_id: tenant_id,
  //       contract_id: result[0]?.contract_id,
  //       updated_by: 'Platform Admin',
  //       token_symbol: 'USBC'
  //     }]

  //     await knex('fee_history').insert(defaultFeeHistory).onConflict().ignore();

  //   }
  // }
};

exports.down = async function (knex) {
  await knex.schema.dropTable('tenant_contract_mapper').dropTable('contract_store');
};