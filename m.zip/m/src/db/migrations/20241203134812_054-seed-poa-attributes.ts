import { Knex } from 'knex';

import { getDefaultTenantId } from '../../utils/encryption';

const proofOfAddressAttribute = [
  {
    attribute_name: 'proofOfAddressList',
    attribute_type: 'ARRAY',
    rule_group: 'ONBOARD',
    attribute_desc: 'Proof Of Address Type',
    is_required: false,
    display_attribute_name: 'Proof of Address Type',
    attribute_options: {
      value: [
        'Utility Bill',
        'Bank Statement',
        'Credit Card statement',
        'Rental Lease Agreement',
        'Vehicle Registration',
        'Property Tax Bill',
        'Property Title',
        'W2 Document',
        'Tax Return Document',
        'Others',
      ],
    },
    options_type: 'string',
  },
  {
    attribute_name: 'proofOfAddress',
    attribute_type: 'BOOLEAN',
    rule_group: 'ONBOARD',
    attribute_desc: 'Proof Of Address',
    is_required: false,
    display_attribute_name: 'Proof of Address',
    derived_attribute: 'proofOfAddressList',
  },
  {
    attribute_name: 'proofOfAddressStatus',
    attribute_type: 'STRING',
    rule_group: 'RISK',
    attribute_desc: 'Proof Of Address Verification Status',
    is_required: false,
    display_attribute_name: 'Proof of Address Verification Status',
    attribute_options: {
      value: ['Verified', 'Not Verified'],
    },
    options_type: 'string',
  },
];

export async function up(knex: Knex): Promise<void> {
  const tenant_id = await getDefaultTenantId(knex);

  console.log('migration running: 054-seed-poa-attributes.ts');
  if (tenant_id) {
    proofOfAddressAttribute.forEach((attribute) => {
      attribute['tenant_id'] = tenant_id;
    });

    await knex('attributes').insert(proofOfAddressAttribute);
  }
  console.log('migration completed: 054-seed-poa-attributes.ts');
}

export async function down(knex: Knex): Promise<void> {
  const tenant_id = await getDefaultTenantId(knex);

  console.log('rolling back migration: 054-seed-poa-attributes.ts');
  if (tenant_id) {
    await knex('attributes')
      .whereIn(
        'attribute_name',
        proofOfAddressAttribute.map((attribute) => attribute.attribute_name),
      )
      .andWhere('tenant_id', tenant_id)
      .del();
  }
  console.log('rollback completed: 054-seed-poa-attributes.ts');
}
