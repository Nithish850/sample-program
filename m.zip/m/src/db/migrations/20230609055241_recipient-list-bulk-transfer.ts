exports.up = function (knex) {
  return knex.schema.alterTable('bulk_transactions', (table) => {
    table.string('recipient_list');
  })
};

exports.down = function (knex) {
  return knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('recipient_list');
  })
};