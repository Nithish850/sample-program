/** function to bring up bulk_transactions_receipts table */
exports.up = async function (knex) {
  return knex.schema
    .alterTable('bulk_transactions_receipts', function (table) {
      table.renameColumn('fromNamespace', 'from_namespace')
      table.renameColumn('toNamespace', 'to_namespace')
    });
};

/** function to bring down bulk_transactions_receipts table */
exports.down = function (knex) {
  return knex.schema.dropTable('bulk_transactions_receipts');
};
