/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'sanction_reports';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter table columns to text for encryption
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN nationality TYPE text,
      ALTER COLUMN residence_of_jurisdiction TYPE text,
      ALTER COLUMN country_of_registration TYPE text,
      ALTER COLUMN tax_country TYPE text,
      ALTER COLUMN principal_country_of_business TYPE text,
      ALTER COLUMN "name" TYPE text,
      ALTER COLUMN address TYPE text,
      ALTER COLUMN email TYPE text,
      ALTER COLUMN phone TYPE text,
      ALTER COLUMN dob TYPE text,
      ALTER COLUMN place_of_birth TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          nationality = encrypt(nationality::bytea, '${val}'::bytea, 'aes'::text),
          residence_of_jurisdiction = encrypt(residence_of_jurisdiction::bytea, '${val}'::bytea, 'aes'::text),
          country_of_registration = encrypt(country_of_registration::bytea, '${val}'::bytea, 'aes'::text),
          tax_country = encrypt(tax_country::bytea, '${val}'::bytea, 'aes'::text),
          principal_country_of_business = encrypt(principal_country_of_business::bytea, '${val}'::bytea, 'aes'::text),
          "name" = encrypt("name"::bytea, '${val}'::bytea, 'aes'::text),
          address = encrypt(address::bytea, '${val}'::bytea, 'aes'::text),
          email = encrypt(email::bytea, '${val}'::bytea, 'aes'::text),
          phone = encrypt(phone::bytea, '${val}'::bytea, 'aes'::text),
          dob = encrypt(dob::bytea, '${val}'::bytea, 'aes'::text),
          place_of_birth = encrypt(place_of_birth::bytea, '${val}'::bytea, 'aes'::text);
    `);

    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 5: Insert entries into encryption_decryption for recipient_list column
    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'nationality' },
      { table_name: tableName , column_name: 'residence_of_jurisdiction' },
      { table_name: tableName , column_name: 'country_of_registration' },
      { table_name: tableName , column_name: 'tax_country' },
      { table_name: tableName , column_name: 'principal_country_of_business' },
      { table_name: tableName , column_name: 'name' },
      { table_name: tableName , column_name: 'address' },
      { table_name: tableName , column_name: 'email' },
      { table_name: tableName , column_name: 'phone' },
      { table_name: tableName , column_name: 'dob' },
      { table_name: tableName , column_name: 'place_of_birth' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Drop trigger for encryption
    console.log(`Dropping trigger for encrypting ${tableName} ...`);
    await knex.raw(`DROP TRIGGER IF EXISTS before_insert_update_${tableName} ON ${tableName};`);
    console.log(`Trigger for encrypting ${tableName} dropped.`);

    // Step 2: Drop trigger function for encryption
    console.log(`Dropping trigger function for encrypting ${tableName} ...`);
    await knex.raw(`DROP FUNCTION IF EXISTS encrypt_${tableName};`);
    console.log(`Trigger function for encrypting ${tableName} dropped.`);

    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET
          nationality = convert_from(decrypt(nationality::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          residence_of_jurisdiction = convert_from(decrypt(residence_of_jurisdiction::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          country_of_registration = convert_from(decrypt(country_of_registration::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          tax_country = convert_from(decrypt(tax_country::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          principal_country_of_business = convert_from(decrypt(principal_country_of_business::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          "name" = convert_from(decrypt("name"::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          address = convert_from(decrypt(address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          phone = convert_from(decrypt(phone::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          dob = convert_from(decrypt(dob::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
          place_of_birth = convert_from(decrypt(place_of_birth::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
      `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 4: Remove entries from encryption_decryption for sanction reports column
    console.log('Removing entries from encryption_decryption for sanction reports column...');
    await knex('encryption_decryption')
      .where({ table_name: tableName })
      .whereIn('column_name', ['nationality', 'residence_of_jurisdiction', 'country_of_registration', 'tax_country', 'principal_country_of_business', 'name', 'address', 'email', 'phone', 'dob', 'place_of_birth'])
      .delete();
    console.log('Entries removed from encryption_decryption for sanction reports column.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
