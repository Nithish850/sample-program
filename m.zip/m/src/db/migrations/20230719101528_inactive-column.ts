
exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_rules', (table) => {
    table.date('inactive_date');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_rules', (table) => {
    table.dropColumn('inactive_date');
  })
}