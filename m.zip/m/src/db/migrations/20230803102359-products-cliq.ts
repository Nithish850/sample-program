const cliqDetails = [
  {
    category: 'Offchain Transactions',
    sub_category: 'Deposits',
    type: 'ACH',
    type_desc: 'Enable Deposit using ACH by toggling ON. By toggling OFF ACH, only Deposits using ACH will be disabled.',
    default_flag: false,
    super_category: 'Customer Wallet',
    partner: 'CLIQ'
  },
  {
    category: 'Offchain Transactions',
    sub_category: 'Deposits',
    type: 'ACH',
    type_desc: 'Enable Deposit using ACH by toggling ON. By toggling OFF ACH, only Deposits using ACH will be disabled.',
    default_flag: false,
    super_category: 'Tenant Wallet',
    partner: 'CLIQ'
  },
]

exports.up = async function(knex) {
  await knex('products').insert(cliqDetails);
};

exports.down = async function(knex) {
  await knex('products').where('partner', 'CLIQ').delete();
};