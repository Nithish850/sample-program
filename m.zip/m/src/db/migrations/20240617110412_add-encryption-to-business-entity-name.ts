/* eslint-disable no-console */
import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';


export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log('Updating column type and encrypting existing data ...');
    
    // Step 1: Alter the column type to text
    await knex.raw(`
      ALTER TABLE business_entities
      ALTER COLUMN business_entity_name TYPE text;
    `);
    console.log('Column type for business_entity_name updated to text.');

    // Step 4: Update the data to trigger the encryption
    console.log('Updating the data to trigger the encryption ...');
    await knex.raw(`
      UPDATE business_entities
      SET business_entity_name = encrypt(business_entity_name::bytea, '${val}'::bytea,'aes'::text);
    `);
    console.log('Existing data in business_entity_name encrypted.');

    // Step 5: Insert into encryption_decryption
    await knex('encryption_decryption').insert({ table_name: 'business_entities', column_name: "business_entity_name" })

    console.log('Insert into encryption_decryption completed.');

  } catch (error) {
    console.error('Error during migration:', error.message);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log('Decrypting existing data in business_entity_name ...');
    await knex.raw(`
      UPDATE business_entities
      SET business_entity_name = convert_from(decrypt(business_entity_name::bytea, '${val}', 'aes'), 'SQL_ASCII')::text
    `);
    console.log('Existing data in business_entity_name decrypted.');

    await knex('encryption_decryption')
      .where({ table_name: 'business_entities', column_name: 'business_entity_name' })
      .del();
    console.log('Deletion from encryption_decryption completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}