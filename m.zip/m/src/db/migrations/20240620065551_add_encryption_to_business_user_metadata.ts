/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'business_user_metadata';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN company_address TYPE text,
      ALTER COLUMN email TYPE text,
      ALTER COLUMN tax_id TYPE text,
      ALTER COLUMN legal_name TYPE text,
      ALTER COLUMN phone TYPE text,
      ALTER COLUMN business_entity_name TYPE text,
      ALTER COLUMN bank_verification_number TYPE text,
      ALTER COLUMN entity_beneficial_owners TYPE text,
      ALTER COLUMN individual_beneficial_owners TYPE text,
      ALTER COLUMN control_persons TYPE text,
      ALTER COLUMN registered_office_address TYPE text,
      ALTER COLUMN signatories TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          company_address = encrypt(company_address::bytea, '${val}'::bytea, 'aes'::text),
          email = encrypt(email::bytea, '${val}'::bytea, 'aes'::text),
          tax_id = encrypt(tax_id::bytea, '${val}'::bytea, 'aes'::text),
          legal_name = encrypt(legal_name::bytea, '${val}'::bytea, 'aes'::text),
          phone = encrypt(phone::bytea, '${val}'::bytea, 'aes'::text),
          business_entity_name = encrypt(business_entity_name::bytea, '${val}'::bytea, 'aes'::text),
          bank_verification_number = encrypt(bank_verification_number::bytea, '${val}'::bytea, 'aes'::text),
          entity_beneficial_owners = encrypt(entity_beneficial_owners::bytea, '${val}'::bytea, 'aes'::text),
          individual_beneficial_owners = encrypt(individual_beneficial_owners::bytea, '${val}'::bytea, 'aes'::text),
          control_persons = encrypt(control_persons::bytea, '${val}'::bytea, 'aes'::text),
          registered_office_address = encrypt(registered_office_address::bytea, '${val}'::bytea, 'aes'::text),
          signatories = encrypt(signatories::bytea, '${val}'::bytea, 'aes'::text);
    `);

    console.log(`Existing data in ${tableName} table encrypted.`);

    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'company_address' },
      { table_name: tableName, column_name: 'email' },
      { table_name: tableName, column_name: 'tax_id' },
      { table_name: tableName, column_name: 'legal_name' },
      { table_name: tableName, column_name: 'phone' },
      { table_name: tableName, column_name: 'business_entity_name' },
      { table_name: tableName, column_name: 'bank_verification_number' },
      { table_name: tableName, column_name: 'entity_beneficial_owners' },
      { table_name: tableName, column_name: 'individual_beneficial_owners' },
      { table_name: tableName, column_name: 'control_persons' },
      { table_name: tableName, column_name: 'registered_office_address' },
      { table_name: tableName, column_name: 'signatories' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        company_address = convert_from(decrypt(company_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tax_id = convert_from(decrypt(tax_id::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        legal_name = convert_from(decrypt(legal_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        phone = convert_from(decrypt(phone::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        business_entity_name = convert_from(decrypt(business_entity_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        bank_verification_number = convert_from(decrypt(bank_verification_number::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        entity_beneficial_owners = convert_from(decrypt(entity_beneficial_owners::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        individual_beneficial_owners = convert_from(decrypt(individual_beneficial_owners::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        control_persons = convert_from(decrypt(control_persons::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        registered_office_address = convert_from(decrypt(registered_office_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        signatories = convert_from(decrypt(signatories::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    console.log('Deleting entries from encryption_decryption for recipient_list column...');
    await knex('encryption_decryption')
      .whereIn('column_name', [
        'company_address', 'email', 'tax_id', 'legal_name', 'phone', 'business_entity_name',
        'bank_verification_number', 'entity_beneficial_owners', 'individual_beneficial_owners',
        'control_persons', 'registered_office_address', 'signatories'
      ])
      .where({ table_name: tableName })
      .del();
    console.log('Deletion from encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
