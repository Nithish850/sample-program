exports.up = function (knex) {
  return knex.schema
    .createTable('tenants', (table) => {
      table.uuid('tenant_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('tenant_name').notNullable();
      table.string('domain').notNullable().unique();
      table.boolean('is_active').notNullable().defaultTo(true);
      table.date('start_date').notNullable();
      table.date('end_date').notNullable();
      table.enu('compliance_status', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
      table.timestamps(true, true);
    })
    .createTable('tenant_metadata', (table) => {
      table.uuid('tenant_metadata_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.jsonb('company_address').notNullable();
      table.string('email').notNullable().unique();
      table.jsonb('incorporation_docs');
      table.jsonb('jurisdiction_docs');
      table.jsonb('other_docs');
      table.string('tax_id').notNullable().unique();
      table.string('legal_name').notNullable().unique();
      table.string('phone').notNullable().unique();
      table.jsonb('entity_beneficial_owners');
      table.jsonb('individual_beneficial_owners');
      table.jsonb('control_persons');
      table.jsonb('memo_fields');
      table.string('bank_verification_number').unique();
      table.jsonb('other_details');
    })
    .createTable('users', (table) => {
      table.uuid('user_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('user_name').notNullable().unique();
      table.string('email').notNullable().unique();
      table.string('login_id').notNullable().unique();
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    })
    .createTable('rules', (table) => {
      table.uuid('rule_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.enu('rule_group', [ 'ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable().defaultTo('NONE');
      table.string('rule_name').notNullable();
      table.string('rule_version').notNullable();
      table.text('rule_description');
      table.jsonb('rule_json');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('updated_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
      table.boolean('is_global').notNullable().defaultTo(false);
      table.timestamps(true, true);
    })
    .createTable('attributes', (table) => {
      table.uuid('attribute_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('attribute_name').notNullable();
      table.enu('attribute_type', [ 'NUMBER', 'BOOLEAN', 'STRING', 'ARRAY', 'OBJECT' ]).notNullable().defaultTo('STRING');
      table.text('attribute_desc');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    })
    .createTable('rules_attributes', (table) => {
      table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('attribute_id').references('attribute_id').inTable('attributes').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'rule_id', 'attribute_id' ]);
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('attribute_value').notNullable();
      table.timestamps(true, true);
    })
    .createTable('tenant_rules', (table) => {
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'tenant_id', 'rule_id' ]);
      table.boolean('is_active').notNullable().defaultTo(true);
      table.date('start_date').notNullable();
      table.date('end_date').notNullable();
      table.timestamps(true, true);
    })
    .createTable('customer_accounts', (table) => {
      table.uuid('customer_account_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('full_legal_name').notNullable();
      table.string('email').notNullable();
      table.string('phone').notNullable().defaultTo(false);
      table.date('dob').notNullable();
      table.jsonb('address').notNullable();
      table.jsonb('customer_metadata');
      table.jsonb('identity_provider_metadata');
      table.enu('compliance_status', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
      table.enu('identity_provider_status ', [ 'PENDING', 'ACCEPTED', 'REJECTED', 'ACTION_REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    })
    .createTable('tenant_customer_accounts', (table) => {
      table.uuid('tenant_customer_accounts_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('namespace').notNullable();
      table.string('public_key').notNullable();
      table.boolean('is_primary').notNullable().defaultTo(false);
      table.string('namespace_provider');
      table.string('namespace_alias');

      table.timestamps(true, true);
    })
    .createTable('dss', (table) => {
      table.uuid('dss_type_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('dss_type').notNullable();
      table.text('dss_description');
    })
    .createTable('dss_customer_accounts', (table) => {
      table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'dss_type_id', 'customer_account_id' ]);
      table.text('dss_id').notNullable();
      table.timestamps(true, true);
    })
    .createTable('dss_tenants', (table) => {
      table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'dss_type_id', 'tenant_id' ]);
      table.text('dss_id').notNullable();
      table.timestamps(true, true);
    })
    .createTable('roles', (table) => {
      table.uuid('role_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('role_name').notNullable();
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.jsonb('role_abilities_json');
      table.boolean('is_active').notNullable().defaultTo(true);
      table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    })
    .createTable('user_roles', (table) => {
      table.uuid('user_roles_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('user_id').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('role_id').references('role_id').inTable('roles').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'user_id', 'role_id' ]);
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    })
    .createTable('entities', (table) => {
      table.uuid('entity_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('entity_name').notNullable();
      table.text('entity_description');
      table.timestamps(true, true);
    })
    .createTable('role_entities', (table) => {
      table.uuid('role_id').references('role_id').inTable('roles').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('entity_id').references('entity_id').inTable('entities').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary([ 'role_id', 'entity_id' ]);
      table.boolean('read');
      table.boolean('write');
      table.boolean('update');
      table.boolean('delete');
      table.boolean('manage');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.timestamps(true, true);
    });
};

exports.down = function (knex) {
  return knex.schema
    .dropTable('tenants')
    .dropTable('tenant_metadata')
    .dropTable('users')
    .dropTable('rules')
    .dropTable('attributes')
    .dropTable('rules_attributes')
    .dropTable('tenant_rules')
    .dropTable('customer_accounts')
    .dropTable('tenant_customer_accounts')
    .dropTable('dss')
    .dropTable('dss_customer_accounts')
    .dropTable('dss_tenants')
    .dropTable('roles')
    .dropTable('user_roles')
    .dropTable('entities')
    .dropTable('role_entities');
};
