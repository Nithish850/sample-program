exports.up = function (knex) {
  return knex.schema.createTable('failed_transactions', (table) => {
    table.uuid('failed_transactions_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('request_id');
    table.string('status');
    table.string('endpoint');
    table.jsonb('payload');
    table.string('attempts');
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('failed_transactions')
}