/* eslint-disable no-console */
import { Knex } from "knex";

export async function up(knex: Knex): Promise<void> {
  console.log('deleting views ...')
  await knex.schema.raw('DROP VIEW IF EXISTS v_compliance_statistics_report');

  await knex.schema.raw('DROP VIEW IF EXISTS v_compliance_statistics_report_updated');

  await knex.schema.raw('DROP VIEW IF EXISTS v_geography_rejection_customer_details');

  await knex.schema.raw('DROP VIEW IF EXISTS v_customer_account');

  await knex.schema.raw('DROP VIEW IF EXISTS v_d_customer_account');

  await knex.schema.raw('DROP VIEW IF EXISTS v_customer_rejection_reason');

  await knex.schema.raw('DROP VIEW IF EXISTS v_finclusive_rejection_reason');

  await knex.schema.raw('DROP VIEW IF EXISTS v_offchain_transaction_details');

  await knex.schema.raw('DROP VIEW IF EXISTS v_onchain_transaction_details');

  await knex.schema.raw('DROP VIEW IF EXISTS v_tenant_jursidiction');

  await knex.schema.raw('DROP VIEW IF EXISTS v_finclusive_customer_status');

}

export async function down(knex:Knex): Promise<void> {
  await knex.schema.raw('DROP VIEW IF EXISTS v_compliance_statistics_report');

}
