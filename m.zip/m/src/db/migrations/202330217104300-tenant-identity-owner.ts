exports.up = function (knex) {
  return knex.schema.createTable('tenant_identity_owner', (table) => {
    table.uuid('tenant_identity_owner_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_owner_dss_id').notNullable();
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('email').notNullable();
    table.string('phone_number');
    table.string('dob');
    table.jsonb('address');
    table.jsonb('tax');
    table.string('gender');
    table.jsonb('documents');
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('tenant_identity_owner')
}