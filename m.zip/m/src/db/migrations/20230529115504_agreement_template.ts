exports.up = function (knex) {
  return knex.schema.createTable('agreement_template', (table) => {
    table.uuid('agreement_template_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.text('template').notNullable();
    table.string('type').notNullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('agreement_template')
}