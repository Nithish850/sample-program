exports.up = function (knex) {
  return knex.schema.createTable('business_user_metadata', (table) => {
    table.uuid('business_user_metadata_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
    table.jsonb('company_address').notNullable();
    table.string('email').notNullable().unique();
    table.string('tax_id').notNullable().unique();
    table.string('legal_name').notNullable();
    table.string('phone').notNullable().unique();
    table.string('business_entity_name');
    table.string('bank_verification_number').unique();
    table.jsonb('incorporation_docs');
    table.jsonb('jurisdiction_docs');
    table.jsonb('other_docs');
    table.jsonb('entity_beneficial_owners');
    table.jsonb('individual_beneficial_owners');
    table.jsonb('control_persons');
    table.jsonb('memo_fields');
    table.jsonb('other_details');
    table.jsonb('registered_office_address');
    table.jsonb('signatories');
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('business_user_metadata')
}