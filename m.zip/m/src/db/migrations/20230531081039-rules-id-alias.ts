exports.up = async function (knex) {
  await knex.schema.alterTable('rules', (table) => {
    table.string('rule_id_alias').notNullable().defaultTo('NA');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('rules', (table) => {
    table.dropColumn('rule_id_alias');
  });
}