
async function dropTables(knex) {
  await knex.schema.dropTable('identification_financial_badge');
  await knex.schema.dropTable('financial_badge_token');
}
async function addNewTable(knex) {
  await knex.schema.createTable('badge_token', (table) => {
    table.uuid('public_id').defaultTo(knex.raw('gen_random_uuid()')).notNullable().primary();
    table.uuid('identification_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
    table.unique(['identification_badge_id', 'financial_badge_id', 'token_symbol']);
  });
}
exports.up = async function (knex) {
  await dropTables(knex);
  await addNewTable(knex);
}

exports.down = async function (knex) {
  await dropTables(knex);
  await addNewTable(knex);
}