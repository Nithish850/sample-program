exports.up = async function (knex) {
    await knex('event_subscription_logs').where({ event_name: "UPGRADE" })
    .update({ event_name: "BADGE UPDATE" });
    
    await knex('dss_event').where({ event: "UPGRADE" })
    .update({ event: "BADGE UPDATE" });
  
    };
  
  
    exports.down = async function (knex) {
      await knex('event_subscription_logs').where({ event_name: "BADGE UPDATE" })
      .update({ event_name: "UPGRADE" });
      
      await knex('dss_event').where({ event: "BADGE UPDATE" })
      .update({ event: "UPGRADE" });
      
    };