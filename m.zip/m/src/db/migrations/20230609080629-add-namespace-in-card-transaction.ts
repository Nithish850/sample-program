exports.up = async function(knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.string('namespace');
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('namespace');
  });
};