exports.up = async (knex) => {
  await knex.schema.dropTable('country_risk_rating');

  await knex.schema.createTable('country_risk_rating', (table) => {
    table.uuid('country_risk_rating_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.text('country').notNullable();
    table.string('country_code').notNullable().unique();
    table.string('risk_score').notNullable();
    table.string('risk_rating');
    table.string('ul_override');
    table.string('rationale');
    table.timestamps(true, true);
  });
};

exports.down = async (knex) => {
  await knex.schema.dropTable('country_risk_rating');
};
