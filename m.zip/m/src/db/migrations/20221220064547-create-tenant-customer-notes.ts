exports.up = function (knex) {
  return knex.schema.createTable('tenant_customer_notes', (table) => {
    table.uuid('tenant_customer_note_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('comment');
    table.jsonb('attachment');
    table.string('created_by');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_customer_notes');
};
