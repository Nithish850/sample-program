import { Knex } from "knex";
import { getDefaultTenantId } from "../../utils/encryption";

const attributes = [
    {
        "attribute_name": "riskAndComplianceBankLegalName",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Legal Name",
        "display_attribute_name": "Bank Legal Name",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountHolderName",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Holder Name",
        "display_attribute_name": "Bank Account Holder Name",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountType",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Type",
        "display_attribute_name": "Bank Account Type",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountNumber",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Number",
        "display_attribute_name": "Bank Account Number",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountHolderPhoneNumber",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Holder Phone Number",
        "display_attribute_name": "Bank Account Holder Phone Number",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountHolderEmail",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Holder Email",
        "display_attribute_name": "Bank Account Holder Email",
        "is_required": false,
    },
    {
        "attribute_name": "riskAndComplianceBankAccountHolderAddress",
        "attribute_type": "BOOLEAN",
        "rule_group": "RISK",
        "attribute_desc": "Bank Account Holder Address",
        "display_attribute_name": "Bank Account Holder Address",
        "is_required": false,
    },
    {
        "attribute_name": "governmentIdVerificationStatus",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "Government ID Verification Status",
        "display_attribute_name": "Government ID Verification Status",
        "is_required": false,
        "attribute_options": {
            "value": ["Verified", "Not Verified"]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "kycPartnerDecision",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "KYC Partner Decision",
        "display_attribute_name": "KYC Partner Decision",
        "is_required": false,
        "attribute_options": {
            "value": ["Approved", "Denied" ]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "pepStatus",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "PEP Status",
        "display_attribute_name": "PEP Status",
        "is_required": false,
        "attribute_options": {
            "value": ["True", "False"]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "sanctionScreening",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "Sanction Screening",
        "display_attribute_name": "Sanction Screening",
        "is_required": false,
        "attribute_options": {
            "value": ["True", "False"]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "userRiskRating",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "User Risk Rating",
        "display_attribute_name": "User Risk Rating",
        "is_required": false,
        "attribute_options": {
            "value": ["High", "Medium", "Low"]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "countryRisk",
        "attribute_type": "STRING",
        "rule_group": "RISK",
        "attribute_desc": "Country Risk",
        "display_attribute_name": "Country Risk",
        "is_required": false,
        "attribute_options": {
            "value": ["High", "Medium", "Low"]
        },
        "options_type": "string"
    },
    {
        "attribute_name": "countryLocationConfidence",
        "attribute_type": "ARRAY",
        "rule_group": "RISK",
        "attribute_desc": "Country Location Confidence",
        "display_attribute_name": "Country Location Confidence",
        "is_required": false,
        "attribute_options": {
            "value": [0,100]
        },
        "options_type": "range"
    },
    {
        "attribute_name": "ipFraudScore",
        "attribute_type": "ARRAY",
        "rule_group": "RISK",
        "attribute_desc": "IP Fraud Score",
        "display_attribute_name": "IP Fraud Score",
        "is_required": false,
        "attribute_options": {
            "value": [0,100]
        },
        "options_type": "range"
    },
    {
        "attribute_name": "phoneNumberTrustScore",
        "attribute_type": "ARRAY",
        "rule_group": "RISK",
        "attribute_desc": "Phone Number Trust Score",
        "display_attribute_name": "Phone Number Trust Score",
        "is_required": false,
        "attribute_options": {
            "value": [0,1000]
        },
        "options_type": "range"
    },
    {
        "attribute_name": "ongoingMonitoringSARsAndSTRs",
        "attribute_type": "ARRAY",
        "rule_group": "RISK",
        "attribute_desc": "Ongoing Monitoring SARs/STRs",
        "display_attribute_name": "Ongoing Monitoring SARs/STRs",
        "is_required": false,
        "attribute_options": {
            "value": [0,100]
        },
        "options_type": "range"
    },
    {
        "attribute_name": "bankLegalName",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Legal Name",
        "display_attribute_name": "Bank Legal Name",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountHolderName",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Holder Name",
        "display_attribute_name": "Bank Account Holder Name",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountType",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Type",
        "display_attribute_name": "Bank Account Type",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountNumber",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Number",
        "display_attribute_name": "Bank Account Number",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountHolderPhoneNumber",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Holder Phone Number",
        "display_attribute_name": "Bank Account Holder Phone Number",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountHolderEmail",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Holder Email",
        "display_attribute_name": "Bank Account Holder Email",
        "is_required": false,
    },
    {
        "attribute_name": "bankAccountHolderAddress",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Bank Account Holder Address",
        "display_attribute_name": "Bank Account Holder Address",
        "is_required": false,
    },
    {
        "attribute_name": "plaidToken",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Plaid Token",
        "display_attribute_name": "Plaid Token",
        "is_required": false,
    },
    {
        "attribute_name": "plaidConsentTimestamp",
        "attribute_type": "BOOLEAN",
        "rule_group": "ONBOARD",
        "attribute_desc": "Plaid Consent Timestamp",
        "display_attribute_name": "Plaid Consent Timestamp",
        "is_required": false,
    },
];


export async function up(knex: Knex): Promise<void> {
    const tenant_id = await getDefaultTenantId(knex);
    console.log("migration running: 051-seed-risk-attributes");
    if (tenant_id) {
        attributes.forEach(attribute => {
            attribute["tenant_id"] = tenant_id;
        });

        await knex("attributes").insert(attributes);
    }
    console.log("migration completed: 051-seed-risk-attributes");
}


export async function down(knex: Knex): Promise<void> {
    const tenant_id = await getDefaultTenantId(knex);
    
    if (tenant_id) {
      await knex("attributes")
        .where("tenant_id", tenant_id)
        .whereIn(
          "attribute_name",
          attributes.map((attr) => attr.attribute_name)
        )
        .del();
    }

    console.log("rollback completed: 051-seed-risk-attributes");
}

