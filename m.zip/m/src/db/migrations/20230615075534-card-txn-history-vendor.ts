const vendorDetails = [
  {
    name: 'CHECKOUT',
    status: 'ACTIVE',
  },
  {
    name: 'RAPYED',
    status: 'ACTIVE',
  },
  {
    name: 'AUTHORIZED.NET',
    status: 'ACTIVE',
  },
];

exports.up = async function (knex) {
  await knex.schema.createTable('card_transaction_history', (table) => {
    table.uuid('card_transaction_history_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('status');
    table.string('description');
    table.jsonb('details');
    table.uuid('card_transaction_id').references('card_transaction_id').inTable('card_transaction').onDelete('CASCADE').onUpdate("CASCADE");
    table.timestamps(true, true);
  })
    .createTable('dss_vendor', (table) => {
      table.uuid('dss_vendor_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('name');
      table.string('status').defaultTo('ACTIVE');
      table.jsonb('details');
      table.timestamps(true, true);
    })
    .alterTable('card_transaction', (table) => {
      table.uuid('dss_vendor_id').references('dss_vendor_id').inTable('dss_vendor').onDelete('CASCADE').onUpdate("CASCADE");
    }).then(() => knex('dss_vendor').insert(vendorDetails))
};

exports.down = async function (knex) {
  return knex.schema.dropTable('card_transaction_history')
    .dropTable('dss_vendor')
    .dropTable('card_transaction');
}