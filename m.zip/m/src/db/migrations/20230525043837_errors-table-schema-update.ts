/** function to create errors DB */
exports.up = async (knex) => {

  // removing old schema
  await knex.schema.dropTable('errors');
  await knex.schema.createTable('errors', (table) => {
    table.string('error_code');
    table.primary('error_code');
    table.string('error_group');
    table.string('error_slug');
    table.string('error_attribute');
    table.string('error_reason').notNullable();
    table.string('error_description');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  });
};

/** function to bring down errors DB */
exports.down = async (knex) => {
  await knex.schema.dropTable('errors');
};
