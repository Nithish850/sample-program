exports.up = function (knex) {
  return knex.schema.createTable('ach_processed_files', (table) => {
    table.uuid('ach_processed_file_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('file_name').notNullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('ach_processed_files')
}