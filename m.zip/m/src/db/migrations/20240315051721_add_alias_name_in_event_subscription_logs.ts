exports.up = async function (knex) {
  await knex.schema.alterTable('event_subscription_logs', (table) => {
    table.dropForeign(['tenant_event_subscription_id']);
  });

  await knex.schema.alterTable('event_subscription_logs', (table)=>{
    table.string('alias_name');
  });

  const subscriptionDetails = await knex.raw(`
    select tenant_event_subscription_id, alias_name from tenant_event_subscription
    where tenant_event_subscription_id in
        (select tenant_event_subscription_id from event_subscription_logs esl
        where tenant_event_subscription_id is not null)
  `);

  if(subscriptionDetails && subscriptionDetails.rows && subscriptionDetails.rows.length > 0) {
    for(const { tenant_event_subscription_id, alias_name } of subscriptionDetails.rows) {
      /* eslint-disable no-await-in-loop */
      await knex('event_subscription_logs').where({ tenant_event_subscription_id })
        .update({ alias_name: alias_name })
    }
  }

};
exports.down = async function (knex) {
  await knex.schema.alterTable('event_subscription_logs',(table)=>{
    table.dropColumn('alias_name');
  })
};
