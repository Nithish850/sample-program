exports.up = async function (knex) {
  await knex.schema.alterTable('bulk_transactions', (table)=>{
    table.string('sender_namespace');
  });
  const bulkTransactionDetails = await knex.raw(`
      select distinct bulk_transaction_id, from_namespace from bulk_transactions_receipts
      group by bulk_transaction_id, from_namespace
    `);

  if(bulkTransactionDetails && bulkTransactionDetails?.rows && bulkTransactionDetails.rows.length) {
    for(const { bulk_transaction_id, from_namespace } of bulkTransactionDetails.rows) {
      /* eslint-disable no-await-in-loop */
      await knex('bulk_transactions').where({ bulk_transaction_id })
        .update({ sender_namespace: from_namespace })
    }
  }
};
exports.down = async function (knex) {
  await knex.schema.alterTable('bulk_transactions',(table)=>{
    table.dropColumn('sender_namespace');
  })
};