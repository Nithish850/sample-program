exports.up = function (knex) {
  return knex.schema.createTable('secrets', (table) =>{
    table.uuid('secret_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('client_id').notNullable().unique();
    table.string('api_key').notNullable().unique();
    table.string('tenant_id').notNullable();
    table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('updated_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true);
  });
}
exports.down = function(knex) {
  return knex.schema.dropTable('secrets');
}