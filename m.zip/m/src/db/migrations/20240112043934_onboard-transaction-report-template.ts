const onboardTransactionReportTemplate = [
  {
    html: `Greetings !<br><br>
        The attached report details Onboarding and Token Transactions. The report covers metrics of "<%=currentDate%>".<br><br><br>
        
        Onboarding summary:<br><br><br>
        
        <html>
        <head>
            <style>
                table,
                th,
                td {
                    border: 1px solid black;
                    border-collapse: collapse;
                }
            </style>
        </head>
        
        <body>
            <table style="width:30%">
                <tr>
                    <td>User Onboarded</td>
                    <td><%=accepted%></td>
                </tr>
                <tr>
                    <td>User Rejected</td>
                    <td><%=rejected%></td>
                </tr>
                <tr>
                    <td>User Pending</td>
                    <td><%=pending%></td>
                </tr>
            </table></br></br>
            Transaction summary of wallet users:</br></br></br>
            <table style="width:30%">
                <tr>
                    <td>Token Name</td>
                    <%=tokenArray%>
                </tr>
                <tr>
                    <td>Total Deposited</td>
                    <%=depositArray%>
                </tr>
                <tr>
                    <td>Total Withdrawals</td>
                    <%=withdrawArray%>
                </tr>
                <tr>
                    <td>Tokens Transferred</td>
                    <%=transferArray%>
                </tr>
            </table>
        </body>
        </html>
        <br>
        Please feel free to contact Product Team in case any feedback to be shared<br><br>
        Thanks<br>
        Omnumi`,
    subject: 'Onboarding and Transaction Metrics - "Omnumi"',
    template_name: 'OnboardAndTransactionReport',
  },
];

exports.up = async function (knex) {
  await knex('email_templates').insert(onboardTransactionReportTemplate);
};
exports.down = async function (knex) {
  await knex('email_templates')
    .delete()
    .where({ template_name: 'OnboardAndTransactionReport' });
};
