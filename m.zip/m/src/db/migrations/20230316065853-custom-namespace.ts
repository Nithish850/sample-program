exports.up = function (knex) {
  return knex.schema.createTable('wallet_user_namespace_mapper', (table) => {
    table.uuid('namespace_mapper_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('custom_namespace');
    table.uuid('namespace_id').references('namespace_id').inTable('namespaces').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('wallet_user_namespace_mapper');
};
