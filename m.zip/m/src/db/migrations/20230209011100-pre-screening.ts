exports.up = function (knex) {
  return knex.schema.createTable('tenant_pre_screening', (table) => {
    table.uuid('tenant_pre_screening_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('email').notNullable();
    table.string('phone').notNullable();
    table.string('website').notNullable();
    table.string('tax_id').notNullable();
    table.string('company_registration_number').notNullable();
    table.jsonb('company_address').notNullable();
    table.string('entity_size').notNullable();
    table.string('commencement').notNullable();
    table.string('description_of_business');
    table.string('industry');
    table.string('product_service');
    table.string('location_of_principal_business');
    table.string('business_reason');
    table.string('marketing_role');
    table.string('compliance_role');
    table.enu('capture_status', [ 'APPROVED', 'PENDING', 'REJECTED' ])
    table.string('submission_date');
    table.string('decision_date');
    table.timestamps(true, true);
  });
}

exports.down = function (knex) {
  return knex.schema.dropTable('pre_screening');
}