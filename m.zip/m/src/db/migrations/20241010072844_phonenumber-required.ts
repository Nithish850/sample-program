exports.up = async function (knex) {
  await knex('attributes').update({
    'is_required': true
  }).where('attribute_name', 'phoneNumber');
}
exports.down = async function (knex) {
  await knex('attributes').update({
    'is_required': false
  }).where('attribute_name', 'phoneNumber');  
}