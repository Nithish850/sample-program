
exports.up = async function (knex) {
  await knex.schema.createTable('secret_history', (table) => {
    table.uuid('secret_history_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('description');
    table.jsonb('details');
    table.uuid('secret_id').references('secret_id').inTable('secrets').onDelete('CASCADE').onUpdate("CASCADE");
    table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true);
  })

};

exports.down = async function (knex) {
  return knex.schema.dropTable('secret_history')

}