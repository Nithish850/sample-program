exports.up = function (knex) {
  return knex.schema
    .createTable('products', (table) => {
      table.uuid('product_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('category').notNullable();
      table.string('sub_category').notNullable();
      table.string('type').notNullable();
      table.string('type_desc');
      table.boolean('default_flag');
      table.timestamps(true, true);
    })
    .createTable('product_subscriptions', (table) => {
      table.uuid('product_subscription_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('product_id').references('product_id').inTable('products').onDelete('CASCADE').onUpdate('CASCADE');
      table.boolean('is_active').notNullable().defaultTo(false);
      table.timestamps(true, true);
    })
    .createTable('product_subscription_logs', (table) => {
      table.uuid('product_subscription_log_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('product_id').references('product_id').inTable('products').onDelete('CASCADE').onUpdate('CASCADE');
      table.boolean('status').notNullable();
      table.string('updated_by');
      table.timestamps(true, true);
    })
};
exports.down = function (knex) {
  return knex.schema
    .dropTable('products')
    .dropTable('product_subscriptions')
    .dropTable('product_subscription_logs');
};