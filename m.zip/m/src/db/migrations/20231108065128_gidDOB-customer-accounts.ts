exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.date('gid_dob').alter();
    table.date('gid_issue_date').alter();
    table.date('gid_expiration_date').alter();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('gid_dob').alter();
    table.string('gid_issue_date').alter();
    table.string('gid_expiration_date').alter();
  });
};
