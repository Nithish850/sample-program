exports.up = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.date('settlement_date').defaultTo(null);
  })
};

exports.down = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('settlement_date');
  });
}