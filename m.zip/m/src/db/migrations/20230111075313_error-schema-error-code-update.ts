import { errorCode, errorGroup, errorSlug } from "../master/error-code-enum-update";

/** function to create errors DB */
exports.up = async function (knex) {
  await knex.schema.alterTable('errors', (table) => {
    table.dropColumn('error_code');
    table.dropColumn('error_group');
    table.dropColumn('error_slug');
  });
  await knex.schema.alterTable('errors', (table) => {
    table.enu('error_code', [ ...errorCode ]);
    table.enu('error_group', [ ...errorGroup ]);
    table.enu('error_slug', [ ...errorSlug ]);
  });
};

/** function to bring down errors DB */
exports.down = function (knex) {
  return knex.schema.dropTable('errors');
};
