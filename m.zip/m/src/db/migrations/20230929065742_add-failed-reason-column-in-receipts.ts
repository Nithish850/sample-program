exports.up = async function (knex) {
  await knex.schema.alterTable('bulk_transactions_receipts', (table) => {
    table.string('failed_reason');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('bulk_transactions_receipts', (table) => {
    table.dropColumn('failed_reason');
  });
};
