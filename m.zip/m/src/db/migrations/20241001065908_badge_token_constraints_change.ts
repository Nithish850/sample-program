async function backupTable(knex) {
    await knex.schema.renameTable('badge_token', 'badge_token_backup');
  }
  
  async function dropColumn(knex) {
    await knex.schema.alterTable('badge_token_backup', (table)=>{
      table.dropColumn('public_id');
    });
  }
  async function dropExistingTableIfExists(knex) {
    const exists = await knex.schema.hasTable('badge_token');
    if (exists) {
      await knex.schema.dropTable('badge_token');
    }
  }
  async function recreateTable(knex) {
    await knex.schema.createTable('badge_token', (table) => {
      table.uuid('public_id').defaultTo(knex.raw('gen_random_uuid()')).notNullable().primary();
      table.uuid('identification_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('custom_financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE').default(null);
      table.specificType('information_badge_id', 'UUID[]').defaultTo(null); // New column
    });
  
    await knex.raw(`
      INSERT INTO badge_token (identification_badge_id, financial_badge_id, token_symbol, custom_financial_badge_id)
      SELECT identification_badge_id, financial_badge_id, token_symbol, custom_financial_badge_id
      FROM badge_token_backup
    `);
    await knex.schema.dropTable('badge_token_backup');
  
  }
  
  exports.up = async function (knex) {
    await backupTable(knex);
    await dropExistingTableIfExists(knex);
    await dropColumn(knex);
    await recreateTable(knex);
  
  };
  
  exports.down = async function (knex) {
    await knex.schema.dropTableIfExists('badge_token');
  };
  