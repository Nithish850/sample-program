exports.up = async function (knex) {
  await knex.schema.alterTable('tenants', (table) => {
    table.enu('account_status', [ 'ACTIVE', 'INACTIVE', 'BLOCKED' ]).notNullable().defaultTo('ACTIVE');
    table.enu('onboarding_status', [ 'PENDING', 'APPROVED', 'REJECTED', 'ACTION REQUIRED', 'FAILED' ]).notNullable().defaultTo('PENDING');
    table.dropColumn('is_active');
  })
}

exports.down = async function (knex) {
  await knex.schema.dropTable('tenants')
}