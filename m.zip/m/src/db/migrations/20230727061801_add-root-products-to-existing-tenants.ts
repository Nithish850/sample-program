// const newProducts = [
//   {
//     category: 'Root',
//     sub_category: 'Offchain Transactions',
//     default_flag: true,
//     super_category: 'Customer Wallet',
//     type: ''
//   },
//   {
//     category: 'Root',
//     sub_category: 'Onchain Transfers',
//     default_flag: true,
//     super_category: 'Customer Wallet',
//     type: ''
//   },
//   {
//     category: 'Root',
//     sub_category: 'Wallet Configuration',
//     default_flag: true,
//     super_category: 'Customer Wallet',
//     type: ''
//   },
//   {
//     category: 'Root',
//     sub_category: 'Offchain Transactions',
//     default_flag: true,
//     super_category: 'Tenant Wallet',
//     type: ''
//   },
//   {
//     category: 'Root',
//     sub_category: 'Onchain Transfers',
//     default_flag: true,
//     super_category: 'Tenant Wallet',
//     type: ''
//   },
//   {
//     category: 'Root',
//     sub_category: 'Wallet Configuration',
//     default_flag: true,
//     super_category: 'Tenant Wallet',
//     type: ''
//   },
// ]

// exports.up = async function(knex) {
//   await knex('products').insert(newProducts);
//   const newProductIds = await knex('products').select('product_id').where('category', 'Root');
//   const tenantIds = await knex('tenants').select('tenant_id').whereNot('tenant_name', 'universal ledger');
//   const newProdSubList = [];

//   for ( const tenants of tenantIds ) {
//     for ( const products of newProductIds ) {
//       newProdSubList.push({
//         product_id: products.product_id,
//         tenant_id: tenants.tenant_id,
//         is_active: true
//       });
//     }
//   }

//   await knex('product_subscriptions').insert(newProdSubList);
// };

// exports.down = async function(knex) {
//   await knex('products').where('category', 'Root').delete();
// };
exports.up = async function (knex) {}
exports.down = async function (knex) {}