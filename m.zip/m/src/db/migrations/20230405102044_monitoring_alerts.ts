exports.up = async function (knex) {

  await knex.schema.createTable('monitoring_alerts', (table) => {
    table.uuid('alert_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('id');
    table.uuid('compliance_transaction_id').references('compliance_transaction_id').inTable('transactions_monitoring');
    table.uuid('rule_id');
    table.string('rule_name');
    table.uuid('alert_config_id');
    table.string('message').nullable();
    table.string('notes').nullable();
    table.integer('severity');
    table.integer('status');
    table.string('date_raised').nullable();
    table.string('date_claimed').nullable();
    table.string('claimed_by_user_id');
    table.string('claimed_by_user_name').nullable();
    table.string('date_cleared').nullable();
    table.string('cleared_by_user_name').nullable();
    table.string('cleared_by_user_id').nullable();
    table.string('internal_notes').nullable();
    table.string('date_updated').nullable();
    table.string('updated_by_user_id').nullable();
    table.string('updated_by_user_name').nullable();
    table.integer('entity_type');
    table.string('historical_transactions').nullable();
    table.jsonb('triggered_alert_config');
    table.string('channel').nullable();
    table.string('entity_id').nullable();
    table.integer('trigger_config_type');
    table.integer('execution_flow');
    table.integer('external_system_raw_alert_raw_risk');
    table.jsonb('metadata');
  })
};

exports.down = async function (knex) {
  return knex.schema.dropTable('monitoring_alerts');
}