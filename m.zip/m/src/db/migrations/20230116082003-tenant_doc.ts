exports.up = function (knex) {
  return knex.schema.createTable('tenant_documents', (table) => {
    table.uuid('tenant_document_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.enu('document_type', [ 'DriversLicense', 'Passport', 'IdCard', 'ResidencePermit', 'Jurisdiction', 'Incorporation', 'None', 'Other', 'Selfie' ]).notNullable().defaultTo('Other');
    table.string('file_name').notNullable();
    table.text('content').notNullable();
    table.string('country_code').notNullable();
    table.string('type').notNullable();
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('tenant_documents');
};
