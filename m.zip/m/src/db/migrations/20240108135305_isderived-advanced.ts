// const derivedAttributes = [
//   {
//     attributeName: 'gidExpirationDate',
//     derivedAttribute: 'gidExpirationDateList'
//   },
//   {
//     attributeName: 'gidIssueDate',
//     derivedAttribute: 'gidIssueDateList'
//   },
//   {
//     attributeName: 'gidGender',
//     derivedAttribute: 'gidGenderIs'
//   },
//   {
//     attributeName: 'gidDob',
//     derivedAttribute: 'gidAge'
//   },
//   {
//     attributeName: 'gidState',
//     derivedAttribute: 'gidStateList'
//   },
//   {
//     attributeName: 'gidCountry',
//     derivedAttribute: 'gidCountryList'
//   },
//   {
//     attributeName: 'city',
//     derivedAttribute: 'cityList'
//   },
//   {
//     attributeName: 'state',
//     derivedAttribute: 'stateList'
//   },
//   {
//     attributeName: 'country',
//     derivedAttribute: 'countryList'
//   },
//   {
//     attributeName: 'dob',
//     derivedAttribute: 'age'
//   }
// ]

exports.up = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.dropColumn('is_derivable');
    table.string('derived_attribute');
  })
  // for( const attribute of derivedAttributes){
  //   // eslint-disable-next-line no-await-in-loop
  //   await knex('attributes').update({
  //     'derived_attribute': attribute?.derivedAttribute,
  //   }).where('attribute_name', attribute?.attributeName);
  // }
}

exports.down = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.dropColumn('derived_attribute');
  })
}