exports.up = async function (knex) {
  await knex.schema.alterTable('users', (table) => {
    table.uuid('created_by');
    table.uuid('updated_by');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('users');
};
