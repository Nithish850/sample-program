exports.up = function (knex) {
  return knex.schema.createTable('compliance_denial', (table) => {
    table
      .uuid('compliance_denial_id')
      .primary()
      .defaultTo(knex.raw('gen_random_uuid()'));
    table.string('compliance_denial_workflow').notNullable();
    table.string('compliance_denial_reason').notNullable();
    table.string('compliance_denial_code').notNullable();
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('compliance_denial');
};
