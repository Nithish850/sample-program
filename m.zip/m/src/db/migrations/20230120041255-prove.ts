exports.up = function (knex) {
  return knex.schema.createTable('prove_metadata', (table) => {
    table.uuid('prove_metadata_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('request_id').notNullable().unique();
    table.string('session_id').notNullable();
    table.string('api_client_id').notNullable();
    table.string('source_ip').notNullable();
    table.string('final_target_url').notNullable();
    table.string('mobile_number').notNullable();
    table.string('sub_client_id').notNullable();
    table.string('license').notNullable();
    table.string('client_context').notNullable();
    table.string('message_text').notNullable();
    table.string('status').notNullable();
    table.string('description').notNullable();
    table.string('authentication_url').notNullable();
    table.string('mobile_operator_name').notNullable();
    table.string('ssn').notNullable();
    table.string('dob');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('tenant_documents');
};
