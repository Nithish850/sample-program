exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('nationality ');
    table.string('ip_address');
    table.string('lat_long');
    table.string('ssn');
    table.string('tax_id');
    table.string('category');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('customer_accounts');
};
