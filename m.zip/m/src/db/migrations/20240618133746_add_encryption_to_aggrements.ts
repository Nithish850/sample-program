/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

export async function up(knex: Knex): Promise<void> {
  try {
    console.log('Altering column types to text for encryption...');
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    await knex.raw(`
      ALTER TABLE agreements
      ALTER COLUMN first_name TYPE text,
      ALTER COLUMN last_name TYPE text,
      ALTER COLUMN email TYPE text,
      ALTER COLUMN ip TYPE text;
    `);
    console.log('Column types altered to text.');

    console.log('Encrypting existing data in agreements table ...');
    await knex.raw(`
        UPDATE agreements
        SET 
          first_name = encrypt(first_name::bytea, '${val}'::bytea,'aes'::text),
          last_name = encrypt(last_name::bytea, '${val}'::bytea,'aes'::text),
          email = encrypt(email::bytea, '${val}'::bytea,'aes'::text),
          ip = encrypt(ip::bytea, '${val}'::bytea,'aes'::text);
      `);
    console.log('Existing data in agreements table encrypted.');

    await knex('encryption_decryption').insert([
      { table_name: 'agreements', column_name: 'first_name' },
      { table_name: 'agreements', column_name: 'last_name' },
      { table_name: 'agreements', column_name: 'email' },
      { table_name: 'agreements', column_name: 'ip' }
    ]);
    console.log('Insert into encryption_decryption for agreements completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    console.log('Decrypting existing data in agreements table...');

    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;

    await knex.raw(`
      UPDATE agreements
      SET first_name = convert_from(decrypt(first_name::bytea, '${val}', 'aes'), 'SQL_ASCII')::text,
          last_name = convert_from(decrypt(last_name::bytea, '${val}', 'aes'), 'SQL_ASCII')::text,
          email = convert_from(decrypt(email::bytea, '${val}', 'aes'), 'SQL_ASCII')::text,
          ip = convert_from(decrypt(ip::bytea, '${val}', 'aes'), 'SQL_ASCII')::text;
    `);
    console.log('Existing data in agreements table decrypted.');

    await knex('encryption_decryption')
      .whereIn('column_name', ['first_name', 'last_name', 'email', 'ip'])
      .andWhere({ table_name: 'agreements' })
      .del();
    console.log('Deletion from encryption_decryption for agreements completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
