exports.up = function (knex) {
  return knex.schema.createTable('wallet_type', (table) => {
    table.uuid('wallet_type_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.string('wallet_type_name').unique().notNullable();
    table.timestamps(true, true);
  })
    .createTable('wallet_capabilities', (table) => {
      table.uuid('wallet_capabilities_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('wallet_type_id').references('wallet_type_id').inTable('wallet_type').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.boolean('deposit').defaultTo(false);
      table.boolean('withdraw').defaultTo(false);
      table.boolean('transfer').defaultTo(false);
      table.boolean('multi_wallet').defaultTo(false);
      table.timestamps(true, true);
    });
};
exports.down = function (knex) {
  return knex.schema
    .dropTable('wallet_capabilities')
    .dropTable('wallet_type');
};
