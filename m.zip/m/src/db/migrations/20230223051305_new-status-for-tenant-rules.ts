/** function to create tenant_rules DB */
exports.up = async function up(knex) {
  const tenantData = await knex('tenant_rules').select('*'). where('status', '!=', 'pending');

  await knex.schema.alterTable('tenant_rules', (table) => {
    table.dropColumn('status');
  });

  await knex.schema.alterTable('tenant_rules', (table) => {
    table.enu('status', [ 'pending', 'approved', 'rejected', 'completed' ]).notNullable().defaultTo('pending');
  });

  // rewritting the previous values
  if(tenantData.length > 0) {
    for(const { rule_id, tenant_id, is_active, rule_group, rule_slug, rule_version, is_default_rule, status } of tenantData) {
      /* eslint-disable no-await-in-loop */
      await knex('tenant_rules').select('*').where({
        rule_id,
        tenant_id,
        is_active,
        rule_group,
        rule_slug,
        rule_version,
        is_default_rule,
      })
        .update({
          status: status
        })
    }
  }
};

/** function to bring down tenant_rules DB */
exports.down = async function down(knex) {
  await knex.schema.dropTable('tenant_rules');
};