/* eslint-disable no-console */
import { Knex } from "knex";

exports.up = function(knex : Knex) {
  console.log('adding safe_decrypt function')

  return knex.schema.raw(`
      CREATE OR REPLACE FUNCTION safe_decrypt(
        column_data bytea,
        encryption_key text,
        encoding text
      )
      RETURNS text AS $$
      DECLARE
        decrypted_value text;
      BEGIN
        BEGIN
          -- Attempt to decrypt and convert
          RETURN convert_from(decrypt(column_data::bytea, encryption_key::bytea, 'aes'::text), encoding);
        EXCEPTION
          WHEN others THEN
            -- If decryption fails, return the original value converted to text
            RETURN convert_from(column_data, encoding);
        END;
      END;
      $$ LANGUAGE plpgsql;
    `);
};

exports.down = function(knex : Knex) {
  console.log('dropping safe_decrypt function')

  return knex.schema.raw(`
      DROP FUNCTION IF EXISTS safe_decrypt(bytea, text, text);
    `);
};
