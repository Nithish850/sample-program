exports.up = async function(knex) {
  await knex.schema.createTable('reconciliation_logs', (table) => {
    table.uuid('reconciliation_log_id').primary().defaultTo(knex.raw('gen_random_uuid()'));  
    table.date('start_date').notNullable();  
    table.date('end_date').notNullable();  
    table.enu('status', ['COMPLETED', 'PENDING', 'FAILED']).defaultTo('PENDING').notNullable();
    table.integer('total_transactions_checked').defaultTo(0).notNullable();
    table.integer('missing_transactions_identified').defaultTo(0).notNullable();
    table.jsonb('missing_transactions').defaultTo('{}').notNullable();
    table.integer('last_block_processed').defaultTo(0).notNullable();
    table.timestamps(true, true);  
  });
};
exports.down = async function(knex) {
  await knex.schema.dropTable('reconciliation_logs')
};