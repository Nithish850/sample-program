exports.up = async function (knex) {

  await knex.schema.createTable('attributes_min_max_val', (table) => {
    table.primary([ 'attribute_id', 'rule_group', 'rule_slug' ]);
    table.enu('rule_group', [ 'ONBOARD', 'UPGRADE', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable().defaultTo('NONE');
    table.enu('rule_slug', [ 'tier0', 'tier1', 'tier2', 'tier3', 'tier4' ]);
    table.string('minimum_value');
    table.string('maximum_value');
    table.uuid('attribute_id').references('attribute_id').inTable('attributes').onDelete('CASCADE').onUpdate('CASCADE');  })
};

exports.down = async function (knex) {
  return knex.schema.dropTable('attributes_min_max_val');
}