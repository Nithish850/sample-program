exports.up = async function(knex) {
  await knex.schema.alterTable('products', async (table) => {
    const hasDefault = await knex.schema.hasColumn('products', 'default_flag');

    if(!hasDefault) {
      table.boolean('default_flag').defaultTo(true);
    }else{
      table.boolean('default_flag').defaultTo(true);
    }
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('products', (table) => {
    table.dropColumn('default_flag');
  });
};
