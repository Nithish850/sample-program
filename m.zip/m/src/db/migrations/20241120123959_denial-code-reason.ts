exports.up = async function (knex) {
  await knex.schema.alterTable('compliance_details', (table) => {
    table.string('denial_code');
    table.string('denial_reason');
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('compliance_details', (table) => {
    table.dropColumn('denial_code');
    table.dropColumn('denial_reason');
  })
};
