exports.up = function (knex) {
  return knex.schema
    .createTable('dss_vendor_consent', (table) => {
      table.uuid('dss_vendor_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('vendor_name').notNullable();
      table.string('consent_version').notNullable();
      table.enu('active_status', [ 'ACTIVE', 'INACTIVE' ]);
      table.string('current_active_version').notNullable();
      table.string('consent_message');
      table.timestamps(true, true);
    })
    .createTable('customer_consent', (table) => {
      table.uuid('customer_consent_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('dss_vendor_id').references('dss_vendor_id').inTable('dss_vendor_consent').onDelete('CASCADE').onUpdate('CASCADE');
      table.enu('consent_status', [ 'PENDING', 'ACCEPTED', 'REJECTED' ]).notNullable().defaultTo('PENDING');
      table.string('consent_version').notNullable();
      table.timestamps(true, true);
    })
};
exports.down = function (knex) {
  return knex.schema
    .dropTable('dss_vendor_consent')
    .dropTable('customer_consent');
};