exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('gid_name');
    table.string('gid_dob');
    table.jsonb('gid_photo');
    table.string('gid_id_number');
    table.string('gid_country');
    table.string('gid_state');
    table.string('gid_issue_date');
    table.string('gid_expiration_date');
    table.jsonb('gid_address');
    table.string('gid_gender');
  });
};
exports.down = async function (knex) {
  return knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('gid_name');
    table.dropColumn('gid_dob');
    table.dropColumn('gid_photo');
    table.dropColumn('gid_id_number');
    table.dropColumn('gid_country');
    table.dropColumn('gid_state');
    table.dropColumn('gid_issue_date');
    table.dropColumn('gid_expiration_date');
    table.dropColumn('gid_address');
    table.dropColumn('gid_gender');
  })
};