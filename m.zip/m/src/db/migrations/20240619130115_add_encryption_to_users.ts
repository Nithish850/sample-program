/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

export async function up(knex: Knex): Promise<void> {
  try {
    console.log('Altering column types to text for encryption in users table...');
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    await knex.raw(`
      ALTER TABLE users
      ALTER COLUMN email TYPE text,
      ALTER COLUMN phone_number TYPE text,
      ALTER COLUMN address TYPE text,
      ALTER COLUMN employee_id TYPE text,
      ALTER COLUMN dob TYPE text,
      ALTER COLUMN nationality TYPE text,
      ALTER COLUMN ip_address TYPE text,
      ALTER COLUMN lat_long TYPE text,
      ALTER COLUMN phone_number_country_code TYPE text;
    `);
    console.log('Column types in users table altered to text.');

    console.log('Encrypting existing data in users table ...');
    await knex.raw(`
        UPDATE users
        SET 
          email = encrypt(email::bytea, '${val}'::bytea,'aes'::text),
          phone_number = encrypt(phone_number::bytea, '${val}'::bytea,'aes'::text),
          address = encrypt(address::bytea, '${val}'::bytea,'aes'::text),
          employee_id = encrypt(employee_id::bytea, '${val}'::bytea,'aes'::text),
          dob = encrypt(dob::bytea, '${val}'::bytea,'aes'::text),
          nationality = encrypt(nationality::bytea, '${val}'::bytea,'aes'::text),
          ip_address = encrypt(ip_address::bytea, '${val}'::bytea,'aes'::text),
          lat_long = encrypt(lat_long::bytea, '${val}'::bytea,'aes'::text),
          phone_number_country_code = encrypt(phone_number_country_code::bytea, '${val}'::bytea,'aes'::text);
      `);
    console.log('Existing data in users table encrypted.');

    await knex('encryption_decryption').insert([
      { table_name: 'users', column_name: 'email' },
      { table_name: 'users', column_name: 'phone_number' },
      { table_name: 'users', column_name: 'address' },
      { table_name: 'users', column_name: 'employee_id' },
      { table_name: 'users', column_name: 'dob' },
      { table_name: 'users', column_name: 'nationality' },
      { table_name: 'users', column_name: 'ip_address' },
      { table_name: 'users', column_name: 'lat_long' },
      { table_name: 'users', column_name: 'phone_number_country_code' }
    ]);
    console.log('Insert into encryption_decryption for users completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log('Dropping trigger for encrypting users ...');
    await knex.raw('DROP TRIGGER IF EXISTS before_insert_update_users ON users;');
    console.log('Trigger for encrypting users dropped.');

    console.log('Dropping trigger function for encrypting users ...');
    await knex.raw('DROP FUNCTION IF EXISTS encrypt_users;');
    console.log('Trigger function for encrypting users dropped.');

    console.log('Decrypting existing data in users table...');

    await knex.raw(`
      UPDATE users
      SET email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          phone_number = convert_from(decrypt(phone_number::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          address = convert_from(decrypt(address::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          employee_id = convert_from(decrypt(employee_id::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          dob = convert_from(decrypt(dob::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          nationality = convert_from(decrypt(nationality::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          ip_address = convert_from(decrypt(ip_address::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          lat_long = convert_from(decrypt(lat_long::bytea, '${val}'::bytea, 'aes'::text), 'SQL_ASCII'::text),
          phone_number_country_code = convert_from(decrypt(phone_number_country_code::bytea, '${val}'::bytea, 'aes'), 'SQL_ASCII'::text);
    `);
    console.log('Existing data in users table decrypted.');

    await knex('encryption_decryption')
      .whereIn('column_name', ['email', 'phone_number', 'address', 'employee_id', 'dob', 'nationality', 'ip_address', 'lat_long', 'phone_number_country_code'])
      .andWhere({ table_name: 'users' })
      .del();
    console.log('Deletion from encryption_decryption for users completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
