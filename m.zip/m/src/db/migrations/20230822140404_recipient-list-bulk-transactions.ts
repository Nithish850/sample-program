exports.up = async function (knex) {
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.text('recipient_list').alter();
  });
}
exports.down = async function (knex) {
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.text('recipient_list').alter();
  });
}