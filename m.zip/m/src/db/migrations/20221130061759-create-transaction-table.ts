exports.up = function (knex) {
  return knex.schema
    .createTable('transaction', (table) => {
      table.uuid('id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('transaction_hash').notNullable();
      table.string('transaction_amount').notNullable();
      table.string('transaction_type').notNullable();
      table.string('initiator').notNullable();
      table.string('beneficiary').notNullable();
      table.string('tenant_namespace').notNullable();
      table.string('full_name');
      table.enu('rule_status', [ 'SUCCESS', 'PENDING', 'FAILED' ]).notNullable().defaultTo('PENDING');
      table.enu('compliance_status', [ 'ACCEPTED', 'PENDING' ]).notNullable().defaultTo('PENDING');
      table.enu('status', [ 'COMPLETED', 'PENDING', 'CANCELLED' ]).notNullable().defaultTo('PENDING');
      table.timestamps(true, true);
    })
    .createTable('transaction_notes', (table) => {
      table.uuid('transaction_note_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('id');
      table.string('comment');
      table.jsonb('attachment');
      table.string('created_by');
      table.timestamp('created_at').defaultTo(knex.fn.now());
    });
};
exports.down = function (knex) {
  return knex.schema.dropTable('transaction').dropTable('transaction_notes');
};
