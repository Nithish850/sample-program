/** function to bring up bulk_transactions and bulk_transactions_receipts table */
exports.up = async function (knex) {
  const bulkTransactionsData = await knex('bulk_transactions').select('*');
  const bulkreceiptsData = await knex('bulk_transactions_receipts').select('*');

  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('bulk_transfer_status');
  }).alterTable('bulk_transactions_receipts', (table) => {
    table.dropColumn('transaction_status');
  });

  await knex.schema
    .alterTable('bulk_transactions', function (table) {
      table.enu('bulk_transfer_status', [ 'PROCESSED', 'PENDING', 'CANCELLED', 'REVERSAL', 'REJECTED', 'FAILED', 'COMPLETED' ]).defaultTo('PENDING').notNullable();
    }).alterTable('bulk_transactions_receipts', function (table) {
      table.enu('transaction_status', [ 'PROCESSED', 'PENDING', 'CANCELLED', 'REVERSAL', 'REJECTED', 'FAILED', 'COMPLETED' ]).defaultTo('PENDING').notNullable();
    });

  if(bulkTransactionsData.length > 0) {
    for(const { bulk_transaction_id, bulk_transfer_status } of bulkTransactionsData) {
      /* eslint-disable no-await-in-loop */
      await knex('bulk_transactions').where({ bulk_transaction_id }).update({
        bulk_transfer_status: bulk_transfer_status
      })
    }
  }

  if(bulkTransactionsData.length > 0) {
    for(const { receipt_id, transaction_status } of bulkreceiptsData) {
      /* eslint-disable no-await-in-loop */
      await knex('bulk_transactions_receipts').where({ receipt_id }).update({
        transaction_status: transaction_status
      })
    }
  }
};

/** function to bring down bulk_transactions and bulk_transactions_receipts table */
exports.down = async function (knex) {
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('bulk_transfer_status');
  });
  await knex.schema.alterTable('bulk_transactions_receipts', (table) => {
    table.dropColumn('transaction_status');
  });
};
