import { mappingOfGidAttributes } from "../master/attribute-display-names";

/* eslint-disable no-await-in-loop */
const derivedAttributes = [
  {
    attributeName: 'verifiedIdExpirationDate',
    derivedAttribute: 'verifiedIdExpirationDateList'
  },
  {
    attributeName: 'verifiedIdIssueDate',
    derivedAttribute: 'verifiedIdIssueDateList'
  },
  {
    attributeName: 'verifiedIdGender',
    derivedAttribute: 'verifiedIdGenderIs'
  },
  {
    attributeName: 'verifiedIdDob',
    derivedAttribute: 'verifiedIdAge'
  },
  {
    attributeName: 'verifiedIdState',
    derivedAttribute: 'verifiedIdStateList'
  },
  {
    attributeName: 'verifiedIdCountry',
    derivedAttribute: 'verifiedIdCountryList'
  }
]

const handleNestedJSON = (defaultRule, mappingOfAttributes) => {
  if (Array.isArray(defaultRule)) {
    defaultRule.forEach((condition) => {
      if (Object.keys(condition).length !== 0) {
        Object.keys(condition).forEach((key) => {
          if (Array.isArray(condition[key]) && (key === 'all' || key === 'any')) {
            handleNestedJSON(condition[key], mappingOfAttributes);
          } else if (key === 'fact') {
            condition[key] = mappingOfAttributes[condition[key]] || condition[key];
          }
        });
      }
    });

    return defaultRule;
  }
};

const updateRules = async (knex) => {
  const onboardActiveRules = await knex('rules').select('rules.*', 'badge_rules.*').join('badge_rules', 'badge_rules.rule_id', '=', 'rules.rule_id')
    .where('badge_rules.is_active', true)
    .where({
      'badge_rules.is_active': true,
      'badge_rules.rule_group': 'ONBOARD'
    })
    .orWhere({
      'badge_rules.is_active': true,
      'badge_rules.rule_group': 'INFORMATION'
    });

  await knex.transaction(async (trx) => {
    await Promise.all(onboardActiveRules.map(async (rule) => {
      const decision_type = rule?.rule_json.decisions[0].conditions?.all
        ? 'all'
        : 'any';

      const decisions = rule?.rule_json?.decisions[0];

      decisions.conditions[decision_type] = handleNestedJSON(rule?.rule_json.decisions[0].conditions[decision_type], mappingOfGidAttributes);

      rule?.rule_json.attributes.forEach((attribute) => {
        attribute.name = mappingOfGidAttributes[attribute.name] != undefined ? mappingOfGidAttributes[attribute.name] : attribute.name;
      });

      rule.rule_json.decisions[0] = decisions;

      await trx('rules').where('rule_id', rule.rule_id).update({
        rule_json: rule.rule_json,
      });
    }));
  });
}

exports.up = async function (knex) {
  await knex('attributes').update({
    'attribute_name': 'verifiedIdState'
  }).where('derived_attribute', 'gidStateList')
  for( const attribute of derivedAttributes){
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'derived_attribute': attribute?.derivedAttribute,
    }).where('attribute_name', attribute?.attributeName);
  }
  await updateRules(knex);
}
exports.down = async function (knex) {
  for( const attribute of derivedAttributes){
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'derived_attribute': attribute?.derivedAttribute,
    }).where('attribute_name', attribute?.attributeName);
  }
  await updateRules(knex);
}