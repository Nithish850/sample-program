/* eslint-disable no-await-in-loop */
exports.up = async function (knex) {
  const tenantMultiWallet = await knex('tenant_multi_wallet').select();

  for(const wallet of tenantMultiWallet) {
    await knex('tenant_namespace').insert({
      tenant_namespace: wallet.wallet_namespace,
      account_address: wallet.wallet_address,
      token: wallet.wallet_token,
      tenant_id: wallet.tenant_id,
      wallet_type: 'DISBURSEMENT WALLET',
      wallet_name: wallet.wallet_alias,
    })
  }
  knex.schema.dropTable('tenant_multi_wallet')
};
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_multi_wallet');
};
