exports.up = async (knex) => {
  await knex.schema
    /* Schema for custom contract requests */
    .createTable('custom_contract_requests', (table) => {
      /* represent the rows uniquely */
      table
        .uuid('public_id')
        .primary()
        .defaultTo(knex.raw('gen_random_uuid()'));
      /* contract_name - name of the contract */
      table.string('contract_name').notNullable();
      /* contract_code - source code of the contract in base64 form */
      table.text('contract_code').notNullable();
      /* token_symbol - symbol of the token that this custom contract built upon */
      table
        .string('token_symbol')
        .references('symbol')
        .inTable('contract_store')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /*
      deploy_status - status of the contract if deployed or not
                    REQUESTED: when tenant requests to deploy their custom contract
                    INPROGRESS: when platform admin reviews the code and approves
                    ACTIVE: when developer deploys the custom contract
                    REJECTED: when platform admin rejects the custom contract to deploy
    */
      table
        .string('deploy_status')
        .checkIn(['REQUESTED', 'IN PROGRESS', 'ACTIVE', 'REJECTED'])
        .defaultTo('REQUESTED');
      /* contract_address - implementation address of the custom contract */
      table.string('contract_address').unique();
      /* proxy_address - proxy address of the custom contract */
      table.string('proxy_address');
      /* version - version of the implementation contract */
      table.integer('version').defaultTo(1);
      /* tenant_id - id of the tenant */
      table
        .uuid('tenant_id')
        .references('tenant_id')
        .inTable('tenants')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /* reviewed_at - is the time when platform admin reviewed and approved */
      table.date('reviewed_at');
      /* reviewed_by - is the person name who reviewed it */
      table.string('reviewed_by');
      /* deployed_at - is the time when custom contract is deployed */
      table.date('deployed_at').defaultTo(knex.fn.now());
      table.timestamps(true, true);
    })
    /* Schema for custom contract keys */
    .createTable('custom_contract_keys', (table) => {
      /* represent the rows uniquely */
      table
        .uuid('public_id')
        .primary()
        .defaultTo(knex.raw('gen_random_uuid()'));
      /* address - account address generated to deploy custom contract */
      table.string('address').unique();
      /* private_key - raw private key storing to restore later */
      table.string('private_key').notNullable().unique();
      /* mnemonic - mnemonic by which private key is generated */
      table.string('mnemonic').notNullable().unique();
      table.timestamps(true, true);
    })
    /* schema for custom contracts */
    .createTable('custom_contracts', (table) => {
      /* public_id - represents the rows uniquely */
      table
        .uuid('public_id')
        .primary()
        .defaultTo(knex.raw('gen_random_uuid()'));
      /* contract_name - name of the custom contract */
      table.string('contract_name').notNullable();
      /* contract_owner - address of the deployer(tenants) */
      table
        .string('contract_owner')
        .notNullable()
        .references('address')
        .inTable('custom_contract_keys')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /* private_key - encrypted private key of the deployer account */
      table.string('private_key').notNullable().unique();
      /* private_key_iv - initialization vector used to encrypt and decrypt private key */
      table.string('private_key_iv').notNullable().unique();
      /* implementation_address - implementation address of the custom contract */
      table
        .string('implementation_address')
        .notNullable()
        .unique()
        .references('contract_address')
        .inTable('custom_contract_requests')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /* proxy_address - proxy address of the custom contract */
      table.string('proxy_address').unique().notNullable();
      /* storage_address - storage address of the custom contract */
      table.string('storage_address').notNullable();
      /* event_emitter_address - event emitter address of the custom contract */
      table.string('event_emitter_address').notNullable();
      /* is_active - true if custom contract is active else false */
      table.boolean('is_active').defaultTo(false);
      /* tenant_id - tenant id of the tenant */
      table
        .uuid('tenant_id')
        .notNullable()
        .references('tenant_id')
        .inTable('tenants')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /* contract_abi - contract abi of the implementation contract */
      table.jsonb('contract_abi').notNullable().defaultTo({});
      table.timestamps(true, true);
    })
    /* Schema for custom contract transactions */
    .createTable('custom_contract_transactions', (table) => {
      /* public_id - represents the rows uniquely */
      table
        .uuid('public_id')
        .primary()
        .defaultTo(knex.raw('gen_random_uuid()'));
      /* sender - address of the sender */
      table.string('sender').notNullable();
      /* receiver - address of the receiver */
      table.string('receiver').notNullable();
      /* status - status of the transaction */
      table.string('status').checkIn(['PENDING', 'COMPLETED', 'REJECTED']);
      /* amount - amount in token's lowest denomination */
      table.string('amount').defaultTo('0');
      /* token - symbol of the token */
      table.string('token');
      /* contract id - id of the custom contract which this transaction belongs to */
      table
        .uuid('contract_id')
        .references('public_id')
        .inTable('custom_contracts')
        .onDelete('CASCADE')
        .onUpdate('CASCADE')
        .notNullable();
      /* tenant_id - id of the tenant */
      table
        .uuid('tenant_id')
        .references('tenant_id')
        .inTable('tenants')
        .onDelete('CASCADE')
        .onUpdate('CASCADE');
      /* transaction_hash - hash of the auto signed transaction */
      table.string('transaction_hash').notNullable().unique();
      /* extra_info - object which contains metadata of the parent transaction, block number etc */
      table.jsonb('extra_info').defaultTo({});
      /* reject_reason - reject reason if transaction is rejected */
      table.string('reject_reason');
      table.timestamps(true, true);
    });
};

exports.down = async (knex) => {
  await knex.schema
    .dropTable('custom_contract_transactions')
    .dropTable('custom_contracts')
    .dropTable('custom_contract_keys')
    .dropTable('custom_contract_requests');
};
