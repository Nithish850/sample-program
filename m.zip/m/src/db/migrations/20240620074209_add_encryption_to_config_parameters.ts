/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'config_parameters';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Altering column type to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN name TYPE text;
    `);
    console.log(`Column type in ${tableName} table altered to text.`);

    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
    UPDATE ${tableName}
    SET 
      name = encrypt(name::bytea, '${val}'::bytea, 'aes'::text);
   `);
    console.log(`Existing data in ${tableName} table encrypted.`);

    console.log('Inserting entry into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'name' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        name = convert_from(decrypt(name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    console.log('Deleting entry from encryption_decryption for recipient_list column...');
    await knex('encryption_decryption')
      .where({ table_name: tableName, column_name: 'name' })
      .del();
    console.log('Deletion from encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
