exports.up = async function (knex) {

  await knex.schema.createTable('criteria', (table) => {
    table.uuid('criteria_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    // this will be unique, will take care at API level
    table.string('criteria_name').notNullable();
    table.jsonb('criteria').notNullable();
    table.text('description');
    table.uuid('tenant_id').references('tenant_id').inTable('tenants');
    table.uuid('created_by').references('user_id').inTable('users');
    table.uuid('updated_by' ).references('user_id').inTable('users');
    table.boolean('is_active').notNullable().defaultTo(true);
    table.timestamps(true, true);
  });

  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.uuid('criteria_id').references('criteria_id').inTable('criteria').onDelete('CASCADE').onUpdate('CASCADE');
  });
}

exports.down = async function (knex) {
  await knex.schema.dropTable('criteria');
  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('criteria_id');
  });
}