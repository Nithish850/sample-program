/* eslint-disable no-await-in-loop */
const attributes = ['countryName', 'walletUserToIntraTenant', 'tenantToInterTenantWalletUser', 'walletUserToInterTenantWallet'];
const requiredAttributes = ['fullName', 'dob'];
const attribute_display_name = {
  attribute_name: 'countryCode',
  display_attribute_name: 'ISO Country Code'
};

exports.up = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.boolean('is_active').defaultTo(true);
  })
  await knex('attributes').update({
    'is_active': false
  }).whereIn('attribute_name', attributes)
  await knex('attributes').update({
    'is_required': false,
  }).where('rule_group', 'ONBOARD');
  await knex('attributes').update({
    'is_required': true
  }).whereIn('attribute_name', requiredAttributes);
  await knex('attributes').update({
    'display_attribute_name': attribute_display_name?.display_attribute_name
  }).where('attribute_name', attribute_display_name?.attribute_name);
}
exports.down = async function (knex) {

  await knex.schema.alterTable('attributes', (table) => {
    table.dropColumn('is_active');
  });
}