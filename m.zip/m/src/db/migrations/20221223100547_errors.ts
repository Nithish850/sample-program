import { errorCode, errorGroup, errorSlug } from "../master/error-codes";

/** function to create errors DB */
exports.up = function (knex) {

  return knex.schema.createTable('errors', (table) => {
    table.enu('error_code', [ ...errorCode ]);
    table.primary([ 'error_code' ]);
    table.enu('error_group', [ ...errorGroup ]);
    table.enu('error_slug', [ ...errorSlug ]);
    table.string('error_attribute');
    table.string('error_reason').notNullable();
    table.string('error_description');
    table.timestamp('created_at').defaultTo(knex.fn.now());
  }).alterTable('transaction', (table) => {
    table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE');
    table.integer('rule_version');
    table.jsonb('errors')
  });
};

/** function to bring down errors DB */
exports.down = function (knex) {
  return knex.schema.dropTable('errors').dropTable('transaction');
};
