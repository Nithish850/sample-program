exports.up = function(knex) {
  return knex.schema.alterTable('activity_logs', function(table) {
    table.jsonb('previous_data');
    table.uuid('entity_id').alter();
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('activity_logs', function(table) {
    table.dropColumn('previous_data');
    table.string('entity_id').alter();
  });
};