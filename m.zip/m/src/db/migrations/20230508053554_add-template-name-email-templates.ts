exports.up = async function(knex) {
  await knex.schema.alterTable('email_templates', (table) => {
    table.string('template_name');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('email_templates', (table) => {
    table.dropColumn('template_name');
  });
};
