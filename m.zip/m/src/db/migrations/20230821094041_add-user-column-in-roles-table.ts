exports.up = async function(knex) {
  await knex.schema.alterTable('roles', function (table) {
    table.enu('user', [ 'UL', 'TENANT' ])
  })

  const roles = await knex('roles').select('role_id as id', 'role_name');

  roles.forEach( async (role) => {
    let user = null;
    const name = role.role_name.split('_');

    if (name[0].toUpperCase() === 'UL') {
      user = 'UL';
      await knex('roles').update({ user: user }).where('role_id', role.id);
    } else if (name[0].toUpperCase() === 'TENANT') {
      user = 'TENANT';
      await knex('roles').update({ user: user }).where('role_id', role.id);
    }
  });

};

exports.down = async function(knex) {
  await knex.schema.alterTable('roles', function (table) {
    table.dropColumn('user')
  })
};