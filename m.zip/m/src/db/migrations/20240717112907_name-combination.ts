exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    // TODO: This is temporary fix (string to text) for long data considering existing data stored as string. Data type Should be jsonb.
    table.text('name_combination').alter();
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.text('name_combination').alter();
  });
};