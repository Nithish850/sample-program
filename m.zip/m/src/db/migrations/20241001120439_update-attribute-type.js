const modifiedAttributes = [
  {
    attribute_name: 'maritalStatusList',
    attribute_type: 'ARRAY',
  },
  {
    attribute_name: 'genderList',
    attribute_type: 'ARRAY',
  },
  {
    attribute_name: 'verifiedIdGenderIs',
    attribute_type: 'ARRAY',
  },
  {
    attribute_name: 'govIdList',
    attribute_type: 'ARRAY',
  },
  {
    attribute_name: 'verifiedIdType',
    attribute_type: 'ARRAY',
  },
];

exports.up = async function (knex) {
  for (const attribute of modifiedAttributes) {
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes')
      .update({
        attribute_type: attribute?.attribute_type,
      })
      .where('attribute_name', attribute?.attribute_name);
  }
};

exports.down = async function (knex) {
  for (const attribute of onboardAttributes) {
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes')
      .update({
        attribute_type: attribute?.attribute_type,
      })
      .where('attribute_name', attribute?.attribute_name);
  }
};
