exports.up = async function(knex) {
    await knex('dss_event').insert({ event: 'CONSENT' })
  };
  
  exports.down = async function(knex) {
    await knex('dss_event').where('event', 'CONSENT').deleted();
  };
  