exports.up = function(knex) {
  return knex.schema.createTable('api_log', (table) => {
    table.uuid('api_log_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.jsonb('request_body');
    table.jsonb('request_headers');
    table.timestamps(true, true);
  });
};
exports.down = function(knex) {
  return knex.schema.dropTable('api_log');
};