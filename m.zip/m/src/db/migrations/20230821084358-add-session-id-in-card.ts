
exports.up = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.string('session_id');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('session_id');
  })
}