/* eslint-disable no-await-in-loop */
import { attributeDisplayNames, gidAttributes, mappingOfGidAttributes, mappingOfTransferAttributes, transferAttributes } from "../master/attribute-display-names";

const updateAttributes = async(knex) => {
  for(const attribute of attributeDisplayNames) {
  // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'display_attribute_name': attribute?.display_attribute_name,
    }).where('attribute_name', attribute?.attribute_name);
  }

  for(const attribute of gidAttributes) {
  // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'display_attribute_name': attribute?.display_attribute_name,
      'attribute_name': attribute?.new_attribute_name
    }).where('attribute_name', attribute?.attribute_name);
  }

  for(const attribute of transferAttributes) {
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'display_attribute_name': attribute?.display_attribute_name,
      'attribute_name': attribute?.new_attribute_name
    }).where('attribute_name', attribute?.attribute_name);
  }
}

const handleNestedJSON = (defaultRule, mappingOfAttributes) => {
  if (Array.isArray(defaultRule)) {
    defaultRule.forEach((condition) => {
      if (Object.keys(condition).length !== 0) {
        Object.keys(condition).forEach((key) => {
          if (Array.isArray(condition[key]) && (key === 'all' || key === 'any')) {
            handleNestedJSON(condition[key], mappingOfAttributes);
          } else if (key === 'fact') {
            condition[key] = mappingOfAttributes[condition[key]] || condition[key];
          }
        });
      }
    });

    return defaultRule;
  }
};
const updateRules = async (knex) => {
  const onboardActiveRules = await knex('rules').select('rules.*', 'badge_rules.*').join('badge_rules', 'badge_rules.rule_id', '=', 'rules.rule_id')
    .where('badge_rules.is_active', true)
    .where({
      'badge_rules.is_active': true,
      'badge_rules.rule_group': 'ONBOARD'
    })
    .orWhere({
      'badge_rules.is_active': true,
      'badge_rules.rule_group': 'INFORMATION'
    });

  await knex.transaction(async (trx) => {
    await Promise.all(onboardActiveRules.map(async (rule) => {
      const decision_type = rule?.rule_json.decisions[0].conditions?.all
        ? 'all'
        : 'any';

      const decisions = rule?.rule_json?.decisions[0];

      decisions.conditions[decision_type] = handleNestedJSON(rule?.rule_json.decisions[0].conditions[decision_type], mappingOfGidAttributes);

      rule?.rule_json.attributes.forEach((attribute) => {
        attribute.name = mappingOfGidAttributes[attribute.name] != undefined ? mappingOfGidAttributes[attribute.name] : attribute.name;
      });

      rule.rule_json.decisions[0] = decisions;

      await trx('rules').where('rule_id', rule.rule_id).update({
        rule_json: rule.rule_json,
      });
    }));
  });
}

const updateTransferRules = async (knex) => {
  let transferActiveRules = await knex('rules').select().join('tenant_rules', 'tenant_rules.rule_id', '=', 'rules.rule_id')
    .where('tenant_rules.is_active', true)
    .where({
      'tenant_rules.is_active': true,
      'tenant_rules.rule_group': 'TRANSFER'
    });

  transferActiveRules = [...transferActiveRules, ...await knex('rules').select()
    .join('badge_rules', 'badge_rules.rule_id', '=', 'rules.rule_id')
    .where('badge_rules.is_active', true)
    .where({
      'badge_rules.is_active': true,
      'badge_rules.rule_group': 'TRANSFER'
    })]
  await knex.transaction(async (trx) => {
    await Promise.all(transferActiveRules.map(async (rule) => {
      const decision_type = rule?.rule_json.decisions[0].conditions?.all
        ? 'all'
        : 'any';

      const decisions = rule?.rule_json?.decisions[0];

      decisions.conditions[decision_type] = handleNestedJSON(rule?.rule_json.decisions[0].conditions[decision_type], mappingOfTransferAttributes);

      rule?.rule_json.attributes.forEach((attribute) => {
        attribute.name = mappingOfTransferAttributes[attribute.name] != undefined ? mappingOfTransferAttributes[attribute.name] : attribute.name;
      });

      rule.rule_json.decisions[0] = decisions;

      await trx('rules').where('rule_id', rule.rule_id).update({
        rule_json: rule.rule_json,
      });
    }));
  });
}

exports.up = async function (knex) {
  await updateAttributes(knex);
  await updateRules(knex);
  await updateTransferRules(knex);
}

exports.down = async function (knex) {
  await updateAttributes(knex);
  await updateRules(knex);
  await updateTransferRules(knex);
}