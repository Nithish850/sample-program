exports.up = async function(knex) {
  await knex.schema.alterTable('dss_vendor_consent', (table) => {
    table.string('dss_id');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('dss_vendor_consent', (table) => {
    table.dropColumn('dss_id');
  });
};
