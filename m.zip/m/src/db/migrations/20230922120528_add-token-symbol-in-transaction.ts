exports.up = async function (knex) {
  await knex.schema.alterTable('transaction', (table) => {
    table.string('token_symbol').notNullable().default('USBC');
  });

  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.string('token_symbol').notNullable().default('USBC');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('transaction', (table) => {
    table.dropColumn('token_symbol');
  });

  await knex.schema.alterTable('bulk_transactions', (table) => {
    table.dropColumn('token_symbol');
  });
};