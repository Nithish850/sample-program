exports.up = function (knex) {
  return knex.schema
    .createTable('validation', (table) => {
      table.uuid('validation_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('type').notNullable();
      table.string('start').notNullable();
      table.string('end').notNullable();
      table.integer('count').notNullable();
      table.timestamps(true, true);
    }).alterTable('roles', (table) => {
      table.string('role_reference_id');
    });

};
exports.down = function (knex) {
  return knex.schema
    .dropTable('validation')
    .dropTable('roles')
};