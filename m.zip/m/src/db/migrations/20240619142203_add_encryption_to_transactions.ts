/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'transaction';

export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Alter table columns to text for encryption
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN initiator TYPE text,
      ALTER COLUMN beneficiary TYPE text,
      ALTER COLUMN full_name TYPE text,
      ALTER COLUMN sender_namespace TYPE text,
      ALTER COLUMN receiver_namespace TYPE text,
      ALTER COLUMN tenant_namespace TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log('Encrypting existing data in users table ...');
    await knex.raw(`
    UPDATE ${tableName}
    SET 
      initiator = encrypt(initiator::bytea, '${val}'::bytea, 'aes'::text),
      beneficiary = encrypt(beneficiary::bytea, '${val}'::bytea, 'aes'::text),
      full_name = encrypt(full_name::bytea, '${val}'::bytea, 'aes'::text),
      sender_namespace = encrypt(sender_namespace::bytea, '${val}'::bytea, 'aes'::text),
      receiver_namespace = encrypt(receiver_namespace::bytea, '${val}'::bytea, 'aes'::text),
      tenant_namespace = encrypt(tenant_namespace::bytea, '${val}'::bytea, 'aes'::text);
`);

    console.log(`Existing data in users ${tableName} encrypted.`);

    console.log('Inserting entries into encryption_decryption for transaction columns...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'initiator' },
      { table_name: tableName, column_name: 'beneficiary' },
      { table_name: tableName, column_name: 'full_name' },
      { table_name: tableName, column_name: 'sender_namespace' },
      { table_name: tableName, column_name: 'receiver_namespace' },
      { table_name: tableName, column_name: 'tenant_namespace' }
    ]);
    console.log('Insert into encryption_decryption for transaction columns completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 1: Drop trigger for encryption
    console.log(`Dropping trigger for encrypting ${tableName} ...`);
    await knex.raw(`DROP TRIGGER IF EXISTS before_insert_update_${tableName} ON ${tableName};`);
    console.log(`Trigger for encrypting ${tableName} dropped.`);

    // Step 2: Drop trigger function for encryption
    console.log(`Dropping trigger function for encrypting ${tableName} ...`);
    await knex.raw(`DROP FUNCTION IF EXISTS encrypt_${tableName};`);
    console.log(`Trigger function for encrypting ${tableName} dropped.`);

    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        initiator = convert_from(decrypt(initiator::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        beneficiary = convert_from(decrypt(beneficiary::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        full_name = convert_from(decrypt(full_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        sender_namespace = convert_from(decrypt(sender_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        receiver_namespace = convert_from(decrypt(receiver_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tenant_namespace = convert_from(decrypt(tenant_namespace::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    console.log('Deleting entries from encryption_decryption for transaction columns...');
    await knex('encryption_decryption')
      .where({ table_name: tableName })
      .whereIn('column_name', ['initiator', 'beneficiary', 'full_name', 'sender_namespace', 'receiver_namespace', 'tenant_namespace'])
      .del();
    console.log('Deletion from encryption_decryption for transaction columns completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
