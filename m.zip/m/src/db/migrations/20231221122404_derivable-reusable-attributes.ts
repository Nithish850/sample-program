// import { attributes, removeAttributes } from "../master/new-onboard-attributes";
// import { defaultTenant } from "../master/tenant-data";

// const onboardAttributes = [ 'zipcode', 'bankAccount', 'gidState', 'gidIssueDate', 'gidExpirationDate', 'gidAddress', 'gidGender', 'pepScreening', 'sanctionScreeningGeo', 'sanctionScreeningName', 'taxId', 'geoLocationOfAddress', 'geoLocationOfPhoneNumber',
//   'geoLocationOfIp', 'metroDeviceData', 'metroAreaAddress', 'metroAreaPhoneNumber', 'metroAreaIp', 'countryDeviceData', 'countryAddress', 'countryPhoneNumber', 'countryIp'
// ]

// const derivableAttributes = [ 'country', 'state', 'city', 'gidCountry', 'gidExpirationDate', 'gidState', 'gidGender', 'gidIssueDate']

// const getDefaultTenantId = async (knex) =>{
//   const defaultTenantData = await knex('tenants').select('tenant_id').where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain })

//   return defaultTenantData[0]?.tenant_id;
// }

exports.up = async function (knex) {
  // const tenant_id = await getDefaultTenantId(knex);

  await knex.schema.alterTable('attributes', (table) => {
    table.boolean('is_derivable').defaultTo(false);
    table.boolean('is_required').defaultTo(true);
  })
  // await knex('attributes').insert(attributes);
  // await knex('attributes').whereIn('attribute_name', removeAttributes).delete();

  // await knex('attributes').update({
  //   'is_required': false,
  // }).whereIn('attribute_name', onboardAttributes);
  // await knex('attributes').update({
  //   'is_derivable': true,
  // }).whereIn('attribute_name', derivableAttributes);
  // await knex('attributes').update({
  //   'tenant_id': tenant_id,
  // }).where('tenant_id', null);
}

exports.down = async function (knex) {
  await knex.schema.alterTable('attributes', (table) => {
    table.dropColumn('is_derivable');
    table.dropColumn('is_required');
  })
}