exports.up = async function(knex) {
  await knex('agreement_template').update({ id: 'UL01', version: 'V1', current_active_version: 'V1' })
    .whereNot('type', 'US_PATRIOTIC_ACT')
};

exports.down = async function(knex) {
  await knex('agreement_template').update({ id: '', version: '', current_active_version: '' })
    .whereNot('type', 'US_PATRIOTIC_ACT')
};
