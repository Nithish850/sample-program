const onboardAttributes = [
  {
    attribute_name: 'isProhibitedCountry',
    display_attribute_name: 'Exclude users from Prohibited Country',
  },
  {
    attribute_name: 'isProhibitedState',
    display_attribute_name: 'Exclude users from Prohibited State'
  }
]

exports.up = async function (knex) {
  for(const attribute of onboardAttributes) {
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'display_attribute_name': attribute?.display_attribute_name,
    }).where('attribute_name', attribute?.attribute_name);
  }
}

exports.down = async function (knex) {
  for(const attribute of onboardAttributes) {
    // eslint-disable-next-line no-await-in-loop
    await knex('attributes').update({
      'display_attribute_name': attribute?.display_attribute_name,
    }).where('attribute_name', attribute?.attribute_name);
  }
}