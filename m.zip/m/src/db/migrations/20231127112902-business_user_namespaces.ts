exports.up = function (knex) {
  return knex.schema.createTable('business_user_namespaces', (table) => {
    table.uuid('business_user_namespace_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('business_user_namespace').notNullable().unique();
    table.string('account_address').notNullable().unique();
    table.enu('category', [ 'tier-1', 'tier0', 'tier1', 'tier2', 'tier3', 'tier4' ]).defaultTo('tier-1');
    table.string('category_name').defaultTo('Business User');
    table.string('wallet_alias').defaultTo('Disbursement Wallet')
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('business_user_namespaces')
}