// /* eslint-disable no-console */
// /* eslint-disable prefer-destructuring */
// /* eslint-disable no-await-in-loop */
// import { onboardAttributes } from '../master/default-attributes';
// import {
//   onboard_tier1_default_rule
// } from '../master/default-rules';
// import {
//   createDefaultAttributes,
//   createDefaultDecisionTree,
//   createDefaultRule,
//   createDefaultTenantRuleMapping,
//   createRuleConditions,
//   createRulesDecisionsConditions,
//   defaultUser,
// } from '../master/tenant-data';

// const createDecisionConditionRelation = async (
//   knex,
//   decision_id,
//   conditionList,
//   tenant_id,
//   created_by,
//   rule_group
// ): Promise<any> => {
//   for (const condition of conditionList) {
//     const attribute = onboardAttributes.filter(
//       (attribute) => attribute.attribute_name === condition.fact && attribute.rule_group === rule_group,
//     )[0];

//     if (attribute) {
//       const isAttributePresent = await knex('attributes')
//         .select()
//         .where({ attribute_name: condition.fact, tenant_id: tenant_id, rule_group: rule_group });

//       if (isAttributePresent && isAttributePresent.length > 0) {
//         await knex('rules_conditions')
//           .insert(
//             await createRuleConditions(
//               isAttributePresent[0].attribute_id,
//               tenant_id,
//               condition.value,
//               condition.operator,
//             ),
//           )
//           .returning('condition_id')
//           .then(async function (c_id) {
//             const condition_id = c_id[0].condition_id;

//             await knex('rules_decisions_conditions').insert(
//               await createRulesDecisionsConditions(
//                 decision_id,
//                 condition_id,
//                 tenant_id,
//                 created_by,
//               ),
//             );
//           });
//       } else {
//         await knex('attributes')
//           .insert(await createDefaultAttributes(tenant_id, attribute))
//           .returning(['attribute_id', 'attribute_name', 'rule_group'])
//           .then(async function (data) {
//             await knex('rules_conditions')
//               .insert(
//                 await createRuleConditions(
//                   data[0].attribute_id,
//                   tenant_id,
//                   condition.value,
//                   condition.operator,
//                 ),
//               )
//               .returning('condition_id')
//               .then(async function (c_id) {
//                 const condition_id = c_id[0].condition_id;

//                 await knex('rules_decisions_conditions').insert(
//                   await createRulesDecisionsConditions(
//                     decision_id,
//                     condition_id,
//                     tenant_id,
//                     created_by,
//                   ),
//                 );
//               });
//           });
//       }
//     }
//   }
// };

// const handleSilver = async (
//   knex,
//   defaultRule,
//   parent_decision_id,
//   tenant_id,
//   rule_id,
//   user_id,
//   rule_group
// ) => {
//   if (Array.isArray(defaultRule)) {
//     for (const condition of defaultRule) {
//       if (Object.keys(condition).length !== 0) {
//         for (const key of Object.keys(condition)) {
//           if (Array.isArray(condition[key]) && (key == 'all' || key == 'any')) {
//             await knex('rules_decisions_tree')
//               .insert(
//                 await createDefaultDecisionTree(
//                   '',
//                   rule_id,
//                   tenant_id,
//                   key,
//                   parent_decision_id,
//                 ),
//               )
//               .returning('decision_id')
//               .then(async function (d_id) {
//                 const { decision_id } = d_id[0];

//                 await handleSilver(
//                   knex,
//                   condition[key],
//                   decision_id,
//                   tenant_id,
//                   rule_id,
//                   user_id,
//                   rule_group,
//                 );
//               });
//           } else {
//             await createDecisionConditionRelation(
//               knex,
//               parent_decision_id,
//               [condition],
//               tenant_id,
//               user_id,
//               rule_group
//             );
//             break;
//           }
//         }
//       }
//     }
//   }
// };

// const createRuleTenantRuleDecisionTree = async (
//   knex,
//   defaultRules,
//   rule_slug,
//   rule_group,
//   tenant_id,
//   user_id,
//   rule_version?: number,
// ) => {
//   await knex('rules')
//     .insert(
//       await createDefaultRule(
//         defaultRules,
//         rule_slug,
//         rule_group,
//         tenant_id,
//         user_id,
//       ),
//     )
//     .returning('rule_id')
//     .then(async function (id) {
//       const { rule_id } = id[0],
//         decision_name = rule_group + rule_slug;
//       const decision_type = defaultRules.decisions[0].conditions?.all
//         ? 'all'
//         : 'any';

//       await knex('tenant_rules').insert(
//         await createDefaultTenantRuleMapping(
//           rule_id,
//           rule_slug,
//           rule_group,
//           tenant_id,
//           user_id,
//           rule_version,
//         ),
//       );
//       await knex('rules_decisions_tree')
//         .insert(
//           await createDefaultDecisionTree(
//             decision_name,
//             rule_id,
//             tenant_id,
//             decision_type,
//             null,
//           ),
//         )
//         .returning('decision_id')
//         .then(async function (d_id) {
//           const { decision_id } = d_id[0];

//           await handleSilver(
//             knex,
//             defaultRules.decisions[0].conditions[decision_type],
//             decision_id,
//             tenant_id,
//             rule_id,
//             user_id,
//             rule_group
//           );
//         });
//     });
// };

// exports.up = async function(knex) {

//   const defaultTenantName = process.env.DEFAULT_TENANT;

//   const defaultTenant = await knex('tenants').select('tenant_id').where({
//     tenant_name: defaultTenantName,
//   })

//   const tenant_id = defaultTenant[0]?.tenant_id;

//   if(tenant_id){

//     const userDeatils = await defaultUser(tenant_id);
//     const userData = await knex('users').where(userDeatils[0]);

//     let user_id;

//     if (!userData.length) {
//       user_id = await knex('users')
//         .insert(userDeatils)
//         .returning('user_id')
//         .then((data) => data[0].user_id);
//     } else {
//       user_id = userData[0].user_id;
//     }

//     const tenantDefaultRulesData = await knex('tenant_rules').where({
//       tenant_id: tenant_id,
//       is_active: true,
//       is_default_rule: true,
//       rule_group: 'ONBOARD',
//       rule_slug: 'tier1',
//     });

//     if (tenantDefaultRulesData.length) {
//       for (const value of tenantDefaultRulesData) {
//         const { rule_id, rule_version, rule_slug, rule_group } = value;
//         let default_rule;

//         if (rule_slug === 'tier1' && rule_group === 'ONBOARD') {
//           default_rule = onboard_tier1_default_rule;
//         }

//         if (default_rule) {

//           // make older default rules as in active.
//           await knex('tenant_rules')
//             .update({
//               is_active: false,
//             })
//             .where({ rule_id: rule_id, tenant_id: tenant_id });

//           // eslint-disable-next-line no-unused-expressions
//           await createRuleTenantRuleDecisionTree(
//             knex,
//             default_rule,
//             rule_slug,
//             rule_group,
//             tenant_id,
//             user_id,
//             rule_version + 1,
//           );
//         }
//       }
//     }
//   }
// };

// exports.down = async function(knex) {
//   const defaultTenantName = process.env.DEFAULT_TENANT;

//   const defaultTenant = await knex('tenants').select('tenant_id').where({
//     tenant_name: defaultTenantName,
//   })

//   const tenant_id = defaultTenant[0]?.tenant_id;

//   if(tenant_id){

//     const userDeatils = await defaultUser(tenant_id);
//     const userData = await knex('users').where(userDeatils[0]);

//     let user_id;

//     if (!userData.length) {
//       user_id = await knex('users')
//         .insert(userDeatils)
//         .returning('user_id')
//         .then((data) => data[0].user_id);
//     } else {
//       user_id = userData[0].user_id;
//     }

//     const tenantDefaultRulesData = await knex('tenant_rules').where({
//       tenant_id: tenant_id,
//       is_active: true,
//       is_default_rule: true,
//       rule_group: 'ONBOARD',
//       rule_slug: 'tier1',
//     });

//     const tenantPreviousRuleData = await knex('tenant_rules').where({
//       tenant_id: tenant_id,
//       is_active: false,
//       is_default_rule: true,
//       rule_group: 'ONBOARD',
//       rule_slug: 'tier1',
//     });

//     let rule_version_to_update = 0;

//     if (tenantDefaultRulesData.length) {
//       for (const value of tenantDefaultRulesData) {
//         const { rule_id, rule_version, rule_slug, rule_group } = value;

//         if (rule_slug === 'tier1' && rule_group === 'ONBOARD') {
//           await knex('tenant_rules')
//             .update({
//               is_active: false,
//             })
//             .where({ rule_id: rule_id, tenant_id: tenant_id });
//         }
//         rule_version_to_update = rule_version - 1;
//       }
//     }
//     if (tenantPreviousRuleData.length) {
//       for (const value of tenantDefaultRulesData) {
//         const { rule_id, rule_version, rule_slug, rule_group } = value;

//         if (rule_slug === 'tier1' && rule_group === 'ONBOARD' && rule_version == rule_version_to_update) {
//           await knex('tenant_rules')
//             .update({
//               is_active: true,
//             })
//             .where({ rule_id: rule_id, tenant_id: tenant_id });
//         }
//       }
//     }
//   }
// };

exports.up = async function (knex) {}
exports.down = async function (knex) {}