import { getDefaultTenantId } from '../../utils/encryption';
import { defaultTenant } from '../master/tenant-data';

const customNamespaceRequiredAttribute = {
    attribute_name: 'customNamespaceRequired',
    attribute_type: 'BOOLEAN',
    rule_group: 'ONBOARD',
    attribute_desc: 'Custom Namespace Required: for this check whether Custom Namespace & Custom Namespace Provider or not while doing onboarding',
    display_attribute_name: 'Custom Namespace Required',
    is_required: false
}

const proofOfAddressAttribute = {
    attribute_name: 'proofOfAddress',
    attribute_type: 'BOOLEAN',
    rule_group: 'ONBOARD',
    attribute_desc: 'Custom Namespace Required: for this check whether Custom Namespace & Custom Namespace Provider or not while doing onboarding',
    display_attribute_name: 'Proof of Address',
}

const maritalStatusList = {
  value: ['Married', 'Unmarried', 'Others', 'Unknown']
}

const genderList = {
  value: ['Male', 'Female', 'Others', 'Unknown']
}

const idList = {
  value: ['Drivers License', 'Passport', 'ID Card', 'Proof of Address', 'Others']
}




exports.up = async function(knex) {
  const tenant_id = await getDefaultTenantId(knex);

  if(!tenant_id) {
    throw new Error(`Default Tenant Id not found`);
  }

  await knex.schema.alterTable('attributes', (table) => {
      table.jsonb('attribute_options');
      table.string('options_type');
    });

  await knex('attributes').insert({ ...customNamespaceRequiredAttribute, tenant_id });
  await knex('attributes').insert({ ...proofOfAddressAttribute, tenant_id });

  await knex('attributes').where({ attribute_name: 'maritalStatusList' })
    .update({ attribute_options: maritalStatusList, options_type: 'string' });
  await knex('attributes').where({ attribute_name: 'govIdList' }).orWhere({ attribute_name: 'verifiedByType' })
    .update({ attribute_options: idList, options_type: 'string' });
  await knex('attributes').where({ attribute_name: 'genderList' })
    .update({ attribute_options: genderList, options_type: 'string' });
  await knex('attributes').where({ attribute_name: 'verifiedIdGenderIs' })
    .update({ attribute_options: genderList, options_type: 'string' });

  await knex('attributes').where({ attribute_name: 'govIdList' })
    .update({ derived_attribute: 'proofOfAddress' });

  await knex('attributes').where({ attribute_name: 'verifiedByType' })
    .update({ 
      attribute_name: 'verifiedIdType', 
      display_attribute_name: 'Verified ID Type',
      derived_attribute: 'proofOfAddress'
    });

  await knex('attributes').where({ derived_attribute: 'verifiedByType' })
    .update({ derived_attribute: 'verifiedIdType' });

  await knex('attributes').where({ attribute_name: 'country' })
    .update({ is_required: true });
};

exports.down = async function(knex) {

    await knex.schema.alterTable('attributes', (table) => {
        table.dropColumn('attribute_options');
        table.dropColumn('options_type');
    });

    await knex('attributes').delete().where(customNamespaceRequiredAttribute);
    await knex('attributes').delete().where(proofOfAddressAttribute);

    await knex('attributes').where({ attribute_name: 'govIdList' })
      .update({ derived_attribute: null });
    await knex('attributes').where({ attribute_name: 'verifiedIdType' })
      .update({ 
        attribute_name: 'verifiedByType', 
        display_attribute_name: 'Verified by Type of ID',
        derived_attribute: null
      });

    await knex('attributes').where({ derived_attribute: 'verifiedIdType' })
      .update({ derived_attribute: 'verifiedByType' });
    
    await knex('attributes').where({ attribute_name: 'country' })
    .update({ is_required: false });
};
