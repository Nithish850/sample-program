/* eslint-disable no-console */
import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';
const tableName = 'customer_accounts';
export async function up(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(
      `Altering column types to text for encryption in ${tableName} table...`,
    );
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN plaid_details TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          plaid_details = encrypt(plaid_details::bytea, '${val}'::bytea, 'aes'::text);
    `);
    console.log(`Existing data in ${tableName} table encrypted.`);
    console.log(
      'Inserting entries into encryption_decryption for plaid_details column...',
    );
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'plaid_details' },
    ]);
    console.log(
      'Insert into encryption_decryption for plaid_details column completed.',
    );
  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}
export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Dropping trigger for encrypting ${tableName} ...`);
    await knex.raw(
      `DROP TRIGGER IF EXISTS before_insert_update_${tableName} ON ${tableName};`,
    );
    console.log(`Trigger for encrypting ${tableName} dropped.`);
    console.log(`Dropping trigger function for encrypting ${tableName} ...`);
    await knex.raw(`DROP FUNCTION IF EXISTS encrypt_${tableName};`);
    console.log(`Trigger function for encrypting ${tableName} dropped.`);
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        plaid_details = convert_from(decrypt(plaid_details::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);
    console.log(
      'Removing entries from encryption_decryption for customer accounts column...',
    );
    await knex('encryption_decryption')
      .whereIn('column_name', ['plaid_details'])
      .where({ table_name: tableName })
      .delete();
    console.log(
      'Entries removed from encryption_decryption for customer accounts column.',
    );
  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
