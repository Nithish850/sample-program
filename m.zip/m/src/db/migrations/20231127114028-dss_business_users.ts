exports.up = function (knex) {
  return knex.schema.createTable('dss_business_users', (table) => {
    table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
    table.primary([ 'dss_type_id', 'business_user_id' ]);
    table.text('dss_id').notNullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('dss_business_users')
}