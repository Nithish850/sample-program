exports.up = async function (knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.string('token_symbol').defaultTo('USBC');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.dropColumn('token_symbol');
  });
};
