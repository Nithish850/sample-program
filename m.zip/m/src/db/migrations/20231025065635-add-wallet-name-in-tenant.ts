exports.up = function (knex) {
  return knex.schema.alterTable('tenant_namespace', (table) => {
    table.string('wallet_alias').defaultTo('Disbursement Wallet')
  })
}

exports.down = function (knex) {
  return knex.schema.alterTable('tenant_namespace', (table) => {
    table.dropColumn('wallet_alias');
  })
}