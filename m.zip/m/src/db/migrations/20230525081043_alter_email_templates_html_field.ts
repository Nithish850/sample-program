exports.up = function(knex) {
  return knex.schema.alterTable('email_templates', (table) => {
    table.text('html').notNullable().alter();
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('email_templates', (table) => {
    table.string('html').notNullable().alter();
  });
};