/* eslint-disable no-console */

import { Knex } from 'knex';
import { getSecret } from '../../utils/util.service';

const tableName = 'tenant_pre_screening';

export async function up(knex: Knex): Promise<void> {
  try {
    // Step 1: Alter table columns to text for encryption
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    console.log(`Altering column types to text for encryption in ${tableName} table...`);
    await knex.raw(`
      ALTER TABLE ${tableName}
      ALTER COLUMN email TYPE text,
      ALTER COLUMN phone TYPE text,
      ALTER COLUMN website TYPE text,
      ALTER COLUMN company_registration_number TYPE text,
      ALTER COLUMN company_address TYPE text,
      ALTER COLUMN entity_size TYPE text,
      ALTER COLUMN description_of_business TYPE text,
      ALTER COLUMN location_of_principal_business TYPE text,
      ALTER COLUMN legal_name TYPE text,
      ALTER COLUMN tax TYPE text,
      ALTER COLUMN region_of_formation TYPE text,
      ALTER COLUMN business_countries TYPE text;
    `);
    console.log(`Column types in ${tableName} table altered to text.`);

    // Step 4: Encrypt existing data in the table
    console.log(`Encrypting existing data in ${tableName} table ...`);
    await knex.raw(`
        UPDATE ${tableName}
        SET 
          email = encrypt(email::bytea, '${val}'::bytea, 'aes'::text),
          phone = encrypt(phone::bytea, '${val}'::bytea, 'aes'::text),
          website = encrypt(website::bytea, '${val}'::bytea, 'aes'::text),
          company_registration_number = encrypt(company_registration_number::bytea, '${val}'::bytea, 'aes'::text),
          company_address = encrypt(company_address::bytea, '${val}'::bytea, 'aes'::text),
          entity_size = encrypt(entity_size::bytea, '${val}'::bytea, 'aes'::text),
          description_of_business = encrypt(description_of_business::bytea, '${val}'::bytea, 'aes'::text),
          location_of_principal_business = encrypt(location_of_principal_business::bytea, '${val}'::bytea, 'aes'::text),
          legal_name = encrypt(legal_name::bytea, '${val}'::bytea, 'aes'::text),
          tax = encrypt(tax::bytea, '${val}'::bytea, 'aes'::text),
          region_of_formation = encrypt(region_of_formation::bytea, '${val}'::bytea, 'aes'::text),
          business_countries = encrypt(business_countries::bytea, '${val}'::bytea, 'aes'::text);
    `);

    console.log(`Existing data in ${tableName} table encrypted.`);

    // Step 5: Insert entries into encryption_decryption for recipient_list column
    console.log('Inserting entries into encryption_decryption for recipient_list column...');
    await knex('encryption_decryption').insert([
      { table_name: tableName, column_name: 'email' },
      { table_name: tableName , column_name: 'phone' },
      { table_name: tableName , column_name: 'website' },
      { table_name: tableName , column_name: 'company_registration_number' },
      { table_name: tableName , column_name: 'company_address' },
      { table_name: tableName , column_name: 'entity_size' },
      { table_name: tableName , column_name: 'description_of_business' },
      { table_name: tableName , column_name: 'location_of_principal_business' },
      { table_name: tableName , column_name: 'legal_name' },
      { table_name: tableName , column_name: 'tax' },
      { table_name: tableName , column_name: 'region_of_formation' },
      //   { table_name: tableName , column_name: 'business_entity_id' },
      { table_name: tableName , column_name: 'business_countries' },
    ]);
    console.log('Insert into encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during migration:', error);
    throw error;
  }
}

export async function down(knex: Knex): Promise<void> {
  try {
    const data = await getSecret('PSQLENCRYPTIONKEY');
    let val = data?.value;
    // Step 3: Decrypt existing data in the table
    console.log(`Decrypting existing data in ${tableName} table...`);
    await knex.raw(`
      UPDATE ${tableName}
      SET
        email = convert_from(decrypt(email::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        phone = convert_from(decrypt(phone::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        website = convert_from(decrypt(website::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        company_registration_number = convert_from(decrypt(company_registration_number::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        company_address = convert_from(decrypt(company_address::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        entity_size = convert_from(decrypt(entity_size::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        description_of_business = convert_from(decrypt(description_of_business::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        location_of_principal_business = convert_from(decrypt(location_of_principal_business::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        legal_name = convert_from(decrypt(legal_name::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        tax = convert_from(decrypt(tax::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        region_of_formation = convert_from(decrypt(region_of_formation::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text),
        business_countries = convert_from(decrypt(business_countries::bytea, '${val}'::bytea, 'aes'::text), 'UTF8'::text);
    `);
    console.log(`Existing data in ${tableName} table decrypted.`);

    // Step 4: Delete entries from encryption_decryption for recipient_list column
    console.log('Deleting entries from encryption_decryption for recipient_list column...');
    await knex('encryption_decryption')
      .whereIn('column_name', [
        'email', 'phone', 'website', 'company_registration_number', 'company_address',
        'entity_size', 'description_of_business', 'location_of_principal_business',
        'legal_name', 'tax', 'region_of_formation',  'business_countries'
      ])
      .where({ table_name: tableName })
      .delete();
    console.log('Deletion from encryption_decryption for recipient_list column completed.');

  } catch (error) {
    console.error('Error during rollback:', error);
    throw error;
  }
}
