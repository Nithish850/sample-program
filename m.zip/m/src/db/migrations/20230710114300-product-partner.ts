const newPartners = [
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Debit Card',
    'type_desc': 'Enable Deposit using Debit Card by toggling ON. By toggling OFF Debit Card, only Deposits using Debit Card will be disabled.',
    'partner': 'Authorize.net',
    'partner_desc': 'Payment gateway partner Authorize.net',
    'super_category': 'Tenant Wallet',
    'default_flag': false
  },
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Credit Card',
    'type_desc': 'Enable credit using Credit Card by toggling ON. By toggling OFF Credit Card, only credits using Credit Card will be disabled.',
    'partner': 'Authorize.net',
    'partner_desc': 'Payment gateway partner Authorize.net',
    'super_category': 'Tenant Wallet',
    'default_flag': false
  },
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Debit Card',
    'type_desc': 'Enable Deposit using Debit Card by toggling ON. By toggling OFF Debit Card, only Deposits using Debit Card will be disabled.',
    'partner': 'Authorize.net',
    'partner_desc': 'Payment gateway partner Authorize.net',
    'super_category': 'Customer Wallet',
    'default_flag': false
  },
  {
    'category': 'Offchain Transactions',
    'sub_category': 'Deposits',
    'type': 'Credit Card',
    'type_desc': 'Enable credit using Credit Card by toggling ON. By toggling OFF Credit Card, only credits using Credit Card will be disabled.',
    'partner': 'Authorize.net',
    'partner_desc': 'Payment gateway partner Authorize.net',
    'super_category': 'Customer Wallet',
    'default_flag': false
  }
];

exports.up = async function (knex) {
  await knex.schema.alterTable('products', (table) => {
    table.string('partner');
    table.string('partner_desc');
  }).then(async () => {

    // Tenant wallet super category
    await knex('products').update({
      'partner': 'Checkout.com',
      'partner_desc': 'Payment gateway partner Checkout.com',
      'default_flag': true
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'Debit Card')
      .andWhere('super_category', 'Tenant Wallet');

    await knex('products').update({
      'partner': 'Checkout.com',
      'partner_desc': 'Payment gateway partner Checkout.com',
      'default_flag': true
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'Credit Card')
      .andWhere('super_category', 'Tenant Wallet');

    await knex('products').update({
      'partner': 'Plaid',
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'ACH')
      .andWhere('super_category', 'Tenant Wallet');

    // Customer wallet super category
    await knex('products').update({
      'partner': 'Checkout.com',
      'partner_desc': 'Payment gateway partner Checkout.com',
      'default_flag': true
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'Debit Card')
      .andWhere('super_category', 'Customer Wallet');

    await knex('products').update({
      'partner': 'Checkout.com',
      'partner_desc': 'Payment gateway partner Checkout.com',
      'default_flag': true
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'Credit Card')
      .andWhere('super_category', 'Customer Wallet');

    await knex('products').update({
      'partner': 'Plaid',
    })
      .where('category', 'Offchain Transactions')
      .andWhere('sub_category', 'Deposits')
      .andWhere('type', 'ACH')
      .andWhere('super_category', 'Customer Wallet');

    await knex('products').insert(newPartners);
  });
};

exports.down = async function (knex) {
  return knex.schema.alterTable('products')
    .dropColumn('partner')
    .dropColumn('partner_desc');
}