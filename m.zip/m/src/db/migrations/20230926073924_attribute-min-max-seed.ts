// /* eslint-disable no-await-in-loop */
// /* eslint-disable no-console */
// import { defaultTenant } from "../master/tenant-data";
// const attributeMinMax = [
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayMaxDepositAmountLimit',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'storedValue'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthMaxDepositAmountLimit',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearMaxDepositAmountLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayMaxDepositAmountLimit',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'storedValue'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthMaxDepositAmountLimit',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearMaxDepositAmountLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'DEPOSIT',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearMaxDepositTransactionLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'maxWithdrawalLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayWithdrwalLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthWithdrawalTransactionLimit',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthWithdrawalAmountLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearWithdrawalAmountLimit',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearWithdrawalTransactionLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'maxWithdrawalLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perDayWithdrwalLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthWithdrawalTransactionLimit',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perMonthWithdrawalAmountLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearWithdrawalAmountLimit',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'WITHDRAW',
//     minimum_value: '0',
//     maximum_value: '0',
//     attribute: 'perYearWithdrawalTransactionLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '100',
//     attribute: 'perMonthTransferOutwardLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '10',
//     attribute: 'perDayTransferOutwardLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '10000000000000',
//     attribute: 'senderBalance',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '500',
//     attribute: 'receiverStoredValue'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '1500',
//     attribute: 'maximumTransactionAmountPerMonth',
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '15000',
//     attribute: 'maximumTransactionAmountPerYear'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '500',
//     attribute: 'maxTransferLimit'
//   },
//   {
//     rule_slug: 'tier1',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '1000',
//     attribute: 'maximumTransactionPerYear'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '100',
//     attribute: 'perMonthTransferOutwardLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '10',
//     attribute: 'perDayTransferOutwardLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '10000000000000',
//     attribute: 'senderBalance',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '500',
//     attribute: 'receiverStoredValue'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '1500',
//     attribute: 'maximumTransactionAmountPerMonth',
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '15000',
//     attribute: 'maximumTransactionAmountPerYear'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '500',
//     attribute: 'maxTransferLimit'
//   },
//   {
//     rule_slug: 'tier2',
//     rule_group: 'TRANSFER',
//     minimum_value: '0',
//     maximum_value: '1000',
//     attribute: 'maximumTransactionPerYear'
//   },
// ];

// const getDefaultTenantId = async (knex) =>{
//   const defaultTenantData = await knex('tenants').select('tenant_id').where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain })

//   return defaultTenantData[0]?.tenant_id;
// }

// const getAttributeId = async (knex, attribute_name) =>{
//   const attribute_data = await knex('attributes').select('attribute_id').where({ attribute_name, tenant_id: await getDefaultTenantId(knex) })

//   return attribute_data[0]?.attribute_id
// }

// exports.up = async function(knex) {
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'DEPOSIT', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'WITHDRAW', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'TRANSFER', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'DEPOSIT', rule_slug: 'tier2' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'WITHDRAW', rule_slug: 'tier2' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'TRANSFER', rule_slug: 'tier2' });

//   for(const attributeMin of attributeMinMax) {
//     const attribute_id = await getAttributeId(knex, attributeMin.attribute);

//     await knex('attributes_min_max_val').insert({
//       rule_slug: attributeMin.rule_slug,
//       rule_group: attributeMin.rule_group,
//       minimum_value: attributeMin.minimum_value,
//       maximum_value: attributeMin.maximum_value,
//       attribute_id
//     })
//   }
// };

// exports.down = async function(knex) {
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'DEPOSIT', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'WITHDRAW', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'TRANSFER', rule_slug: 'tier1' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'DEPOSIT', rule_slug: 'tier2' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'WITHDRAW', rule_slug: 'tier2' });
//   await knex('attributes_min_max_val').delete().where({ rule_group: 'TRANSFER', rule_slug: 'tier2' });
// };

exports.up = async function (knex) {}
exports.down = async function (knex) {}