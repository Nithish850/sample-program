exports.up = async function (knex) {
  // await knex.schema
  //   .alterTable('badge_token', function (table) {
  //     table.uuid('custom_financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE').default(null)
  //   })
  //   .alterTable('badge', function (table) {
  //     table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
  //     table.enu('owner_type', [ 'DEFAULT', 'CUSTOM' ]).defaultTo('DEFAULT').notNullable();
  //   })
};
exports.down = async function (knex) {
  await knex.schema.alterTable('badge_token', (table) => {
    table.dropColumn('custom_financial_badge_id');
  })
  await knex.schema.alterTable('badge', (table) => {
    table.dropColumn('tenant_id');
    table.dropColumn('owner_type');
  })
};