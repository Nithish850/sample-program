exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.string('legal_name').notNullable();
    table.string('initiated_by');
    table.string('compliance_users')
  });
}

exports.down = async function (knex) {
  await knex.schema.dropTable('tenant_pre_screening');
}