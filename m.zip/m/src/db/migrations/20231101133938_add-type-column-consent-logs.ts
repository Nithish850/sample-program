exports.up = async function(knex) {
  await knex.schema.alterTable('consent_logs', (table) => {
    table.string('type');
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('consent_logs', (table) => {
    table.dropColumn('type');
  });
};
