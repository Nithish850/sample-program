exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.dropColumn('risk_level');
  })
};

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_customer_accounts', (table) => {
    table.dropColumn('risk_level');
  })
};
