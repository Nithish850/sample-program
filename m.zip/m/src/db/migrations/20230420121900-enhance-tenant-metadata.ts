exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_metadata', (table) => {
    table.string('business_entity_name');
  });

  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.dropColumn('attestation_question');
    table.dropColumn('sanctioned_country_attestation');
    table.jsonb('business_countries');
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('tenant_metadata', (table) => {
    table.dropColumn('business_entity_name');
  });

  await knex.schema.alterTable('tenant_pre_screening', (table) => {
    table.dropColumn('attestation_question');
    table.dropColumn('sanctioned_country_attestation');
    table.jsonb('business_countries');
  });
}