exports.up = async function(knex) {
  const namespaceData = await knex.raw(`
    SELECT n.namespace_id, n.namespace FROM namespaces n
    LEFT JOIN wallet_user_namespace_mapper AS cn ON cn.namespace_id = n.namespace_id
    WHERE is_global = false AND is_deleted = false
    AND custom_namespace IS NULL
  `);

  if(namespaceData && namespaceData.rows && namespaceData.rows.length) {
    namespaceData.rows.map(async (data) => {
      await knex('wallet_user_namespace_mapper').insert({
        custom_namespace: data.namespace.replace(/\./g, '_'),
        namespace_id: data.namespace_id
      });
    })
  }
}

exports.down = async function(knex) {
  await knex('wallet_user_namespace_mapper').delete().where('custom_namespace', 'like', '%_ul');
};
