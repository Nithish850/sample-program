exports.up = async function (knex) {
  await knex.schema.alterTable('code_master', (table) => {
    table.text('template').nullable();
  });
};

exports.down = async function (knex) {
  return await knex.schema.alterTable('code_master', (table) => {
    table.dropColumn('template');
  });
};
