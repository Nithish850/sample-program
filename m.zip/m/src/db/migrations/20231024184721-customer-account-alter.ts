exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.jsonb('metro_location_details');
    table.jsonb('additional_lat_long');
    table.jsonb('additional_address');
    table.jsonb('geo_location_details');
    table.jsonb('metro_area_details');
    table.jsonb('country_details');
  });
};

exports.down = async function (knex) {
  return knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('metro_location_details');
    table.dropColumn('additional_lat_long');
    table.dropColumn('additional_address');
    table.dropColumn('geo_location_details');
    table.dropColumn('metro_area_details');
    table.dropColumn('country_details');
  })
};
