exports.up = function (knex) {
  return knex.schema.createTable('sanction_reports', (table) => {
    table.uuid('sanction_report_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.boolean('is_tenant').notNullable();
    table.string('nationality').notNullable();
    table.string('residence_of_jurisdiction').notNullable();
    table.string('country_of_registration').notNullable();
    table.string('tax_country').notNullable();
    table.string('principal_country_of_business').notNullable();
    table.string('name');
    table.string('address');
    table.string('email');
    table.string('phone');
    table.string('dob');
    table.string('place_of_birth');
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
    table.timestamps(true, true)
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('sanction_reports');
}