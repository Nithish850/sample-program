// /* eslint-disable no-console */
// /* eslint-disable prefer-destructuring */
// /* eslint-disable no-await-in-loop */
// import { onboardAttributes } from '../master/default-attributes';
// import { deposit_tier3_default_rule, onboard_tier3_default_rule, transfer_tier3_default_rule, withdraw_tier3_default_rule } from '../master/silver-plus-rules';
// import {
//   createDefaultAttributes,
//   createDefaultDecisionTree,
//   createDefaultRule,
//   createDefaultTenantRuleMapping,
//   createRuleConditions,
//   createRulesDecisionsConditions,
//   defaultUser,
// } from '../master/tenant-data';

// const createDecisionConditionRelation = async (
//   knex,
//   decision_id,
//   conditionList,
//   tenant_id,
//   created_by,
//   rule_group
// ): Promise<any> => {
//   for (const condition of conditionList) {
//     const attribute = onboardAttributes.filter(
//       (attribute) => attribute.attribute_name === condition.fact && attribute.rule_group === rule_group,
//     )[0];

//     if (attribute) {
//       const isAttributePresent = await knex('attributes')
//         .select()
//         .where({ attribute_name: condition.fact, tenant_id: tenant_id, rule_group: rule_group });

//       if (isAttributePresent && isAttributePresent.length > 0) {
//         await knex('rules_conditions')
//           .insert(
//             await createRuleConditions(
//               isAttributePresent[0].attribute_id,
//               tenant_id,
//               condition.value,
//               condition.operator,
//             ),
//           )
//           .returning('condition_id')
//           .then(async function (c_id) {
//             const condition_id = c_id[0].condition_id;

//             await knex('rules_decisions_conditions').insert(
//               await createRulesDecisionsConditions(
//                 decision_id,
//                 condition_id,
//                 tenant_id,
//                 created_by,
//               ),
//             );
//           });
//       } else {
//         await knex('attributes')
//           .insert(await createDefaultAttributes(tenant_id, attribute))
//           .returning(['attribute_id', 'attribute_name', 'rule_group'])
//           .then(async function (data) {
//             await knex('rules_conditions')
//               .insert(
//                 await createRuleConditions(
//                   data[0].attribute_id,
//                   tenant_id,
//                   condition.value,
//                   condition.operator,
//                 ),
//               )
//               .returning('condition_id')
//               .then(async function (c_id) {
//                 const condition_id = c_id[0].condition_id;

//                 await knex('rules_decisions_conditions').insert(
//                   await createRulesDecisionsConditions(
//                     decision_id,
//                     condition_id,
//                     tenant_id,
//                     created_by,
//                   ),
//                 );
//               });
//           });
//       }
//     }
//   }
// };

// const handleSilver = async (
//   knex,
//   defaultRule,
//   parent_decision_id,
//   tenant_id,
//   rule_id,
//   user_id,
//   rule_group
// ) => {
//   if (Array.isArray(defaultRule)) {
//     for (const condition of defaultRule) {
//       if (Object.keys(condition).length !== 0) {
//         for (const key of Object.keys(condition)) {
//           if (Array.isArray(condition[key]) && (key == 'all' || key == 'any')) {
//             await knex('rules_decisions_tree')
//               .insert(
//                 await createDefaultDecisionTree(
//                   '',
//                   rule_id,
//                   tenant_id,
//                   key,
//                   parent_decision_id,
//                 ),
//               )
//               .returning('decision_id')
//               .then(async function (d_id) {
//                 const { decision_id } = d_id[0];

//                 await handleSilver(
//                   knex,
//                   condition[key],
//                   decision_id,
//                   tenant_id,
//                   rule_id,
//                   user_id,
//                   rule_group,
//                 );
//               });
//           } else {
//             await createDecisionConditionRelation(
//               knex,
//               parent_decision_id,
//               [condition],
//               tenant_id,
//               user_id,
//               rule_group
//             );
//             break;
//           }
//         }
//       }
//     }
//   }
// };

// const createRuleTenantRuleDecisionTree = async (
//   knex,
//   defaultRules,
//   rule_slug,
//   rule_group,
//   tenant_id,
//   user_id,
//   rule_version?: number,
// ) => {
//   await knex('rules')
//     .insert(
//       await createDefaultRule(
//         defaultRules,
//         rule_slug,
//         rule_group,
//         tenant_id,
//         user_id,
//       ),
//     )
//     .returning('rule_id')
//     .then(async function (id) {
//       const { rule_id } = id[0],
//         decision_name = rule_group + rule_slug;
//       const decision_type = defaultRules.decisions[0].conditions?.all
//         ? 'all'
//         : 'any';

//       await knex('tenant_rules').insert(
//         await createDefaultTenantRuleMapping(
//           rule_id,
//           rule_slug,
//           rule_group,
//           tenant_id,
//           user_id,
//           rule_version,
//         ),
//       );
//       await knex('rules_decisions_tree')
//         .insert(
//           await createDefaultDecisionTree(
//             decision_name,
//             rule_id,
//             tenant_id,
//             decision_type,
//             null,
//           ),
//         )
//         .returning('decision_id')
//         .then(async function (d_id) {
//           const { decision_id } = d_id[0];

//           await handleSilver(
//             knex,
//             defaultRules.decisions[0].conditions[decision_type],
//             decision_id,
//             tenant_id,
//             rule_id,
//             user_id,
//             rule_group
//           );
//         });
//     });
// };

// exports.up = async function(knex) {

//   const defaultTenantName = process.env.DEFAULT_TENANT;

//   const defaultTenant = await knex('tenants').select('tenant_id').where({
//     tenant_name: defaultTenantName,
//   })

//   const tenant_id = defaultTenant[0]?.tenant_id, rule_version = 0;

//   if(tenant_id){

//     const userDeatils = await defaultUser(tenant_id);
//     const userData = await knex('users').where(userDeatils[0]);

//     let user_id;

//     if (!userData.length) {
//       user_id = await knex('users')
//         .insert(userDeatils)
//         .returning('user_id')
//         .then((data) => data[0].user_id);
//     } else {
//       user_id = userData[0].user_id;
//     }

//     const accountCategoryId = 'tier3';

//     await knex('account_category').insert({
//       subcategory_name: 'silver-plus',
//       created_by: user_id,
//       account_category_id: accountCategoryId,
//     });
//     // eslint-disable-next-line no-unused-expressions
//     await createRuleTenantRuleDecisionTree(
//       knex,
//       onboard_tier3_default_rule,
//       accountCategoryId,
//       'ONBOARD',
//       tenant_id,
//       user_id,
//       rule_version,
//     );
//     await createRuleTenantRuleDecisionTree(
//       knex,
//       transfer_tier3_default_rule,
//       accountCategoryId,
//       'TRANSFER',
//       tenant_id,
//       user_id,
//       rule_version,
//     );
//     await createRuleTenantRuleDecisionTree(
//       knex,
//       deposit_tier3_default_rule,
//       accountCategoryId,
//       'DEPOSIT',
//       tenant_id,
//       user_id,
//       rule_version,
//     );
//     await createRuleTenantRuleDecisionTree(
//       knex,
//       withdraw_tier3_default_rule,
//       accountCategoryId,
//       'WITHDRAW',
//       tenant_id,
//       user_id,
//       rule_version,
//     );
//   }
// };

// exports.down = async function(knex) {
//   await knex('tenant_rules')
//     .update({
//       is_active: false,
//     })
//     .where({ is_default_rule: true, is_active: true, rule_slug: 'tier3' });
// };

exports.up = async function (knex) {}
exports.down = async function (knex) {}