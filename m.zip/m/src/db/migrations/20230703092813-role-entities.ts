// /* eslint-disable no-await-in-loop */
// import { defaultRoles } from "../master/roles";
// import { getRoleAndEntityFlags } from "../master/role-entities";

// exports.up = async function (knex) {
//   const tenantData = await knex('tenants').select('tenant_id').where({ domain: 'ul-ledger' });
//   const userData = await knex('users').select('user_id').where({ user_name: 'ul-default' });
//   const entityData = await knex('entities').select('*').where({ role_assigned: 'BOTH' });

//   await knex('roles').insert(await defaultRoles(tenantData[0].tenant_id, userData[0].user_id)).returning('*').then(async function (roleData) {
//     const roleEntities: any = [];

//     for (const role of roleData) {
//       for (const entity of entityData) {
//         const flag = await getRoleAndEntityFlags(role.role_name, entity.entity_name);
//         const roleEntity = {
//           entity_id: entity.entity_id,
//           role_id: role.role_id,
//           tenant_id: tenantData[0].tenant_id,
//           ...flag.flag
//         };

//         roleEntities.push(roleEntity);
//       }
//     }
//     await knex('role_entities').insert(roleEntities);
//   });
// };

// exports.down = async function (knex) {
//   const tenantData = await knex('tenants').select('tenant_id').where({ domain: 'ul-ledger' });
//   const userData = await knex('users').select('user_id').where({ user_name: 'ul-default' });
//   const roles = await defaultRoles(tenantData[0].tenant_id, userData[0].user_id);

//   const roleNames = await roles.map((item) => item.role_name);

//   const roleIds = await knex('roles').find().whereIn({ role_name: roleNames }).select('role_id');

//   await knex('roles').delete().whereIn({ role_id: roleIds });
//   await knex('role_entities').delete().whereIn({ role_id: roleIds });

// }
exports.up = async function (knex) {}
exports.down = async function (knex) {}