exports.up = function (knex) {
  return knex.schema.alterTable('tenant_event_subscription', function (table) {
    table.string('secret_header')
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('tenant_event_subscription', function (table) {
    table.dropColumn('secret_header')
  });
};