exports.up = async function (knex) {
    const hasColumn = await knex.schema.hasColumn('badge', 'can_be_linked_to_financial_badge');
    if (!hasColumn) {
        await knex.schema.alterTable('badge', (table) => {
            table.boolean('can_be_linked_to_financial_badge').defaultTo(false);
        });
    }
};

exports.down = async function (knex) {
    const hasColumn = await knex.schema.hasColumn('badge', 'can_be_linked_to_financial_badge');
    if (hasColumn) {
        await knex.schema.alterTable('badge', (table) => {
            table.dropColumn('can_be_linked_to_financial_badge');
        });
    }
};