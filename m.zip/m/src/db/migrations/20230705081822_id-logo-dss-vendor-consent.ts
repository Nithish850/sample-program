exports.up = async function(knex) {
  await knex.schema.alterTable('dss_vendor_consent', (table) => {
    table.string('consent_id').notNullable();
    table.jsonb('logo');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('dss_vendor_consent', (table) => {
    table.dropColumn('consent_id');
    table.dropColumn('logo');
  });
};
