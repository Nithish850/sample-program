/** Adding new fields to tenant_rule and tenant_namespace table */
exports.up = async function (knex) {

  const tenantData = await knex('tenant_rules').select('*');

  await knex.schema.alterTable('tenant_rules', (table) => {
    table.dropColumn('rule_slug');
  });

  await knex.schema.alterTable('tenant_rules', (table) => {
    table.enu('rule_slug', [ 'tier0', 'tier1', 'tier2', 'tier3', 'tier4' ]);
  })
    .alterTable('tenant_namespace', (table) => {
      table.enu('category', [ 'tier0', 'tier1', 'tier2', 'tier3', 'tier4' ]).defaultTo('tier0');
      table.string('category_name').defaultTo('Tenant');
    });

  // rewriting the previous values
  if(tenantData.length > 0) {
    for(const { rule_id, tenant_id, is_active, rule_group, rule_slug, rule_version, is_default_rule } of tenantData) {
      /* eslint-disable no-await-in-loop */
      await knex('tenant_rules').select('*').where({
        rule_id,
        tenant_id,
        is_active,
        rule_group,
        rule_version,
        is_default_rule,
      })
        .update({
          rule_slug: rule_slug
        })
    }
  }
};

exports.down = async function (knex) {
  await knex.schema
    .dropTable('tenant_rules')
    .dropTable('tenant_namespace')
};
