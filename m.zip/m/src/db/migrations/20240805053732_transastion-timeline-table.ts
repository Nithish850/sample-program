exports.up = function (knex) {
    return knex.schema.createTable('transaction_timeline', (table) => {
        table.uuid('transaction_timeline_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
        table.uuid('transaction_id').notNullable();
        table.string('transaction_hash');
        table.string('status');
        table.uuid('tenant_id').notNullable();
        table.string('type');
        table.timestamps(true, true);
    });
};

exports.down = function (knex) {
    return knex.schema.dropTable('transaction_timeline');
};