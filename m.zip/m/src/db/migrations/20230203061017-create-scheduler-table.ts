exports.up = function (knex) {
  return knex.schema.createTable('webhook_scheduler', (table) => {
    table.uuid('webhook_scheduler_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_event_subscription_id').references('tenant_event_subscription_id').inTable('tenant_event_subscription').onDelete('CASCADE').onUpdate('CASCADE');
    table.json('payload');
    table.string('retry_count');
    table.boolean('is_email_sent').notNullable().defaultTo(false);
    table.boolean('is_processed').notNullable().defaultTo(false);
    table.string('status');
    table.timestamps(true, true);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTable('webhook_scheduler');
};
