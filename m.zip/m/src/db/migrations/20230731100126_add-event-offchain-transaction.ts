// exports.up = async function(knex) {
//   await knex('dss_event').insert({ event: 'OFFCHAIN TRANSACTION' })
//   const [ event ] = await knex('dss_event').select('dss_event_id').where('event', 'OFFCHAIN TRANSACTION');
//   const tenants = await knex('tenants').select('tenant_id').whereNot('tenant_name', 'universal ledger');
//   const eventForAllTenants = [];

//   for (const tenantId of tenants) {
//     eventForAllTenants.push({
//       dss_event_id: event.dss_event_id,
//       endpoint: '',
//       is_active: false,
//       tenant_id: tenantId.tenant_id
//     });
//   }

//   await knex('tenant_event_subscription').insert(eventForAllTenants);
// };

// exports.down = async function(knex) {
//   await knex('dss_event').where('event', 'OFFCHAIN TRANSACTION').deleted();
// };
exports.up = async function (knex) {}
exports.down = async function (knex) {}