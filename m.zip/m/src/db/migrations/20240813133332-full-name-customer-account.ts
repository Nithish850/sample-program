exports.up = async function (knex) {
    await knex.schema.alterTable('customer_accounts', (table) => {
        table.string('full_name');
    });
};

exports.down = function (knex) {
    return knex.schema.alterTable('customer_accounts', (table) => {
        table.dropColumn('full_name');
    });
};
