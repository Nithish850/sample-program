exports.up = async function (knex) {
  return await knex.schema.alterTable('badge', (table) => {
    table.dropColumn('display_badge_name');
  });
};

exports.down = async function (knex) {
  return await knex.schema.alterTable('badge', (table) => {
    table.string('display_badge_name');
  });
};
