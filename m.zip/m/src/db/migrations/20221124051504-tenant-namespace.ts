exports.up = function (knex) {
  return knex.schema
    .createTable('tenant_namespace', (table) => {
      table.uuid('tenant_namespace_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('tenant_namespace').notNullable().unique();
      table.string('account_address').notNullable().unique();
    })
};

exports.down = function (knex) {
  return knex.schema
    .dropTable('tenant_namespace')
};
