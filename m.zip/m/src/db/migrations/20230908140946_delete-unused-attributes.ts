// /* eslint-disable no-await-in-loop */
// /* eslint-disable no-console */
// import { defaultTenant } from "../master/tenant-data";
// const attributes = [
//   {
//     "attribute_name": "isBronzeReceiver",
//     "attribute_type": "BOOLEAN",
//     "rule_group": "TRANSFER",
//   },
//   {
//     "attribute_name": "isSilverReceiver",
//     "attribute_type": "BOOLEAN",
//     "rule_group": "TRANSFER",
//   },
//   {
//     "attribute_name": "maxDepositTrxAmountPerMonth",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxDepositTrxAmountPerYear",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxWithdrawalTrxAmountPerMonth",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxWithdrawalTrxAmountPerYear",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "dailyDepositTrxAmountLimit",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "dailyWithdrawalTrxAmountLimit",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxDepositTrxCountDaily",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxDepositTrxCountMonthly",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxWithdrawalTrxCountDaily",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "maxWithdrawalTrxCountMonthly",
//     "attribute_type": "NUMBER",
//     "rule_group": "TRANSFER"
//   },
//   {
//     "attribute_name": "monthlyStoreLimit",
//     "attribute_type": "NUMBER",
//     "rule_group": "DEPOSIT"
//   },
//   {
//     "attribute_name": "minWalletBalance",
//     "attribute_type": "NUMBER",
//     "rule_group": "WITHDRAW"
//   },
// ];

// const getDefaultTenantId = async (knex) =>{
//   const defaultTenantData = await knex('tenants').select('tenant_id').where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain })

//   return defaultTenantData[0]?.tenant_id;
// }

// exports.up = async function(knex) {

//   const tenant_id = await getDefaultTenantId(knex);

//   for(const attribute of attributes) {
//     await knex('attributes').delete().where({
//       attribute_name: attribute.attribute_name,
//       attribute_type: attribute.attribute_type,
//       rule_group: attribute.rule_group,
//       tenant_id,
//     })
//   }
// };

// exports.down = async function(knex) {
//   const tenant_id = await getDefaultTenantId(knex);

//   for(const attribute of attributes) {
//     await knex('attributes').insert({
//       attribute_name: attribute.attribute_name,
//       attribute_type: attribute.attribute_type,
//       rule_group: attribute.rule_group,
//       tenant_id
//     });
//   }
// };

exports.up = async function (knex) {}
exports.down = async function (knex) {}
