const cloud_provider = [
  {
    "provider_name": "azure",
    "provider_service": "blob",
  },
];

exports.up = async function (knex) {
  await knex.schema.createTable('badge_rules', (table) => {
    table.uuid('rule_id').references('rule_id').inTable('rules').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.boolean('is_active').notNullable().defaultTo(true);
    table.date('start_date').notNullable();
    table.date('end_date').notNullable();
    table.string('rule_group').checkIn([ 'ONBOARD', 'DEPOSIT', 'TRANSFER', 'WITHDRAW' ]).notNullable();
    table.integer('rule_version').notNullable().defaultTo(1);
    table.boolean('is_default_rule').notNullable().defaultTo(false);
    table.uuid('created_by').references('user_id').inTable('users').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('status').checkIn([ 'pending', 'approved', 'rejected' ]).notNullable().defaultTo('pending');
    table.date('inactive_date');
    table.primary(['rule_id', 'badge_id']);
    table.timestamps(true, true);
  })
    .createTable('identification_financial_badge', (table) => {
      table.uuid('identification_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary(['identification_badge_id', 'financial_badge_id']);
      table.timestamps(true, true);
    })
    .createTable('financial_badge_token', (table) => {
      table.uuid('financial_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.string('token_symbol').references('symbol').inTable('contract_store').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary(['financial_badge_id', 'token_symbol']);
      table.timestamps(true, true);
    })
    .createTable('information_badge_customer_account', (table) => {
      table.uuid('information_badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
      table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
      table.primary(['information_badge_id', 'customer_account_id']);
      table.timestamps(true, true);
    })
    .createTable('cloud_provider', (table) => {
      table.uuid('provider_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
      table.string('provider_name').notNullable();
      table.string('provider_service').notNullable();
    })
    .alterTable('badge', (table) => {
      table.uuid('storage_provider').references('provider_id').inTable('cloud_provider').onDelete('CASCADE').onUpdate('CASCADE');
    });
  await knex('cloud_provider').insert(cloud_provider);
};
exports.down = async function (knex) {
  await knex.schema
    .dropTable('badge_rules')
    .dropTable('identification_financial_badge')
    .dropTable('financial_badge_token')
    .dropTable('cloud_provider')
    .dropTable('badge');
};
