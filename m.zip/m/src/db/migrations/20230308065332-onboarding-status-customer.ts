exports.up = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.string('onboarding_status').default('PENDING');
  });
};

exports.down = async function (knex) {
  await knex.schema.dropTable('customer_accounts');
};
