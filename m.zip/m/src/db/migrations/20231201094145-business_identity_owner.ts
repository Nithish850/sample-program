exports.up = function (knex) {
  return knex.schema.createTable('business_identity_owner', (table) => {
    table.uuid('business_identity_owner_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.uuid('business_user_id').references('business_user_id').inTable('business_users').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('dss_type_id').references('dss_type_id').inTable('dss').onDelete('CASCADE').onUpdate('CASCADE');
    table.uuid('business_owner_dss_id').notNullable();
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('email').notNullable();
    table.string('phone_number');
    table.string('dob');
    table.jsonb('address');
    table.jsonb('tax');
    table.string('gender');
    table.jsonb('documents');
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('business_identity_owner')
}