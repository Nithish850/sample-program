import { Knex } from 'knex';
import { getDefaultTenantId } from '../../utils/encryption';

const denialReasonAttribute = [
  {
    attribute_name: 'denialReason',
    attribute_type: 'STRING',
    rule_group: 'RISK',
    attribute_desc: 'Compliance Denial Reason',
    is_required: false,
    display_attribute_name: 'Denial Reason',
    attribute_options: {
      value: [
        'i02 - prohibited country based on input address',
        'i03 - prohibited country based on lat/lon',
        'i04 - prohibited country based on ip address',
        'i05 - prohibited country based on phone number',
        'i01 - Customer age',
        'i07 - Quantifind - high risk and high confidence factor found',
        'i08 - Quantifind - Sanction screening',
        'i10 - low phone trustscore',
        'i11 - Line type - landline',
        'i12 - Line type - fixed VoIP',
        'i15 - sim tenure less than 24 hours',
        'i13 - Line type - non fixed VoIP',
        'i14 - low country location confidence',
        'b01 - Missing plaid identity data',
        'b02 - Missing plaid balance data',
        'b03 - Missing Plaid token',
        'l01 - lexis nexis emailage fraud flagged',
        'l02 - lexis nexis emailage non existant email',
        'l03 - high email frauscore',
        'l04 - customer flagged as deceased',
        'l05 - no id content supplied',
        'l06 - Error in payload response from lexis nexis instant id api',
        'l07 - Invalid email address',
        'i16 - null address field',
        'i17 - null ip address',
        'i18 - null phone number',
        'i19 - invalid plaid token for identity',
        'i20 - invalid plaid token for balance',
        'l08 - missing selfie content',
        'i21 - Invalid plaid public token',
        'i22 - Address not found with geolocator API',
      ],
    },
    options_type: 'string',
  },
];

export async function up(knex: Knex): Promise<void> {
  console.log('migration running: 056-seed-denial-reason-attribute.ts');
  const tenant_id = await getDefaultTenantId(knex);

  if (tenant_id) {
    denialReasonAttribute.forEach((attribute) => {
      attribute['tenant_id'] = tenant_id;
    });

    await knex('attributes').insert(denialReasonAttribute);
  }
  console.log('migration completed: 056-seed-denial-reason-attribute.ts');
}

export async function down(knex: Knex): Promise<void> {
  console.log('rollback running: 056-seed-denial-reason-attribute.ts');
  const tenant_id = await getDefaultTenantId(knex);
  const attributeName = 'denialReason';

  if (tenant_id) {
    await knex('attributes')
      .where({
        attribute_name: attributeName,
        tenant_id,
      })
      .del();
  }
  console.log('rollback completed: 056-seed-denial-reason-attribute.ts');
}
