exports.up = async function(knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('auth_code');
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('card_transaction', (table) => {
    table.dropColumn('auth_code');
  });
};
