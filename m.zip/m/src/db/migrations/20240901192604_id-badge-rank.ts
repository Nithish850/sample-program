exports.up = async function (knex) {
  await knex.schema.alterTable('badge', (table) => {
    table.integer('rank');
    table.boolean('is_risk_compliance').defaultTo(0);
  });
};

exports.down = function (knex) {
  return knex.schema.alterTable('badge', (table) => {
    table.dropColumn('rank');
    table.dropColumn('is_risk_compliance').defaultTo(0);
  });
};
