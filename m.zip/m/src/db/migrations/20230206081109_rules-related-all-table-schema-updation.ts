/** function to make changes in schema w.r.t rules and droping rule_attributes table from DB */
exports.up = async function (knex) {
  await knex.schema
    .dropTable('rules_attributes')
    .alterTable('rules', (table) => {
      table.boolean('is_default_rule').notNullable().defaultTo(false);
    })
    .alterTable('attributes', (table) => {
      table.boolean('is_default_rule').notNullable().defaultTo(false);
    })
    .alterTable('rules_conditions', (table) => {
      table.boolean('is_default_rule').notNullable().defaultTo(false);
    })
    .alterTable('rules_decisions_tree', (table) => {
      table.boolean('is_default_rule').notNullable().defaultTo(false);
    })
    .alterTable('rules_decisions_conditions', (table) => {
      table.boolean('is_default_rule').notNullable().defaultTo(false);
    })
    // .alterTable('transaction', (table) => {
    //   table.dropColumn('rule_id_array');
    // })
    .alterTable('transaction', (table) => {
      table.specificType('rule_id_array', 'uuid ARRAY');
    });
};

exports.down = async function (knex) {
  await knex.schema
    .dropTable('rules')
    .dropTable('tenant_rules')
    .dropTable('attributes')
    .dropTable('rules_conditions')
    .dropTable('rules_decisions_tree')
    .dropTable('rules_decisions_conditions')
    .dropTable('transaction');
};
