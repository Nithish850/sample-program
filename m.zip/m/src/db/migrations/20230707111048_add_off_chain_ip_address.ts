exports.up = function(knex) {
  return knex.schema.alterTable('offchain_transaction', function(table) {
    table.string('ip_address');
  });
};

exports.down = function(knex) {
  return knex.schema.alterTable('offchain_transaction', function(table) {
    table.dropColumn('ip_address');
  });
};