exports.up = async function (knex) {
  await knex.schema.alterTable('code_master', (table) => {
    table.string('attribute')
  });
};

exports.down = async function (knex) {
  return await knex.schema.alterTable('code_master', (table) => {
    table.dropColumn('attribute');

  });
};
