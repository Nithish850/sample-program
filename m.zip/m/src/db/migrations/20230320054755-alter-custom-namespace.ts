exports.up = async function (knex) {
  await knex.schema.alterTable('wallet_user_namespace_mapper', (table) => {
    table.string('provider', 50);
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('wallet_user_namespace_mapper', (table) => {
    table.dropColumn('provider');
  });
};
