/* eslint-disable no-await-in-loop */
/* eslint-disable no-console */
import { defaultTenant } from "../master/tenant-data";
const attributes = [
  {
    "attribute_name": "gidNumber",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Number",
    "display_attribute_name": "GID Number",
  },
  {
    "attribute_name": "gidCountry",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Country",
    "display_attribute_name": "GID Country",
  },
  {
    "attribute_name": "gidState",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document State/Province",
    "display_attribute_name": "GID State/Province",
  },
  {
    "attribute_name": "gidIssueDate",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Issue Date",
    "display_attribute_name": "GID Issue Date",
  },
  {
    "attribute_name": "gidExpirationDate",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Expiration Date",
    "display_attribute_name": "GID Expiration Date",
  },
  {
    "attribute_name": "gidAddress",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Address",
    "display_attribute_name": "GID Address",
  },
  {
    "attribute_name": "gidGender",
    "attribute_type": "BOOLEAN",
    "rule_group": "ONBOARD",
    "attribute_desc": "Government Issued Document Gender",
    "display_attribute_name": "GID Gender",
  },
];

const getDefaultTenantId = async (knex) =>{
  const defaultTenantData = await knex('tenants').select('tenant_id').where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain })

  return defaultTenantData[0]?.tenant_id;
}

exports.up = async function(knex) {

  const tenant_id = await getDefaultTenantId(knex);

  for(const attribute of attributes) {
    await knex('attributes').insert({
      attribute_name: attribute.attribute_name,
      attribute_type: attribute.attribute_type,
      rule_group: attribute.rule_group,
      tenant_id,
      attribute_desc: attribute.attribute_desc,
      display_attribute_name: attribute.display_attribute_name,
    })
  }
};

exports.down = async function(knex) {
  for(const attribute of attributes) {
    await knex('attributes').delete().where({
      attribute_name: attribute.attribute_name,
      attribute_type: attribute.attribute_type,
      rule_group: attribute.rule_group,
      attribute_desc: attribute.attribute_desc,
      display_attribute_name: attribute.display_attribute_name,
    });
  }
};
