import { getSecret } from '../../utils/util.service';
exports.up = async function (knex) {
  const data = await getSecret('PSQLENCRYPTIONKEY');
  let val = data?.value;
  const encryptionKey = val;

  return knex.transaction(trx => {
      return trx.raw(`
    UPDATE customer_accounts
    SET full_name = CONCAT(
      COALESCE(safe_decrypt(first_name::bytea, ?, 'SQL_ASCII')::text, ''), 
      ' ', 
      COALESCE(safe_decrypt(middle_name::bytea, ?, 'SQL_ASCII')::text, ''), 
      ' ', 
      COALESCE(safe_decrypt(last_name::bytea, ?, 'SQL_ASCII')::text, '')
    );
  `, [encryptionKey, encryptionKey, encryptionKey])
      .then(() => {
          return trx.raw(`
      UPDATE customer_accounts
      SET full_name = REGEXP_REPLACE(full_name, '  +', ' ', 'g');
    `);
      });
  });
};

exports.down = function (knex) {
    return knex.raw(`
    UPDATE customer_accounts
    SET full_name = NULL;
  `);
};