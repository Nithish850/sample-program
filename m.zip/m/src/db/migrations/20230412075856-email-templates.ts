
exports.up = function(knex) {
  return knex.schema.createTable('email_templates', (table) => {
    table.uuid('email_template_id').primary().defaultTo(knex.raw('gen_random_uuid()')).notNullable();
    table.string('html').notNullable();
    table.string('subject').notNullable();
    table.string('text');
    table.timestamps(true, true)
  })
};

exports.down = function(knex) {
  return knex.schema.dropTable('email_templates');
};
