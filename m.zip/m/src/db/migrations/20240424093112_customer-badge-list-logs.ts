/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = async (knex) => {
  await knex.schema
    .createTable('customer_badge_list_logs', (table) => {
        table.uuid('badge_id').references('badge_id').inTable('badge').onDelete('CASCADE').onUpdate('CASCADE');
        table.uuid('customer_account_id').references('customer_account_id').inTable('customer_accounts').onDelete('CASCADE').onUpdate('CASCADE');
        table.timestamps(true, true);
      })
  
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = async (knex) => {
  await knex.schema
  .dropTable('customer_badge_list_logs')
  
};
