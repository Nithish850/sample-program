exports.up = async function (knex) {
  await knex.schema.alterTable('event_subscription_logs', (table)=>{
    table.boolean('is_deleted');
  });
};
exports.down = async function (knex) {
  await knex.schema.alterTable('event_subscription_logs',(table)=>{
    table.dropColumn('is_deleted');
  })
};
