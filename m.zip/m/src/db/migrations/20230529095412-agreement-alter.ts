exports.up = async function (knex) {
  await knex.schema.alterTable('agreements', (table) => {
    table.dropColumn('payload');
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('email').notNullable();
    table.string('account_address').notNullable();
    table.string('ip');
    table.string('agreement_type').notNullable();
  });
}

exports.down = async function (knex) {
  await knex.schema.alterTable('agreements', (table) => {
    table.dropColumn('payload');
    table.string('first_name').notNullable();
    table.string('last_name').notNullable();
    table.string('email').notNullable();
    table.string('account_address').notNullable();
    table.string('ip');
    table.string('agreement_type').notNullable();
  });
}