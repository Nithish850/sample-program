import { defaultTenant } from '../master/tenant-data';


const proofOfAddressAttribute = {
    attribute_name: 'proofOfAddress',
    attribute_type: 'BOOLEAN',
    rule_group: 'ONBOARD',
    attribute_desc: 'Custom Namespace Required: for this check whether Custom Namespace & Custom Namespace Provider or not while doing onboarding',
    display_attribute_name: 'Proof of Address',
}

const getDefaultTenantId = async (knex) => {
  const defaultTenantData = await knex('tenants').select('tenant_id')
    .where({ 'tenant_name': defaultTenant[0]?.tenant_name,  domain: defaultTenant[0]?.domain });

  return defaultTenantData[0]?.tenant_id;
}

exports.up = async function(knex) {

  await knex('attributes').delete().where(proofOfAddressAttribute);
  await knex('attributes').where({ derived_attribute: 'proofOfAddress' })
  .update({ derived_attribute: null });

};

exports.down = async function(knex) {
    const tenant_id = await getDefaultTenantId(knex);

    if(!tenant_id) {
      throw new Error(`Default Tenant Id not found`);
    }

    await knex('attributes').insert({ ...proofOfAddressAttribute, tenant_id });


    await knex('attributes').where({ attribute_name: 'govIdList' })
      .update({ derived_attribute: 'proofOfAddress' });
    await knex('attributes').where({ attribute_name: 'verifiedIdType' })
      .update({ derived_attribute: 'proofOfAddress' });
};
