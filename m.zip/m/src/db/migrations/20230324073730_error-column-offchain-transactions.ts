exports.up = async function(knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.jsonb('errors')
  });
};

exports.down = async function(knex) {
  await knex.schema.alterTable('offchain_transaction', (table) => {
    table.dropColumn('errors');
  });
};
