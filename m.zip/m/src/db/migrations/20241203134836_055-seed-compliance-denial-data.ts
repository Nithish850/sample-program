import { Knex } from 'knex';
/* eslint-disable no-console */
const complianceDenialData = [
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'prohibited country based on input address',
    compliance_denial_code: 'i02',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'prohibited country based on lat/lon',
    compliance_denial_code: 'i03',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'prohibited country based on ip address',
    compliance_denial_code: 'i04',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'prohibited country based on phone number',
    compliance_denial_code: 'i05',
  },
  {
    compliance_denial_workflow: 'kyc_main',
    compliance_denial_reason: 'Customer age',
    compliance_denial_code: 'i01',
  },
  {
    compliance_denial_workflow: 'kyc_screening_checks',
    compliance_denial_reason:
      'Quantifind - high risk and high confidence factor found',
    compliance_denial_code: 'i07',
  },
  {
    compliance_denial_workflow: 'kyc_screening_checks',
    compliance_denial_reason: 'Quantifind - Sanction screening',
    compliance_denial_code: 'i08',
  },
  {
    compliance_denial_workflow: 'kyc_phone_checks',
    compliance_denial_reason: 'low phone trustscore',
    compliance_denial_code: 'i10',
  },
  {
    compliance_denial_workflow: 'kyc_phone_checks',
    compliance_denial_reason: 'Line type - landline',
    compliance_denial_code: 'i11',
  },
  {
    compliance_denial_workflow: 'kyc_phone_checks',
    compliance_denial_reason: 'Line type - fixed VoIP',
    compliance_denial_code: 'i12',
  },
  {
    compliance_denial_workflow: 'kyc_phone_checks',
    compliance_denial_reason: 'sim tenure less than 24 hours',
    compliance_denial_code: 'i15',
  },
  {
    compliance_denial_workflow: 'kyc_phone_checks',
    compliance_denial_reason: 'Line type - non fixed VoIP',
    compliance_denial_code: 'i13',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'low country location confidence',
    compliance_denial_code: 'i14',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'Missing plaid identity data',
    compliance_denial_code: 'b01',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'Missing plaid balance data',
    compliance_denial_code: 'b02',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'Missing Plaid token',
    compliance_denial_code: 'b03',
  },
  {
    compliance_denial_workflow: 'kyc_email_checks',
    compliance_denial_reason: 'lexis nexis emailage fraud flagged',
    compliance_denial_code: 'l01',
  },
  {
    compliance_denial_workflow: 'kyc_email_checks',
    compliance_denial_reason: 'lexis nexis emailage non existant email',
    compliance_denial_code: 'l02',
  },
  {
    compliance_denial_workflow: 'kyc_email_checks',
    compliance_denial_reason: 'high email frauscore',
    compliance_denial_code: 'l03',
  },
  {
    compliance_denial_workflow: 'kyc_death_screening',
    compliance_denial_reason: 'customer flagged as deceased',
    compliance_denial_code: 'l04',
  },
  {
    compliance_denial_workflow: 'id_checks',
    compliance_denial_reason: 'no id content supplied',
    compliance_denial_code: 'l05',
  },
  {
    compliance_denial_workflow: 'kyc_death_screening',
    compliance_denial_reason:
      'Error in payload response from lexis nexis instant id api',
    compliance_denial_code: 'l06',
  },
  {
    compliance_denial_workflow: 'kyc_email_checks',
    compliance_denial_reason: 'Invalid email address',
    compliance_denial_code: 'l07',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'null address field',
    compliance_denial_code: 'i16',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'null ip address',
    compliance_denial_code: 'i17',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'null phone number',
    compliance_denial_code: 'i18',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'invalid plaid token for identity',
    compliance_denial_code: 'i19',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'invalid plaid token for balance',
    compliance_denial_code: 'i20',
  },
  {
    compliance_denial_workflow: 'id_checks',
    compliance_denial_reason: 'missing selfie content',
    compliance_denial_code: 'l08',
  },
  {
    compliance_denial_workflow: 'kyc_banking_checks',
    compliance_denial_reason: 'Invalid plaid public token',
    compliance_denial_code: 'i21',
  },
  {
    compliance_denial_workflow: 'kyc_geolocator_checks',
    compliance_denial_reason: 'Address not found with geolocator API',
    compliance_denial_code: 'i22',
  },
];

export async function up(knex: Knex): Promise<void> {
  console.log('seed running: 055-seed-compliance-denial-data');
  await knex('compliance_denial').insert(complianceDenialData);
  console.log('seed completed: 055-seed-compliance-denial-data');
}

export async function down(knex: Knex): Promise<void> {
    console.log('rollback running: 055-seed-compliance-denial-data');
    
    const codesToDelete = complianceDenialData.map((entry) => entry.compliance_denial_code);
    
    await knex('compliance_denial')
      .whereIn('compliance_denial_code', codesToDelete)
      .del();
      
    console.log('rollback completed: 055-seed-compliance-denial-data');
  }
