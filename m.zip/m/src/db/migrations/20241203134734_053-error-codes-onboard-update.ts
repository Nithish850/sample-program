import { Knex } from 'knex';

/* eslint-disable no-console */
const errors = [
  {
    code: 'ULOT0043',
    ul_code: 'ULOT0043',
    description: `Blockchain address already exists on the platform, onboarding not permitted.`,
    ul_description: `Blockchain address already exists on the platform, onboarding not permitted.`,
    group: 'ONBOARD',
    category: 'ONBOARD',
  },
  {
    code: 'ULOT0044',
    ul_code: 'ULOT0044',
    description: `UNS ID (Custom namespace) already exists on the platform, onboarding not permitted.`,
    ul_description: `UNS ID (Custom namespace) already exists on the platform, onboarding not permitted.`,
    group: 'ONBOARD',
    category: 'ONBOARD',
  },
  {
    code: 'ULOT0045',
    ul_code: 'ULOT0045',
    description: `Customer has already been onboarded based on unique identification parameters.`,
    ul_description: `Customer has already been onboarded based on unique identification parameters.`,
    group: 'ONBOARD',
    category: 'ONBOARD',
  },
  {
    code: 'ULOT0046',
    ul_code: 'ULOT0046',
    description: `Missing one or more Unique Identification parameters in the onboarding request.`,
    ul_description: `Missing one or more Unique Identification parameters in the onboarding request.`,
    template:
      'Missing ${missingFields} Unique Identification parameters in the onboarding request.',
    group: 'ONBOARD',
    category: 'ONBOARD',
  },
  {
    code: 'ULOT0047',
    ul_code: 'ULOT0047',
    description: `Unable to allocate badge to wallet user for onboarding request.`,
    ul_description: `Unable to allocate badge to wallet user for onboarding request.`,
    group: 'ONBOARD',
    category: 'ONBOARD',
  },
  {
    code: 'ULOU0001',
    ul_code: 'ULOU0001',
    description: `We were unable to allocate the requested badge, but the user has been assigned the most suitable`,
    ul_description: `We were unable to allocate the requested badge, but the user has been assigned the most suitable`,
    template:
      'We were unable to allocate the requested badge, but the user has been assigned the badge ${badgeName} [${assignedBadge}] and is also eligible for other badges, including ${eligibleBadges}.',
    group: 'ONBOARD_UPDATE',
    category: 'ONBOARD_UPDATE',
  },
  {
    code: 'ULOU0002',
    ul_code: 'ULOU0002',
    description: `User has been assigned the most suitable badge according to badge ranking`,
    ul_description: `User has been assigned the most suitable badge according to badge ranking`,
    template:
      'User has been assigned the badge ${badgeName} [${assignedBadge}] and is also eligible for other badges, including ${eligibleBadges}.',
    group: 'ONBOARD_UPDATE',
    category: 'ONBOARD_UPDATE',
  },
  {
    code: 'ULOU0001B',
    ul_code: 'ULOU0001B',
    description: `We were unable to allocate the requested badge, but the user has been assigned the most suitable`,
    ul_description: `We were unable to allocate the requested badge, but the user has been assigned the most suitable`,
    template:
      'We were unable to allocate the requested badge, but the user has been assigned the badge ${badgeName} [${assignedBadge}].',
    group: 'ONBOARD_UPDATE',
    category: 'ONBOARD_UPDATE',
  },
  {
    code: 'ULOU0002B',
    ul_code: 'ULOU0002B',
    description: `User has been assigned the most suitable badge according to badge ranking`,
    ul_description: `User has been assigned the most suitable badge according to badge ranking`,
    template:
      'User has been assigned the badge ${badgeName} [${assignedBadge}].',
    group: 'ONBOARD_UPDATE',
    category: 'ONBOARD_UPDATE',
  },
  {
    code: 'ULOU0003',
    ul_code: 'ULOU0003',
    description: `User has successfully onboarded with the most suitable badge`,
    ul_description: `User has successfully onboarded with the most suitable badge`,
    template:
      'User has successfully onboarded with the badge ${badgeName} [${assignedBadge}].',
    group: 'ONBOARD_UPDATE',
    category: 'ONBOARD_UPDATE',
  },
  {
    code: 'ULUP0001',
    ul_code: 'ULUP0001',
    description: `Failed to update badge for user request.`,
    ul_description: `Failed to update badge for user request.`,
    group: 'UPDATE',
    category: 'UPDATE',
  },
];

export async function up(knex: Knex): Promise<void> {
  console.log('migration running: 053-error-codes-onboard-update');
  await knex('code_master').insert(errors);
  console.log('migration completed: 053-error-codes-onboard-update');
}

export async function down(knex: Knex): Promise<void> {
  console.log('rolling back 053-error-codes-onboard-update');
  await knex('code_master')
    .whereIn(
      'code',
      errors.map((error) => error.code),
    )
    .del();
  console.log('rollback completed: 053-error-codes-onboard-update');
}
