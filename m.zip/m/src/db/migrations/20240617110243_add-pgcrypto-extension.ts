/* eslint-disable no-console */
import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  console.log('Starting the up migration: creating pgcrypto extension');

  await knex.raw('CREATE EXTENSION IF NOT EXISTS "pgcrypto";');
  console.log('Successfully created pgcrypto extension');
}

export async function down(knex: Knex): Promise<void> {
  console.log('Starting the down migration: dropping pgcrypto  extension');

  await knex.raw('DROP EXTENSION IF EXISTS "pgcrypto";');
  console.log('Successfully dropped pgcrypto extension');
}