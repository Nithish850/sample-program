exports.up = async function(knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.jsonb('rejection_reason');
  });
};

exports.down = async function (knex) {
  await knex.schema.alterTable('customer_accounts', (table) => {
    table.dropColumn('rejection_reason');
  });
};
