exports.up = function (knex) {
  return knex.schema.createTable('deposit_requests', (table) => {
    table.uuid('deposit_request_id').primary().defaultTo(knex.raw('gen_random_uuid()'));
    table.uuid('tenant_id').references('tenant_id').inTable('tenants').onDelete('CASCADE').onUpdate('CASCADE');
    table.string('amount').notNullable();
    table.string('token').notNullable();
    table.string('wallet_identifier').notNullable();
    table.enu('wallet_identifier_type', [ 'CUSTOM NAMESPACE', 'WALLET ADDRESS' ]).notNullable();
    table.string('status').notNullable();
    table.enu('status_stage', [ 'INTERMEDIATE', 'FINAL' ]).notNullable();
    table.string('rejection_reason').nullable();
    table.timestamps(true, true);
  })
}

exports.down = function (knex) {
  return knex.schema.dropTable('deposit_requests');
}