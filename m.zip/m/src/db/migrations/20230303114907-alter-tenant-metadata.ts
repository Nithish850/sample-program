exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_metadata', (table) => {
    table.jsonb('registered_office_address');
    table.jsonb('signatories');
  });
}

exports.down = async function (knex) {
  await knex.schema.dropTable('tenant_metadata');
}