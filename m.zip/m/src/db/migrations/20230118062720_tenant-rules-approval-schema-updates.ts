/** function to create errors DB */
exports.up = async function (knex) {
  await knex.schema.alterTable('tenant_rules', (table) => {
    table.enu('status', [ 'pending', 'approved', 'rejected' ]).notNullable().defaultTo('pending');
  });
};

/** function to bring down errors DB */
exports.down = function (knex) {
  return knex.schema.dropTable('tenant_rules');
};
