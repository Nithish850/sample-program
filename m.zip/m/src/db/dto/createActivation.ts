import { ApiProperty } from '@nestjs/swagger';

/**
 * This class is for create activation request payload
 */
export class CreateActivationDTO {
    /**
   * @param {string} email
   * @example email : 'test@gmail.com'
   */
    @ApiProperty({
      type: 'string',
      description: 'Email',
    })
      email: string;
}
