import { Global, Module } from '@nestjs/common';
import { knex } from 'knex';
import { knexSnakeCaseMappers, Model } from 'objection';
import { envValues } from '../utils/util.service';
import { AccessRequests } from './models/access-requests';
import { Tenants } from './models/tenant';
import { Users } from './models/user';
import { TenantMetaData } from './models/tenant-meta-data';
import { UserRoles } from './models/user-role';
import { TenantCustomerAccounts } from './models/tenant-customer-account';
envValues();
/**
 * Defines models array
 */
const models = [
  AccessRequests,
  Tenants,
  TenantMetaData,
  Users,
  UserRoles,
  TenantCustomerAccounts,
];

/**
 * defines model providers
 * the models array is mapped to get all providers
 */
const modelProviders = models.map((model) => ({
  provide: model.name,
  useValue: model,
}));

/**
 * model provider array
 * defines the connection
 */
const providers = [
  ...modelProviders,
  {
    provide: 'KnexConnection',
    useFactory: async () => {
      const db = knex({
        client: 'pg',
        connection: `postgres://${process.env.DB_USER}:${process.env.DB_PWD}@${process.env.DB_HOST}/${process.env.DB_NAME}?sslmode=require`,
        debug: process.env.KNEX_DEBUG === 'true',
        ...knexSnakeCaseMappers(),
      });

      Model.knex(db);

      return db;
    },
  },
];

@Global()
@Module({
  providers: [...providers],
  exports: [...providers],
})
export class DatabaseModule {}

// `postgres://${process.env.DB_USER}:${process.env.DB_PWD}@${process.env.DB_HOST}/${process.env.DB_NAME}?sslmode=require`

// {
//   host: process.env.DB_HOST,
//   user: process.env.DB_USER,
//   password: process.env.DB_PWD,
//   database: process.env.DB_NAME,
// }
