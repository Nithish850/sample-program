import { Model } from 'objection';

export class DssVendor extends Model {

  dssVendorId: string;
  status: string;
  name: string;

  static get tableName() {
    return 'dss_vendor';
  }

  static get idColumn() {
    return [ 'dss_vendor_id' ];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        dss_vendor_id: { type: 'string' },
        name: { type: 'string' },
        status: { type: 'string' }
      },
    };
  }

}
