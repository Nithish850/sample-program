import { Model } from 'objection';

export class BusinessNamespaceMapper extends Model {
  created_at: string;
  updated_at: string;
  custom_namespace: string;
  business_user_namespace_id: string;
  provider: string;

  static get tableName() {
    return 'business_user_namespace_mapper';
  }

  static get idColumn() {
    return 'mapper_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        custom_namespace: { type: 'string' },
        business_user_namespace_id: { type: 'string' },
        provider: { type: 'string' },
      },
    };
  }
}
