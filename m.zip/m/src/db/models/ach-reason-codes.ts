import { Model } from 'objection';
export class AchReasonCodes extends Model {
  code: string;
  cliq_description: string;
  ul_response_code: string;
  ul_description: string;

  static get tableName() {
    return 'ach_reason_codes';
  }

  static get idColumn() {
    return 'ach_reason_code_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        code: { type: 'string' },
        cliq_description: { type: 'string' },
        ul_response_code: { type: 'string' },
        ul_description: { type: 'string' },
      },
    };
  }
}
