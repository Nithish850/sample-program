import { Model } from 'objection';

export class CustomContractTransactions extends Model {
  sender: string;
  receiver: string;
  status: string;
  amount: string;
  token: string;
  contractId: string;
  tenantId: string;
  transactionHash: string;
  extraInfo: object;
  rejectReason: string;

  static get tableName() {
    return 'custom_contract_transactions';
  }

  static get idColumn() {
    return 'public_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        sender: { type: 'string' },
        receiver: { type: 'string' },
        status: { type: 'string' },
        amount: { type: 'string' },
        token: { type: 'string' },
        contract_id: { type: 'string' },
        tenant_id: { type: 'string' },
        transaction_hash: { type: 'string' },
        extra_info: { type: 'object' },
        reject_reason: { type: 'string' },
      },
    };
  }
}
