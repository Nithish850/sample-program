import { Model } from 'objection';

export class  TokenType extends Model {
  tokenType: string;
  displayName: string;
  description: string;

  static get tableName() {
    return 'token_type';
  }

  static get idColumn() {
    return 'token_type';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'token_type', 'display_name' ],
      properties: {
        token_type: { type: 'string' },
        display_name: { type: 'string' },
        description: { type: 'string' },
      },
    };
  }
}