import { Model } from 'objection';
import { CustomerAccounts } from './customer-account';
import { Tenants } from './tenant';
import { TenantCustomerDocuments } from './customer-account-documents';
import { TenantCustomerNotes } from './tenant-customer-notes';
import { Namespace } from './namespace';
import { CustomNamespace } from './custom-namespace';
import { CustomerBadgeListLogs } from './customer-badge-list-logs';
import { InformationBadgeCustomerAccount } from './information-badge-customer-account';

export class TenantCustomerAccounts extends Model {
  tenant_customer_accounts_id: string;
  tenant_id: string;
  customer_account_id: string;
  category: any;
  created_at: string;
  updated_at: string;
  category_name: string;
  is_forgotten?:boolean;
  badge_id?:string;
  customerAccountId: string;
  complianceStatus: string;
  count: string;
  categoryName: string;

  static get tableName() {
    return 'tenant_customer_accounts';
  }

  static get idColumn() {
    return 'tenant_customer_accounts_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_customer_accounts_id: { type: 'string' },
        tenant_id: { type: 'string' },
        customer_account_id: { type: 'string' },
        category: {  },
        badge_id: {}
      },
    };
  }

  /**
   * Relate the TenantCustomerAccounts and Tenants with the help of TENANT_ID
   * Relate the TenantCustomerAccounts and CustomerAccounts with the help of CUSTOMER_ACCOUNT_ID
   */
  static get relationMappings() {
    return {
      tenants: {
        relation: Model.HasOneRelation,
        modelClass: Tenants,
        join: {
          from: 'tenants.tenant_id',
          to: 'tenant_customer_accounts.tenant_id',
        },
      },

      customer_accounts: {
        relation: Model.HasOneRelation,
        modelClass: CustomerAccounts,
        join: {
          from: 'tenant_customer_accounts.customerAccountId',
          to: 'customer_accounts.customerAccountId',
        },
      },

      tenant_customer_documents: {
        relation: Model.HasManyRelation,
        modelClass: TenantCustomerDocuments,
        filter: (query) =>
          query.select(
            'name as fileName',
            'type',
            'number',
            'expired',
            'content',
            'tenant_customer_document_id  as documentId',
          ),
        join: {
          from: 'tenant_customer_documents.customerAccountId',
          to: 'tenant_customer_accounts.customerAccountId'
        }
      },

      tenant_customer_notes: {
        relation: Model.HasManyRelation,
        modelClass: TenantCustomerNotes,
        join: {
          from: 'tenant_customer_notes.customerAccountId',
          to: 'tenant_customer_accounts.customerAccountId'
        }
      },
      namespaces: {
        relation: Model.HasManyRelation,
        modelClass: Namespace,
        filter: (query: any) => query.select("namespaceId", "account_address", "is_global", "is_primary", "namespace as domainNamespace"),
        join: {
          from: 'namespaces.customerAccountId',
          to: 'tenant_customer_accounts.customerAccountId',
          andOn: (builder) => {
            builder.where('namespaces.tenant_id', '=', 'tenant_customer_accounts.tenant_id')
          }
        }
      },
      wallet_user_namespace_mapper: {
        relation: Model.ManyToManyRelation,
        modelClass: CustomNamespace,
        join: {
          from: 'tenant_customer_accounts.customerAccountId',
          through: {
            from: 'namespaces.customerAccountId',
            to: 'namespaces.namespaceId',
          },
          to: 'wallet_user_namespace_mapper.namespaceId',
        }
      },
      badgeLogs: {
        relation: Model.HasManyRelation,
        modelClass: CustomerBadgeListLogs,
        join: {
          from: 'tenant_customer_accounts.customerAccountId',
          to: 'customer_badge_list_logs.customerAccountId',
        },
      },
      infoBadge: {
        relation: Model.HasManyRelation,
        modelClass: InformationBadgeCustomerAccount,
        join: {
          from: 'tenant_customer_accounts.customerAccountId',
          to: 'information_badge_customer_account.customerAccountId',
        },
      }
    };
  }
}
