import { Model } from "objection";

export class DSSVendorConsent extends Model {
  dss_vendor_id: string;
  vendor_name: string;
  dss_id: string;
  consent_version: string;
  active_status: string;
  current_active_version: string;
  consent_message: string;
  consent_id: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return "dss_vendor_consent";
  }

  static get idColumn() {
    return [ "dss_vendor_id" ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  // $beforeUpdate() {
  //   this.updated_at = new Date().toISOString();
  // }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        dss_vendor_id: { type: 'string' },
        vendor_name: { type: 'string' },
        dss_id: { type: 'string' },
        consent_version: { type: 'string' },
        active_status: { type: 'string' },
        current_active_version: { type: 'string' },
        consent_message: { type: 'string' },
        consent_id: { type: 'string' },
      },
    };
  }
}
