import { Model } from 'objection';
import { Tenants } from './tenant';

export class TenantNamespace extends Model {

  tenantNamespace: string;
  account_address: string;
  public_key: string;
  tenant_id: string;
  accountAddress: string;
  tenantId: string;
  walletName: string;
  walletType: string;
  token: string;
  isActive: boolean;
  // Account status space from tenant_namespace table
  accountStatus: string;
  tenantNamespaceId: string;
  settlementTenantId: string;
  disbursementStatus: string;

  $beforeInsert() {
    if (this.account_address) {
      this.account_address = this.account_address.toLowerCase();
    }
  }

  static get tableName() {
    return 'tenant_namespace';
  }

  static get idColumn() {
    return 'tenant_namespace_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ ],
      properties: {
        tenant_namespace_id: { type: 'string' },
        tenant_namespace: { type: 'string' },
        account_address: { type: 'string' },
        tenant_id: { type: 'string' },
      },
    };
  }

  /**
   * Relate the Tenants and TenantNamespace with the help of tenant_id
   */
  static get relationMappings() {
    return {
      roles: {
        relation: Model.HasOneRelation,
        modelClass: Tenants,
        join: {
          from: 'tenant_namespace.tenant_id',
          to: 'tenants.tenant_id',
        },
      }
    }
  }
}
