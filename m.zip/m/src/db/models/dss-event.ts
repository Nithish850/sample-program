import { Model } from "objection";

export class DSSEvent extends Model {
  created_at: string;
  updated_at: string;
  dssEventId: string;
  event: string;

  static get tableName() {
    return "dss_event";
  }

  static get idColumn() {
    return [ "dss_event_id" ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
