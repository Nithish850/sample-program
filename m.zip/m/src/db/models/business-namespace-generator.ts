import { Model } from 'objection';
export class BusinessNamespaceGenerator extends Model {
  base_name: string;
  count: number;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'business_namespace_generator';
  }

  static get idColumn() {
    return 'business_namespace_generator_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        business_namespace_generator_id: { type: 'string' },
        base_name: { type: 'string' },
        count: { type: 'number' },
        created_at: { type: 'string' },
        updated_at: { type: 'string' },
      },
    };
  }
}
