import { Model } from 'objection';
import { TenantEventSubscription } from './tenant-event-subscription';

export class EventSubscriptionLogs extends Model {
  event_subscription_log_id: string;
  event_name: string;
  tenant_id: string;
  subscribed_by: string;
  subscriber: string;
  updated_by: string;
  is_subscribed: boolean;
  created_at: string;
  updated_at: string;
  tenant_event_subscription_id: string;
  is_deleted: boolean;

  static get tableName() {
    return 'event_subscription_logs';
  }

  static get idColumn() {
    return 'event_subscription_log_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ ],
      properties: {
        event_subscription_log_id: { type: 'string' },
        event_name: { type: 'string' },
        tenant_id: { type: 'string' },
        subscribed_by: { type: 'string' },
        subscriber: { type: 'string' },
        updated_by: { type: 'string' },
        is_subscribed: { type: 'boolean' },
        tenant_event_subscription_id: { type: 'string' }
      },
    };
  }

  static get relationMappings() {
    return {
      tenant_subscription: {
        relation: Model.HasOneRelation,
        modelClass: TenantEventSubscription,
        join: {
          from: 'event_subscription_logs.tenant_event_subscription_id',
          to: 'tenant_event_subscription.tenantEventSubscriptionId',
        },
      },
    }
  }
}
