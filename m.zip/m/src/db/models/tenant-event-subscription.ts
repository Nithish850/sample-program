import { Model } from 'objection';
import { EventSubscriptionLogs } from './event-subscription-logs';

export class TenantEventSubscription extends Model {
  tenant_event_subscription_id: string;
  dss_event_id: string;
  tenant_id: string;
  endpoint: string;
  is_active: string;
  secret_header?: string;
  secret_key?: string;
  createdAt: string;
  updatedAt: string;
  aliasName: string;

  static get tableName() {
    return 'tenant_event_subscription';
  }

  static get idColumn() {
    return 'tenant_event_subscription_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_event_subscription_id: { type: 'string' },
        dss_event_id: { type: 'string' },
        secret_header: { type: 'string' },
        secret_value: { type: 'string' },
        tenant_id: { type: 'string' },
        endpoint: { type: 'string' },
        is_active: { type: 'boolean' },
      },
    };
  }

  static get relationMappings() {
    return {
      event_subscription_logs: {
        relation: Model.HasOneRelation,
        modelClass: EventSubscriptionLogs,
        join: {
          from: 'tenant_event_subscription.tenantEventSubscriptionId',
          to: 'event_subscription_logs.tenant_event_subscription_id',
        },
      },
    };
  }
}
