import { Model } from 'objection';

export class IndustryMaster extends Model {
  industry: string;
  risk: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'industry_master';
  }

  static get idColumn() {
    return 'industry_master_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        industry: { type: 'string' },
        risk: { type: 'string' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
