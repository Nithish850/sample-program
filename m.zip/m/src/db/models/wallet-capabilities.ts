import { Model } from 'objection';

export class WalletCapabilities extends Model {
  walletTypeId: string;
  tenantId: string;
  deposit: boolean;
  withdraw: boolean;
  transfer: boolean;
  multiWallet: boolean;

  static get tableName() {
    return 'wallet_capabilities';
  }

  static get idColumn() {
    return 'wallet_capabilities_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        wallet_type_id: { type: 'string' },
        multi_token: { type: 'boolean' },
      },
    };
  }
}