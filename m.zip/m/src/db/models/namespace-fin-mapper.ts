import { Model } from 'objection';
import { Badge } from './badge';

export class NamespaceFinbadgeMapper extends Model {
  static get tableName() {
    return 'namespace_token_financial_badge_mapper';
  }

  static get idColumn() {
    return ['namespace_id'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        namespace_id: { type: 'string' },
        financial_badge_id: { type: 'string' },
        token_symbol: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      financeBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'namespace_token_financial_badge_mapper.financialBadgeId',
          to: 'badge.badgeId'
        },
      },
    }
  }

}
