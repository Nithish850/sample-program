import { Model } from 'objection';

export class SecretHistory extends Model {
  created_at: string;
  updated_at: string;
  details: object;
  description:string;
  secretHistoryId: string;
  secretId: string;

  static get tableName() {
    return 'secret_history';
  }

  static get idColumn() {
    return 'secret_history_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        secret_history_id: { type: 'string' },
        secret_id: { type: 'string' },
        description: { type: 'string' },
        details: { type: 'object' },
      },
    };
  }
}
