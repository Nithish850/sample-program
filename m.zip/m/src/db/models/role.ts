import { Model } from 'objection';
import { RoleEntities } from './role-entity';
import { Tenants } from './tenant';
import { Entities } from './entity';

export class Roles extends Model {
  created_at: string;
  updated_at: string;
  roleName: string;
  tenant_id: string;
  is_active: boolean;
  created_by: string;
  role_abilities_json: object;
  role_id: string;

  static get tableName() {
    return 'roles';
  }

  static get idColumn() {
    return 'role_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'role_name' ],
      properties: {
        role_name: { type: 'string' },
        tenant_id: { type: 'string' },
        role_abilities_json: { type: 'object' },
        is_active: { type: 'boolean' },
        created_by: { type: 'string' },
        role_id: { type: 'string' },
      },
    };
  }

  /**
   * Relate the UserRole and Roles with the help of ROLE_ID
   * Relate the RoleEntities and Roles with the help of ROLE_ID
   */
  static get relationMappings() {
    return {
      entities: {
        relation: Model.HasOneThroughRelation,
        modelClass: Entities,
        join: {
          from: 'roles.roleId',
          through: {
            from: 'role_entities.roleId',
            to: 'role_entities.entityId',
          },
          to: 'entities.entityId',
        },
      },
      role_entities: {
        relation: Model.HasManyRelation,
        modelClass: RoleEntities,
        join: {
          from: 'roles.roleId',
          to: 'role_entities.roleId',
        },
      },
      tenants: {
        relation: Model.BelongsToOneRelation,
        modelClass: Tenants,
        filter: (query: any) => query.select('tenant_name'),
        join: {
          from: 'roles.tenantId',
          to: 'tenants.tenantId'
        }
      }
    };
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
