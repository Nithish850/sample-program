import { Model } from 'objection';
/**
 * AttributesMinMaxVal Model Class
 */
export class AttributesMinMaxVal extends Model {
  /** attribute_id: string; */
  attributeId: string;
  /** minimum_value: string; */
  minimumValue: string;
  /** maximum_value: string; */
  maximumValue: string;
  /** rule_group: string; */
  ruleGroup: string;
  /** rule_slug: string; */
  ruleSlug: string;

  /**
   * Function to get table name
   */
  static get tableName() {
    return 'attributes_min_max_val';
  }

  /**
   * Function to get schema of table in json/object format
   */
  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        attribute_id: { type: 'string' },
        minimum_value: { type: 'string' },
        maximum_value: { type: 'string' },
        rule_group: { type: 'string' },
        rule_slug: { type: 'string' },
      },
    };
  }
}
