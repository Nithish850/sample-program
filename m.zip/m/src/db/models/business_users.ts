import { Model } from 'objection';
import { ERROR_MESSAGE, ERROR_TYPE } from '../../utils/constant';
import { BusinessUserMetadata } from './business_user_metadata';
import { BusinessUserNamespaces } from './business_user_namespaces';
import { DssBusinessUsers } from './dss_business_users';
import { BusinessUserDocuments } from './business_user_documents';
import { TenantBusinessUsers } from './tenant-business-users';
import { EncryptionDecryption } from './encryption-decryption';

export class BusinessUsers extends Model {
  created_at: string;
  updated_at: string;
  start_date: string;
  end_date: string;
  compliance_status: string;
  businessUserName: string;
  domain: string;
  business_user_id: string;
  email: string;
  bank_verification_number: string;
  identity_provider_status: string;
  business_user_metadata: BusinessUserMetadata;
  business_user_namespaces: BusinessUserNamespaces;

  static get tableName() {
    return 'business_users';
  }

  static get idColumn() {
    return 'business_user_id';
  }

  async $afterFind() {
    const businessUserName = await EncryptionDecryption.decrypt(this.businessUserName)
    this.businessUserName = businessUserName
  }

  async $beforeInsert() {
    const namespaceData = await BusinessUserNamespaces.query().findOne({ account_address: this.business_user_namespaces?.account_address });

    if (namespaceData && Object.keys(namespaceData).length) {
      throw [{ type: ERROR_TYPE.DUPLICATE, message: ERROR_MESSAGE.ACCOUNT_ADDRESS_ALREADY_PRESENT }];
    }

    const data = await BusinessUsers.query().withGraphFetched('business_user_metadata').where({ domain: this.domain });

    if (data && data.length != 0) {
      const { errors } = this.checkDuplicateEntry(data);

      if (errors) {
        throw errors;
      }
    }

    const errorsArray = [];

    if (this.business_user_metadata.bankVerificationNumber) {
      const isBankDetails: any = await BusinessUserMetadata.query().findOne({ bank_verification_number: this.business_user_metadata.bankVerificationNumber });

      if (isBankDetails && Object.keys(isBankDetails).length != 0) {
        const { errors } = this.checkDuplicateRecords('bank_verification_number', isBankDetails.bankVerificationNumber, this.business_user_metadata.bankVerificationNumber);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }

    if (errorsArray.length) {
      throw errorsArray;
    }

    this.created_at = new Date().toISOString();
    this.start_date = new Date().toISOString();
    this.end_date = new Date().toISOString();
  }

  $beforeUpdate() {
    this.created_at = new Date().toISOString();
    this.start_date = new Date().toISOString();
    this.end_date = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        business_user_id: { type: 'string' },
        business_user_name: { type: 'string' },
        domain: { type: 'string' },
        onboarding_status: { type: 'string', default: 'PENDING' },
      },
    };
  }

  /**
   * Relate the BusinessUsers and BusinessUserMetadata with the help of business_user_id
   */
  static get relationMappings() {
    return {
      business_user_metadata: {
        relation: Model.HasOneRelation,
        modelClass: BusinessUserMetadata,
        join: {
          from: 'business_users.businessUserId',
          to: 'business_user_metadata.businessUserId',
        },
      },
      business_user_namespaces: {
        relation: Model.HasOneRelation,
        modelClass: BusinessUserNamespaces,
        join: {
          from: 'business_users.businessUserId',
          to: 'business_user_namespaces.businessUserId',
        },
      },
      dss_business_users: {
        relation: Model.HasOneRelation,
        modelClass: DssBusinessUsers,
        join: {
          from: 'business_users.businessUserId',
          to: 'dss_business_users.businessUserId',
        },
      },
      business_user_documents: {
        relation: Model.HasManyRelation,
        modelClass: BusinessUserDocuments,
        join: {
          from: 'business_users.businessUserId',
          to: 'business_user_documents.businessUserId',
        },
      },
      tenant_business_users: {
        relation: Model.HasOneRelation,
        modelClass: TenantBusinessUsers,
        join: {
          from: 'business_users.businessUserId',
          to: 'tenant_business_users.businessUserId',
        },
      },
    };
  }

  checkDuplicateEntry(businessDetailsFromDB) {
    const errors = [];
    const type = ERROR_TYPE.DUPLICATE;

    if (businessDetailsFromDB[0].domain === this.domain) {
      const message = ERROR_MESSAGE.DUPLICATE_BUSINESS_DOMAIN;

      errors.push({ type, message });
    }

    if (businessDetailsFromDB[0].businessUserName === this.businessUserName) {
      const message = ERROR_MESSAGE.DUPLICATE_BUSINESS_NAME;

      errors.push({ type, message });
    }

    return { errors };
  }

  checkDuplicateRecords(keyName, item, itemToCompare) {
    const errors = {};
    const type = ERROR_TYPE.DUPLICATE;

    if (item === itemToCompare && keyName === 'bank_verification_number') {
      const message = ERROR_MESSAGE.DUPLICATE_BUSINESS_BANK_VERIFICATION;

      Object.assign(errors, { type, message });
    }

    return { errors };
  }
}
