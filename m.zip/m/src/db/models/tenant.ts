import { Model } from 'objection';
import { TenantMetaData } from './tenant-meta-data';
import { ERROR_MESSAGE, ERROR_TYPE } from '../../utils/constant';
import { Users } from './user';
import { Roles } from './role';
import { TenantCustomerAccounts } from './tenant-customer-account';
import { UserRoles } from './user-role';
import { Namespace } from './namespace';
import { TenantNamespace } from './tenant-namespace';
import { DssTenant } from './dss-tenant';
import { TenantDocuments } from './tenant-documents';
import { ProductSubscriptions } from './product-subscriptions';
import { TenantContractMapper } from './tenant-contract-mapper';
import { EncryptionDecryption } from './encryption-decryption';

export class Tenants extends Model {
  created_at: string;
  updated_at: string;
  start_date: string;
  end_date: string;
  tenantName: string;
  domain: string;
  tenant_id: string;
  email: string;
  bank_verification_number: string;
  identity_provider_status: string;
  users: Users;
  tenant_metadata?: TenantMetaData;
  tenant_name?: string

  static get tableName() {
    return 'tenants';
  }

  static get idColumn() {
    return 'tenant_id';
  }

  async $beforeInsert() {
    const data = await Tenants.query().withGraphFetched('tenant_metadata').where({ domain: this.domain });

    if (data && data.length != 0) {
      const { errors } = this.checkDuplicateEntry(data);

      if (errors) {
        throw errors;
      }
    }

    const errorsArray = [];

    if (this.tenant_metadata.bankVerificationNumber) {
      const isBankDetails: any = await TenantMetaData.query().findOne({ bank_verification_number: this.tenant_metadata.bankVerificationNumber });

      if (isBankDetails && Object.keys(isBankDetails).length != 0) {
        const { errors } = this.checkDuplicateRecords('bank_verification_number', isBankDetails.bankVerificationNumber, this.tenant_metadata.bankVerificationNumber);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if (this.users.email) {
      const isUserDetails: any = await Users.query().findOne({ email: this.users.email });

      if (isUserDetails && Object.keys(isUserDetails).length != 0) {
        const { errors } = this.checkDuplicateRecords('email', isUserDetails.email, this.users.email);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if (this.users.user_name) {
      const isUserDetails: any = await Users.query().findOne({ user_name: this.users.user_name });

      if (isUserDetails && Object.keys(isUserDetails).length != 0) {
        const { errors } = this.checkDuplicateRecords('user_name', isUserDetails.userName, this.users.user_name);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if (errorsArray.length) {
      throw errorsArray;
    }
    const tenant_name = await EncryptionDecryption.encrypt(this.tenant_name);

    this.tenant_name = tenant_name

    this.created_at = new Date().toISOString();
    this.start_date = new Date().toISOString();
    this.end_date = new Date().toISOString();
  }

  async $beforeUpdate() {

    const tenant_name = await EncryptionDecryption.decryptAndEncrypt(this.tenant_name || this.tenantName);

    this.tenant_name = tenant_name

    this.created_at = new Date().toISOString();
    this.start_date = new Date().toISOString();
    this.end_date = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_name', 'domain' ],
      properties: {
        tenant_id: { type: 'string' },
        tenant_name: { type: 'string' },
        domain: { type: 'string' },
        onboarding_status: { type: 'string', default: 'PENDING' },
      },
    };
  }

  /**
   * Relate the Tenants and TenantMetadata with the help of TENANT_ID
   * Relate the Tenants and Roles with the help of TENANT_ID
   * Relate the Tenants and Users with the help of TENANT_ID
   * Relate the Tenants and TenantCustomerAccounts with the help of TENANT_ID
   */
  static get relationMappings() {
    return {
      tenant_metadata: {
        relation: Model.HasOneRelation,
        modelClass: TenantMetaData,
        join: {
          from: 'tenants.tenantId',
          to: 'tenant_metadata.tenantId',
        },
      },
      roles: {
        relation: Model.HasManyRelation,
        modelClass: Roles,
        join: {
          from: 'tenants.tenantId',
          to: 'roles.tenantId',
        },
      },
      users: {
        relation: Model.HasManyRelation,
        modelClass: Users,
        filter: (query: any) => query.select('user_name', 'email', 'login_id', 'phone_number', 'address', 'employee_id'),
        join: {
          from: 'tenants.tenantId',
          to: 'users.tenantId',
        },
      },
      tenant_customer_accounts: {
        relation: Model.HasManyRelation,
        modelClass: TenantCustomerAccounts,
        join: {
          from: 'tenants.tenantId',
          to: 'tenant_customer_accounts.tenantId',
        },
      },
      user_roles: {
        relation: Model.HasManyRelation,
        modelClass: UserRoles,
        join: {
          from: 'tenants.tenantId',
          to: 'user_roles.tenantId',
        },
      },
      namespace: {
        relation: Model.HasManyRelation,
        modelClass: Namespace,
        join: {
          from: 'tenants.tenantId',
          to: 'namespaces.tenantId',
        },
      },
      tenant_namespace: {
        relation: Model.HasManyRelation,
        modelClass: TenantNamespace,
        join: {
          from: 'tenants.tenantId',
          to: 'tenant_namespace.tenantId',
        },
      },
      dss_tenants: {
        relation: Model.HasOneRelation,
        modelClass: DssTenant,
        join: {
          from: 'tenants.tenantId',
          to: 'dss_tenants.tenantId',
        },
      },
      tenant_documents: {
        relation: Model.HasManyRelation,
        modelClass: TenantDocuments,
        join: {
          from: 'tenants.tenantId',
          to: 'tenant_documents.tenantId',
        },
      },
      /** This relation is in use for the GET APIs  */
      tenant_products: {
        relation: Model.HasManyRelation,
        modelClass: ProductSubscriptions,
        filter: (query: any) => query.select('productSubscriptionId', 'tenantId', 'productId', 'is_active'),
        join: {
          from: 'tenants.tenantId',
          to: 'product_subscriptions.tenantId',
        }
      },
      tenant_token_contract: {
        relation: Model.HasManyRelation,
        modelClass: TenantContractMapper,
        join: {
          from: 'tenants.tenantId',
          to: 'tenant_contract_mapper.tenantId',
        },
      }
    };
  }

  checkDuplicateEntry(tenantDetailsFromDB) {
    const errors = [];
    const type = ERROR_TYPE.DUPLICATE;

    if (tenantDetailsFromDB[0].domain === this.domain) {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_DOMAIN;

      errors.push({ type, message });
    }

    if (tenantDetailsFromDB[0].tenantName === this.tenantName) {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_NAME;

      errors.push({ type, message });
    }

    return { errors };
  }

  checkDuplicateRecords(keyName, item, itemToCompare) {
    const errors = {};
    const type = ERROR_TYPE.DUPLICATE;

    if (item === itemToCompare && keyName === 'bank_verification_number') {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_BANK_VERIFICATION;

      Object.assign(errors, { type, message });
    }
    if (item === itemToCompare && keyName === 'email') {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_ADMIN_EMAIL;

      Object.assign(errors, { type, message });
    }
    if (item === itemToCompare && keyName === 'user_name') {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_ADMIN_USERNAME;

      Object.assign(errors, { type, message });
    }

    return { errors };
  }

  async $afterFind() {
    const tenantName =await EncryptionDecryption.decrypt(this.tenantName)

    this.tenantName = tenantName

  }

}
