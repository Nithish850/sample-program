import { Model } from 'objection';
import { Badge } from './badge';

export class CustomerBadgeListLogs extends Model {
  badgeId: string;
  customerAccountId: string;

  static get tableName() {
    return 'customer_badge_list_logs';
  }

  static get idColumn() {
    return ['badge_id', 'customer_account_id'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['badgeId', 'customerAccountId'],
      properties: {
        badge_id: { type: 'string' },
        customer_account_id: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      badgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'customer_badge_list_logs.badgeId',
          to: 'badge.badgeId'
        },
      }
    }
  }
}