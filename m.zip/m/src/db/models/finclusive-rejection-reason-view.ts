import { Model } from 'objection';

export class FinclusiveRejectionReasonView extends Model {
  static get tableName() {
    return 'v_finclusive_rejection_reason';
  }
}