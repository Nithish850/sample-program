import { Model } from "objection";

export class StateRiskRating extends Model {
  createdAt: string;
  updatedAt: string;
  state: string;
  stateCode: string;
  countryCode: string;
  riskScore: string;
  riskRating: string;
  ulOverride: string;
  rationale: string;

  static get tableName() {
    return "state_risk_rating";
  }

  static get idColumn() {
    return [ 'country_code', 'state_code' ];
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'country', 'country_code', 'risk_score' ],
      properties: {
        country_code: { type: 'string' },
        state: { type: 'string' },
        state_code: { type: 'string' },
        risk_score: { type: 'string' },
        risk_rating: { type: 'string' },
        ul_override: { type: 'string' },
        rationale: { type: 'string' },
      },
    };
  }
}
