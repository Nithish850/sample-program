import { Model } from 'objection';
import { Badge } from './badge';

export class BadgeToken extends Model {
  static get tableName() {
    return 'badge_token';
  }

  static get idColumn() {
    return ['public_id'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        public_id: { type: 'string' },
        identification_id: { type: 'string' },
        financial_badge_id: { type: 'string' },
        token_symbol: { type: 'string' },
        infoatmation_badge_id: {type: 'object'}
      },
    };
  }

  static get relationMappings() {
    return {
      identificationBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'badge_token.identificationBadgeId',
          to: 'badge.badgeId'
        },
      },
      financeBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'badge_token.financialBadgeId',
          to: 'badge.badgeId'
        },
      },
      customFinanceBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'badge_token.customFinancialBadgeId',
          to: 'badge.badgeId'
        },
      },
      informationBadgeDetails: {
        relation: Model.HasManyRelation, 
        modelClass: Badge,
        filter: (query) => query.select('badgeName', 'badgeType'),
        join: {
          from: 'badge_token.informationBadgeId',  
          to: 'badge.badgeId'            
        }
      }
    } 
  }
}
