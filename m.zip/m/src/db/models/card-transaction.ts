import { Model } from 'objection';
import { OffchainTransaction } from './offchain-transaction';
import { CardTransactionHistory } from './card-transaction-history';
import { DssVendor } from './dss-vendor';

export class CardTransaction extends Model {
  created_at: string;
  updated_at: string;
  response: object;
  transaction_id: string;
  reference_id: string;
  status: string;
  namespace: string;
  cardTransactionId: string;
  offchain_transaction_id: string;
  settlement_date: string;
  sessionId?: string
  tokenSymbol: string;
  dss_vendor_id:string;

  static get tableName() {
    return 'card_transaction';
  }

  static get idColumn() {
    return 'card_transaction_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        card_transaction_id: { type: 'string' },
        transaction_id: { type: 'string' },
        session_id: { type: 'string' },
        reference_id: { type: 'string' },
        namespace: { type: 'string' },
        status: { type: 'string' },
        response: { type: 'object' },
      },
    };
  }

  static get relationMappings() {
    return {
      offChain: {
        relation: Model.HasOneRelation,
        modelClass: OffchainTransaction,
        join: {
          from: 'card_transaction.offchainTransactionId',
          to: 'offchain_transaction.offchainTransactionId',
        },
      },
      fiatHistory: {
        relation: Model.HasManyRelation,
        modelClass: CardTransactionHistory,
        filter: (query) => query.select('cardTransactionHistoryId as fiatTransactionHistoryId','status','description','createdAt','updatedAt'),
        join: {
          from: 'card_transaction.cardTransactionId',
          to: 'card_transaction_history.cardTransactionId',
        },
      },
      dss_vendor: {
        relation: Model.HasOneRelation,
        modelClass: DssVendor,
        filter: (query) => query.select('dssVendorId as id', 'name' ,'status'),
        join: {
          from: 'card_transaction.dssVendorId',
          to: 'dss_vendor.dssVendorId',
        },
      }
    };
  }
}
