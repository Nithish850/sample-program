import { Model } from 'objection';

export class DssEvents extends Model {
  event: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'dss_event';
  }

  static get idColumn() {
    return 'dss_event_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'event' ],
      properties: {
        event: { type: 'string' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
