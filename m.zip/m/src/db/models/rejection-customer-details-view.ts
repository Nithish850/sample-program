import { Model } from 'objection';

export class RejectionCustomerDetailsView extends Model {
  static get tableName() {
    return 'v_geography_rejection_customer_details';
  }
}