import { Model, } from "objection";

export class DepositUtilityTokensMap extends Model {
  depositTokenSymbol: string;
  utilityTokenSymbol: string;
  createdBy: string;
  updatedBy?: string;
  tenantId: string;
  tenantName: string;
  settlementTenantId: string;
  symbol: string;
  abi: object;
  proxyAddress: string;
  currency: string;

  static get tableName() {
    return 'deposit_utility_tokens_map';
  }

  static get idColumn() {
    return [ 'utility_token_symbol', 'deposit_token_symbol' ];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        utility_token_symbol: { type: 'string' },
        deposit_token_symbol: { type: 'string' },
      },
    };
  }
}