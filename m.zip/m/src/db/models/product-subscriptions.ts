import { Model } from 'objection';
import { Products } from './products';

export class ProductSubscriptions extends Model {
  tenant_id: string;
  productId: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  productSubscriptionId: string;

  static get tableName() {
    return 'product_subscriptions';
  }

  static get idColumn() {
    return 'product_subscription_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_id', 'product_id', 'is_active' ],
      properties: {
        tenant_id: { type: 'string' },
        product_id: { type: 'string' },
        is_active: { type: 'boolean' },
      },
    };
  }

  static get relationMappings() {
    return {
      products: {
        relation: Model.HasOneRelation,
        modelClass: Products,
        join: {
          from: 'product_subscriptions.productId',
          to: 'products.productId',
        },
      },
    }
  }
}
