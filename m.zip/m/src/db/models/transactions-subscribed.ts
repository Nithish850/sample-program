import { Model } from 'objection';

export class TransactionsSubscribed extends Model {
  from: string;
  to: string;
  amount: string;
  transaction_hash: string;
  token_symbol: string;
  input: string;
  transaction_details: object;
  status: string;
  transaction_type: string;
  proxy_address: string;
  reject_reason: string;
  transactionHash: string;
  tokenSymbol: string;
  transactionDetails: object;
  transactionType: string;
  proxyAddress: string;
  rejectReason: string;

  static get tableName() {
    return 'transactions_subscribed';
  }

  static get idColumn() {
    return 'transactions_subscription_id'
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['from', 'to', 'amount', 'transaction_hash'],
      properties: {
        from: { type: 'string' },
        to: { type: 'string' },
        amount: { type: 'string' },
        transaction_hash: { type: 'string' },
        token_symbol: { type: 'string' },
        input: { type: 'string' },
        transaction_details: { type: 'object' },
        status: { type: 'string' },
        transaction_type: { type: 'string' },
        proxy_address: { type: 'string' },
        reject_reason: { type: 'string' },
      },
    };}
}
