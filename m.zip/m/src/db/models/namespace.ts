import { Model } from 'objection';
import { CustomerAccounts } from './customer-account';
import { CustomNamespace } from './custom-namespace';
import { Tenants } from './tenant';

export class Namespace extends Model {
  created_at: string;
  updated_at: string;
  tenant_id: string;
  namespace: string;
  accountAddress: string;
  namespace_id: string;
  is_global: boolean;
  customer_account_id: string;
  isPrimary:boolean;
  is_deleted:boolean;
  tenantId: string;
  tenantNamespace: string;
  account_address: string;
  namespaceId: string;

  static get tableName() {
    return 'namespaces';
  }

  static get idColumn() {
    return 'namespace_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
    if (this.account_address) {
      this.account_address = this.account_address.toLowerCase();
    }
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        namespace_id: { type: 'string' },
        customer_account_id: { type: 'string' },
        tenant_id: { type: 'string' },
        namespace: { type: 'string' },
        account_address: { type: 'string' },
        is_global: { type: 'boolean' },
        created_at: { type: 'string' },
        updated_at: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      customer: {
        relation: Model.HasOneRelation,
        modelClass: CustomerAccounts,
        join: {
          from: 'namespaces.customerAccountId',
          to: 'customer_accounts.customerAccountId',
        },
      },
      wallet_user_namespace_mapper: {
        relation: Model.HasOneRelation,
        modelClass: CustomNamespace,
        filter: (query: any) => query.select('custom_namespace', "provider as namespaceProvider",),
        join: {
          from: 'namespaces.namespaceId',
          to: 'wallet_user_namespace_mapper.namespaceId',
        }
      },
      tenants: {
        relation: Model.HasOneRelation,
        modelClass: Tenants,
        filter: (query: any) => query.select('tenantName', 'tenantId'),
        join: {
          from: 'namespaces.tenantId',
          to: 'tenants.tenantId',
        }
      }
    };
  }
}
