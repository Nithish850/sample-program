/* eslint-disable no-dupe-class-members */
import { Logger } from '@nestjs/common';
import { Model, raw } from 'objection';

const logger = new Logger('EncryptionDecryption');

export class EncryptionDecryption extends Model {
  table_name: string;
  column_name: string;
  created_at: string;
  updated_at: string;
  decryptedvalue: string;
  encryptValue: string

  static get tableName() {
    return 'encryption_decryption';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        table_name: { type: 'string' },
        column_name: { type: 'string' },
      },
    };
  }

  static async decrypt(
    encryptedText: any,
    columnName = 'data',
  ): Promise<string> {
    try {
      if (!encryptedText) {
        return null
      }

      const { decryptedvalue } = await EncryptionDecryption.query()
        .select(
          raw(`convert_from(decrypt(?::bytea, ?, 'aes'), 'SQL_ASCII') as decryptedValue`, [
            encryptedText,
            process.env.PSQL_ENCRYPTION_KEY,
          ]),
        )
        .first();

      return decryptedvalue;
    } catch (error) {
      // If decryption fails, it may be because old data was not encrypted.
      // In such cases, the encrypted text itself is returned to maintain backward compatibility.
      // logger.error(`Error while decrypting ${columnName}:: ${error.message}`);

      return encryptedText;
    }
  }

  static async encrypt(text: any, columnName = 'data'): Promise<string> {
    try {
      if (text && text !== undefined && text !== '' && text !== null) {
        const { encryptvalue }: any = await EncryptionDecryption.query()
          .select(
            raw(`encrypt(?::bytea, ?::bytea, 'aes'::text) as encryptValue`, [
              text,
              process.env.PSQL_ENCRYPTION_KEY,
            ]),
          )
          .first();

        const hexString = encryptvalue.toString('hex');

        const finalString = hexString.toString();

        return `\\x${finalString}`;
      }

      return text;
    } catch (error) {
      // If decryption fails, it may be because old data was not encrypted.
      // In such cases, the encrypted text itself is returned to maintain backward compatibility.
      logger.error(`Error while decryptingg ${columnName}:: ${error.message}`);

      return text;
    }
  }

  static async decryptAndEncrypt(text: any, columnName = 'data'): Promise<string> {
    try {
      if(text){
        const value = await this.decrypt(text)
        const encryptedValue = await this.encrypt(value)

        return encryptedValue;
      }

      return text
    } catch (error) {
      // If decryption fails, it may be because old data was not encrypted.
      // In such cases, the encrypted text itself is returned to maintain backward compatibility.
      logger.error(`Error while decryptAndEncrypt ${columnName}:: ${error.message}`);

      return text;
    }
  }
}
