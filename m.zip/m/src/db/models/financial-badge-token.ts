import { Model } from 'objection';

export class FinancialBadgeToken extends Model {
  tokenSymbol:string;
  financialBadgeId: string;

  static get tableName() {
    return 'financial_badge_token';
  }

  static get idColumn() {
    return ['financial_badge_id', 'token_symbol'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        token_symbol: { type: 'string' },
        financial_badge_id: { type: 'string' },
      },
    };
  }
}
