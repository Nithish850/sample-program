import { Model } from 'objection';
import { CardTransaction } from './card-transaction';
import { TransactionNote } from './transaction-note';
import { EncryptionDecryption } from './encryption-decryption';
import { offchainTransactionEncryptedColumns } from 'src/utils/encryption';

export class OffchainTransaction extends Model {
  offchain_transaction_id: string;
  tenant_customer_accounts_id: string;
  tenant_id: string;
  id: string;
  address_id: string;
  app_id: string;
  transaction_amount: string;
  code: string;
  deleted_at: string;
  currency: string;
  identity_id: string;
  transfer_method_id: string;
  origin_address: string;
  destination_address: string;
  external_reference: string;
  metadata: string;
  status: string;
  transaction_details: string;
  transaction_hash: string;
  type: string;
  transaction_type: string;
  full_name: string;
  fullName: string;
  transaction_method: string;
  sender_namespace: string;
  receiver_namespace: string;
  senderNamespace: string;
  receiverNamespace: string;
  tenant_namespace: string;
  tenantNamespace: string;
  rule_status: string;
  created_at: string;
  updated_at: string;
  tokenSymbol: string;
  memo: string;
  memo_hex: string;
  ipAddress: string;

  static get tableName() {
    return 'offchain_transaction';
  }

  static get idColumn() {
    return 'offchain_transaction_id';
  }

  async $afterFind() {
    const fullName = await EncryptionDecryption.decrypt(this.fullName)
    this.fullName = fullName
    const senderNamespace = await EncryptionDecryption.decrypt(this.senderNamespace)
    this.senderNamespace = senderNamespace
    const receiverNamespace = await EncryptionDecryption.decrypt(this.receiverNamespace)
    this.receiverNamespace = receiverNamespace
    const ipAddress = await EncryptionDecryption.decrypt(this.ipAddress)
    this.ipAddress = ipAddress
    const tenantNamespace = await EncryptionDecryption.decrypt(this.tenantNamespace)
    this.tenantNamespace = tenantNamespace
  }

  async $beforeInsert() {
    for (const field of offchainTransactionEncryptedColumns) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.encrypt(this[field]) || null;
      }
    }
    this.created_at = new Date().toISOString();
  }

  async $beforeUpdate() {
    for (const field of offchainTransactionEncryptedColumns) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]) || null;
      }
    }
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_customer_accounts_id: { type: 'string' },
        tenant_id: { type: 'string' },
        id: { type: 'string' },
        app_id: { type: 'string' },
        transaction_amount: { type: 'string' },
        code: { type: 'string' },
        currency: { type: 'string' },
        identity_id: { type: 'string' },
        destination_address: { type: 'string' },
        external_reference: { type: 'string' },
        metadata: { type: 'object' },
        status: { type: 'string' },
        type: { type: 'string' },
        transaction_type: { type: 'string' },
        full_name: { type: 'string' },
        transaction_method: { type: 'string' },
        sender_namespace: { type: 'string' },
        receiver_namespace: { type: 'string' },
        tenant_namespace: { type: 'string' },
        transaction_hash: { type: 'string' },
        rule_status: { type: 'string' },
        token_symbol: { type: 'string' },
      },
    };
  }

  /**
   * Relate the OffchainTransaction and TransactionNote with the help of OFFCHAIN_TRANSACTION_ID
   * Relate the OffchainTransaction and CardTransaction with the help of OFFCHAIN_TRANSACTION_ID
   */
  static get relationMappings() {
    return {
      transaction_notes: {
        relation: Model.HasManyRelation,
        modelClass: TransactionNote,
        join: {
          from: 'offchain_transaction.offchainTransactionId',
          to: 'transaction_notes.id',
        },
      },
      fiatTransaction: {
        relation: Model.HasOneRelation,
        modelClass: CardTransaction,
        filter: (query) => query.select('cardTransactionId as fiatTransactionId', 'status as fiatStatus', 'settlement_date'),
        join: {
          from: 'offchain_transaction.offchainTransactionId',
          to: 'card_transaction.offchainTransactionId',
        },
      }
    };
  }
}
