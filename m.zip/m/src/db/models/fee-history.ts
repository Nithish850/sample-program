import { Model } from "objection";

export class FeeHistory extends Model {
  createdAt: string;
  updatedAt: string;
  feeHistoryId: string;
  tenantId: string;
  contractId: string;
  updatedBy: string;
  tokenSymbol: string;
  onchainFee: number;
  gasFee: number;
  withdrawFee: object;
  depositFee: object;
  // offchainFee: number;
  // archWithdrawFee: number;
  // wireWithdrawFee: number;
  // iwireWithdrawFee: number;
  // archDepositFee: number;
  // wireDepositFee: number;
  // iwireDepositFee: number;

  static get tableName() {
    return "fee_history";
  }

  static get idColumn() {
    return 'fee_history_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_id', 'contract_id', 'updated_by', 'token_symbol' ],
      properties: {
        tenant_id: { type: 'string' },
        contract_id: { type: 'string' },
        updated_by: { type: 'string' },
        token_symbol: { type: 'string' },
        onchain_fee: { type: 'number' },
        gas_fee: { type: 'number' },
        withdraw_fee: { type: 'object' },
        deposit_fee: { type: 'object' },
        // offchain_fee: { type: 'number' },
        // ach_withdraw_fee: { type: 'number' },
        // wire_withdraw_fee: { type: 'number' },
        // iwire_withdraw_fee: { type: 'number' },
        // ach_deposit_fee: { type: 'number' },
        // wire_deposit_fee: { type: 'number' },
        // iwire_deposit_fee: { type: 'number' },
      },
    };
  }
}
