import { Model } from "objection";
import { EncryptionDecryption } from "./encryption-decryption";

export class SanctionReports extends Model {
  nationality?: string
  residenceOfJurisdiction?: any
  countryOfRegistration?: string
  taxCountry?: string
  principalCountryOfBusiness?: string
  name?: string
  address?: any
  email: string
  phone: string
  dob: string
  placeOfBirth: string

  static get tableName() {
    return 'sanction_reports';
  }

  static get idColumn() {
    return 'sanction_report_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        sanction_report_id: { type: 'string' },
        is_tenant: { type: 'boolean' },
        nationality: { type: 'string' },
        residence_of_jurisdiction: { type: 'string' },
        country_of_registration: { type: 'string' },
        tax_country: { type: 'string' },
        principal_country_of_business: { type: 'string' },
        name: { type: 'string' },
        address: { type: 'string' },
        email: { type: 'string' },
        phone: { type: 'string' },
        dob: { type: 'string' },
        place_of_birth: { type: 'string' }
      }
    }
  }

  async $afterFind() {
    const nationality = await EncryptionDecryption.decrypt(this.nationality)
    const residenceOfJurisdiction = await EncryptionDecryption.decrypt(this.residenceOfJurisdiction)
    const countryOfRegistration = await EncryptionDecryption.decrypt(this.countryOfRegistration)
    const taxCountry = await EncryptionDecryption.decrypt(this.taxCountry)
    const principalCountryOfBusiness = await EncryptionDecryption.decrypt(this.principalCountryOfBusiness)
    const name = await EncryptionDecryption.decrypt(this.name)
    const address = await EncryptionDecryption.decrypt(this.address)
    const email = await EncryptionDecryption.decrypt(this.email)
    const phone = await EncryptionDecryption.decrypt(this.phone)
    const dob = await EncryptionDecryption.decrypt(this.dob)
    const placeOfBirth = await EncryptionDecryption.decrypt(this.placeOfBirth)

    this.nationality = nationality
    this.residenceOfJurisdiction = residenceOfJurisdiction
    this.countryOfRegistration = countryOfRegistration
    this.taxCountry = taxCountry
    this.principalCountryOfBusiness = principalCountryOfBusiness
    this.address = address
    this.name = name
    this.email = email
    this.phone = phone
    this.dob = dob
    this.placeOfBirth = placeOfBirth

  }

}