import { Model } from 'objection';

export class CustomContracts extends Model {
  contractName: string;
  contractOwner: string;
  privateKey: string;
  privateKeyIV: string;
  implementationAddress: string;
  proxyAddress: string;
  storageAddress: string;
  eventEmitterAddress: string;
  isActive: string;
  tenantId: string;
  contractAbi: object;

  static get tableName() {
    return 'custom_contracts';
  }

  static get idColumn() {
    return 'public_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        contract_name: { type: 'string' },
        contract_owner: { type: 'string' },
        private_key: { type: 'string' },
        private_key_iv: { type: 'string' },
        implementation_address: { type: 'string' },
        proxy_address: { type: 'string' },
        storage_address: { type: 'string' },
        event_emitter_address: { type: 'string' },
        is_active: { type: 'boolean' },
        tenant_id: { type: 'string' },
        contract_abi: { type: 'object' },
      },
    };
  }
}
