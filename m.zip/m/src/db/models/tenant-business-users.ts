import { Model } from 'objection';
import { Tenants } from './tenant';
import { BusinessUsers } from './business_users';

export class TenantBusinessUsers extends Model {
  tenant_business_user_id: string;
  tenant_id: string;
  business_user_id: string;
  is_forgotten?:boolean;
  badge_id?:string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'tenant_business_users';
  }

  static get idColumn() {
    return 'tenant_business_user_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_business_user_id: { type: 'string' },
        tenant_id: { type: 'string' },
        business_user_id: { type: 'string' },
      },
    };
  }

  /**
   * Relate the TenantBusinessUsers and Tenants with the help of TENANT_ID
   * Relate the TenantBusinessUsers and BusinessUsers with the help of BUSINESS_USER_ID
   */
  static get relationMappings() {
    return {
      tenants: {
        relation: Model.HasOneRelation,
        modelClass: Tenants,
        join: {
          from: 'tenants.tenant_id',
          to: 'tenant_business_users.tenant_id',
        },
      },

      customer_accounts: {
        relation: Model.HasOneRelation,
        modelClass: BusinessUsers,
        join: {
          from: 'tenant_business_users.business_user_id',
          to: 'customer_accounts.business_user_id',
        },
      },

    }
  }
}
