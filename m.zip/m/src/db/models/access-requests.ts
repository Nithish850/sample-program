import { Model } from 'objection';

export class AccessRequests extends Model {
  created_at: string;
  updated_at: string;
  leadStatus!: string;
  activationCode: string;
  email: string;

  static get tableName() {
    return 'access_requests';
  }

  static get idColumn() {
    return 'access_requests_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['email'],
      properties: {
        access_requests_id: { type: 'string' },
        email: { type: 'string' },
        lead_status: { type: 'string', default: 'PENDING' },
        activation_code: { type: 'string' },
        is_activated: { type: 'boolean', default: false },
        device_type: { type: 'string' },
        device_token: { type: 'string' },
      },
    };
  }
}
