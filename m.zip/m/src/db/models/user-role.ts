import { Model } from 'objection';
import { Roles } from './role';

export class UserRoles extends Model {

  created_at: string;
  updated_at: string;
  role_id: string;
  tenant_id: string;
  user_id: string;

  static get tableName() {
    return 'user_roles';
  }

  static get idColumn() {
    return 'user_roles_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'role_id', 'tenant_id' ],
      properties: {
        user_roles_id: { type: 'string' },
        user_id: { type: 'string' },
        role_id: { type: 'string' },
        tenant_id: { type: 'string' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  /**
   * Relate the Roles and UserRoles with the help of ROLE_ID
   */
  static get relationMappings() {
    return {
      roles: {
        relation: Model.HasManyRelation,
        modelClass: Roles,
        join: {
          from: 'user_roles.roleId',
          to: 'roles.roleId',
        },
      }
    }
  }
}
