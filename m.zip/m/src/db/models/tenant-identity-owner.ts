import { Model } from "objection";
import { EncryptionDecryption } from "./encryption-decryption";

export class TenantIdentityOwner extends Model {

  firstName?: string;
  lastName?: string;
  email?: string
  phoneNumber?: string
  dob?: string;
  address?: any;
  tax?: any
  gender?: string

  static get tableName() {
    return 'tenant_identity_owner';
  }

  static get idColumn() {
    return 'tenant_identity_owner_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_identity_owner_id: { type: 'string' },
        tenant_id: { type: 'string' },
        dss_type_id: { type: 'string' },
        tenant_owner_dss_id: { type: 'string' },
        first_name: { type: 'string' },
        last_name: { type: 'string' },
        email: { type: 'string' },
        phone_number: { type: 'string' },
        dob: { type: 'string' },
        address: { type: 'object' },
        tax: { type: 'object' },
        documents: { type: 'array' },
      }
    }
  }

  async $afterFind() {
    const firstName = await EncryptionDecryption.decrypt(this.firstName)
    const lastName = await EncryptionDecryption.decrypt(this.lastName)
    const email = await EncryptionDecryption.decrypt(this.email)
    const phoneNumber = await EncryptionDecryption.decrypt(this.phoneNumber)
    const dob = await EncryptionDecryption.decrypt(this.dob)
    const address = await EncryptionDecryption.decrypt(this.address)
    const tax = await EncryptionDecryption.decrypt(this.tax)
    const gender = await EncryptionDecryption.decrypt(this.gender)

    this.firstName = firstName
    this.lastName = lastName
    this.email = email
    this.phoneNumber = phoneNumber
    this.dob = dob
    this.address = address
    this.tax = tax
    this.gender = gender

  }
}