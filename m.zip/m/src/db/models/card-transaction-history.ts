import { Model } from 'objection';

export class CardTransactionHistory extends Model {
  created_at: string;
  updated_at: string;
  details: object;
  status: string;
  cardTransactionId: string;
  cardTransactionHistoryId: string;
  description:string;

  static get tableName() {
    return 'card_transaction_history';
  }

  static get idColumn() {
    return 'card_transaction_history_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        card_transaction_history_id: { type: 'string' },
        card_transaction_id: { type: 'string' },
        status: { type: 'string' },
        description: { type: 'string' },
        details: { type: 'object' },
      },
    };
  }
}
