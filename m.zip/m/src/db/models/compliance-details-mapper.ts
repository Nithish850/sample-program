import { Model } from 'objection';

export class ComplianceDetailsMapper extends Model {
  compliance_details_id: string;
  customer_account_id: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'compliance_details_mapper';
  }

  static get idColumn() {
    return 'compliance_details_mapper_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        compliance_details_id: { type: 'string' },
        customer_account_id: { type: 'string' },
      },
    };
  }
}
