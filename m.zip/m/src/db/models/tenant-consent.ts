import { Model } from "objection";

export class TenantConsent extends Model {
  tenant_consent_id: string;
  tenant_id: string;
  dss_vendor_id: string;
  consent_status: string;
  consent_version: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return "tenant_consent";
  }

  static get idColumn() {
    return [ "tenant_consent_id" ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
