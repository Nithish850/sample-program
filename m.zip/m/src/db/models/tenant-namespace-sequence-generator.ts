import { Model } from 'objection';
export class TenantNamespaceSequenceGenerator extends Model {
  tenantId: string;
  tenantNamespace: string;
  count: number;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'tenant_namespace_sequence_generator';
  }

  static get idColumn() {
    return 't_namespace_sequence_generator_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        t_namespace_sequence_generator_id: { type: 'string' },
        tenant_id: { type: 'string' },
        tenant_namespace: { type: 'string' },
        count: { type: 'number' },
        created_at: { type: 'string' },
        updated_at: { type: 'string' },
      },
    };
  }
}
