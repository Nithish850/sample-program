import { Model } from 'objection';

export class ComplianceLogs extends Model {
  compliance_details_id: string;
  dss_type_id: string;
  compliance_response: object;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'compliance_logs';
  }

  static get idColumn() {
    return 'compliance_logs_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        compliance_details_id: { type: 'string' },
        dss_type_id: { type: 'string' },
        compliance_response: { type: 'object' },
      },
    };
  }
}
