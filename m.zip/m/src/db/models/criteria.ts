import { Model } from 'objection';

export class  Criteria extends Model {
  criteriaId: string;
  criteriaName: string;
  criteria: object;
  description: string;
  tenantId: string;
  createdBy: string;
  updatedBy: string;
  isActive: boolean;

  static get tableName() {
    return ' criteria';
  }

  static get idColumn() {
    return ' criteria_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'criteria_name', 'criteria' ],
      properties: {
        criteria_id: { type: 'string' },
        criteria_name: { type: 'string', minLength: 3, maxLength: 10 },
        criteria: { type: 'object' },
        description: { type: 'string', maxLength: 25 },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
        updated_by: { type: 'string' },
        is_active: { type: 'boolean' },
      },
    };
  }
}