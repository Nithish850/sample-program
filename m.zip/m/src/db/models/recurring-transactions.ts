import { Model } from 'objection';

export class RecurringTransactions extends Model {
  recurringTransactionId: string;
  bulkTransactionId: string;
  occurrenceStatus: string;
  scheduledTime: string;
  processedTime: string;
  rejectReason: string;
  freezedAmount: string;
  isFundFreezed:string;
  fundFreezed: string;
  fundUnfreezed:string;
  createdAt: string;
  updatedAt: string;

  static get tableName() {
    return 'recurring_transactions';
  }

  static get idColumn() {
    return 'recurring_transaction_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        recurring_transaction_id: { type: 'string' },
        bulk_transaction_id: { type: 'string' },
        occurrence_status: { type: 'string' },
        scheduled_time: { type: 'string' },
        processed_time: { type: 'string' },
        reject_reason: { type: 'string' },
        freezed_amount: { type: 'string' },
        is_fund_freezed: { type: 'boolean' },
        fund_freezed: { type: 'boolean' },
        fund_unfreezed: { type: 'boolean' },
      },
    };
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }
}
