import { Model } from 'objection';
export class AccountCategory extends Model {
  subcategoryName: string;
  createdBy: string;
  accountCategoryId: string;
  static get tableName() {
    return 'account_category';
  }

  static get idColumn() {
    return 'account_category_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['subcategoryName'],
      properties: {
        account_category_id: { type: 'string' },
        subcategory_name: { type: 'string' },
        created_by: { type: 'string' },
      },
    };
  }
}
