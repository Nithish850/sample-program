import { Model } from 'objection';
import { TenantTokenRequest } from './tenant-token-request';
import { TenantContractMapper } from './tenant-contract-mapper';

export class ContractStore extends Model {
  createdAt: string;
  updatedAt: string;
  contractAddress: string;
  implementationAddress: string;
  proxyAddress: string;
  storageAddress: string;
  abi: object;
  contractId: string;
  symbol: string;
  tokenName: string;
  status: string;
  tokenType: string;
  accountAddress: string;
  currency: string;
  account_address: string;
  proxy_address: string;
  implementation_address: string;
  storage_address: string;
  /*
    isVisible is added to classify the contract store table between tokens and event emitter contracts.
    For event emitter contract rows, isVisible will be false
  */
  isVisible: boolean;

  static get tableName() {
    return 'contract_store';
  }

  static get idColumn() {
    return 'contract_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
    if (this.account_address) {
      this.account_address = this.account_address.toLowerCase();
    }
    if (this.proxy_address) {
      this.proxy_address = this.proxy_address.toLowerCase();
    }
    if (this.implementation_address) {
      this.implementation_address = this.implementation_address.toLowerCase();
    }
    if (this.storage_address) {
      this.storage_address = this.storage_address.toLowerCase();
    }
  
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [
        'symbol',
        'abi',
        'implementation_address',
        'currency',
        'token_type',
      ],
      // required: [ 'symol', 'abi', 'contract_address', 'currency', 'token_type' ],
      properties: {
        contract_address: { type: 'string' },
        proxy_address: { type: 'string' },
        storage_address: { type: 'string' },
        implementation_address: { type: 'string' },
        contract_id: { type: 'string' },
        symbol: { type: 'string' },
        abi: { type: 'object' },
        token_name: { type: 'string' },
        status: { type: 'string' },
        token_type: { type: 'string' },
        is_visible: { type: 'boolean' },
      },
    };
  }

  static get relationMappings() {
    return {
      token_request: {
        relation: Model.HasOneRelation,
        modelClass: TenantTokenRequest,
        filter: (query: any) =>
          query.select(
            'symbol',
            'name',
            'currency',
            'status',
            'logo_details',
            'deposit_fee',
            'withdraw_fee',
            'onchain_fee',
            'created_at',
            'token_type',
          ),
        join: {
          from: 'contract_store.symbol',
          to: 'tenant_token_request.symbol',
        },
      },
      tenant_contract_mapper: {
        relation: Model.HasOneRelation,
        modelClass: TenantContractMapper,
        join: {
          from: 'contract_store.contract_id',
          to: 'tenant_contract_mapper.contract_id',
        },
      },
    };
  }
}
