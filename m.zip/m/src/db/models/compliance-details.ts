import { Model } from 'objection';

export class ComplianceDetails extends Model {
  compliance_details_id: string;
  created_at: string;
  updated_at: string;
  risk_profile: object;
  finclusive_risk_profile: object;
  risk_score: object;
  reasons: object;
  rules:object;
  customer_account_id: string;
  compliance_risk_assessment_reference_id: string;
  pep_status: string;
  sanction_screening: string;
  user_risk_rating: string;
  country_risk: string;
  country_location_confidence: string;
  metro_area_location_confidence: string;
  ip_trust_score: string;
  ip_fraudscore: string;
  email_fraudscore: string;
  phone_number_trust_score: string;
  user_risk_rating_components: object;


  static get tableName() {
    return 'compliance_details';
  }

  static get idColumn() {
    return 'compliance_details_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        compliance_details_id: { type: 'string' },
        risk_profile: { type: 'object' },
        finclusive_risk_profile: { type: 'object' },
        risk_score: { type: 'object' },
        reasons: { type: 'object' },
        rules: { type: 'object' },
        compliance_risk_assessment_reference_id: { type: 'string' },
        pep_status: { type: 'string' },
        sanction_screening: { type: 'string' },
        user_risk_rating: { type: 'string' },
        country_risk: { type: 'string' },
        country_location_confidence: { type: 'string' },
        metro_area_location_confidence: { type: 'string' },
        ip_trust_score: { type: 'string' },
        phone_number_trust_score: { type: 'string' },
        ip_fraudscore: { type: ['string', 'null'] },
        user_risk_rating_components: { type: 'object' },
        email_fraudscore: { type: ['string', 'null'] },
      },
    };
  }
}
