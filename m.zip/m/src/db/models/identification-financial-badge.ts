import { Model } from 'objection';
import { Badge } from './badge';

export class IdentificationFinancialBadge extends Model {
  createdAt: string;
  updatedAt: string;
  identificationBadgeId: string;
  financialBadgeId: string;

  static get tableName() {
    return 'identification_financial_badge';
  }

  static get idColumn() {
    return ['identification_badge_id', 'financial_badge_id'];
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        identification_badge_id: { type: 'string' },
        financial_badge_id: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      fBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName', 'badgeType', 'userGroup', 'badgeDescription', 'badgeSymbolRef'),
        join: {
          from: 'identification_financial_badge.financialBadgeId',
          to: 'badge.badgeId',
        },
      },
      iBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName', 'badgeType', 'userGroup', 'badgeDescription', 'badgeSymbolRef'),
        join: {
          from: 'identification_financial_badge.identificationBadgeId',
          to: 'badge.badgeId',
        },
      },
    }
  }
}
