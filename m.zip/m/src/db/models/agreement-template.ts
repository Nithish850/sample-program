import { Model } from 'objection';

export class AgreementTemplate extends Model {
  template: string;
  type: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'agreement_template';
  }

  static get idColumn() {
    return 'agreement_template_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'template' ],
      properties: {
        agreement_template_id: { type: 'string' },
        template: { type: 'string' },
        type: { type: 'string' },
      },
    };
  }
}
