import { Model } from "objection";

export class CountryRiskRating extends Model {
  created_at: string;
  updated_at: string;
  countryRiskRatingId: string;
  country: string;
  country_code: string;
  risk_score: string;
  risk_rating: string;
  ul_override: string;
  rationale: string;
  ulOverride: string;

  static get tableName() {
    return "country_risk_rating";
  }

  static get idColumn() {
    return [ "country_risk_rating_id" ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'country', 'country_code', 'risk_score' ],
      properties: {
        country_risk_rating_id: { type: 'string' },
        country: { type: 'string' },
        country_code: { type: 'string' },
        risk_score: { type: 'string' },
        risk_rating: { type: 'string' },
        ul_override: { type: 'string' },
        rationale: { type: 'string' },
      },
    };
  }
}
