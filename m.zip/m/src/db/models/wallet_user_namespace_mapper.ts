import { Model } from "objection";
import { Namespace } from "./namespace";

export class WalletUserNamespaceMapper extends Model  {

  custom_namespace:string
  provider:string
  namespaceId:string

  static get tableName() {
    return 'wallet_user_namespace_mapper';
  }

  static get idColumn() {
    return 'namespace_mapper_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        namespace_mapper_id: { type: 'string' },
        custom_namespace: { type: 'string' },
        namespace_id: { type: 'string' },
        provider: { type: 'string' },
      },
    };
  }

  /**
   * Relate the TransactionNote and Transaction with the help of id
   */
  static get relationMappings() {
    return {
      namespace: {
        relation: Model.HasOneRelation,
        modelClass: Namespace,
        join: {
          to: 'wallet_user_namespace_mapper.namespaceId',
          from: 'namespaces.namespaceId',
        },
      },
    };
  }

}