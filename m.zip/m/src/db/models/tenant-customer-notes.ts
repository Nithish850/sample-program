import { Model } from 'objection';
import { Users } from './user';

export class TenantCustomerNotes extends Model {
  created_at: string;
  comment: string;
  created_by: string;
  attachment: string;
  id: string;

  static get tableName() {
    return 'tenant_customer_notes';
  }

  static get idColumn() {
    return 'tenant_customer_note_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'comment' ],
      properties: {
        id: { type: 'string' },
        comment: { type: 'string' },
        createdBy: { type: 'string' },
        attachment: { type: 'object' },
      },
    };
  }

  static get relationMappings() {
    return {
      created_by: {
        relation: Model.HasOneRelation,
        modelClass: Users,
        filter: (query) => query.select('user_name'),
        join: {
          from: 'tenant_customer_notes.createdBy',
          to: 'users.userId'
        }
      }
    }
  }
}
