import { Model } from 'objection';
import { BusinessUsers } from './business_users';

export class BusinessUserNamespaces extends Model {

  businessUserNamespace: string;
  account_address: string;
  public_key: string;
  business_user_id: string;
  accountAddress: string;
  businessUserId: string;

  // Account status space from business_user_namespaces table
  accountStatus: string;

  $beforeInsert() {
    if (this.account_address) {
      this.account_address = this.account_address.toLowerCase();
    }
  }

  static get tableName() {
    return 'business_user_namespaces';
  }

  static get idColumn() {
    return 'business_user_namespace_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'business_user_namespace', 'account_address' ],
      properties: {
        business_user_namespace_id: { type: 'string' },
        business_user_namespace: { type: 'string' },
        account_address: { type: 'string' },
        business_user_id: { type: 'string' },
      },
    };
  }

  /**
   * Relate the BusinessUsers and BusinessUserNamespaces with the help of business_user_id
   */
  static get relationMappings() {
    return {
      roles: {
        relation: Model.HasOneRelation,
        modelClass: BusinessUsers,
        join: {
          from: 'business_user_namespaces.business_user_id',
          to: 'business_users.business_user_id',
        },
      }
    }
  }
}
