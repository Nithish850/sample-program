import { Model } from 'objection';

export class CodeTenantMapper extends Model {
  coderMasterId: string;
  tenantId: string;
  tenantMessage: object;
  isActive: boolean;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'code_tenant_mapper';
  }

  static get idColumn() {
    return 'code_tenant_mapper_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();

  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        code_master_id: { type: 'string' },
        tenant_id: { type: 'string' },
        tenant_message: { type: 'string' },
        is_active: { type: 'boolean' },

      },
    };
  }

}
