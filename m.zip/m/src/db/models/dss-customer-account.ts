import { Model } from 'objection';

export class DssCustomerAccount extends Model {
  created_at: string;
  updated_at: string;
  customerAccountId: string;
  dssId: string;
  dssTypeId: string;
  static get tableName() {
    return 'dss_customer_accounts';
  }

  static get idColumn() {
    return [ 'dss_type_id', 'customer_account_id' ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        dss_type_id: { type: 'string' },
        customer_account_id: { type: 'string' },
        dss_id: { type: 'string' },
      },
    };
  }
}
