import { Model } from 'objection';
import { Attributes } from './attributes';

export class UniqueAttributes extends Model {
  attributeId!: string;
  mandatoryBadge: boolean;
  mandatoryOnboard: boolean;
  tenantId!: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'unique_identifiers';
  }

  static get idColumn() {
    return 'attribute_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['attributeId', 'tenantId'],
      properties: {
        attribute_id: { type: 'string' },
        mandatory_badge: { type: 'boolean' },
        mandatory_onboard: { type: 'boolean' },
        tenant_id: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      attribute: {
        relation: Model.BelongsToOneRelation,
        modelClass: Attributes,
        join: {
          from: 'unique_identifiers.attributeId',
          to: 'attributes.attributeId',
        },
      },
    };
  }
}
