import { Model, } from "objection";
import { SecretHistory } from "./secret-history";

export class Secret extends Model {
  secret_id: number;
  clientId: string;
  apiKey: string;
  tenantId: string;
  createdBy: string;
  updatedBy?: string;

  static get tableName() {
    return 'secrets';
  }

  static get idColumn() {
    return 'secret_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['clientId', 'apiKey', 'tenantId', 'createdBy'],
      properties: {
        secret_id: { type: 'string' },
        clientId: { type: 'string' },
        apiKey: { type: 'string' },
        tenantId: { type: 'string' },
        createdBy: { type: 'string' },
        updatedBy: { type: 'string' },
      },
    };
  }

  async $beforeInsert() {
    const existingRecordWithClientId = await Secret.query().where('clientId', this.clientId).first();
    const existingRecordWithApiKey = await Secret.query().where('apiKey', this.apiKey).first();

    if (existingRecordWithClientId || existingRecordWithApiKey) {

      return { errors: [{ type: 'validation error', message: 'client id should be unique' }] }
    }
  }

  static get relationMappings() {
    return {

      secretHistory: {
        relation: Model.HasManyRelation,
        modelClass: SecretHistory,
        filter: (query: any) => query.select('secretHistoryId','description','createdAt','updatedAt','createdBy'),
        join: {
          from: 'secrets.secretId',
          to: 'secret_history.secretId',
        },
      },
    }}

}