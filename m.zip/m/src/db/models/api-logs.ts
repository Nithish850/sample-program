import { Model } from 'objection';
export class ApiLog extends Model {
  apiLogId: string;
  requestHeaders: object;
  requestBody: object;
  createdBy: string;
  tenantId: string;
  static get tableName() {
    return 'api_log';
  }

  static get idColumn() {
    return 'api_log_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        api_log_id: { type: 'string' },
        request_headers: { type: 'object' },
        request_body: { type: 'object' },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
      },
    };
  }
}
