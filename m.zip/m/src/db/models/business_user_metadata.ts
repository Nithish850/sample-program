import { Model } from 'objection';
import { ERROR_MESSAGE, ERROR_TYPE } from '../../utils/constant';
import { BusinessUsers } from './business_users';
import { EncryptionDecryption } from './encryption-decryption';

export class BusinessUserMetadata extends Model {
  company_address: object;
  email: string;
  taxId: string;
  legalName: string;
  phone: string;
  bankVerificationNumber: string;
  businessEntityName: string
  entityBeneficialOwners: string
  individualBeneficialOwners: string
  controlPersons: string
  registeredOfficeAddress: string
  signatories: string;
  companyAddress: string;

  static get tableName() {
    return 'business_user_metadata';
  }

  static get idColumn() {
    return 'business_user_metadata_id';
  }

  async $afterFind() {
    const companyAddress = await EncryptionDecryption.decrypt(this.companyAddress)

    this.companyAddress = companyAddress
    const email = await EncryptionDecryption.decrypt(this.email)

    this.email = email
    const taxId = await EncryptionDecryption.decrypt(this.taxId)

    this.taxId = taxId
    const legalName = await EncryptionDecryption.decrypt(this.legalName)

    this.legalName = legalName
    const phone = await EncryptionDecryption.decrypt(this.phone)

    this.phone = phone
    const businessEntityName = await EncryptionDecryption.decrypt(this.businessEntityName)

    this.businessEntityName = businessEntityName
    const bankVerificationNumber = await EncryptionDecryption.decrypt(this.bankVerificationNumber)

    this.bankVerificationNumber = bankVerificationNumber
    const entityBeneficialOwners = await EncryptionDecryption.decrypt(this.entityBeneficialOwners)

    this.entityBeneficialOwners = typeof entityBeneficialOwners === 'string' ? JSON.parse(entityBeneficialOwners):entityBeneficialOwners

    const individualBeneficialOwners = await EncryptionDecryption.decrypt(this.individualBeneficialOwners)

    this.individualBeneficialOwners = typeof individualBeneficialOwners === 'string'? JSON.parse(individualBeneficialOwners):individualBeneficialOwners
    const controlPersons = await EncryptionDecryption.decrypt(this.controlPersons)

    this.controlPersons = typeof controlPersons === 'string' ? JSON.parse(controlPersons): controlPersons
    const registeredOfficeAddress = await EncryptionDecryption.decrypt(this.registeredOfficeAddress)

    this.registeredOfficeAddress = typeof registeredOfficeAddress === 'string' ? JSON.parse(registeredOfficeAddress):registeredOfficeAddress
    const signatories = await EncryptionDecryption.decrypt(this.signatories)

    this.signatories = typeof signatories === 'string' ? JSON.parse(signatories) :signatories

  }

  async $beforeUpdate() {
    const errorsArray = [];

    if(this.bankVerificationNumber) {
      const isBankDetails: any = await BusinessUserMetadata.query().findOne({ bank_verification_number: this.bankVerificationNumber });

      if (isBankDetails && Object.keys(isBankDetails).length != 0) {
        const { errors } = this.checkDuplicateEntry('bank_verification_number', isBankDetails.bankVerificationNumber, this.bankVerificationNumber);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if(this.taxId) {
      const isTaxIdDetails: any = await BusinessUserMetadata.query().findOne({ tax_id: this.taxId });

      if (isTaxIdDetails && Object.keys(isTaxIdDetails).length != 0) {
        const { errors } = this.checkDuplicateEntry('tax_id', isTaxIdDetails.taxId, this.taxId);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if(errorsArray.length) {
      throw errorsArray;
    }
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'company_address', 'email', 'tax_id', 'legal_name', 'phone' ],
      properties: {
        business_user_metadata_id: { type: 'string' },
        business_user_id: { type: 'string' },
        company_address: { type: 'object' },
        email: { type: 'string' },
        tax_id: { type: 'string' },
        legal_name: { type: 'string' },
        phone: { type: 'string' },
      },
    };
  }

  /**
   * Relate the BusinessUsers and BusinessUserMetadata with the help of business_user_id
   */
  static get relationMappings() {
    return {
      business_user_metadata: {
        relation: Model.HasOneRelation,
        modelClass: BusinessUsers,
        join: {
          from: 'business_users.business_user_id',
          to: 'business_user_metadata.business_user_id',
        },
      },
    }
  }

  checkDuplicateEntry(keyName, item, itemToCompare) {
    const errors = {};
    const type = ERROR_TYPE.DUPLICATE;

    if (item === itemToCompare && keyName === 'bank_verification_number') {
      const message = ERROR_MESSAGE.DUPLICATE_BUSINESS_BANK_VERIFICATION;

      Object.assign(errors, { type, message })
    }
    if (item === itemToCompare && keyName === 'tax_id') {
      const message = ERROR_MESSAGE.DUPLICATE_BUSINESS_TAX_ID;

      Object.assign(errors, { type, message })
    }

    return { errors };
  }
}
