import { Model } from 'objection';

export class CustomContractRequests extends Model {
  contractName: string;
  contractCode: string;
  tokenSymbol: string;
  deployStatus: string;
  contractAddress: string;
  proxyAddress: string;
  version: number;
  tenantId: string;
  reviewedAt: string;
  reviewedBy: string;
  deployedAt: string;

  static get tableName() {
    return 'custom_contract_requests';
  }

  static get idColumn() {
    return 'public_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['contractName', 'contractCode', 'tokenSymbol'],
      properties: {
        contract_name: { type: 'string' },
        contract_code: { type: 'string' },
        token_symbol: { type: 'string' },
        deploy_status: { type: 'string' },
        contract_address: { type: 'string' },
        proxy_address: { type: 'string' },
        version: { type: 'number' },
        tenant_id: { type: 'string' },
        reviewed_at: { type: 'string' },
        reviewed_by: { type: 'string' },
        deployed_at: { type: 'string' },
      },
    };
  }
}
