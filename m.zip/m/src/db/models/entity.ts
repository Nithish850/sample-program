import { Model } from 'objection';

export class Entities extends Model {
  entityName: string;
  entity_description: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'entities';
  }

  static get idColumn() {
    return 'entity_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        entity_name: { type: 'string' },
        entity_description: { type: 'string' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
