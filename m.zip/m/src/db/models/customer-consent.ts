import { Model } from "objection";

export class CustomerConsent extends Model {
  customer_consent_id: string;
  customer_account_id: string;
  dss_vendor_id: string;
  consent_status: string;
  consent_version: string;
  created_at: string;
  updated_at: string;
  tenant_id: string;

  static get tableName() {
    return "customer_consent";
  }

  static get idColumn() {
    return [ "customer_consent_id" ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
