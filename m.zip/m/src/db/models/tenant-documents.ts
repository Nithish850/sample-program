import { Model } from 'objection';

export class TenantDocuments extends Model {
  tenant_document_id: string;
  tenant_id: string;
  document_type: string;
  file_name: string;
  content: string;
  country_code: string;
  type: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'tenant_documents';
  }

  static get idColumn() {
    return 'tenant_document_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'document_type', 'file_name', 'content', 'country_code' ],
      properties: {
        tenant_document_id: { type: 'string' },
        tenant_id: { type: 'string' },
        document_type: { type: 'string' },
        file_name: { type: 'string' },
        content: { type: 'string' },
        country_code: { type: 'string' },
        type: { type: 'string' },
      },
    };
  }
}
