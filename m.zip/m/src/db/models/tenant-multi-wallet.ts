import { Model } from 'objection';

export class TenantMultiWallet extends Model {
  walletAlias:string;
  walletToken: string;
  walletDescription?: string;
  walletAddress: string;
  wallet_namespace: string;
  tenantId: string;
  tenantNamespaceId: string
  createdAt?: string;
  updatedAt?: string;

  static get tableName() {
    return 'tenant_multi_wallet';
  }

  static get idColumn() {
    return 'tenant_multi_wallet_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_multi_wallet_id: { type: 'string', format: 'uuid' },
        tenant_id: { type: 'string', format: 'uuid' },
        tenant_namespace_id: { type: 'string', format: 'uuid' },
        wallet_alias: { type: 'string' },
        wallet_description: { type: 'string' },
        wallet_namespace: { type: 'string', },
        wallet_address: { type: 'string', },
        wallet_token: { type: 'string' },
      },
    };
  }
}
