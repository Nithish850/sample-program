import { Model } from 'objection';

export class Products extends Model {
  name: string;
  category: string;
  subCategory: string;
  type: string;
  created_at: string;
  updated_at: string;
  superCategory: string;

  static get tableName() {
    return 'products';
  }

  static get idColumn() {
    return 'product_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'name' ],
      properties: {
        name: { type: 'string' },
        type: { type: 'string' },
      },
    };
  }
}
