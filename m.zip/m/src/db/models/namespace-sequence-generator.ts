import { Model } from 'objection';
import { EncryptionDecryption } from './encryption-decryption';

const fieldsToEncrypt = [
  'first_name',
  'last_name',
  'firstName',
  'lastName'
];

export class NamespaceSequenceGenerator extends Model {
  created_at: string;
  updated_at: string;
  firstName: string;
  lastName: string;
  baseNamespace: string
  count: number;

  static get tableName() {
    return 'namespace_sequence_generator';
  }

  static get idColumn() {
    return 'namespace_sequence_generator_id';
  }

  async $beforeInsert() {
    for (const field of fieldsToEncrypt) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.encrypt(this[field]);
      }
    }
    this.created_at = new Date().toISOString();
  }

  async $beforeUpdate() {

    for (const field of fieldsToEncrypt) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]);
      }
    }
    this.updated_at = new Date().toISOString();
  }

  async $afterFind() {
    const firstName = await EncryptionDecryption.decrypt(this.firstName)

    this.firstName = firstName
    const lastName = await EncryptionDecryption.decrypt(this.lastName)

    this.lastName = lastName
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        namespace_sequence_generator0_id: { type: 'string' },
        first_name: { type: 'string' },
        last_name: { type: 'string' },
        base_namespace: { type: 'string' },
        count: { type: 'number' },
        created_at: { type: 'string' },
        updated_at: { type: 'string' },
      },
    };
  }
}
