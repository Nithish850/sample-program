import { Model } from 'objection';

export class Validation extends Model {
  type: string;
  start: string;
  end: string;
  count: number;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'validation';
  }

  static get idColumn() {
    return 'validation_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        type: { type: 'string' },
        start: { type: 'string' },
        end: { type: 'string' },
        count: { type: 'number' },
      },
    };
  }
}
