import { Model } from 'objection';

export class CustomNamespace extends Model {
  created_at: string;
  updated_at: string;
  custom_namespace: string;
  namespace_id: string;
  provider: string;

  static get tableName() {
    return 'wallet_user_namespace_mapper';
  }

  static get idColumn() {
    return [ 'namespace_mapper_id' ];
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        custom_namespace: { type: 'string' },
        namespace_id: { type: 'string' },
      },
    };
  }
}
