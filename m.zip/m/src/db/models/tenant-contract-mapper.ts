import { Model } from "objection";
import { ContractStore } from "./contract-store";

export class TenantContractMapper extends Model {
  createdAt: string;
  updatedAt: string;
  status: string;
  tenantId: string;
  withdrawFee: object;
  depositFee: object;
  onchainFee: number;
  gasFee: number;
  symbol: string;
  tokenType: string;
  depositTokenSymbol: string;
  utilityTokenSymbol: string;
  token: string;
  settlementTenantId: string;

  static get tableName() {
    return "tenant_contract_mapper";
  }

  static get idColumn() {
    return ['contract_id', 'tenant_id'];
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_id', 'contract_id' ],
      properties: {
        tenant_id: { type: 'string' },
        contract_id: { type: 'string' },
        status: { type: 'string' },
        withdraw_fee: { type: 'object' },
        deposit_fee: { type: 'object' },
        gas_fee: { type: 'number' },
        onchain_fee: { type: 'number' },
      },
    };
  }

  static get relationMappings() {
    return {
      contract_mapper: {
        relation: Model.HasOneRelation,
        modelClass: ContractStore,
        join: {
          from: 'contract_store.contractId',
          to: 'tenant_contract_mapper.contractId',
        },
      }
    };
  }
}
