import { Model } from 'objection';

export class Rules extends Model {
  ruleId: string;
  ruleJson: object;
  ruleGroup: string;
  ruleName: string;
  createdBy: string;
  ruleDescription: string;
  ruleIdAlias: string;
  isDefaultRule: boolean;

  static get tableName() {
    return 'rules';
  }

  static get idColumn() {
    return 'rule_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        rule_id: { type: 'string' },
        rule_name: { type: 'string' },
        rule_description: { type: 'string' },
        rule_json: { type: 'object' },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
        updated_by: { type: 'string' },
      },
    };
  }
}
