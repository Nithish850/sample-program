import { Model } from "objection";
import { EncryptionDecryption } from "./encryption-decryption";

export class TenantPreScreening extends Model {
  email?: string;
  phone?: string;
  website?: string;
  company_registration_number?: string;
  company_address?: any
  entity_size?: any
  description_of_business?: string
  legal_name?: string;
  region_of_formation?: string;
  business_countries?: any
  location_of_principal_business: string
  tax: any

  static get tableName() {
    return 'tenant_pre_screening';
  }

  static get idColumn() {
    return 'tenant_pre_screening_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_pre_screening_id: { type: 'string' },
        legal_name: { type: 'string' },
        email: { type: 'string' },
        phone: { type: 'string' },
        website: { type: 'string' },
        tax_id: { type: 'string' },
        company_registration_number: { type: 'string' },
        company_address: { type: 'object' },
        entity_size: { type: 'string' },
        commencement_date: { type: 'string' },
      },
    };
  }

  async $afterFind() {
    const email = await EncryptionDecryption.decrypt(this.email)
    const phone = await EncryptionDecryption.decrypt(this.phone)
    const website = await EncryptionDecryption.decrypt(this.website)
    const companyRegistrationNumber = await EncryptionDecryption.decrypt(this.company_registration_number)
    const companyAddress = await EncryptionDecryption.decrypt(this.company_address)
    const entitySize = await EncryptionDecryption.decrypt(this.entity_size)
    const businessDescription = await EncryptionDecryption.decrypt(this.description_of_business)
    const locationOfPrincipalBusiness = await EncryptionDecryption.decrypt(this.location_of_principal_business)
    const tax = await EncryptionDecryption.decrypt(this.tax)
    const legalName = await EncryptionDecryption.decrypt(this.legal_name)
    const regionOfFormation = await EncryptionDecryption.decrypt(this.region_of_formation)
    const businessCountries = await EncryptionDecryption.decrypt(this.business_countries)

    this.email = email
    this.phone = phone
    this.website = website
    this.company_registration_number = companyRegistrationNumber
    this.company_address = companyAddress
    this.entity_size = entitySize
    this.description_of_business = businessDescription
    this.location_of_principal_business = locationOfPrincipalBusiness
    this.tax = tax
    this.legal_name = legalName
    this.region_of_formation = regionOfFormation
    this.business_countries = businessCountries
  }

  async $beforeInsert() {
    const email = await EncryptionDecryption.encrypt(this.email)
    const phone = await EncryptionDecryption.encrypt(this.phone)
    const website = await EncryptionDecryption.encrypt(this.website)
    const companyRegistrationNumber = await EncryptionDecryption.encrypt(this.company_registration_number)
    const companyAddress = await EncryptionDecryption.encrypt(this.company_address)
    const entitySize = await EncryptionDecryption.encrypt(this.entity_size)
    const businessDescription = await EncryptionDecryption.encrypt(this.description_of_business)
    const locationOfPrincipalBusiness = await EncryptionDecryption.encrypt(this.location_of_principal_business)
    const tax = await EncryptionDecryption.encrypt(this.tax)
    const legalName = await EncryptionDecryption.encrypt(this.legal_name)
    const regionOfFormation = await EncryptionDecryption.encrypt(this.region_of_formation)
    const businessCountries = await EncryptionDecryption.encrypt(this.business_countries)

    this.email = email
    this.phone = phone
    this.website = website
    this.company_registration_number = companyRegistrationNumber
    this.company_address = companyAddress
    this.entity_size = entitySize
    this.description_of_business = businessDescription
    this.location_of_principal_business = locationOfPrincipalBusiness
    this.tax = tax
    this.legal_name = legalName
    this.region_of_formation = regionOfFormation
    this.business_countries = businessCountries
  }
}