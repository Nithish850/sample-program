import { Model } from 'objection';
import { Transaction } from './transaction';

export class TransactionNote extends Model {
  created_at: string;
  comment: string;
  attachment: string;
  id: string;

  static get tableName() {
    return 'transaction_notes';
  }

  static get idColumn() {
    return 'transaction_note_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['comment'],
      properties: {
        id: { type: 'string' },
        comment: { type: 'string' },
        attachment: { type: 'object' },
      },
    };
  }

  /**
   * Relate the TransactionNote and Transaction with the help of id
   */
  static get relationMappings() {
    return {
      transaction_notes: {
        relation: Model.HasManyRelation,
        modelClass: Transaction,
        join: {
          from: 'transaction_notes.id',
          to: 'transaction.id',
        },
      },
    };
  }
}
