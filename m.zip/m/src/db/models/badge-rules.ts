import { Model } from 'objection';
import { Rules } from './rule';

export class BadgeRules extends Model {
  static get tableName() {
    return 'badge_rules';
  }

  static get idColumn() {
    return ['rule_id', 'badge_id'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        rule_id: { type: 'string' },
        badge_id: { type: 'string' },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      rules: {
        relation: Model.HasOneRelation,
        modelClass: Rules,
        filter: (query) => query.select('ruleName', 'ruleDescription', 'ruleJson', 'ruleIdAlias'),
        join: {
          from: 'badge_rules.ruleId',
          to: 'rules.ruleId'
        },
      }
    }
  }
}
