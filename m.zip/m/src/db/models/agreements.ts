import { Model } from 'objection';
import { EncryptionDecryption } from './encryption-decryption';

export class Agreements extends Model {
  customer_account_id: string;
  id: string;
  content: string;
  status: string;
  // first_name: string;
  // last_name: string;
  email: string;
  ip: string;
  account_address: string;
  agreement_type: string;
  created_at: string;
  updated_at: string;
  firstName: string;
  lastName: string;

  static get tableName() {
    return 'agreements';
  }

  static get idColumn() {
    return 'agreement_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  async $afterFind() {
    const firstName = await EncryptionDecryption.decrypt(this.firstName)
    this.firstName = firstName
    const lastName = await EncryptionDecryption.decrypt(this.lastName)
    this.lastName = lastName
    const email = await EncryptionDecryption.decrypt(this.email)
    this.email = email
    const ip = await EncryptionDecryption.decrypt(this.ip)
    this.ip = ip
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'status' ],
      properties: {
        customer_account_id: { type: 'string' },
        id: { type: 'string' },
        content: { type: 'string' },
        status: { type: 'string' },
        payload: { type: 'string' },
      },
    };
  }
}
