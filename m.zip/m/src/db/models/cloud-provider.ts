import { Model } from 'objection';

export class CloudProvider extends Model {
  static get tableName() {
    return 'cloud_provider';
  }

  static get idColumn() {
    return 'provider_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        provider_id: { type: 'string' },
        provider_name: { type: 'string' },
        provider_service: { type: 'string' },
      },
    };
  }
}
