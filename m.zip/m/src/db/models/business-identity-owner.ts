import { Model } from "objection";
import { EncryptionDecryption } from "./encryption-decryption";

export class BusinessIdentityOwner extends Model {
  firstName:string;
  lastName: string;
  email:string;
  phoneNumber:string;
  dob:string;
  address: string;
  tax:string;
  gender:string;

  static get tableName() {
    return 'business_identity_owner';
  }

  static get idColumn() {
    return 'business_identity_owner_id';
  }

  async $afterFind() {
    const firstName = await EncryptionDecryption.decrypt(this.firstName)
    this.firstName = firstName
    const lastName = await EncryptionDecryption.decrypt(this.lastName)
    this.lastName = lastName
    const email = await EncryptionDecryption.decrypt(this.email)
    this.email = email
    const phoneNumber = await EncryptionDecryption.decrypt(this.phoneNumber)
    this.phoneNumber = phoneNumber
    const dob = await EncryptionDecryption.decrypt(this.dob)
    this.dob = dob
    const address = await EncryptionDecryption.decrypt(this.address)
    this.address = address
    const tax = await EncryptionDecryption.decrypt(this.tax)
    this.tax = tax
    const gender = await EncryptionDecryption.decrypt(this.gender)
    this.gender = gender
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        business_identity_owner_id: { type: 'string' },
        business_user_id: { type: 'string' },
        dss_type_id: { type: 'string' },
        business_owner_dss_id: { type: 'string' },
        first_name: { type: 'string' },
        last_name: { type: 'string' },
        email: { type: 'string' },
        phone_number: { type: 'string' },
        dob: { type: 'string' },
        address: { type: 'object' },
        tax: { type: 'object' },
        documents: { type: 'array' },
      }
    }
  }
}