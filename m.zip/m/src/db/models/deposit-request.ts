import { Model } from 'objection';

export class DepositRequest extends Model {
  depositRequestId: string;
  tenantId: string;
  amount: string;
  token: string;
  walletIdentifier: string;
  walletIdentifierType: string;
  status: string;
  statusStage: string;
  rejectionReason: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'deposit_requests';
  }

  static get idColumn() {
    return 'deposit_request_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        deposit_request_id: { type: 'string' },
        tenant_id: { type: 'string' },
        amount: { type: 'string' },
        token: { type: 'string' },
        wallet_identifier: { type: 'string' },
        wallet_identifier_type: { type: 'string' },
        status: { type: 'string' },
        status_stage: { type: 'string' },
        rejection_reason: { type: 'string' },
      },
    };
  }
}
