import { Model } from 'objection';

export class DSS extends Model {
  dss_type: string;
  dss_description: string;
  dssTypeId: string;

  static get tableName() {
    return 'dss';
  }

  static get idColumn() {
    return 'dss_type_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        dss_type: { type: 'string' },
        dss_description: { type: 'string' },
      },
    };
  }
}
