import { Model } from 'objection';
/**
 * Errors Model Class
 */
export class ErrorsModel extends Model {
  /** error_code: string */
  error_code: string;
  /** error_group: string */
  error_group: string;
  /** error_attribute: string */
  error_attribute: string;
  /** error_reason: string */
  error_reason: string;
  /** error_description: boolean */
  error_description: string;

  /**
   * Function to get table name
   */
  static get tableName() {
    return 'errors';
  }

  /**
   * Function to get idColumn
   */
  static get idColumn() {
    return 'error_code';
  }

  /**
   * Function to get schema of table in json/object format
   */
  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'error_code' ],
      properties: {
        error_code: { type: 'string' },
        error_group: { type: 'string' },
        error_attribute: { type: 'string' },
        error_reason: { type: 'string' },
        error_description: { type: 'string' },
      },
    };
  }
}
