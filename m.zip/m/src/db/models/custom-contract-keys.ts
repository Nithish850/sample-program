import { Model } from 'objection';

export class CustomContractKeys extends Model {
  address: string;
  privateKey: string;
  mnemonic: string;

  static get tableName() {
    return 'custom_contract_keys';
  }

  static get idColumn() {
    return 'public_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        address: { type: 'string' },
        private_key: { type: 'string' },
        mnemoic: { type: 'string' },
      },
    };
  }
}
