
import { Model } from 'objection';
import { Users } from './user';
import { RecurringTransactions } from './recurring-transactions';
import { BulkTransactionsReceipts } from './bulk-transactions-receipts';
import { EncryptionDecryption } from './encryption-decryption';

export class BulkTransactions extends Model {

  transactionAmount: string;
  bulkTransactionId: string;
  isScheduledTransaction: string;
  scheduledTime: string;
  criteria: string;
  memo: string;
  tenantId: string;
  createdBy: string;
  bulkTransferStatus: string;
  rejectReasons: object;
  freezedAmount: string;
  isFundFreezed: boolean;
  isStaticRecipients: boolean;
  receiptsLists: object;
  isRecurring: boolean;
  recurringStartDate: string;
  recurringEndDate: string;
  recurringFrequency: string;
  recipientList: string;
  processedTime: string;
  senderNamespace: string
  recipient_list: string;
  sender_namespace: string;

  static get tableName() {
    return 'bulk_transactions';
  }

  static get idColumn() {
    return 'bulk_transaction_id';
  }

  async $afterFind() {
    const recipientList = await EncryptionDecryption.decrypt(this.recipientList)
    this.recipientList = recipientList
    const senderNamespace = await EncryptionDecryption.decrypt(this.senderNamespace)
    this.senderNamespace = senderNamespace
  }

  async $beforeInsert() {
    const recipientList = await EncryptionDecryption.encrypt(this.recipient_list)
    this.recipient_list = recipientList
    const senderNamespace = await EncryptionDecryption.encrypt(this.sender_namespace)
    this.sender_namespace = senderNamespace
  }

  static get jsonSchema() {
    return {
      type: 'object',
      // required: [ 'transaction_amount', 'tenant_id', 'created_by' ],
      properties: {
        bulk_transaction_id: { type: 'string' },
        transaction_amount: { type: 'string' },
        is_scheduled_transaction: { type: 'boolean' },
        scheduled_time: { type: 'string' },
        criteria: { type: 'object' },
        memo: { type: 'string' },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
        is_recurring: { type: 'boolean' },
        recurring_start_date: { type: 'string' },
        recurring_end_date: { type: 'string' },
        recurring_frequency: { type: 'string' },
        recipient_list: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      createdByUser: {
        relation: Model.HasOneRelation,
        modelClass: Users,
        join: {
          from: 'bulk_transactions.createdBy',
          to: 'users.userId'
        }
      },
      recurringTransactions: {
        relation: Model.HasManyRelation,
        modelClass: RecurringTransactions,
        join: {
          from: 'bulk_transactions.bulkTransactionId',
          to: 'recurring_transactions.bulkTransactionId'
        }
      },
      bulkTransferReceipts: {
        relation: Model.HasManyRelation,
        modelClass: BulkTransactionsReceipts,
        join: {
          from: 'bulk_transactions.bulkTransactionId',
          to: 'bulk_transactions_receipts.bulkTransactionId'
        }
      },
    }
  }
}
