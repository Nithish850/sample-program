import { Model } from 'objection';

export class WalletType extends Model {
  walletTypeName: string;
  tokenSymbol: string;

  static get tableName() {
    return 'wallet_type';
  }

  static get idColumn() {
    return 'wallet_type_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        wallet_type_name: { type: 'string' },
        token_symbol: { type: 'string' },
      },
    };
  }
}