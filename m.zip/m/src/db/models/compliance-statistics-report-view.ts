import { Model } from 'objection';

export class ComplianceStatisticsReportView extends Model {
  static get tableName() {
    return 'v_compliance_statistics_report';
  }
}