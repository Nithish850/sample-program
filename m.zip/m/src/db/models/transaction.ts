import { Model } from 'objection';
import { Namespace } from './namespace';
import { TransactionNote } from './transaction-note';
import { EncryptionDecryption } from './encryption-decryption';
import { transactionEncryptedColumns } from '../../utils/encryption';

export class Transaction extends Model {
  id: string;
  transactionHash: string;
  transaction_amount: string;
  transaction_type: string;
  initiator: string;
  beneficiary: string;
  tenant_namespace: string;
  rule_status: string;
  compliance_status: string;
  status: string;
  created_at: string;
  updated_at: string;
  sum: number;
  receiverNamespace: string;
  parent_transaction_id: string;
  settlement_tenant_id: string;
  deposit_token_symbol: string;
  memo: string;
  memo_hex: string;
  fullName?:string
  senderNamespace? :string

  static get tableName() {
    return 'transaction';
  }

  static get idColumn() {
    return 'id';
  }

  async $beforeInsert() {
    for (const field of transactionEncryptedColumns) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.encrypt(this[field]) || null;
      }
    }
    this.created_at = new Date().toISOString();
  }

  async $beforeUpdate() {
    for (const field of transactionEncryptedColumns) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]) || null;
      }
    }
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'transaction_hash', 'transaction_amount', 'transaction_type', 'initiator', 'beneficiary' ],
      properties: {
        id: { type: 'string' },
        transaction_hash: { type: 'string' },
        transaction_amount: { type: 'string' },
        transaction_type: { type: 'string' },
        initiator: { type: 'string' },
        beneficiary: { type: 'string' },
        tenant_namespace: { type: 'string' },
        rule_status: { type: 'string' },
        compliance_status: { type: 'string' },
        status: { type: 'string' },
      },
    };
  }

  /**
   * Relate the Transaction and Transaction note with the help of ID
   */
  static get relationMappings() {
    return {
      transaction_notes: {
        relation: Model.HasManyRelation,
        modelClass: TransactionNote,
        join: {
          from: 'transaction.id',
          to: 'transaction_notes.id',
        },
      },

      namespaceOfCustomer: {
        relation: Model.HasOneRelation,
        modelClass: Namespace,
        join: {
          from: 'transaction.beneficiary',
          to: 'namespaces.accountAddress',
        },
      },
    };
  }

  async $afterFind() {

    const initiator = await EncryptionDecryption.decrypt(this.initiator)
    const beneficiary = await EncryptionDecryption.decrypt(this.beneficiary)
    const fullName  = await EncryptionDecryption.decrypt(this.fullName)
    const senderNamespace = await EncryptionDecryption.decrypt(this.senderNamespace)
    const receiverNamespace = await EncryptionDecryption.decrypt(this.receiverNamespace)
    const tenantNamespace = await EncryptionDecryption.decrypt(this.tenant_namespace)

    this.initiator = initiator
    this.beneficiary = beneficiary
    this.fullName = fullName
    this.senderNamespace = senderNamespace
    this.receiverNamespace = receiverNamespace
    this.tenant_namespace = tenantNamespace

  }
}
