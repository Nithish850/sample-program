import { Model } from 'objection';
export class ActivityLogs extends Model {
  activity_id: string;
  entity_id: string;
  entity: string;
  entity_table_name: string;
  activity_type: string;
  db_operation: string;
  data: object;
  created_by: string;
  tenant_id: string;
  previous_data: object;

  static get tableName() {
    return 'activity_logs';
  }

  static get idColumn() {
    return 'activity_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        activity_id: { type: 'string' },
        entity_id: { type: 'string' },
        entity: { type: 'string' },
        entity_table_name: { type: 'string' },
        activity_type: { type: 'string' },
        db_operation: { type: 'string' },
        data: { type: 'object' },
        tenant_id: { type: 'string' },
        created_by: { type: 'string' },
      },
    };
  }
}
