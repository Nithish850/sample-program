import { Model } from 'objection';

export class TenantCustomerDocuments extends Model {
  tenant_customer_document_id: string;
  customer_account_id: string;
  name: string;
  side: string;
  type: string;
  content: Text;
  description: string;
  number: string;
  issued_country: string;
  expired: boolean;
  valid_from: string;
  valid_till: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'tenant_customer_documents';
  }

  static get idColumn() {
    return 'tenant_customer_document_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        tenant_customer_document_id: { type: 'string' },
        customer_account_id: { type: 'string' },
        name: { type: 'string' },
        side: { type: 'string' },
        type: { type: 'string' },
        content: { type: 'string' },
        description: { type: 'string' },
        number: { type: 'string' },
        expired: { type: 'boolean' },
        issued_country: { type: 'string' },
        valid_from: { type: 'string' },
        valid_till: { type: 'string' },
      },
    };
  }
}
