import { Model } from 'objection';


export class TransactionTimeline extends Model {
    transactionId: string;
    transactionHash: string;
    status: string;
    tenantId: string;
    type: string;
    createdAt: string;

    static get tableName() {
        return 'transaction_timeline';
    }

    static get idColumn() {
        return 'transaction_timeline_id';
    }

    $beforeInsert() {
        this.createdAt = new Date().toISOString();
    }




}
