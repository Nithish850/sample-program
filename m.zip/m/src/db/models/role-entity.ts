import { Model } from 'objection';
import { Entities } from './entity';
import { Roles } from './role';

export class RoleEntities extends Model {
  created_at: string;
  updated_at: string;
  role_id: string;
  read: boolean;
  write: boolean;
  update: boolean;
  delete: boolean;
  manage: boolean;

  static get tableName() {
    return 'role_entities';
  }

  static get idColumn() {
    return 'entity_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'read', 'write', 'update', 'delete', 'manage' ],
      properties: {
        entity_id: { type: 'string' },
        role_id: { type: 'string' },
        tenant_id: { type: 'string' },
        read: { type: 'boolean' },
        write: { type: 'boolean' },
        update: { type: 'boolean' },
        delete: { type: 'boolean' },
        manage: { type: 'boolean' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  /**
  * Relate the Role Entities and Role with the help of ROLE_ID
  * Relate the Role Entities and Entities with the help of ENTITY_ID
  */
  static get relationMappings() {
    return {
      tenant_metadata: {
        relation: Model.HasOneRelation,
        modelClass: Roles,
        join: {
          from: 'role_entities.role_id',
          to: 'roles.role_id',
        },
      },
      entities: {
        relation: Model.HasOneRelation,
        modelClass: Entities,
        join: {
          from: 'role_entities.entityId',
          to: 'entities.entityId'
        }
      }
    };
  }
}
