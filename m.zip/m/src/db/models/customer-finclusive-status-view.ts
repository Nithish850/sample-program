import { Model } from 'objection';

export class CustomerFinclusiveStatusView extends Model {
  static get tableName() {
    return 'v_finclusive_customer_status';
  }
}