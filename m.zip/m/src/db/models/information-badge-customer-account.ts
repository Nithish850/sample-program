import { Model } from 'objection';
import { Badge } from './badge';

export class InformationBadgeCustomerAccount extends Model {
  static get tableName() {
    return 'information_badge_customer_account';
  }

  static get idColumn() {
    return ['information_badge_id', 'customer_account_id'];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        information_badge_id: { type: 'string' },
        customer_account_id: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      infoBadgeDetails: {
        relation: Model.HasOneRelation,
        modelClass: Badge,
        filter: (query) => query.select('badgeName','badgeType'),
        join: {
          from: 'information_badge_customer_account.informationBadgeId',
          to: 'badge.badgeId'
        },
      },
    }
  }
}
