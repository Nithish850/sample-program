import { Model } from 'objection';

export class  CurrencyList extends Model {
  currency: string;
  code: string;

  static get tableName() {
    return 'currency_list';
  }

  static get idColumn() {
    return 'code';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'currency', 'code' ],
      properties: {
        currency: { type: 'string' },
        code: { type: 'string' },
      },
    };
  }
}