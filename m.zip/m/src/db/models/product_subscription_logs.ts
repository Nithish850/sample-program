import { Model } from 'objection';

export class ProductSubscriptionLogs extends Model {
  tenant_id: string;
  product_id: string;
  status: boolean;
  updated_by: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'product_subscription_logs';
  }

  static get idColumn() {
    return 'product_subscription_log_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_id', 'product_id', 'status', 'updated_by' ],
      properties: {
        tenant_id: { type: 'string' },
        product_id: { type: 'string' },
        status: { type: 'boolean' },
        updated_by: { type: 'string' },
      },
    };
  }
}
