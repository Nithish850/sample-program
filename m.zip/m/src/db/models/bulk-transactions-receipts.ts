
import { Model } from 'objection';
import { BulkTransactions } from './bulk-transactions';
import { Transaction } from './transaction';

export class BulkTransactionsReceipts extends Model {

  receiptId: string;
  bulkTransactionId: string;
  fromNamespace: string;
  toNamespace: string;
  transactionHash: string;
  transactionStatus: string;
  failedReason: string;

  static get tableName() {
    return 'bulk_transactions_receipts';
  }

  static get idColumn() {
    return 'receipt_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'bulk_transaction_id', 'from_namespace', 'to_namespace' ],
      properties: {
        receipt_id: { type: 'string' },
        bulk_transaction_id: { type: 'string' },
        from_namespace: { type: 'string' },
        to_namespace: { type: 'string' },
        transaction_hash: { type: 'string' },
        transaction_status: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      bulkTransfer: {
        relation: Model.HasOneRelation,
        modelClass: BulkTransactions,
        join: {
          from: 'bulk_transactions_receipts.bulkTransactionId',
          to: 'bulk_transactions.bulkTransactionId'
        }
      },
      transactionDetails: {
        relation: Model.HasOneRelation,
        modelClass: Transaction,
        join: {
          from: 'bulk_transactions_receipts.transactionHash',
          to: 'transaction.transactionHash'
        }
      }
    }
  }
}
