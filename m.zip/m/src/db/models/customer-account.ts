import { Model } from 'objection';
import { TenantCustomerDocuments } from './customer-account-documents';
import { Namespace } from './namespace';
import { Tenants } from './tenant';
import { TenantCustomerAccounts } from './tenant-customer-account';
import { TenantCustomerNotes } from './tenant-customer-notes';
import { WalletUserNamespaceMapper } from './wallet_user_namespace_mapper';
import { CustomerBadgeListLogs } from './customer-badge-list-logs';
import { InformationBadgeCustomerAccount } from './information-badge-customer-account';
import { EncryptionDecryption } from './encryption-decryption';
import { JsonParse } from '../../utils/constant';

const customerAccountsEncryptedFields = [
  'email',
  'phone',
  'dob',
  'address',
  'customer_metadata',
  'first_name',
  'middle_name',
  'last_name',
  'nationality',
  'identity_provider_metadata',
  'ip_address',
  'lat_long',
  'ssn',
  'tax_id',
  'additional_address',
  'geo_location_details',
  'metro_area_details',
  'country_details',
  'gid_name',
  'gid_dob',
  'gid_id_number',
  'gid_country',
  'gid_state',
  'gid_issue_date',
  'gid_expiration_date',
  'gid_address',
  'gid_gender',
  'gid_photo',
  'bank_account_details',
  'name_combination',
  'name_combination_index',
  'metro_location_details',
  'firstName',
  'middleName',
  'lastName',
  'full_name',
  'fullName',
  'plaid_details',
]

export class CustomerAccounts extends Model {
  account_status: string;
  full_name: string;
  customer_account_id: string;
  onboarding_status: string;
  firstName: string;
  middleName: string;
  lastName: string;
  taxId: string;
  email: string;
  phone: string;
  dob: Date;
  address: any;
  customerMetadata: object;
  compliance_status: string;
  complianceStatus: string;
  tenant_id: string;
  created_at: string;
  updated_at: string;
  ipAddress: string;
  latLong: JSON;
  nationality: string;
  ssn: string;
  identityProviderStatus: string;
  accountStatus: string;
  maritalStatus: string;
  risk_level?: string;
  gidName?: string;
  gid_name?: string;
  gidDob?: Date;
  gid_dob?: Date;
  gidPhoto?: object;
  gid_photo?: object;
  gid_id_number?: string;
  gidIdNumber?: string;
  gid_country?: string;
  gidCountry?: string;
  gid_state?: string;
  gidState?: string;
  gid_issue_date?: Date;
  gidIssueDate?: Date;
  gid_expiration_date?: Date;
  gidExpirationDate?: Date;
  gid_address?: object;
  gidAddress?: object;
  gid_gender?: string;
  gidGender?: string;
  bank_account?: string;
  bankAccount?: string;
  bank_account_details?: string;
  bankAccountDetails?: string;
  count?: string;
  name_combination?: string;
  nameCombination?: string;
  name_combination_index?: string;
  plaidDetails?: string;
  nameCombinationIndex?: string;
  identity_provider_status: string
  gender: string
  metroLocationDetails: string
  addtionalAddress: string
  geoLocationDetails: string
  metroAreaDetails: string
  countryDetails: string
  fullName?: string
  customerAccountId: string;

  static get tableName() {
    return 'customer_accounts';
  }

  static get idColumn() {
    return 'customer_account_id';
  }

  async $beforeInsert() {
    for (const field of customerAccountsEncryptedFields) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.encrypt(this[field]) || null;
      }
    }
    this.created_at = new Date().toISOString();

  }

  async $beforeUpdate() {
    for (const field of customerAccountsEncryptedFields) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]) || null;
      }
    }
    this.updated_at = new Date().toISOString();
  }

  async $afterFind() {
    const phone = await EncryptionDecryption.decrypt(this.phone)

    this.phone = phone

    const email = await EncryptionDecryption.decrypt(this.email)

    this.email = email

    const nationality = await EncryptionDecryption.decrypt(this.nationality)

    this.nationality = nationality
    const dob: any = await EncryptionDecryption.decrypt(this.dob)

    this.dob = dob
    const customerMetadata: any = await EncryptionDecryption.decrypt(this.customerMetadata)

    this.customerMetadata = customerMetadata
    const identityProviderStatus = await EncryptionDecryption.decrypt(this.identityProviderStatus)

    this.identityProviderStatus = identityProviderStatus
    const ipAddress = await EncryptionDecryption.decrypt(this.ipAddress)

    this.ipAddress = ipAddress
    const latLong: any = await EncryptionDecryption.decrypt(this.latLong)

    this.latLong = latLong
    const ssn = await EncryptionDecryption.decrypt(this.ssn)

    this.ssn = ssn
    const address = await EncryptionDecryption.decrypt(this.address)

    this.address = typeof address === 'string' ? JSON.parse(address) : address || {}

    const taxId = await EncryptionDecryption.decrypt(this.taxId)

    this.taxId = taxId

    const firstName: any = await EncryptionDecryption.decrypt(this.firstName)

    this.firstName = firstName

    const lastName: any = await EncryptionDecryption.decrypt(this.lastName)

    this.lastName = lastName

    const middleName: any = await EncryptionDecryption.decrypt(this.middleName)

    this.middleName = middleName

    const fullName: any = await EncryptionDecryption.decrypt(this.fullName)

    this.fullName = fullName
    // const gender = await EncryptionDecryption.decrypt(this.gender)
    // this.gender = gender
    // const maritalStatus = await EncryptionDecryption.decrypt(this.maritalStatus)
    // this.maritalStatus = maritalStatus
    const metroLocationDetails: any = await EncryptionDecryption.decrypt(this.metroLocationDetails)

    this.metroLocationDetails = metroLocationDetails
    const addtionalAddress = await EncryptionDecryption.decrypt(this.addtionalAddress)

    this.addtionalAddress = addtionalAddress
    const geoLocationDetails = await EncryptionDecryption.decrypt(this.geoLocationDetails)

    this.geoLocationDetails = JsonParse(geoLocationDetails)
    const metroAreaDetails = await EncryptionDecryption.decrypt(this.metroAreaDetails)

    this.metroAreaDetails = metroAreaDetails
    const countryDetails = await EncryptionDecryption.decrypt(this.countryDetails)

    this.countryDetails = countryDetails
    const gidName: any = await EncryptionDecryption.decrypt(this.gidName)

    this.gidName = gidName
    const gidDob: any = await EncryptionDecryption.decrypt(this.gidDob)

    this.gidDob = gidDob
    const gidPhoto: any = await EncryptionDecryption.decrypt(this.gidPhoto)

    this.gidPhoto = gidPhoto
    const gidIdNumber = await EncryptionDecryption.decrypt(this.gidIdNumber)

    this.gidIdNumber = gidIdNumber
    const gidCountry = await EncryptionDecryption.decrypt(this.gidCountry)

    this.gidCountry = gidCountry
    const gidState: any = await EncryptionDecryption.decrypt(this.gidState)

    this.gidState = gidState
    const gidIssueDate: any = await EncryptionDecryption.decrypt(this.gidIssueDate)

    this.gidIssueDate = gidIssueDate
    const gidExpirationDate: any = await EncryptionDecryption.decrypt(this.gidExpirationDate)

    this.gidExpirationDate = gidExpirationDate

    const gidAddress: any = await EncryptionDecryption.decrypt(this.gidAddress)

    this.gidAddress = gidAddress
    const gidGender = await EncryptionDecryption.decrypt(this.gidGender)

    this.gidGender = gidGender
    const bankAccount: any = await EncryptionDecryption.decrypt(this.bankAccount)

    this.bankAccount = bankAccount
    const bankAccountDetails: any = await EncryptionDecryption.decrypt(this.bankAccountDetails)

    this.bankAccountDetails = bankAccountDetails
    const nameCombination: any = await EncryptionDecryption.decrypt(this.nameCombination)

    this.nameCombination = nameCombination
    const nameCombinationIndex: any = await EncryptionDecryption.decrypt(this.nameCombinationIndex)

    this.nameCombinationIndex = nameCombinationIndex

    const plaidDetails: any = await EncryptionDecryption.decrypt(this.plaidDetails);

    this.plaidDetails = plaidDetails;
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        customer_account_id: { type: 'string' },
        fullName: { type: 'string' },
        onboarding_status: { type: 'string' },
        first_name: { type: 'string', minLength: 1, maxLength: 255 },
        middle_name: { type: 'string' },
        last_name: { type: 'string', minLength: 2, maxLength: 255 },
        tax_id: { type: 'string' },
        email: { type: 'string' },
        phone: { type: 'string' },
        dob: { type: 'string' },
        address: { type: 'object' },
        customer_metadata: { type: 'object' },
        tenant_id: { type: 'string' },
        ipAddress: { type: 'string' },
        latLong: { type: 'object' },
        nationality: { type: 'string' },
        ssn: { type: 'string' },
        identity_provider_status: { type: 'string' },
        marital_status: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      wallet_user_namespace_mapper: {
        relation: Model.HasOneThroughRelation,
        modelClass: WalletUserNamespaceMapper,
        join: {
          from: 'customer_accounts.customerAccountId',
          through: {
            from: 'namespaces.customerAccountId',
            to: 'namespaces.namespaceId',
          },
          to: 'wallet_user_namespace_mapper.namespaceId',
        },
      },
      tenant_customer_accounts: {
        relation: Model.HasOneRelation,
        modelClass: TenantCustomerAccounts,
        filter: (query) =>
          query.select('category', 'category_name'),
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'tenant_customer_accounts.customerAccountId',
        },
      },
      namespace: {
        relation: Model.HasManyRelation,
        modelClass: Namespace,
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'namespaces.customerAccountId',
        },
      },
      tenant_customer_notes: {
        relation: Model.HasManyRelation,
        modelClass: TenantCustomerNotes,
        filter: (query) => query.select('comment', 'attachment', 'created_at'),
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'tenant_customer_notes.customerAccountId',
        },
      },
      tenants: {
        relation: Model.HasManyRelation,
        modelClass: Tenants,
        filter: (query) => query.select('tenant_name'),
        join: {
          from: 'customer_accounts.tenantId',
          to: 'tenants.tenantId',
        },
      },
      tenant_customer_documents: {
        relation: Model.HasManyRelation,
        modelClass: TenantCustomerDocuments,
        filter: (query) =>
          query.select(
            'name as fileName',
            'side',
            'type',
            'number',
            'expired',
            'description',
            'issued_country',
            'valid_from as validFromDate',
            'valid_till as validTillDate',
            'tenant_customer_document_id  as documentId',
            'content'
          ),
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'tenant_customer_documents.customerAccountId',
        },
      },
      badgeLogs: {
        relation: Model.HasManyRelation,
        modelClass: CustomerBadgeListLogs,
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'customer_badge_list_logs.customerAccountId',
        },
      },
      infoBadge: {
        relation: Model.HasManyRelation,
        modelClass: InformationBadgeCustomerAccount,
        join: {
          from: 'customer_accounts.customerAccountId',
          to: 'information_badge_customer_account.customerAccountId',
        },
      }
    };
  }
}
