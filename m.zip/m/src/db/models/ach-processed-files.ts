import { Model } from 'objection';
export class ACHProcessedFiles extends Model {
  file_name: string;

  static get tableName() {
    return 'ach_processed_files';
  }

  static get idColumn() {
    return 'ach_processed_file_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        file_name: { type: 'string' },
      },
    };
  }
}
