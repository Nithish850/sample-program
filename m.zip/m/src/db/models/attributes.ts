import { Model } from 'objection';
import { AttributesMinMaxVal } from './attribute-min-max-values';
/**
 * Attributes Model Class
 */
export class Attributes extends Model {
  /** attribute_id: string; */
  attributeId: string;
  /** attribute_name: string; */
  attributeName: string;
  /** attribute_type: string; */
  attributeType: string;
  /** attribute_desc: string; */
  attributeDesc: string;
  /** tenant_id: string; */
  tenantId: string;
  /** rule_group: string; */
  ruleGroup: string;

  /**
   * Function to get table name
   */
  static get tableName() {
    return 'attributes';
  }

  /**
   * Function to get idColumn
   */
  static get idColumn() {
    return 'attribute_id';
  }

  /**
   * Function to get schema of table in json/object format
   */
  static get jsonSchema() {
    return {
      type: 'object',
      required: ['attribute_name', 'attribute_type', 'tenant_id'],
      properties: {
        attribute_id: { type: 'string' },
        attribute_name: { type: 'string' },
        attribute_type: { type: 'string' },
        attribute_desc: { type: 'string' },
        tenant_id: { type: 'string' },
      },
    };
  }

  static get relationMappings() {
    return {
      minMaxValueOfAttribute: {
        relation: Model.HasOneRelation,
        modelClass: AttributesMinMaxVal,
        join: {
          from: 'attributes.attributeId',
          to: 'attributes_min_max_val.attributeId',
        },
      },
    };
  }
}
