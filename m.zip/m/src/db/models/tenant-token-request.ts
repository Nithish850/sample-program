import { Model } from "objection";

export class TenantTokenRequest extends Model {
  createdAt: string;
  updatedAt: string;
  tenantId: string;
  requestId: string;
  symbol: string;
  withdrawFee: object;
  depositFee: object;
  onchainFee: number;
  gasFee: number;
  status: string;
  name: string;
  currency: string;
  logoDetails: object;
  tokenType: string;

  static get tableName() {
    return "tenant_token_request";
  }

  static get idColumn() {
    return 'request_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenant_id', 'symbol', 'name', 'logo_details', 'currency', 'token_type' ],
      properties: {
        request_id: { type: 'string' },
        tenant_id: { type: 'string' },
        symbol: { type: 'string' , minLength: 2, maxLength: 6 },
        withdraw_fee: { type: 'object' },
        deposit_fee: { type: 'object' },
        logo_details: { type: 'object' },
        gas_fee: { type: 'number' },
        onchain_fee: { type: 'number' },
        currency: { type: 'string' },
        status: { type: 'string' },
        name: { type: 'string' },
        token_type: { type: 'string' },
      },
    };
  }
}
