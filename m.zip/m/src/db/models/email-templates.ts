import { Model } from 'objection';

export class EmailTemplates extends Model {
  html: string;
  subject: string;
  text: string;
  template_name: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'email_templates';
  }

  static get idColumn() {
    return 'email_template_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        html: { type: 'string' },
        subject: { type: 'string' },
        text: { type: 'string' },
        template_name: { type: 'string' },
      },
    };
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }
}
