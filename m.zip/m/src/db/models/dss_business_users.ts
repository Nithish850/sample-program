import { Model } from 'objection';

export class DssBusinessUsers extends Model {

  dssId: string;

  static get tableName() {
    return 'dss_business_users';
  }

  static get idColumn() {
    return [ 'dss_type_id', 'business_user_id' ];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'dss_id' ],
      properties: {
        dss_id: { type: 'string' },
      },
    };
  }

}
