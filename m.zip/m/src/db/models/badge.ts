import { Model } from 'objection';
import { BadgeRules } from './badge-rules';
import { BadgeToken } from './badge-token';

export class Badge extends Model {
  badgeId: string;
  badge_name: string;
  badge_type: string;
  badge_description: string;
  user_group: string;
  badge_symbol_ref: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  storage_provider:string;
  owner_type?: string;
  rank: number;
  can_be_linked_to_financial_badge: boolean;
  
  static get tableName() {
    return 'badge';
  }

  static get idColumn() {
    return 'badge_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ ],
      properties: {
        badge_name: { type: 'string' },
        badge_type: { type: 'string' },
        badge_description: { type: 'string' },
        user_group: { type: 'string' },
        badge_symbol_ref: { type: 'string' },
        created_by: { type: 'string' },
        storage_provider: { type: 'string' },
        rank: { type: 'number' },
      },
    };
  }

  static get relationMappings() {
    return {
      badgeRules: {
        relation: Model.HasManyRelation,
        modelClass: BadgeRules,
        join: {
          from: 'badge.badgeId',
          to: 'badge_rules.badgeId',
        },
      },
      IdBadgeTokens: {
        relation: Model.HasManyRelation,
        modelClass: BadgeToken,
        join: {
          from: 'badge.badgeId',
          to: 'badge_token.identificationBadgeId',
        },
      },
    };
  }
}
