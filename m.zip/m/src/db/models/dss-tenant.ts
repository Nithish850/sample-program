import { Model } from 'objection';

export class DssTenant extends Model {

  dssId: string;

  static get tableName() {
    return 'dss_tenants';
  }

  static get idColumn() {
    return [ 'dss_type_id', 'tenant_id' ];
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'dss_id' ],
      properties: {
        dss_id: { type: 'string' },
      },
    };
  }

}
