import { Model } from 'objection';
import { EncryptionDecryption } from './encryption-decryption';

export class BusinessEntities extends Model {
  businessEntityId:string;
  businessEntityName: string;
  business_entity_name:string;
  description:string;
  is_active:boolean;

  static get tableName() {
    return 'business_entities';
  }

  static get idColumn() {
    return 'business_entity_id';
  }

  async $afterFind() {
    const businessEntityName = await EncryptionDecryption.decrypt(this.businessEntityName)
    this.businessEntityName = businessEntityName
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        business_entity_id: { type: 'string' },
        business_entity_name: { type: 'string' },
        description: { type: 'string' },
        is_active: { type: 'boolean' }
      },
    };
  }

  // static async decryptBusinessEntitiesFieldsForSingle(
  //   businessEntity: BusinessEntities,
  // ): Promise<any> {
  //   const [name]: any = await Promise.all([
  //     await EncryptionDecryption.decrypt(businessEntity.businessEntityName)
  //   ]);

  //   businessEntity.businessEntityName = name;
  //   // Add decryption logic for other encrypted fields here
  // }

  // static async decryptBusinessEntitiesFieldsForMultiple(
  //   businessEntities: BusinessEntities[],
  // ): Promise<void> {
  //   for (const businessEntity of businessEntities) {
  //     // eslint-disable-next-line no-await-in-loop
  //     await BusinessEntities.decryptBusinessEntitiesFieldsForSingle(businessEntity);
  //   }
  // }
}
