import { Model } from 'objection';

export class CodeMaster extends Model {
  coderMasterId: string;
  code: string;
  description: string;
  group: string;
  category: string;
  ulCode: string;
  ulDescription: string;
  template: string;
  created_at:string;
  updated_at:string

  static get tableName() {
    return 'code_master';
  }

  static get idColumn() {
    return 'code_master_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [],
      properties: {
        code_master_id: { type: 'string' },
        code: { type: 'string' },
        description: { type: 'string' },
        group: { type: 'string' },
        category: { type: 'string' },
        ulCode: { type: 'string' },
        ulDescription: { type: 'string' },
      },
    };
  }
}
