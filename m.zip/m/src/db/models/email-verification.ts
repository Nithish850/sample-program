import { Model } from 'objection';

export class EmailVerification extends Model {
  customer_account_id: string;
  email: string;
  otp: string;
  expiration_timestamp: string;
  attempt_count: number;
  verification_timestamp: string;
  reason: string;
  failure_timestamp: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'email_verification';
  }

  static get idColumn() {
    return 'email_verification_id';
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['customer_account_id', 'email', 'otp', 'expiration_timestamp', 'attempt_count'],
      properties: {
        customer_account_id: { type: 'string' },
        email: { type: 'string' },
        otp: { type: 'string' },
        expiration_timestamp: { type: 'string' },
        attempt_count: { type: 'number' },
        verification_timestamp: { type: 'string' },
        reason: { type: 'string' },
        failure_timestamp: { type: 'string' },
        created_at: { type: 'string' },
        updated_at: { type: 'string' },
      },
    };
  }
}