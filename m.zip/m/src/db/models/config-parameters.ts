import { Model } from 'objection';
import { EncryptionDecryption } from './encryption-decryption';

export class ConfigParameters extends Model {
  tenantId: string;
  name: string;
  value: string;
  unit: string;
  type: string;
  descrption: string;

  static get tableName() {
    return 'config_parameters';
  }

  static get idColumn() {
    return 'name';
  }

  async $afterFind() {
    const name = await EncryptionDecryption.decrypt(this.name)
    this.name = name
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'tenantId', 'name' ],
      properties: {
        tenant_id: { type: 'string' },
        name: { type: 'string' },
        value: { type: 'string' },
        unit: { type: 'string' },
        descrption: { type: 'string' },
      },
    };
  }
}
