import { Model } from 'objection';

export class WebhookScheduler extends Model {
  tenantId: string;
  tenantEventSubscriptionId: string;
  payload: any;
  retry_count: string;
  isEmailSent: boolean;
  isProcessed: boolean;
  status: string;
  createdAt: string;
  updatedAt: string;

  static get tableName() {
    return 'webhook_scheduler';
  }

  static get idColumn() {
    return 'webhook_scheduler_id';
  }

  $beforeInsert() {
    this.createdAt = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updatedAt = new Date().toISOString();
  }
}
