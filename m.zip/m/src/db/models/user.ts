/* eslint-disable no-await-in-loop */
import { Model } from 'objection';
import { Roles } from './role';
import { UserRoles } from './user-role';
import { EncryptionDecryption } from './encryption-decryption';

export class Users extends Model {
  created_at: string;
  updated_at: string;
  userId: string;
  user_name: string;
  email: string;
  login_id: string;
  tenantId: string;
  phone_number: string;
  address: string;
  employeeId: string;
  dob: string;
  nationality: string;
  ip_address: string;
  lat_long: string;
  notification: boolean;
  account_status: string;
  role_id: string;
  user_reference_id: string;
  phoneNumber: string;
  lastLogin: string;
  phoneNumberCountryCode: string;
  phone_number_country_code?:string
  employee_id?:string
  tenantName?:string;
  latLong?: string;
  ipAddress?:string;

  static get tableName() {
    return 'users';
  }

  static get idColumn() {
    return 'user_id';
  }

  async $beforeInsert() {
    const email = await EncryptionDecryption.encrypt(this.email)
    const phoneNumber = await EncryptionDecryption.encrypt(this.phone_number)
    const address = await EncryptionDecryption.encrypt(this.address)
    const empId = await EncryptionDecryption.encrypt(this.employee_id)
    const dob = await EncryptionDecryption.encrypt(this.dob)
    const nationality = await EncryptionDecryption.encrypt(this.nationality)
    const ipAddress = await EncryptionDecryption.encrypt(this.ip_address || this.ipAddress)
    const latLong = await EncryptionDecryption.encrypt(this.lat_long || this.latLong)
    const phoneNumberCountryCode = await EncryptionDecryption.encrypt(this.phone_number_country_code)

    this.email = email
    this.phone_number = phoneNumber
    this.address = address
    this.employee_id = empId
    this.dob = dob
    this.nationality = nationality
    this.lat_long = latLong
    this.ip_address = ipAddress
    this.phone_number_country_code = phoneNumberCountryCode
    this.created_at = new Date().toISOString();
  }

  async $beforeUpdate() {
    const fieldsToEncrypt = [
      'email',
      'phone_number',
      'address',
      'employee_id',
      'dob',
      'nationality',
      'ip_address',
      'lat_long',
      'phone_number_country_code',
      'ipAddress',
      'latLong'
    ];

    for (const field of fieldsToEncrypt) {
      if (this[field]) {
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]);
      }
    }

    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      // Please don't use the required in the model, it may cause issue in the other APIs.
      // required: [ 'user_name', 'email', 'login_id' ],
      properties: {
        user_id: { type: 'string' },
        user_name: { type: 'string' },
        email: { type: 'string' },
        login_id: { type: 'string' },
        tenant_id: { type: 'string' },
        phone_number: { type: 'string' },
        address: { type: 'string' },
        employee_id: { type: 'string' },
        account_status: { type: 'string' },
        createdBy: { type: 'string' },
        updatedBy: { type: 'string' },
        dob: { type: 'string' },
        nationality: { type: 'string' },
        ip_address: { type: 'string' },
        lat_long: { type: 'string' },
        notification: { type: 'boolean' },
        phone_number_country_code: { type: 'string' },
      },
    };
  }

  /**
   * Relate the Users and Roles through the UserRoles with the help of USER_ID and ROLE_ID
   */
  static get relationMappings() {
    return {
      /** This relation is in use for the GET APIs  */
      user_roles: {
        relation: Model.HasOneThroughRelation,
        modelClass: Roles,
        filter: (query: any) => query.select('role_name', 'is_active', 'created_by'),
        join: {
          from: 'users.userId',
          through: {
            from: 'user_roles.userId',
            to: 'user_roles.roleId',
          },
          to: 'roles.roleId',
        },
      },

      roles: {
        relation: Model.ManyToManyRelation,
        modelClass: Roles,
        filter: (query: any) => query.select('role_name', 'roles.roleId'),
        join: {
          from: 'users.userId',
          through: {
            from: 'user_roles.userId',
            to: 'user_roles.roleId',
          },
          to: 'roles.roleId',
        },
      },

      /** This relation is in use for the create user with the role */
      userRoles: {
        relation: Model.HasManyRelation,
        modelClass: UserRoles,
        join: {
          from: 'users.userId',
          to: 'user_roles.userId',
        },
      },
    };
  }

  async $afterFind() {

    const email = await EncryptionDecryption.decrypt(this.email)
    const phoneNumber = await EncryptionDecryption.decrypt(this.phoneNumber)
    const address = await EncryptionDecryption.decrypt(this.address)
    const empId = await EncryptionDecryption.decrypt(this.employeeId)
    const dob = await EncryptionDecryption.decrypt(this.dob)
    const nationality = await EncryptionDecryption.decrypt(this.nationality)
    const ipAddress = await EncryptionDecryption.decrypt(this.ip_address)
    const latLong = await EncryptionDecryption.decrypt(this.lat_long)
    const phoneNumberCountryCode = await EncryptionDecryption.decrypt(this.phoneNumberCountryCode)
    const tenantName = await EncryptionDecryption.decrypt(this.tenantName)

    this.email = email
    this.phoneNumber = phoneNumber
    this.address = address
    this.employeeId = empId
    this.dob = dob
    this.nationality = nationality
    this.lat_long = latLong
    this.ip_address = ipAddress
    this.phoneNumberCountryCode = phoneNumberCountryCode
    this.tenantName= tenantName

  }

}
