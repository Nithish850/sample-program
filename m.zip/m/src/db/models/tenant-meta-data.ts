import { Model } from 'objection';
import { ERROR_MESSAGE, ERROR_TYPE } from '../../utils/constant';
import { Tenants } from './tenant';
import { EncryptionDecryption } from './encryption-decryption';

export class TenantMetaData extends Model {
  company_address: object;
  email: string;
  taxId?: string;
  legal_name: string;
  phone: string;
  bankVerificationNumber: string;
  companyAddress?: string;
  legalName?: string;
  entityBeneficialOwners?: string
  individualBeneficialOwners?: string
  controlPersons?: string
  memoFields?:string
  registeredOfficeAddress?: string
  signatories?: string
  businessEntityName?: string
  tax_id?: string
  business_entity_name?:string
  entity_beneficial_owners?:string
  individual_beneficial_owners?:string
  control_persons?:string
  memo_fields?: string
  bank_verification_number?: string
  registered_office_address?: string

  static get tableName() {
    return 'tenant_metadata';
  }

  static get idColumn() {
    return 'tenant_metadata_id';
  }

  async $beforeUpdate() {
    const errorsArray = [];

    if (this.bankVerificationNumber) {
      const isBankDetails: any = await TenantMetaData.query().findOne({ bank_verification_number: this.bankVerificationNumber });

      if (isBankDetails && Object.keys(isBankDetails).length != 0) {
        const { errors } = this.checkDuplicateEntry('bank_verification_number', isBankDetails.bankVerificationNumber, this.bankVerificationNumber);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if (this.taxId) {
      const isTaxIdDetails: any = await TenantMetaData.query().findOne({ tax_id: this.taxId });

      if (isTaxIdDetails && Object.keys(isTaxIdDetails).length != 0) {
        const { errors } = this.checkDuplicateEntry('tax_id', isTaxIdDetails.taxId, this.taxId);

        if (errors) {
          errorsArray.push(errors);
        }
      }
    }
    if (errorsArray.length) {
      throw errorsArray;
    }

    const fieldsToEncrypt = [
      'company_address',
      'email',
      'tax_id',
      'legal_name',
      'entity_beneficial_owners',
      'individual_beneficial_owners',
      'control_persons',
      'memo_fields',
      'bank_verification_number',
      'registered_office_address',
      'signatories',
      'business_entity_name',
      'phone'
    ];

    for (const field of fieldsToEncrypt) {
      if (this[field]) {
        // eslint-disable-next-line no-await-in-loop
        this[field] = await EncryptionDecryption.decryptAndEncrypt(this[field]) || null;
      }
    }

  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['company_address', 'email', 'tax_id', 'legal_name', 'phone'],
      properties: {
        tenant_metadata_id: { type: 'string' },
        tenant_id: { type: 'string' },
        company_address: { type: 'object' },
        email: { type: 'string' },
        tax_id: { type: 'string' },
        legal_name: { type: 'string' },
        phone: { type: 'string' },
      },
    };
  }

  /**
   * Relate the Tenant and TenantMetaData with the help of TENANT_ID
   */
  static get relationMappings() {
    return {
      tenant_metadata: {
        relation: Model.HasOneRelation,
        modelClass: Tenants,
        join: {
          from: 'tenants.tenant_id',
          to: 'tenant_metadata.tenant_id',
        },
      },
    }
  }

  checkDuplicateEntry(keyName, item, itemToCompare) {
    const errors = {};
    const type = ERROR_TYPE.DUPLICATE;

    if (item === itemToCompare && keyName === 'bank_verification_number') {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_BANK_VERIFICATION;

      Object.assign(errors, { type, message })
    }
    if (item === itemToCompare && keyName === 'tax_id') {
      const message = ERROR_MESSAGE.DUPLICATE_TENANT_TAX_ID;

      Object.assign(errors, { type, message })
    }

    return { errors };
  }

  async $beforeInsert() {
    if(this.company_address){
      const company_address : any = await EncryptionDecryption.encrypt(this.company_address);

      this.company_address = company_address
    }
    const email = await EncryptionDecryption.encrypt(this.email)
    const taxId = await EncryptionDecryption.encrypt(this.tax_id)
    const legalName = await EncryptionDecryption.encrypt(this.legal_name)
    const entityBeneficialOwners = await EncryptionDecryption.encrypt(this.entity_beneficial_owners)
    const individualBeneficialOwners = await EncryptionDecryption.encrypt(this.individual_beneficial_owners)
    const controlPersons = await EncryptionDecryption.encrypt(this.control_persons)
    const memoFields = await EncryptionDecryption.encrypt(this.memo_fields)
    const bankVerificationNumber = await EncryptionDecryption.encrypt(this.bank_verification_number)
    const registeredOfficeAddress = await EncryptionDecryption.encrypt(this.registered_office_address)
    const signatories = await EncryptionDecryption.encrypt(this.signatories)
    const businessEntityName = await EncryptionDecryption.encrypt(this.business_entity_name)
    const phone = await EncryptionDecryption.encrypt(this.phone)

    this.email = email
    this.tax_id = taxId
    this.legal_name = legalName
    this.phone = phone

    this.entity_beneficial_owners = entityBeneficialOwners || null
    this.individual_beneficial_owners = individualBeneficialOwners || null
    this.control_persons = controlPersons || null
    this.memo_fields = memoFields || null
    this.bank_verification_number = bankVerificationNumber
    this.registered_office_address = registeredOfficeAddress || null
    this.signatories = signatories || null
    this.business_entity_name = businessEntityName
  }

  async $afterFind() {
    const email = await EncryptionDecryption.decrypt(this.email)

    if(this.companyAddress){
      const address : any = this.companyAddress
      const value = address.replace('\\\\','\\')
      const encryptedText = value.replaceAll('"',"")

      const companyAddress = await EncryptionDecryption.decrypt(encryptedText)

      this.companyAddress = companyAddress ? JSON.parse(companyAddress) : null

    }
    const taxId = await EncryptionDecryption.decrypt(this.taxId)
    const legalName = await EncryptionDecryption.decrypt(this.legalName)
    const entityBeneficialOwners = await EncryptionDecryption.decrypt(this.entityBeneficialOwners)
    const individualBeneficialOwners = await EncryptionDecryption.decrypt(this.individualBeneficialOwners)
    const controlPersons = await EncryptionDecryption.decrypt(this.controlPersons)
    const memoFields = await EncryptionDecryption.decrypt(this.memoFields)
    const bankVerificationNumber = await EncryptionDecryption.decrypt(this.bankVerificationNumber)
    const registeredOfficeAddress = await EncryptionDecryption.decrypt(this.registeredOfficeAddress)
    const signatories = await EncryptionDecryption.decrypt(this.signatories)
    const businessEntityName = await EncryptionDecryption.decrypt(this.businessEntityName)
    const phone = await EncryptionDecryption.decrypt(this.phone)

    this.email = email
    this.taxId = taxId
    this.legalName = legalName
    this.phone = phone
    this.entityBeneficialOwners = entityBeneficialOwners ?  JSON.parse(entityBeneficialOwners) : null
    this.individualBeneficialOwners = individualBeneficialOwners ? JSON.parse(individualBeneficialOwners) : null
    this.controlPersons = controlPersons ?  JSON.parse(controlPersons) : null
    this.memoFields = memoFields ?  JSON.parse(memoFields) : null
    this.bankVerificationNumber = bankVerificationNumber
    this.registeredOfficeAddress = registeredOfficeAddress ? JSON.parse(registeredOfficeAddress) : null
    this.signatories = signatories ?  JSON.parse(signatories) : null
    this.businessEntityName = businessEntityName
  }
}
