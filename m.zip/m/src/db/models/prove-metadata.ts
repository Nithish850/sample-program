import { Model } from 'objection';

export class ProveMetadata extends Model {
  request_id: string;
  session_id: string;
  api_client_id: string;
  source_ip: string;
  final_target_url: string;
  mobile_number: string;
  sub_client_id: string;
  license: string;
  client_context: string;
  message_text: string;
  status: string;
  description: string;
  authentication_url: string;
  mobile_operator_name: string;
  ssn: string;
  dob: string;
  created_at: string;
  updated_at: string;

  static get tableName() {
    return 'prove_metadata';
  }

  static get idColumn() {
    return 'prove_metadata_id';
  }

  $beforeInsert() {
    this.created_at = new Date().toISOString();
  }

  $beforeUpdate() {
    this.updated_at = new Date().toISOString();
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: [ 'request_id', 'authentication_url', 'api_client_id', 'status' ],
      properties: {
        request_id: { type: 'string' },
        session_id: { type: 'string' },
        api_client_id: { type: 'string' },
        source_ip: { type: 'string' },
        final_target_url: { type: 'string' },
        mobile_number: { type: 'string' },
        sub_client_id: { type: 'string' },
        license: { type: 'string' },
        client_context: { type: 'string' },
        message_text: { type: 'string' },
        status: { type: 'string' },
        description: { type: 'string' },
        authentication_url: { type: 'string' },
        mobile_operator_name: { type: 'string' },
        ssn: { type: 'string' },
        dob: { type: 'string' },
      },
    };
  }
}
