import { Model } from 'objection';
import { EncryptionDecryption } from './encryption-decryption';

export class ConsentLogs extends Model {
  tenant_id: string;
  customer_account_id: string;
  partner_name: string;
  namespace: string;
  type: string;
  consent_version: string;
  status: string;
  customerName: string;
  tenantName: string;

  static get tableName() {
    return 'consent_logs';
  }

  static get idColumn() {
    return 'consent_log_id';
  }

  async $afterFind() {
    const name = this.customerName.split(' ');
    const fName = await EncryptionDecryption.decrypt(name[0]);
    const lName = await EncryptionDecryption.decrypt(name[1]);
    this.tenantName = await EncryptionDecryption.decrypt(this.tenantName);
    this.customerName = `${fName} ${lName}`;
  }

  static get jsonSchema() {
    return {
      type: 'object',
      required: ['tenant_id'],
      properties: {
        tenant_id: { type: 'string' },
        customer_account_id: { type: 'string' },
        partner_name: { type: 'string' },
        namespace: { type: 'string' },
        type: { type: 'string' },
        consent_version: { type: 'string' },
        status: { type: 'string' },
      },
    };
  }
}
