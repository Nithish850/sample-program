import { ERROR_MESSAGE, ERROR_TYPE } from "../../utils/constant";

export const GET_CUSTOMER_CONSENT_PAYLOAD = {
  "customerAccountId": "dc789f72-0218-4e47-8e3a-9eaa2ff41bf5",
  "dssVendorId": "793b51ff-a426-4c9c-aea6-6ded653c8168",
  "consentStatus": "ACCEPTED",
  "consentVersion": "V3"
};

export const GET_CUSTOMER_CONSENT_RESPONSE = {
  data: [
    {
      customerConsentId: "56963f01-feb6-4472-9afc-a1d577deb00c",
      customerAccountId: "dc789f72-0218-4e47-8e3a-9eaa2ff41bf5",
      dssVendorId: "793b51ff-a426-4c9c-aea6-6ded653c8168",
      consentStatus: "ACCEPTED",
      consentVersion: "V3",
      createdAt: "2023-06-17T18:57:43.621Z",
      updatedAt: "2023-06-20T06:01:56.749Z"
    }
  ],
  message: "Customer consent updated successfully"
};

export const GET_VENDOR_CONSENT_MESSAGE_RESPONSE = {
  data: [
    {
      vendorName: "checkout.com",
      currentActiveVersion: "V2",
      consentMessage: "You will be redirected to external website for completing the card payment. Kindly confirm your consent"
    }
  ],
  message: "Vendor consent details fetched successfully"
};

export const TENANT_ID = 'd726b9b1-42db-403d-b47e-a4516dda388c';
export const TENANT_ID_IN_HEADER = { 'tenant-id': 'd726b9b1-42db-403d-b47e-a4516dda388c' };

export const CREATE_CONSENT_PAYLOAD = {
  logo: { logo: 'logo' },
  vendorName: 'Ash',
  consentMessage: 'message'
};

export const CREATED_UL_CONSENT_RESPONSE = {
  message: 'UL Consent successfully created',
  data: {
    vendor_name: 'Ash',
    consent_version: 'V1',
    active_status: 'ACTIVE',
    current_active_version: 'V1',
    consent_message: 'message',
    dss_id: '4e8e1e87-9410-4275-9f4c-53ceb58cd837',
    consent_id: 'PR01',
    logo: { logo: 'logo' },
    dssVendorId: '990da60c-9ff5-4683-97ac-898e853d9126'
  }
};

export const UPDATE_CONSENT_PAYLOAD = {
  consentMessage: 'message'
};

export const UPDATED_UL_CONSENT_RESPONSE = {
  message: 'UL Consent successfully created',
  data: {
    vendor_name: 'Ash',
    consent_version: 'V2',
    active_status: 'ACTIVE',
    current_active_version: 'V2',
    consent_message: 'message 2',
    dss_id: '4e8e1e87-9410-4275-9f4c-53ceb58cd837',
    consent_id: 'PR01',
    logo: { logo: 'logo' },
    dssVendorId: '990da60c-9ff5-4683-97ac-898e853d9126'
  }
};

export const DSS_VENDOR_ID = '990da60c-9ff5-4683-97ac-898e853d9126'

export const DELETED_UL_CONSENT_RESPONSE = {
  message: 'UL Consent Deleted Successfully',
  data: 1
}

export const UNAUTHORIZED_ERROR = { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
export const CATCH_ERROR = {
  errors: [
    {
      type: ERROR_TYPE.CATCH,
      message: 'shows the error message while API failed in execution',
    },
  ],
};

export const GET_CONSENT_LIST_RESPONSE = {
  data: {
    results: [
      {
        "id": "AH02",
        "partnerName": "checkout.com",
        "consentMessage": "You will be redirected to external website for completing the card payment. Kindly confirm your consent",
        "currentActiveVersion": "V2",
        "createdAt": "2022-07-05T13:02:47.705Z",
        "logo": null
      },
      {
        "id": "PR02",
        "partnerName": "Ash",
        "consentMessage": "message 3",
        "currentActiveVersion": "V3",
        "createdAt": "2023-07-06T10:20:22.159Z",
        "logo": {
          "logo": "logo"
        }
      },
      {
        "id": "PR03",
        "partnerName": "Flash",
        "consentMessage": "Dont mess with the time",
        "currentActiveVersion": "V2",
        "createdAt": "2023-07-06T12:57:07.010Z",
        "logo": {
          "logo": "logo"
        }
      },
      {
        "id": "PR04",
        "partnerName": "Ash",
        "consentMessage": "message",
        "currentActiveVersion": "V1",
        "createdAt": "2023-07-07T06:29:52.153Z",
        "logo": {
          "logo": "logo"
        }
      },
      {
        "id": "PR05",
        "partnerName": "GET",
        "consentMessage": "message 0",
        "currentActiveVersion": "V2",
        "createdAt": "2023-07-07T06:36:25.062Z",
        "logo": {
          "logo": "logo"
        }
      }
    ],
    total: 5
  },
  message: "Consent list fetched successfully"
}

export const PAGE = 1;
export const PAGESIZE = 10;

export const GET_VENDORS_LIST_RESPONSE = {
  "data": [
    {
      "dssVendorId": "78367369-8074-4882-846c-54d6c1460897",
      "name": "CHECKOUT",
      "status": "ACTIVE",
      "details": null,
      "createdAt": "2023-07-03T06:18:12.719Z",
      "updatedAt": "2023-07-03T06:18:12.719Z",
      "logo": null
    },
    {
      "dssVendorId": "c9901d45-b9d6-404b-baf6-13b2142e14b5",
      "name": "RAPYED",
      "status": "ACTIVE",
      "details": null,
      "createdAt": "2023-07-03T06:18:12.719Z",
      "updatedAt": "2023-07-03T06:18:12.719Z",
      "logo": null
    },
    {
      "dssVendorId": "85684f4a-4acc-48d5-baeb-22f9aa1ff2f6",
      "name": "AUTHORIZED.NET",
      "status": "ACTIVE",
      "details": null,
      "createdAt": "2023-07-03T06:18:12.719Z",
      "updatedAt": "2023-07-03T06:18:12.719Z",
      "logo": null
    },
    {
      "dssVendorId": "949d3acc-1d2a-48d9-80e0-a362cbf8c70e",
      "name": "UL-OFFLINE",
      "status": "ACTIVE",
      "details": null,
      "createdAt": "2023-07-03T07:23:22.298Z",
      "updatedAt": "2023-07-03T07:23:22.298Z",
      "logo": null
    }
  ],
  "message": "Fetched vendors list successfully"
}

export const CREATE_PARTNER_PAYLOAD = {
  "tenantId": "",
  "details": {},
  "logo": {
    "logo": "logo"
  }
}

export const CREATE_PARTNER_RESPONSE = {
  "message": "UL consent is created successfully",
  "data": {
    "name": "CHECKOUT2",
    "status": "ACTIVE",
    "details": null,
    "logo": null,
    "dssVendorId": "f5629611-d645-4976-8241-f75f429c2e30"
  }
}

export const FETCH_PARTNERS_LIST_RESPONSE = {
  "message": "Fetched partner list successfully",
  "data": [
    {
      "dssVendorId": "78367369-8074-4882-846c-54d6c1460897",
      "name": "CHECKOUT",
      "status": "ACTIVE",
      "details": null,
      "createdAt": "2023-07-03T06:18:12.719Z",
      "updatedAt": "2023-07-03T06:18:12.719Z",
      "logo": {
        "abc": "abc"
      }
    }
  ],
  "page": 1,
  "pageSize": 10
}

export const FETCH_TC_PP_LIST_RESPONSE = {
  "message": "Fetched Terms & Conditions / Privacy Policy list successfully",
  "data": [
    {
      "agreementTemplateId": "78367369-8074-4882-846c-54d6c1460897",
      "template": "Content",
      "type": "PrivacyPolicy",
      "activeStatus": "ACTIVE",
      "id": 'PP01',
      "version": "V1.0",
      "currentActiveVersion": "V1.0",
      "dssVendorId": "78367369-8074-4882-846c-54d6c1460897"
    }
  ]
}

export const FETCH_TC_PP_BY_ID_RESPONSE = {
  "message": "Fetched Terms & Conditions / Privacy Policy successfully",
  "data": {
    "agreementTemplateId": "78367369-8074-4882-846c-54d6c1460897",
    "template": "Content",
    "type": "PrivacyPolicy",
    "activeStatus": "ACTIVE",
    "id": 'PP01',
    "version": "V1.0",
    "currentActiveVersion": "V1.0",
    "dssVendorId": "78367369-8074-4882-846c-54d6c1460897"
  }
}

export const UPDATE_TC_PP_BY_ID_RESPONSE = {
  "message": "UL01 UL_PRIVACY_POLICY updated successfully",
  "data": {
    "template": "content",
    "id": "UL02",
    "type": "UL_PRIVACY_POLICY",
    "version": "V2",
    "currentActiveVersion": "V2",
    "dssVendorId": null,
    "activeStatus": "ACTIVE",
    "created_at": "2023-08-28T14:17:40.920Z",
    "agreementTemplateId": "e7d0509f-6125-4dd8-be5a-e51b047c03a6"
  }
}

export const GET_CONSENT_LOGS_RESPONSE = {
  "data": {
    "results": [
      {
        "consentLogId": "ad53369d-c946-49c9-b612-6306260de63a",
        "tenantId": "2b7bf392-c669-40fc-8b71-c87b0b314a60",
        "customerAccountId": "fd780ded-8f84-4d5d-b89c-1c304d019f09",
        "partnerName": "CLIQ",
        "namespace": "msvltd.albertak.ul",
        "consentVersion": "V3",
        "status": "ACCEPTED",
        "createdAt": "2023-09-21T11:17:30.675Z",
        "updatedAt": "2023-09-21T11:17:30.675Z"
      },
      {
        "consentLogId": "cd46fd85-40f3-4fd4-8601-525960d1c5f7",
        "tenantId": "2b7bf392-c669-40fc-8b71-c87b0b314a60",
        "customerAccountId": "fd780ded-8f84-4d5d-b89c-1c304d019f09",
        "partnerName": "RAPYED",
        "namespace": "msvltd.albertak.ul",
        "consentVersion": "V4",
        "status": "ACCEPTED",
        "createdAt": "2023-09-21T10:32:00.255Z",
        "updatedAt": "2023-09-21T10:32:00.255Z"
      },
      {
        "consentLogId": "cb5ff184-24b8-4aaa-b457-dccb7a653c90",
        "tenantId": "2b7bf392-c669-40fc-8b71-c87b0b314a60",
        "customerAccountId": null,
        "partnerName": "CLIQ",
        "namespace": "msvltd.ul",
        "consentVersion": "V3",
        "status": "ACCEPTED",
        "createdAt": "2023-09-21T10:30:03.014Z",
        "updatedAt": "2023-09-21T10:30:03.014Z"
      },
      {
        "consentLogId": "7bbb0347-4f58-4d4b-8510-eca676180ba0",
        "tenantId": "2b7bf392-c669-40fc-8b71-c87b0b314a60",
        "customerAccountId": "fd780ded-8f84-4d5d-b89c-1c304d019f09",
        "partnerName": "CLIQ",
        "namespace": "msvltd.albertak.ul",
        "consentVersion": "V3",
        "status": "ACCEPTED",
        "createdAt": "2023-09-21T10:14:26.698Z",
        "updatedAt": "2023-09-21T10:14:26.698Z"
      }
    ],
    "total": 4
  },
  "message": "Consent Logs fetched successfully"
}