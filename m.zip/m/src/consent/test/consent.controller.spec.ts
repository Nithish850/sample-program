import { ConsentController } from '../controller/consent.controller';
import { ConsentService } from '../service/consent.service';
import {
  CATCH_ERROR,
  CREATED_UL_CONSENT_RESPONSE,
  CREATE_CONSENT_PAYLOAD,
  CREATE_PARTNER_PAYLOAD,
  CREATE_PARTNER_RESPONSE,
  DELETED_UL_CONSENT_RESPONSE,
  DSS_VENDOR_ID,
  FETCH_PARTNERS_LIST_RESPONSE,
  FETCH_TC_PP_BY_ID_RESPONSE,
  FETCH_TC_PP_LIST_RESPONSE,
  GET_CONSENT_LIST_RESPONSE,
  GET_CONSENT_LOGS_RESPONSE,
  GET_CUSTOMER_CONSENT_PAYLOAD,
  GET_CUSTOMER_CONSENT_RESPONSE,
  GET_VENDORS_LIST_RESPONSE,
  GET_VENDOR_CONSENT_MESSAGE_RESPONSE,
  PAGE,
  PAGESIZE,
  TENANT_ID,
  TENANT_ID_IN_HEADER,
  UNAUTHORIZED_ERROR,
  UPDATED_UL_CONSENT_RESPONSE,
  UPDATE_CONSENT_PAYLOAD,
  UPDATE_TC_PP_BY_ID_RESPONSE
} from './consent.testConfig';
import { Test } from '@nestjs/testing';
import { mockRequest, mockResponse } from 'jest-mock-req-res';

const mockConsentService = {
  getCustomerConsent: jest.fn(() => GET_CUSTOMER_CONSENT_RESPONSE),
  getVendorConsentDetails: jest.fn(() => GET_VENDOR_CONSENT_MESSAGE_RESPONSE),
  createULConsent: jest.fn(() => CREATED_UL_CONSENT_RESPONSE),
  updateULConsent: jest.fn(() => UPDATED_UL_CONSENT_RESPONSE),
  deleteULConsent: jest.fn(() => DELETED_UL_CONSENT_RESPONSE),
  getConsentList: jest.fn(() => GET_CONSENT_LIST_RESPONSE),
  getVendorList: jest.fn(() => GET_VENDORS_LIST_RESPONSE),
  createPartner: jest.fn(() => CREATE_PARTNER_RESPONSE),
  getPartnersList: jest.fn(() => FETCH_PARTNERS_LIST_RESPONSE),
  getTermsAndConditionsOrPrivacyPolicy: jest.fn(() => FETCH_TC_PP_LIST_RESPONSE),
  getTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => FETCH_TC_PP_BY_ID_RESPONSE),
  updateTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => UPDATE_TC_PP_BY_ID_RESPONSE),
};

// Test cases to create primary name space
describe('Consent Controller', () => {
  let consentController: ConsentController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsentController ],
      providers: [ ConsentService ],
    })
      .overrideProvider(ConsentService)
      .useValue(mockConsentService)
      .compile();

    consentController = moduleRef.get<ConsentController>(ConsentController);
  });

  /** Success Test cases for the getCustomerConsent() POST api */
  describe('should be able to test if we are able to get customer consent or not', () => {

    const request = mockRequest(GET_CUSTOMER_CONSENT_PAYLOAD);
    const response = mockResponse({
      HttpStatus: 201,
      body: GET_CUSTOMER_CONSENT_RESPONSE,
    });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, response, request);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, response, request);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, response, request);

      expect(res.HttpStatus).toEqual(201);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, response, request);

      expect(res.body).toEqual(GET_CUSTOMER_CONSENT_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, response, request);

      expect(res.body.data).toEqual(GET_CUSTOMER_CONSENT_RESPONSE.data);
    });
  });

  /** Success Test cases for the getVendorConsentDetails() GET api */
  describe('should be able to test if we are able to get vendor consent details or not', () => {

    const response = mockResponse({
      HttpStatus: 200,
      body: GET_VENDOR_CONSENT_MESSAGE_RESPONSE,
    });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID, response);

      expect(res.body).toEqual(GET_VENDOR_CONSENT_MESSAGE_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID, response);

      expect(res.body.data).toEqual(GET_VENDOR_CONSENT_MESSAGE_RESPONSE.data);
    });
  });

  /** Success Test cases for the createULConsent() POST api */
  describe('should be able to test if we are able to create UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 201,
      body: CREATED_UL_CONSENT_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.HttpStatus).toEqual(201);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).toEqual(CREATED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body.data).toEqual(CREATED_UL_CONSENT_RESPONSE.data);
    });
  });

  /** Success Test cases for the updateULConsent() PUT api */
  describe('should be able to test if we are able to update UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 202,
      body: UPDATED_UL_CONSENT_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(202);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(UPDATED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.data).toEqual(UPDATED_UL_CONSENT_RESPONSE.data);
    });
  });

  /** Success Test cases for the deleteULConsent() DELETE api */
  describe('should be able to test if we are able to deleted UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 202,
      body: DELETED_UL_CONSENT_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(202);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(DELETED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.data).toEqual(DELETED_UL_CONSENT_RESPONSE.data);
    });
  });

  /** Success Test cases for the getConsentList() GET api */
  describe('should be able to test if we are able to get consent list or not', () => {

    const response = mockResponse({
      HttpStatus: 200,
      body: GET_CONSENT_LIST_RESPONSE,
    });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getConsentList('','', PAGE, PAGESIZE, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getConsentList('','', PAGE, PAGESIZE, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getConsentList('','', PAGE, PAGESIZE, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getConsentList('','', PAGE, PAGESIZE, response);

      expect(res.body).toEqual(GET_CONSENT_LIST_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getConsentList('','', PAGE, PAGESIZE, response);

      expect(res.body.data).toEqual(GET_CONSENT_LIST_RESPONSE.data);
    });
  });

  /** Success Test cases for the getVendorList() GET api */
  describe('should be able to test getting vendor list or not', () => {

    const response = mockResponse({
      HttpStatus: 200,
      body: GET_VENDORS_LIST_RESPONSE,
    });

    const request = mockRequest();

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getVendorList(request, response);

      expect(res.body).toEqual(GET_VENDORS_LIST_RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getVendorList(request, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getVendorList(request, response);

      expect(res.body).toEqual(GET_VENDORS_LIST_RESPONSE);
    });
  });

  /** Success Test cases for the createPartner() POST api */
  describe('should be able to test if we are able to create Partner or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 201,
      body: CREATE_PARTNER_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(201);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).toEqual(CREATE_PARTNER_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body.data).toEqual(CREATE_PARTNER_RESPONSE.data);
    });
  });

  /** Success Test cases for the getPartnersList() GET api */
  describe('should be able to test if we are able to get consent list or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 200,
      body: FETCH_PARTNERS_LIST_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(FETCH_PARTNERS_LIST_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.data).toEqual(FETCH_PARTNERS_LIST_RESPONSE.data);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicy() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicy or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 200,
      body: FETCH_TC_PP_LIST_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(FETCH_TC_PP_LIST_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.data).toEqual(FETCH_TC_PP_LIST_RESPONSE.data);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicyById() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 200,
      body: FETCH_TC_PP_BY_ID_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(FETCH_TC_PP_BY_ID_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.data).toEqual(FETCH_TC_PP_BY_ID_RESPONSE.data);
    });
  });

  /** Success Test cases for the updateTermsAndConditionsOrPrivacyPolicyById() PUT api */
  describe('should be able to test if we are able to updateTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 201,
      body: UPDATE_TC_PP_BY_ID_RESPONSE,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(201);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(UPDATE_TC_PP_BY_ID_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.data).toEqual(UPDATE_TC_PP_BY_ID_RESPONSE.data);
    });
  });
});

const mockConsentServiceUnauthorized = {
  createULConsent: jest.fn(() => UNAUTHORIZED_ERROR),
  updateULConsent: jest.fn(() => UNAUTHORIZED_ERROR),
  deleteULConsent: jest.fn(() => UNAUTHORIZED_ERROR),
  createPartner: jest.fn(() => UNAUTHORIZED_ERROR),
  getPartnersList: jest.fn(() => UNAUTHORIZED_ERROR),
  getTermsAndConditionsOrPrivacyPolicy: jest.fn(() => UNAUTHORIZED_ERROR),
  getTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => UNAUTHORIZED_ERROR),
  updateTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => UNAUTHORIZED_ERROR),
};

describe('Consent Controller', () => {
  let consentController: ConsentController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsentController ],
      providers: [ ConsentService ],
    })
      .overrideProvider(ConsentService)
      .useValue(mockConsentServiceUnauthorized)
      .compile();

    consentController = moduleRef.get<ConsentController>(ConsentController);
  });

  /** Success Test cases for the createULConsent() POST api */
  describe('should be able to test if we are able to create UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the updateULConsent() PUT api */
  describe('should be able to test if we are able to update UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the deleteULConsent() DELETE api */
  describe('should be able to test if we are able to deleted UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the createPartner() POST api */
  describe('should be able to test if we are able to create UL vendor consent or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the getPartnersList() GET api */
  describe('should be able to test if we are able to create UL vendor consent or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicy() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicy or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicyById() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

  /** Success Test cases for the updateTermsAndConditionsOrPrivacyPolicyById() PUT api */
  describe('should be able to test if we are able to updateTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 401,
      body: UNAUTHORIZED_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(401);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(UNAUTHORIZED_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(UNAUTHORIZED_ERROR.errors);
    });
  });

});

const mockConsentServiceCatchError = {
  createULConsent: jest.fn(() => CATCH_ERROR),
  updateULConsent: jest.fn(() => CATCH_ERROR),
  deleteULConsent: jest.fn(() => CATCH_ERROR),
  createPartner: jest.fn(() => CATCH_ERROR),
  getPartnersList: jest.fn(() => CATCH_ERROR),
  getTermsAndConditionsOrPrivacyPolicy: jest.fn(() => CATCH_ERROR),
  getTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => CATCH_ERROR),
  updateTermsAndConditionsOrPrivacyPolicyById: jest.fn(() => CATCH_ERROR),
  getConsentLogs: jest.fn(() => GET_CONSENT_LOGS_RESPONSE),
};

describe('Consent Controller', () => {
  let consentController: ConsentController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsentController ],
      providers: [ ConsentService ],
    })
      .overrideProvider(ConsentService)
      .useValue(mockConsentServiceCatchError)
      .compile();

    consentController = moduleRef.get<ConsentController>(ConsentController);
  });

  /** Success Test cases for the createULConsent() POST api */
  describe('should be able to test if we are able to create UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createULConsent(CREATE_CONSENT_PAYLOAD, REQUEST, response);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the updateULConsent() PUT api */
  describe('should be able to test if we are able to update UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the deleteULConsent() DELETE api */
  describe('should be able to test if we are able to deleted UL vendor consent or not', () => {

    const response = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.deleteULConsent(DSS_VENDOR_ID, REQUEST, response);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the createPartner() POST api */
  describe('should be able to test if we are able to deleted UL vendor consent or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.createPartner(CREATE_PARTNER_PAYLOAD, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the getPartnersList() GET api */
  describe('should be able to test if we are able to deleted UL vendor consent or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getPartnersList(PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicy() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicy or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicy('Privacy Policy', PAGE, PAGESIZE, RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the getTermsAndConditionsOrPrivacyPolicyById() GET api */
  describe('should be able to test if we are able to getTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getTermsAndConditionsOrPrivacyPolicyById( 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the updateTermsAndConditionsOrPrivacyPolicyById() PUT api */
  describe('should be able to test if we are able to updateTermsAndConditionsOrPrivacyPolicyById or not', () => {

    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: CATCH_ERROR,
    });

    const REQUEST = mockRequest({ headers: TENANT_ID_IN_HEADER });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res).toEqual(RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body).toEqual(CATCH_ERROR);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.updateTermsAndConditionsOrPrivacyPolicyById( { template: 'content' }, 'UL01', 'Privacy Policy', RESPONSE, REQUEST);

      expect(res.body.errors).toEqual(CATCH_ERROR.errors);
    });
  });

  /** Success Test cases for the getConsentLogs() GET api */
  describe('should be able to test if we are able to get consent logs or not', () => {

    const response = mockResponse({
      HttpStatus: 200,
      body: GET_CONSENT_LOGS_RESPONSE,
    });

    it('should be able to check if consent controller is defined or not', () => {
      expect(consentController).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentController.getConsentLogs('', '', PAGE, PAGESIZE, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consentController.getConsentLogs('', '', PAGE, PAGESIZE, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting success status code or not.', async () => {
      const res = await consentController.getConsentLogs('', '', PAGE, PAGESIZE, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consentController.getConsentLogs('', '', PAGE, PAGESIZE, response);

      expect(res.body).toEqual(GET_CONSENT_LOGS_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentController.getConsentLogs('', '', PAGE, PAGESIZE, response);

      expect(res.body.data).toEqual(GET_CONSENT_LOGS_RESPONSE.data);
    });
  });

});