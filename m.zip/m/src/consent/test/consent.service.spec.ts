import { mockRequest } from 'jest-mock-req-res';
import { ConsentController } from '../controller/consent.controller';
import { ConsentService } from '../service/consent.service';
import {
  CREATED_UL_CONSENT_RESPONSE,
  CREATE_CONSENT_PAYLOAD,
  DELETED_UL_CONSENT_RESPONSE,
  DSS_VENDOR_ID,
  GET_CONSENT_LIST_RESPONSE,
  GET_CONSENT_LOGS_RESPONSE,
  GET_CUSTOMER_CONSENT_PAYLOAD,
  GET_CUSTOMER_CONSENT_RESPONSE,
  GET_VENDORS_LIST_RESPONSE,
  GET_VENDOR_CONSENT_MESSAGE_RESPONSE,
  PAGE,
  PAGESIZE,
  TENANT_ID,
  TENANT_ID_IN_HEADER,
  UPDATED_UL_CONSENT_RESPONSE,
  UPDATE_CONSENT_PAYLOAD
} from './consent.testConfig';

import { Test } from '@nestjs/testing';

const mockConsentService = {
  getCustomerConsent: jest.fn(() => GET_CUSTOMER_CONSENT_RESPONSE),
  getVendorConsentDetails: jest.fn(() => GET_VENDOR_CONSENT_MESSAGE_RESPONSE),
  createULConsent: jest.fn(() => CREATED_UL_CONSENT_RESPONSE),
  updateULConsent: jest.fn(() => UPDATED_UL_CONSENT_RESPONSE),
  deleteULConsent: jest.fn(() => DELETED_UL_CONSENT_RESPONSE),
  getConsentList: jest.fn(() => GET_CONSENT_LIST_RESPONSE),
  getVendorList: jest.fn(() => GET_VENDORS_LIST_RESPONSE),
  getConsentLogs: jest.fn(() => GET_CONSENT_LOGS_RESPONSE),
};

// Test cases to create primary name space
describe('ConsentService', () => {
  let consentService: ConsentService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsentController ],
      providers: [ ConsentService ],
    })
      .overrideProvider(ConsentService)
      .useValue(mockConsentService)
      .compile();

    consentService = moduleRef.get<ConsentService>(ConsentService);
  });

  /**
   * Test Cases for the getCustomerConsent() function SUCCESS
   */
  describe('Test case to check the functionality of the getCustomerConsent() function: POST / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res).toEqual(GET_CUSTOMER_CONSENT_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data).not.toBeNull();
    });

    it('should make sure that consent service gets called', () => {
      expect(consentService.getCustomerConsent).toBeCalled();
    });

    it('should make sure that getCustomerConsent gets called with requested payload', () => {
      expect(consentService.getCustomerConsent).toHaveBeenCalledWith(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);
    });

    it('should check if customerConsentId is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data.customerConsentId).not.toBeNull();
    });

    it('should check if customerAccountId is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data.customerAccountId).not.toBeNull();
    });

    it('should check if dssVendorId is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data.dssVendorId).not.toBeNull();
    });

    it('should check if consent Status is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data.consentStatus).not.toBeNull();
    });

    it('should check if consent Version is not null', async () => {
      const res = await consentService.getCustomerConsent(GET_CUSTOMER_CONSENT_PAYLOAD, TENANT_ID);

      expect(res.data.consentVersion).not.toBeNull();
    });

  });

  /**
   * Test Cases for the getVendorConsentDetails() function SUCCESS
   */
  describe('Test case to check the functionality of the getVendorConsentDetails() function: GET / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID);

      expect(res).toEqual(GET_VENDOR_CONSENT_MESSAGE_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that consent service gets called', () => {
      expect(consentService.getVendorConsentDetails).toBeCalled();
    });

    it('should be make sure that getVendorConsentDetails gets called with requested payload', () => {
      expect(consentService.getVendorConsentDetails).toHaveBeenCalledWith('Deposits', 'ACH', TENANT_ID);
    });

    it('should check if vendor name is not null', async () => {
      const res = await consentService.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID);

      expect(res.data.vendorName).not.toBeNull();
    });

    it('should check if consent Message is not null', async () => {
      const res = await consentService.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID);

      expect(res.data.consentMessage).not.toBeNull();
    });

    it('should check if current Active Version is not null', async () => {
      const res = await consentService.getVendorConsentDetails('Deposits', 'ACH', TENANT_ID);

      expect(res.data.currentActiveVersion).not.toBeNull();
    });

  });

  describe('Test case to check the functionality of the createULConsent() function: POST / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.createULConsent(CREATE_CONSENT_PAYLOAD, TENANT_ID_IN_HEADER);

      expect(res).toEqual(CREATED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.createULConsent(CREATE_CONSENT_PAYLOAD, TENANT_ID_IN_HEADER);

      expect(res.data).not.toBeNull();
    });

    it('should make sure that consent service gets called', () => {
      expect(consentService.createULConsent).toBeCalled();
    });
  });

  describe('Test case to check the functionality of the updateULConsent() function: PUT / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, TENANT_ID_IN_HEADER);

      expect(res).toEqual(UPDATED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.updateULConsent(UPDATE_CONSENT_PAYLOAD, DSS_VENDOR_ID, TENANT_ID_IN_HEADER);

      expect(res.data).not.toBeNull();
    });

    it('should make sure that consent service gets called', () => {
      expect(consentService.updateULConsent).toBeCalled();
    });
  });

  describe('Test case to check the functionality of the deleteULConsent() function: DELETE / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.deleteULConsent(DSS_VENDOR_ID, TENANT_ID_IN_HEADER);

      expect(res).toEqual(DELETED_UL_CONSENT_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.deleteULConsent(DSS_VENDOR_ID, TENANT_ID_IN_HEADER);

      expect(res.data).not.toBeNull();
    });

    it('should make sure that consent service gets called', () => {
      expect(consentService.deleteULConsent).toBeCalled();
    });
  });

  /**
   * Test Cases for the getConsentList() function SUCCESS
   */
  describe('Test case to check the functionality of the getConsentList() function: GET / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consentService.getConsentList('','', PAGE, PAGESIZE);

      expect(res).toEqual(GET_CONSENT_LIST_RESPONSE);
    });

    it('should check if response data is not null', async () => {
      const res = await consentService.getConsentList('','', PAGE, PAGESIZE);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that consent service gets called', () => {
      expect(consentService.getConsentList).toBeCalled();
    });

    it('should be make sure that getConsentList gets called with requested payload', () => {
      expect(consentService.getConsentList).toHaveBeenCalledWith('','', PAGE, PAGESIZE);
    });

    it('should check if message is not null', async () => {
      const res = await consentService.getConsentList('','', PAGE, PAGESIZE);

      expect(res.message).not.toBeNull();
    });

    it('should check if results is not null', async () => {
      const res = await consentService.getConsentList('','', PAGE, PAGESIZE);

      expect(res.data.results).not.toBeNull();
    });

  });

  /** Success Test cases for the getVendorList() GET api */
  describe('should be able to test getting vendor list or not', () => {

    const request = mockRequest();

    it('should be able to check if consent service is defined or not', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if we are getting proper response or not.', async () => {
      const res = await consentService.getVendorList(request.header);

      expect(res).toEqual(GET_VENDORS_LIST_RESPONSE);
    });

    it('should check if response body is not null', async () => {
      const res = await consentService.getVendorList(request.header);

      expect(res).not.toBeNull();
    });

    it('should check if response body has data or not', async () => {
      const res = await consentService.getVendorList(request.header);

      expect(res).toEqual(GET_VENDORS_LIST_RESPONSE);
    });
  });

  /** Success Test cases for the getConsentLogs() GET api */
  describe('should be able to test if we are able to get consent logs or not', () => {

    it('should be able to check if consent service is defined or not', () => {
      expect(consentService).toBeDefined();
    });

    it('should check if response body is not null', async () => {
      const res = await consentService.getConsentLogs('', '', PAGE, PAGESIZE);

      expect(res).not.toBeNull();
    });

    it('should check if response body has data or not', async () => {
      const res = await consentService.getConsentLogs('', '', PAGE, PAGESIZE);

      expect(res).toEqual(GET_CONSENT_LOGS_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consentService.getConsentLogs('', '', PAGE, PAGESIZE);

      expect(res.data).toEqual(GET_CONSENT_LOGS_RESPONSE.data);
    });
  });

});
