import { Request, Response } from 'express';
import { Body, Controller, Delete, Get, HttpStatus, Logger, Param, Post, Put, Query, Req, Res } from "@nestjs/common";
import { ApiAcceptedResponse, ApiBadRequestResponse, ApiBody, ApiCreatedResponse, ApiHeader, ApiNotAcceptableResponse, ApiNotFoundResponse, ApiOkResponse, ApiOperation, ApiParam, ApiQuery, ApiTags, ApiUnauthorizedResponse } from "@nestjs/swagger";
import { ConsentService } from "../service/consent.service";
import { AddCustomerConsent, AddCustomerConsentErrorRes, AddCustomerConsentSuccess } from '../dto/customer-consent';
import { VendorConsentDetailsErrorRes, VendorConsentDetailsNoDataRes, VendorConsentDetailsSuccessRes } from '../dto/dss-vendor-consent';
import { ERROR_TYPE } from '../../utils/constant';
import { GetConsentStatusErrorRes, GetConsentStatusNoDataRes, GetConsentStatusSuccessRes } from '../dto/consent-status';
import { CreateConsentCatchErrorDO, CreateULConsentBody, CreateULConsentDO, DeleteConsentCatchErrorDO, DeleteULConsentDO } from '../dto/create-ul-consent';
import { UnauthorizedDO, UpdateConsentCatchErrorDO, UpdateULConsentBody, UpdateULConsentDO } from '../dto/update-ul-consent';
import { GetConsentListErrorRes, GetConsentListNoDataRes, GetConsentListSuccessRes } from '../dto/consent-list';
import { VendorsErrorRes, VendorsNoDataFoundErrorDTO, VendorsSuccessRes } from '../dto/dss-vendors';
import { CreatePartnerBody, CreatePartnerCatchError, CreatePartnerNotAcceptable, CreatePartnerSuccessDTO, CreatePartnerUnauthorized } from '../dto/create-partner';
import { FetchPartnerUnauthorized, FetchedPartnerCatchError, FetchedPartnerDTO } from '../dto/get-partners-list';
import { FetchLatestTCOrPP, FetchTCOrPPByIdSuccess, FetchTCOrPPCatchError, FetchTCOrPPSuccess, FetchTCOrPPUnauthorized, UpdatedTCOrPPByIdSuccess, policyPayload } from '../dto/get-tc-pp-list';
import { GetConsentLogsErrorRes, GetConsentLogsNoDataRes } from '../dto/consent-logs';

@Controller()
@ApiTags('Consent')
export class ConsentController {
  private readonly logger = new Logger(ConsentController.name);
  constructor(private readonly consentService: ConsentService) { }

  /**
     * API to accept customer consent for a particular vendor
     * @param consentStatus
     * @return success response for adding customer consent
     */
  @Post('accept-consent')
  @ApiBody({ type: () => AddCustomerConsent, required: true })
  @ApiHeader({ name: 'tenant-id', description: 'Tenant Id', required: true, })
  @ApiOperation({ summary: 'accept customer or tenant consent | Author : Komal Prakash ' })
  @ApiCreatedResponse({ description: 'Success Response when consent is accepted successfully', type: () => AddCustomerConsentSuccess })
  @ApiBadRequestResponse({ description: 'Error response when accept consent api gets failed.', type: () => AddCustomerConsentErrorRes })
  async getCustomerConsent(@Body() addCustomerConsent: AddCustomerConsent, @Res() res: Response, @Req() req: Request,): Promise<any> {
    this.logger.log(`inside accept consent controller :: {start}`);
    const response: any = await this.consentService.getCustomerConsent(addCustomerConsent, req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.CREATED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

  /**
   * API to fetch vendor consent details for a particular vendor
   * @param tenantId tenantId of the customer
   * @return vendor consent details
   */
  @Get('consent-message/:tenantId')
  @ApiOkResponse({
    description: 'Get consent message',
    type: () => VendorConsentDetailsSuccessRes,
  })
  @ApiNotFoundResponse({
    description: 'No data response if there is no details for the given vendor',
    type: () => VendorConsentDetailsNoDataRes,
    isArray: false,
  })
  @ApiBadRequestResponse({ description: 'Error response when consent-message api gets failed.', type: () => VendorConsentDetailsErrorRes })
  @ApiParam({
    name: 'tenantId',
    description: 'tenant Id',
    required: true,
  })
  @ApiQuery({
    name: 'subCategory',
    description: 'Sub Category',
    required: true,
    example: 'Deposits'
  })
  @ApiQuery({
    name: 'type',
    description: 'Type',
    required: true,
    example: 'ACH'
  })
  @ApiOperation({ summary: 'get consent message | Author : Komal Prakash ' })
  async getVendorConsentDetails(@Query('subCategory') subCategory: string, @Query('type') type: string, @Param('tenantId') tenantId: string, @Res() res: Response): Promise<any> {
    this.logger.log(`inside consent controller :: {start}`);
    const response: any = await this.consentService.getVendorConsentDetails(subCategory, type, tenantId);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

  /**
   * API to check consent status for a customer
   * @param customerAccountId customerAccountId of the customer
   * @return consent status details
   */
  @Get('consent-status')
  @ApiOkResponse({
    description: 'Check consent status',
    type: () => GetConsentStatusSuccessRes,
  })
  @ApiNotFoundResponse({
    description: `will give you the error response when no consent is present for the customer`,
    type: () => GetConsentStatusNoDataRes,
  })
  @ApiBadRequestResponse({
    description: 'Error response when consent-status api gets failed.',
    type: () => GetConsentStatusErrorRes
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    required: true,
  })
  @ApiQuery({
    name: 'customerAccountId',
    description: 'customer Account Id',
    required: false,
  })
  @ApiQuery({
    name: 'subCategory',
    description: 'Sub Category',
    required: true,
    example: 'Deposits'
  })
  @ApiQuery({
    name: 'type',
    description: 'Type',
    required: true,
    example: 'ACH'
  })
  @ApiOperation({ summary: 'check consent status | Author : Komal Prakash ' })
  async checkConsentStatus(@Query('subCategory') subCategory: string, @Query('type') type: string, @Query('customerAccountId') customerAccountId: string, @Req() req: Request,  @Res() res: Response): Promise<any> {
    this.logger.log(`inside consent controller :: {start}`);
    this.logger.log(`customerAccountId controller: ${customerAccountId} `);

    const tenantId = req.headers['tenant-id'];

    const response: any = await this.consentService.checkConsentStatus(subCategory, type, customerAccountId, tenantId);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);

  }

/**
 * API to get the consent list
 * @param search
 * @param filter
 * @param page
 * @param pagesize
 * @return consent list
 */
@Get('consent-list')
@ApiOkResponse({
  description: 'Get consent list',
  type: () => GetConsentListSuccessRes,
})
@ApiNotFoundResponse({
  description: `will give you the error response when no consent is present for the customer`,
  type: () => GetConsentListNoDataRes,
})
@ApiBadRequestResponse({
  description: 'Error response when consent-list api gets failed.',
  type: () => GetConsentListErrorRes
})
@ApiQuery({
  name: 'filter',
  description: 'filter by partner name',
  example: 'checkout.com',
  required: false,
})
@ApiQuery({
  name: 'search',
  description: 'search by partner name',
  example: 'checkout.com',
  required: false,
})
@ApiQuery({
  name: 'page',
  description: 'Page index',
  required: true,
})
@ApiQuery({
  name: 'pagesize',
  description: 'Page size',
  required: true,
})
@ApiOperation({ summary: 'check consent status | Author : Komal Prakash ' })
  async getConsentList(@Query('filter') filter: string, @Query('search') search: string, @Query('page') page: number, @Query('pagesize') pagesize: number, @Res() res: Response): Promise<any> {
    this.logger.log(`inside consent controller :: {start}`);
    const response:any  = await this.consentService.getConsentList(filter, search, page - 1, pagesize);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }
    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to create an UL Consent
   * @return - it will return the newly created consent details
   */
  @Post('create-consent')
  @ApiCreatedResponse({ type: () => CreateULConsentDO, description: 'Get the created UL consent data' })
  @ApiUnauthorizedResponse({ type: () => UnauthorizedDO, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => CreateConsentCatchErrorDO, description: 'Error response while create an UL Consent failed' })
  @ApiBody({ type: () => CreateULConsentBody })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiOperation({ summary: 'Create an UL Consent | Author : Guru' })
async createULConsent(@Body() reqBody: CreateULConsentBody, @Req() req: Request, @Res() res: Response): Promise<any> {
  this.logger.log(`Create an UL Consent controller :: {start}`);

  const response = await this.consentService.createULConsent(reqBody, req.headers);

  if (response && response.data) {
    return res.status(HttpStatus.CREATED).send(response);
  }

  if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
    return res.status(HttpStatus.UNAUTHORIZED).send(response);
  }

  return res.status(HttpStatus.BAD_REQUEST).send(response);
}

  /**
   * API to update an UL Consent
   * @return - it will return the newly created consent details with the old consent has the updated active_status and current_active_version
   */
  @Put('update-consent/:dssVendorId')
  @ApiAcceptedResponse({ type: () => UpdateULConsentDO, description: 'Get the updated UL Consent data' })
  @ApiUnauthorizedResponse({ type: () => UnauthorizedDO, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => UpdateConsentCatchErrorDO, description: 'Error response while update an UL Consent failed' })
  @ApiParam({
    name: 'dssVendorId',
    description: 'Dss Vendor Id',
    required: true,
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiBody({ type: () => UpdateULConsentBody })
  @ApiOperation({ summary: 'Update an UL Consent | Author : Guru' })
  async updateULConsent(@Body() reqBody: UpdateULConsentBody, @Param('dssVendorId') dssVendorId: string, @Req() req: Request, @Res() res: Response): Promise<any> {
    this.logger.log(`Update an UL Consent controller :: {start}`);

    const response = await this.consentService.updateULConsent(reqBody, dssVendorId, req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.ACCEPTED).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to delete an UL Consent
   * @return - it will return delete consent details records
   */
  @Delete('delete-consent/:dssVendorId')
  @ApiAcceptedResponse({ type: () => DeleteULConsentDO, description: 'Get the deleted UL Consent data' })
  @ApiUnauthorizedResponse({ type: () => UnauthorizedDO, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => DeleteConsentCatchErrorDO, description: 'Error response while delete an UL consent failed' })
  @ApiParam({
    name: 'dssVendorId',
    description: 'Dss Vendor Id',
    required: true
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiOperation({ summary: 'Delete an UL Consent | Author : Guru' })
  async deleteULConsent(@Param('dssVendorId') dssVendorId: string, @Req() req: Request, @Res() res: Response): Promise<any> {
    this.logger.log(`Delete an UL Consent controller :: {start}`);

    const response = await this.consentService.deleteULConsent(dssVendorId, req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.ACCEPTED).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to fetch vendors list
   * @return vendors list
   */
  @Get('vendors')
  @ApiOkResponse({
    description: 'Get vendors list',
    type: () => VendorsSuccessRes,
  })
  @ApiNotFoundResponse({
    description: 'No data response if there is no vendor',
    type: () => VendorsNoDataFoundErrorDTO,
    isArray: false,
  })
  @ApiBadRequestResponse({ description: 'Error response when get vendors api gets fail.', type: () => VendorsErrorRes })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiOperation({ summary: 'get vendors | Author : Qamar Khan' })
  async getVendorList(@Req() req: Request, @Res() res: Response): Promise<any> {
    this.logger.log(`inside consent controller :: {start}`);
    const response: any = await this.consentService.getVendorList(req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * Create Partner API
   * @param payload with name, details and logo
   */
  @Post('create-partner')
  @ApiBadRequestResponse({ type: () => CreatePartnerCatchError, description: 'Bad Request Response' })
  @ApiCreatedResponse({ type: () => CreatePartnerSuccessDTO, description: 'Success Payload' })
  @ApiNotAcceptableResponse({ type: () => CreatePartnerNotAcceptable, description: 'Not Acceptable Response' })
  @ApiUnauthorizedResponse({ type: () => CreatePartnerUnauthorized, description: 'Unauthorized Response' })
  @ApiBody({ type: () => CreatePartnerBody })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    required: true,
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
  })
  async createPartner(@Body() payload: CreatePartnerBody, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log(`inside consent controller :: create partner : {start}`);
    const response: any = await this.consentService.createPartner(payload, req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.CREATED).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.PARTNER) {
      return res.status(HttpStatus.NOT_ACCEPTABLE).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).status(response);
  }

  /**
   * Fetch the Partners list with or without the limit.
   * @param page Index of the page
   * @param pageSize Size of the page
   */
  @Get('fetch-partners-list')
  @ApiBadRequestResponse({ type: () => FetchedPartnerCatchError, description: 'Bad Request Response' })
  @ApiOkResponse({ type: () => FetchedPartnerDTO, description: 'Success Response' })
  @ApiUnauthorizedResponse({ type: () => FetchPartnerUnauthorized, description: 'Unauthorized Response' })
  @ApiQuery({
    name: 'page',
    type: Number,
    description: 'Page index',
    required: false,
    example: 1
  })
  @ApiQuery({
    name: 'pageSize',
    type: Number,
    description: 'Page size',
    required: false,
    example: 10
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    required: true,
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe'
  })
  async getPartnersList(@Query('page') page: number, @Query('pageSize') pageSize: number, @Res() res: Response, @Req() req: Request): Promise<any> {
    this.logger.log(`inside consent controller :: create partner : {start}`);
    const response: any = await this.consentService.getPartnersList(page-1, pageSize, req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to Get the Terms & Condition / Privacy Policy list data
   * @return - it will return list of records which contains Terms & Condition or Privacy Policy
   */
  @Get('privacy-policy-or-terms-conditions-list')
  @ApiOkResponse({ type: () => FetchTCOrPPSuccess, description: 'Get the Terms & Condition or Privacy Policy list data' })
  @ApiUnauthorizedResponse({ type: () => FetchTCOrPPUnauthorized, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => FetchTCOrPPCatchError, description: 'Error response while fetching the Terms & Condition or Privacy Policy failed' })
  @ApiQuery({
    name: 'type',
    description: 'document type',
    example: 'PRIVACY_POLICY / TERMS_CONDITIONS',
    required: true
  })
  @ApiQuery({
    name: 'page',
    type: Number,
    description: 'Page index',
    required: false,
    example: 1
  })
  @ApiQuery({
    name: 'pageSize',
    type: Number,
    description: 'Page size',
    required: false,
    example: 10
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiOperation({ summary: 'Get the Terms & Condition or Privacy Policy list data | Author : Guru' })
  async getTermsAndConditionsOrPrivacyPolicy(
    @Query('type') type: string,
    @Query('page') page: number,
    @Query('pageSize') pageSize: number,
    @Res() res: Response,
    @Req() req: Request
  ): Promise<any> {
    this.logger.log(`inside T&C or Privacy Policy controller : {start}`);
    const response: any = await this.consentService.getTermsAndConditionsOrPrivacyPolicy(type.trim(), page-1, Number(pageSize), req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to Get the Terms & Condition / Privacy Policy data by Id
   * @return - it will return a data which contains Terms & Condition or Privacy Policy
   */
  @Get('privacy-policy-or-terms-conditions-by-id/:id')
  @ApiOkResponse({ type: () => FetchTCOrPPByIdSuccess, description: 'Get the Terms & Condition or Privacy Policy by Id' })
  @ApiUnauthorizedResponse({ type: () => FetchTCOrPPUnauthorized, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => FetchTCOrPPCatchError, description: 'Error response while fetching the Terms & Condition or Privacy Policy failed' })
  @ApiQuery({
    name: 'type',
    description: 'document type',
    example: 'PRIVACY_POLICY / TERMS_CONDITIONS',
    required: true
  })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'Id',
    required: true,
    example: 'UL01'
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiOperation({ summary: 'Get Terms & Condition or Privacy Policy by Id | Author : Guru' })
  async getTermsAndConditionsOrPrivacyPolicyById(
    @Query('type') type: string,
    @Param('id') id: string,
    @Res() res: Response,
    @Req() req: Request
  ): Promise<any> {
    this.logger.log(`inside fetch T&C or Privacy Policy by Id controller : {start}`);
    const response: any = await this.consentService.getTermsAndConditionsOrPrivacyPolicyById(id.trim(), type.trim(), req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to Update the Terms & Condition / Privacy Policy data by Id
   * @return - it will return a data which contains updated Terms & Condition or Privacy Policy
   */
  @Put('update-privacy-policy-or-terms-conditions-by-id/:id')
  @ApiAcceptedResponse({ type: () => UpdatedTCOrPPByIdSuccess, description: 'Update the Terms & Condition or Privacy Policy by Id' })
  @ApiUnauthorizedResponse({ type: () => FetchTCOrPPUnauthorized, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => FetchTCOrPPCatchError, description: 'Error response while fetching the Terms & Condition or Privacy Policy failed' })
  @ApiQuery({
    name: 'type',
    description: 'document type',
    example: 'PRIVACY_POLICY / TERMS_CONDITIONS',
    required: true
  })
  @ApiParam({
    name: 'id',
    type: 'string',
    description: 'Id',
    required: true,
    example: 'UL01'
  })
  @ApiHeader({
    name: 'tenant-id',
    description: 'Tenant Id',
    example: 'dff33fea-b456-4cfa-b2a1-0cbf9071aefe',
    required: true
  })
  @ApiBody({ type: () => policyPayload, description: 'Edited Policy' })
  @ApiOperation({ summary: 'Update Terms & Condition or Privacy Policy by Id | Author : Guru' })
  async updateTermsAndConditionsOrPrivacyPolicyById(
    @Body() payload: policyPayload,
    @Query('type') type: string,
    @Param('id') id: string,
    @Res() res: Response,
    @Req() req: Request
  ): Promise<any> {
    this.logger.log(`inside update T&C or Privacy Policy by Id controller : {start}`);
    const response: any = await this.consentService.updateTermsAndConditionsOrPrivacyPolicyById(payload, id.trim(), type.trim(), req.headers);

    if (response && response.data) {
      return res.status(HttpStatus.CREATED).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * API to fetch the latest active version of either Terms & Condition or Privacy Policy data
   * @return - it will return a data which contains latest active Terms & Condition or Privacy Policy
   */
  @Get('fetch-tnc')
  @ApiOkResponse({ type: () => FetchLatestTCOrPP, description: 'Fetch the latest version of Terms & Condition or Privacy Policy by Id' })
  @ApiUnauthorizedResponse({ type: () => FetchTCOrPPUnauthorized, description: 'Only the universal leger can able to execute the operations' })
  @ApiBadRequestResponse({ type: () => FetchTCOrPPCatchError, description: 'Error response while fetching the Terms & Condition or Privacy Policy failed' })
  @ApiQuery({
    name: 'type',
    description: 'document type',
    example: 'PRIVACY_POLICY / TERMS_CONDITIONS',
    required: true
  })
  @ApiOperation({ summary: 'Get latest active version of Terms & Condition or Privacy Policy | Author : Guru' })
  async fetchLatestTermsAndConditionsOrPrivacyPolicy(
    @Query('type') type: string,
    @Res() res: Response
  ): Promise<any> {
    this.logger.log(`inside get latest version of T&C or Privacy Policy controller : {start}`);
    const response: any = await this.consentService.fetchLatestTermsAndConditionsOrPrivacyPolicy(type.trim());

    if (response && response.content) {
      return res.status(HttpStatus.OK).send(response);
    }

    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NOT_AUTHORIZED) {
      return res.status(HttpStatus.UNAUTHORIZED).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
 * API to get the consent logs
 * @param search
 * @param filter
 * @param page
 * @param pagesize
 * @return consent logs
 */
@Get('consent-logs')
@ApiOkResponse({
  description: 'Get consent logs',
  type: () => GetConsentListSuccessRes,
})
@ApiNotFoundResponse({
  description: `will give you the error response when no consent logs present`,
  type: () => GetConsentLogsNoDataRes,
})
@ApiBadRequestResponse({
  description: 'Error response when consent-logs api gets failed.',
  type: () => GetConsentLogsErrorRes
})
@ApiQuery({
  name: 'filter',
  description: 'filter by partner name',
  example: 'CLIQ',
  required: false,
})
@ApiQuery({
  name: 'search',
  description: 'search by namespace',
  example: 'abc.ul',
  required: false,
})
@ApiQuery({
  name: 'page',
  description: 'Page index',
  required: true,
  example: 1,
})
@ApiQuery({
  name: 'pagesize',
  description: 'Page size',
  required: true,
  example: 10,
})
@ApiOperation({ summary: 'Get consent logs | Author : Qamar Khan ' })
  async getConsentLogs(@Query('filter') filter: string, @Query('search') search: string, @Query('page') page: number, @Query('pagesize') pagesize: number, @Res() res: Response): Promise<any> {
    this.logger.log(`inside consent controller :: {start}`);
    const response:any  = await this.consentService.getConsentLogs(filter, search, page - 1, pagesize);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }
    if (response && response.errors && response.errors[0].type === ERROR_TYPE.NO_DATA) {
      return res.status(HttpStatus.NOT_FOUND).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }
}
