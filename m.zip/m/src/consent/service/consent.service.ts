import { Injectable, Logger } from "@nestjs/common";
import { Namespace } from "../../db/models/namespace";
import { ACCOUNT_STATUS, ADMIN_ROLES, CONSTENT_TYPE, ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE, UNIVERSAL_LEDGER } from "../../utils/constant";
import { getPartnerDetails, isBelongToTenant, } from "../../utils/helper";
import { CustomerConsent } from "../../db/models/customer-consent";
import { checkConsent, getConsentId } from "../helper";
import { DSSVendorConsent } from "../../db/models/dss-vendor-consent";
import { DSS } from "../../db/models/dss";
import { Tenants } from "../../db/models/tenant";
import { TenantConsent } from "../../db/models/tenant-consent";
import { DssVendor } from "../../db/models/dss-vendor";
import { isUUID } from "class-validator";
import { Users } from "../../db/models/user";
import { PartialModelObject } from "objection";
import { AgreementTemplate } from "../../db/models/agreement-template";
import { ConsentLogs } from "../../db/models/consent-logs";
import { TenantNamespace } from "../../db/models/tenant-namespace";
import { TenantCustomerService } from "../../tenant/service/customer.service";

@Injectable()
export class ConsentService {

  private readonly logger = new Logger(ConsentService.name);

  constructor(private customerService: TenantCustomerService) { }

  /**
     * API to accept customer consent for a particular vendor
     * @param consentStatus
     * @return success response for adding customer consent
     */
  async getCustomerConsent(payload, headers): Promise<any> {
    this.logger.log(`inside getCustomerConsent service :: {start}`);
    try {

      const tenantId = headers['tenant-id']

      if (!tenantId) {
        return { errors: [{ type: ERROR_TYPE.CONSENT, message: ERROR_MESSAGE.TENANT_ID_MISSING }] };
      }

      const { customerAccountId, dssVendorId, consentStatus, consentVersion, type } = payload;

      const venderDetails: any = await DSSVendorConsent.query().findOne({ dss_vendor_id: dssVendorId }).select('vendorName');

      if (!venderDetails) {
        return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_VENDOR }] };
      }

      //accept consent status for customer
      if(customerAccountId){
        const customer: any = await Namespace.query().findOne({ customer_account_id: customerAccountId, tenant_id: tenantId });

        if (!customer) {
          return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_CUSTOMER_ACCOUNT }] };
        }

        const customerNamespace = customer.namespace;
        const isPresent = await isBelongToTenant(headers['tenant-id'], customerNamespace, null);

        if (!isPresent) {
          return { errors: [{ type: ERROR_TYPE.CONSENT, message: ERROR_MESSAGE.CUSTOMER_DOES_NOT_BELONGS_TO_TENANT, }] };
        }

        const consentLogsData = {
          tenant_id: tenantId,
          customer_account_id: customerAccountId,
          partner_name: venderDetails?.vendorName,
          namespace: customerNamespace,
          consent_version: consentVersion,
          status: consentStatus,
          type: type
        }

        await ConsentLogs.query().insert(consentLogsData);

        const message = {
          consent_partner : venderDetails?.vendorName,
          version: consentVersion,
          status : 'accepted',
          message_type: 'AcceptConsent'
        }
        await this.customerService.notifyTenants(
          'CONSENT',
          tenantId,
          customerAccountId,
          message
        );

        const consent: any = await CustomerConsent.query().findOne({ customer_account_id: customerAccountId, dss_vendor_id: dssVendorId, tenant_id: tenantId });

        if (consent) {
          const updatedData : any = await CustomerConsent.query()
            .patch({ consent_status: consentStatus, consent_version: consentVersion })
            .where('customer_account_id', customerAccountId)
            .andWhere('dss_vendor_id', dssVendorId)
            .andWhere('tenant_id', tenantId)
            .returning('*');

          return {
            data: updatedData,
            message: SUCCESS_RESPONSE_MESSAGE.CUSTOMER_CONSENT_SUCCESS,
          }
        }

        else {
          const updatedPayload = { ...payload, tenantId: tenantId };

          delete updatedPayload.type;
          const data : any = await CustomerConsent.query().insert(updatedPayload);

          return {
            data: data,
            message: SUCCESS_RESPONSE_MESSAGE.CUSTOMER_CONSENT_SUCCESS,
          }
        }
      }

      else{

        //accept consent status for tenant
        const consent: any = await TenantConsent.query().findOne({ tenant_id: tenantId, dss_vendor_id: dssVendorId });

        const tenantDetails: any = await TenantNamespace.query().findOne({ tenant_id: tenantId, is_active: true }).select('tenant_namespace');

        const consentLogsData = {
          tenant_id: tenantId,
          partner_name: venderDetails?.vendorName,
          namespace: tenantDetails?.tenantNamespace,
          consent_version: consentVersion,
          status: consentStatus,
          type: type
        }

        await ConsentLogs.query().insert(consentLogsData);

        if (consent) {
          const updatedData = await TenantConsent.query()
            .patch({ consent_status: consentStatus, consent_version: consentVersion })
            .where('tenant_id', tenantId)
            .andWhere('dss_vendor_id', dssVendorId)
            .returning('*');

          return {
            data: updatedData,
            message: SUCCESS_RESPONSE_MESSAGE.TENANT_CONSENT_SUCCESS,
          }
        }

        else {

          const updatedPayload = {
            tenantId: tenantId,
            dss_vendor_id: dssVendorId,
            consent_status: consentStatus,
            consent_version: consentVersion,
          };
          const data = await TenantConsent.query().insert(updatedPayload);

          return {
            data: data,
            message: SUCCESS_RESPONSE_MESSAGE.TENANT_CONSENT_SUCCESS,
          }
        }
      }

    } catch (err) {
      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  /**
  /**
 * API to fetch vendor consent details for a particular vendor
 * @param tenantId tenant Id
 * @return vendor consent details
 */
  async getVendorConsentDetails(subCategory: string, type: string, tenantId: string): Promise<any> {
    this.logger.log(`inside getVendorConsentDetails service :: {start} : ${tenantId}`);
    try {
      // Fetching the partner details from the product subscribed by the tenant
      const paymentPartnerType = await getPartnerDetails(tenantId, 'Offchain Transactions', subCategory, type, 'Customer Wallet');

      if (!paymentPartnerType) {
        return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_PARTNER }] };
      }
      //fetch dss vendor id based on tenant id from feature flagging
      const dssDetails: any = await DSS.query().findOne({ dss_type: paymentPartnerType }).select('dss_type_id');

      if(!dssDetails || !dssDetails.dssTypeId){
        return { errors: [{ type: ERROR_TYPE.NO_DATA, message: `No partner details available: ${paymentPartnerType}` }] };
      }

      const dssConsentDetails: any = await DSSVendorConsent.query()
        .select('dss_vendor_id', 'vendor_name', 'current_active_version', 'consent_message')
        .where('dss_id', dssDetails.dssTypeId)
        .where('active_status', 'ACTIVE')
        .orderBy('updated_at', 'desc')
        .first();

      if (!dssConsentDetails){
        return { errors: [{ type: ERROR_TYPE.CONSENT, message: ERROR_MESSAGE.NO_DATA_FOUND }] };
      }

      return {
        data: dssConsentDetails,
        message: SUCCESS_RESPONSE_MESSAGE.VENDOR_CONSENT_FETCHED,
      };
    } catch (err) {
      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  /**
 * API to check consent status for a customer
 * @param customerAccountId customerAccountId of the customer
 * @return consent status details
 */
  async checkConsentStatus(subCategory, type, customerAccountId: string, tenantId): Promise<any> {
    this.logger.log(`inside checkConsentStatus service :: {start}`);
    try {

      //fetch dss vendor id based on tenant id from feature flagging
      // const dssId = 'a2e95479-a0bb-44c6-a473-4a5dc786adce';

      if (!tenantId) {
        return {
          errors: [ { type: ERROR_TYPE.NO_VALUE, message: ERROR_MESSAGE.PROVIDE_VALID_TENANT_ID } ],
        };
      }

      const response = await checkConsent(subCategory, type, customerAccountId, tenantId);

      return response;

    } catch (err) {
      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  /**
  * API to get the consent list
  * @param search
  * @param filter
  * @param page
  * @param pagesize
  * @return consent list
  */
  async getConsentList(filter: string, searchKey: string, page: number, pagesize: number): Promise<any> {
    this.logger.log(`inside checkConsentStatus service :: {start}`);
    try {

      const search = searchKey ? `%${searchKey}%` : ''

      const consentDetails : any = await DSSVendorConsent.query().alias('dvc')
        .leftJoin('dss_vendor as dv', 'dvc.vendor_name', 'dv.name')
        .select('dvc.dss_vendor_id','consent_id as id','vendor_name as partnerName','consent_message','consent_version','current_active_version','dvc.created_at','dvc.updated_at','dv.logo')
        .modify((builder) => {
          if (search) {
            builder.where('vendor_name', 'ilike', search);
          }
        })
        .modify((builder) => {
          if (filter) {
            builder.where('vendor_name', filter);
          }
        })
        .orderBy('updated_at', 'DESC')
        .page(page, pagesize);

      if(!consentDetails){
        return{
          errors: [{ type: ERROR_TYPE.NO_DATA , message: ERROR_MESSAGE.NO_DATA_FOUND }]
        }
      }

      return {
        data: consentDetails,
        message: SUCCESS_RESPONSE_MESSAGE.CONSENT_LIST_FETCHED,
      };

    } catch (err) {
      this.logger.log(`Catch Error in Create UL Consent :: ${err.message}`);

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async createULConsent(payload, headers): Promise<any> {
    try {

      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      const consentId: any = await getConsentId();

      if (consentId && consentId.errors) {
        return consentId;
      }

      let partner = await DSS.query().select('dss_type_id').findOne({ dss_type: payload.vendorName });

      if (!partner) {
        partner = await DSS.query().insert({ dss_type: payload.vendorName, dss_description: 'Consent Partner' });
      }

      payload['consentId'] = consentId;
      payload['dssTypeId'] = partner.dssTypeId;
      const createdConsent: any = await this.addConsent(payload);

      if (createdConsent && createdConsent.errors) {
        return createdConsent;
      }

      this.logger.log('UL Consent successfully created ' + createdConsent.dssVendorId);

      return { message: SUCCESS_RESPONSE_MESSAGE.CONSENT_CREATED, data: createdConsent };
    } catch (err) {
      this.logger.log(`Catch Error in Create UL Consent :: ${err.message}`);

      if (err.message.includes('insert')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async updateULConsent(payload, dssVendorId, headers): Promise<any> {
    try {
      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      const consent: any  = await DSSVendorConsent.query().select('dss_vendor_id', 'vendor_name', 'consent_version', 'current_active_version', 'dss_id', 'consent_id').findById(dssVendorId);

      if (!consent) {
        return { errors: [{ type: ERROR_TYPE.UPDATE, message: ERROR_MESSAGE.NO_CONSENT + dssVendorId }] };
      }

      const newVersion = 'V' + (Number(consent?.currentActiveVersion.slice(1))+1);

      consent['currentActiveVersion'] = newVersion;
      const updatePayload = { ...payload, ...consent };
      const newConsent: any = await this.addConsent(updatePayload);

      if (newConsent && newConsent.errors) {
        return newConsent;
      }

      await DSSVendorConsent.query().update({ active_status: ACCOUNT_STATUS[1], current_active_version: newVersion }).findById(dssVendorId);
      this.logger.log('UL Consent successfully updated ' + newConsent.dssVendorId);

      return { message: SUCCESS_RESPONSE_MESSAGE.CONSENT_UPDATED, data: newConsent };
    } catch (err) {
      this.logger.log(`Catch Error in Update UL Consent :: ${err.message}`);

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async addConsent(payload) {
    try {
      const newConsent = {
        vendor_name: payload?.vendorName,
        consent_version: payload?.currentActiveVersion || 'V1',
        active_status: ACCOUNT_STATUS[0],
        current_active_version: payload?.currentActiveVersion || 'V1',
        consent_message: payload?.consentMessage,
        dss_id: payload?.dssTypeId || payload?.dssId,
        consent_id: payload?.consentId,
      };
      const createdConsent = await DSSVendorConsent.query().insert(newConsent);

      return createdConsent;
    } catch (err) {
      this.logger.log('Inserting new consent failed', err.message);

      if (err.message.includes('insert')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] }
    }
  }

  async deleteULConsent(dssVendorId: string, headers): Promise<any> {
    try {
      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      const deletedVendor = await DSSVendorConsent.query().deleteById(dssVendorId);

      if (!deletedVendor){
        return { errors: [{ type: ERROR_TYPE.DELETE, message: ERROR_MESSAGE.NO_CONSENT + dssVendorId }] }
      }

      this.logger.log(dssVendorId + ' is Deleted successfully');

      return  { message: SUCCESS_RESPONSE_MESSAGE.CONSENT_DELETED, data: deletedVendor }
    } catch (err) {
      this.logger.log(`Catch Error in Delete UL Consent :: ${err.message}`);

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  /**
  * API to get vendors list
  * @return vendors list
  */
  async getVendorList(headers): Promise<any> {
    this.logger.log(`inside getVendorList service :: {start}`);
    try {

      if(!headers['tenant-id']) {
        return { errors: [ { type: ERROR_TYPE.VENDORS, message: ERROR_MESSAGE.TENANT_ID_MISSING } ] };
      }

      if (!(isUUID(headers['tenant-id']))) {
        return { errors: [ { message: ERROR_MESSAGE.UUID_INVALID, type: ERROR_TYPE.INVALID_UUID } ] };
      }

      const tenantDetails: any = await Tenants.query().where({ 'tenant_id': headers['tenant-id'] });

      if (!tenantDetails?.length) {
        return {
          errors: [
            {
              type: ERROR_TYPE.VENDORS,
              message: ERROR_MESSAGE.TENANT_ADDRESS_NOT_FOUND,
            },
          ],
        };
      }

      const vendorsDetails: any = await DssVendor.query();

      if(!vendorsDetails && !vendorsDetails.length){
        return{
          errors: [{ type: ERROR_TYPE.NO_DATA , message: ERROR_MESSAGE.NO_DATA_FOUND }]
        }
      }

      return {
        data: vendorsDetails,
        message: SUCCESS_RESPONSE_MESSAGE.VENDOR_LIST,
      };

    } catch (err) {
      this.logger.log(`Catch Error in getVendorList :: ${err.message}`);

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async createPartner(payload, headers): Promise<any> {
    try {

      const tenant: any = await Tenants.query().select('tenant_name')
        .findOne({ 'tenant_id': headers['tenant-id'] });

      const user: any = await Users.query().alias('u')
        .join('user_roles as ur', 'ur.user_id', 'u.user_id')
        .join('roles as r', 'r.role_id', 'ur.role_id')
        .findOne({ 'u.user_id': payload.createdBy, 'u.tenant_id': headers['tenant-id'] })
        .whereIn('r.role_name', [ADMIN_ROLES.UL_ADMIN, ADMIN_ROLES.UL_COMPLIANCE] )

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      if (!user) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.USER_UNAUTHORIZED }] };
      }

      if (!payload?.partnerName) {
        return { errors: [{ type: ERROR_TYPE.PARTNER, message: ERROR_MESSAGE.VALID_PARTNER_NAME }] };
      }

      const isExist = await DssVendor.query().where({ name: payload?.partnerName.toUpperCase().trim() });

      if (isExist && isExist.length) {
        return { errors: [{ type: ERROR_TYPE.PARTNER, message: ERROR_MESSAGE.PARTNER_ALREADY_EXIST }] };
      }

      const newPartner = {
        name: payload?.partnerName.toUpperCase().trim(),
        status: ACCOUNT_STATUS[0],
        details: (payload?.details && Object.keys(payload?.details).length) ? JSON.stringify(payload?.details) : null,
        logo: (payload?.logo && Object.keys(payload?.logo).length) ? JSON.stringify(payload?.logo) : null
      }
      const partner: any = await DssVendor.query().insert(newPartner as PartialModelObject<DssVendor>);

      this.logger.log('Partner successfully created ' + partner.dssVendorId);

      return { message: SUCCESS_RESPONSE_MESSAGE.PARTNER_CREATE, data: partner };
    } catch (err) {
      this.logger.log(`Catch Error in Create UL Consent :: ${err.message}`);

      if (err.message.includes('insert') || err.message.includes('select')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async getPartnersList(page: number, pageSize: number, headers): Promise<any> {
    try {

      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      const partners = await DssVendor.query()
        .modify((query) => {
          if (page && pageSize) {
            query.page(page, pageSize)
          }
        });

      this.logger.log('Partner successfully fetched');

      return { message: SUCCESS_RESPONSE_MESSAGE.FETCHED_PARTNER, data: partners, page: page+1, pageSize: Number(pageSize) };
    } catch (err) {
      this.logger.log(`Catch Error in Create UL Consent :: ${err.message}`);

      if (err.message.includes('select')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async getTermsAndConditionsOrPrivacyPolicy(type: string, page: number, pageSize: number, headers): Promise<any> {
    try {
      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      if (!(Object.values(CONSTENT_TYPE)).includes(type)) {
        return { errors: [{ type: ERROR_TYPE.UNEXPECTED_VALUE_PASSES, message: ERROR_MESSAGE.VALID_CONSENT_DOCUMENT_TYPE }] };
      }

      let total = 0;
      const policies = await AgreementTemplate.query()
        .select(
          'id', 'type', 'created_at', 'version', 'current_active_version', 'active_status',
          AgreementTemplate.knex().raw(
            `(select count(*) from agreement_template where type like ? and active_status = 'ACTIVE') as count`, 
            [`%${type}%`]
          )
        )
        .whereILike('type', `%${type}%`)
        .where('active_status', 'ACTIVE')
        .modify((query) => {
          if (page && pageSize) {
            query.page(page, pageSize);
          }
        })
        .orderBy('created_at', 'DESC');

      policies.forEach((p: any) => {
        total = p?.count
        delete p?.count;
      });

      this.logger.log(`${type} successfully fetched`);

      return { message: type + SUCCESS_RESPONSE_MESSAGE.FETCHED_TC_OR_PP, data: { results: policies, total: total } };

    } catch (err) {
      this.logger.log('Catch Error :: while getting the T&C or Privacy Policies :', err.message);

      if (err.message.includes('select')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async getTermsAndConditionsOrPrivacyPolicyById(id: string, type: string, headers): Promise<any> {
    try {
      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      if (!(Object.values(CONSTENT_TYPE)).includes(type)) {
        return { errors: [{ type: ERROR_TYPE.UNEXPECTED_VALUE_PASSES, message: ERROR_MESSAGE.VALID_CONSENT_DOCUMENT_TYPE }] };
      }

      const policies = await AgreementTemplate.query()
        .findOne({ id: id, active_status: 'ACTIVE' })
        .whereILike('type', `%${type}%`)

      if(!policies) {
        return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_TEMPLATE + id }] };
      }

      this.logger.log(`${id} ${type} successfully fetched`);

      return { message: id + ' ' + type + SUCCESS_RESPONSE_MESSAGE.FETCHED_TC_OR_PP, data: policies };

    } catch (err) {
      this.logger.log('Catch Error :: while getting the T&C or Privacy Policies by Id:', err.message);

      if (err.message.includes('select')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async updateTermsAndConditionsOrPrivacyPolicyById(payload, id: string, type: string, headers): Promise<any> {
    try {
      const tenant = await Tenants.query().select('tenant_name').findById(headers['tenant-id']);

      if (!tenant || (tenant && tenant.tenantName !== UNIVERSAL_LEDGER)) {
        return { errors: [{ type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }] };
      }

      if (!(Object.values(CONSTENT_TYPE)).includes(type)) {
        return { errors: [{ type: ERROR_TYPE.UNEXPECTED_VALUE_PASSES, message: ERROR_MESSAGE.VALID_CONSENT_DOCUMENT_TYPE }] };
      }

      const data: any  = await AgreementTemplate.query()
        .select('id', 'type', 'version', 'current_active_version', 'dss_vendor_id', 'active_status')
        .findOne({ id: id, active_status: 'ACTIVE' }).whereILike('type', `%${type}%`);

      if (!data) {
        return { errors: [{ type: ERROR_TYPE.UPDATE, message: ERROR_MESSAGE.NO_TEMPLATE + id }] };
      }

      const newVersion = 'V' + (Number(data?.currentActiveVersion.slice(1))+1);

      data['id'] = data?.id ? 'UL' + (Number(data.id.slice(2)) < 9 ? '0' + (Number(data.id.slice(2)) + 1) : Number(data.id.slice(2)) + 1 ) : 'UL01';
      data['currentActiveVersion'] = newVersion;
      data['version'] = newVersion;
      const updatePayload = { ...payload, ...data };

      await AgreementTemplate.query()
        .findOne({ id: id, active_status: 'ACTIVE' }).whereILike('type', `%${type}%`)
        .patch({
          current_active_version: newVersion,
          active_status: 'INACTIVE',
        } as PartialModelObject<AgreementTemplate>);

      this.logger.log(`${id} template active status is updated as INACTIVE`);

      const updatedPolicy = await AgreementTemplate.query()
        .insert(updatePayload as PartialModelObject<AgreementTemplate>);

        const message = {
          version: newVersion,
          message_type: 'UL-TnC'
        }
        await this.customerService.notifyTenants(
          'CONSENT',
          headers['tenant-id'],
          '',
          message
        );

      this.logger.log(`${id} ${data.type} successfully updated`);

      return { message: id + ' ' + data.type + SUCCESS_RESPONSE_MESSAGE.UPDATED_TC_OR_PP, data: updatedPolicy };

    } catch (err) {
      this.logger.log('Catch Error :: while updating the T&C or Privacy Policies by Id:', err.message);

      if (err.message.includes('select') || err.message.includes('update') || err.message.includes('insert')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  async fetchLatestTermsAndConditionsOrPrivacyPolicy(type: string): Promise<any> {
    try {
      if (!(Object.values(CONSTENT_TYPE)).includes(type)) {
        return { errors: [{ type: ERROR_TYPE.UNEXPECTED_VALUE_PASSES, message: ERROR_MESSAGE.VALID_CONSENT_DOCUMENT_TYPE }] };
      }

      const data: any  = await AgreementTemplate.query()
        .select('template')
        .findOne({ active_status: 'ACTIVE' }).whereILike('type', `%${type}%`);

      if(!data || !data?.template) {
        return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_AGREEMENT_TEMPLATE }] };
      }

      this.logger.log(`${type}'s content successfully fetched`);

      return { message: type + SUCCESS_RESPONSE_MESSAGE.FETCHED_LATEST_TC_OR_PP, content: data?.template };

    } catch (err) {
      this.logger.log('Catch Error :: while fetching latest version of the T&C or Privacy Policies:', err.message);

      if (err.message.includes('select')) {
        const error = err.message.split('- ');

        return { errors: [ { type: ERROR_TYPE.CATCH, message: error[1] } ] };
      }

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }

  /**
  * API to get the consent logs
  * @param search
  * @param filter
  * @param page
  * @param pagesize
  * @return consent logs
  */
  async getConsentLogs(filter: string, searchKey: string, page: number, pagesize: number): Promise<any> {
    this.logger.log(`inside getConsentLogs service :: {start}`);
    try {

      const search = searchKey ? `%${searchKey}%` : ''

      const consentDetails : any = await ConsentLogs.query()
        .leftJoin('customer_accounts as ca', 'ca.customer_account_id', 'consent_logs.customer_account_id')
        .join('tenants', 'tenants.tenant_id', 'consent_logs.tenant_id')
        .select('consent_logs.*', ConsentLogs.raw(`concat(NULLIF(ca.first_name,'') || ' ', ca.last_name) as customer_name`), 'tenants.tenant_name')
        .modify((builder) => {
          if (search) {
            builder.where('namespace', 'ilike', search);
          }
        })
        .modify((builder) => {
          if (filter) {
            builder.where('partner_name', filter);
          }
        })
        .orderBy('updated_at', 'DESC')
        .page(page, pagesize);

      if(!consentDetails){
        return{
          errors: [{ type: ERROR_TYPE.NO_DATA , message: ERROR_MESSAGE.NO_DATA_FOUND }]
        }
      }

      return {
        data: consentDetails,
        message: SUCCESS_RESPONSE_MESSAGE.CONSENT_LOGS_FETCHED,
      };

    } catch (err) {
      this.logger.log(`Catch Error in Consent logs :: ${err.message}`);

      return { errors: [{ type: ERROR_TYPE.CATCH, message: err.message }] };
    }
  }
}