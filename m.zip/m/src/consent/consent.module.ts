import { Module } from '@nestjs/common';
import { ConsentController } from './controller/consent.controller';
import { ConsentService } from './service/consent.service';
import { TenantCustomerService } from '../tenant/service/customer.service';
import { TenantWalletService } from '../tennat-wallet/tennat-wallet.service';
import { TransactionService } from 'src/transaction/transaction.service';
import { CriteriaService } from 'src/tennat-wallet/criteria.service';

@Module({
  controllers: [ ConsentController ],
  providers: [ ConsentService, TenantCustomerService, TenantWalletService, TransactionService, CriteriaService ],
})
export class ConsentModule {}
