import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";
import { ERROR_TYPE, ERROR_MESSAGE } from "../../utils/constant";

export class CreateULConsentBody {

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'Partner Name',
    default: 'Ash'
  })
    vendorName: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'Consent Message',
    default: 'message'
  })
    consentMessage: string;

}

class CreateULConsent {

  @ApiProperty({
    type: 'string',
    description: 'Vendor Name',
    default: 'Ash'
  })
    vendor_name: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Version',
    default: 'V1'
  })
    consent_version: string;

  @ApiProperty({
    type: 'string',
    description: 'Active Status',
    default: 'ACTIVE'
  })
    active_status: string;

  @ApiProperty({
    type: 'string',
    description: 'Current Active Version',
    default: 'V1'
  })
    current_active_version: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Message',
    default: 'message'
  })
    consent_message: string;

  @ApiProperty({
    type: 'string',
    description: 'Dss Id',
    default: '4e8e1e87-9410-4275-9f4c-53ceb58cd837'
  })
    dss_id: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Id',
    default: 'PR01'
  })
    consent_id: string;

  @ApiProperty({
    type: 'string',
    description: 'Dss Vendor Id',
    default: '990da60c-9ff5-4683-97ac-898e853d9126'
  })
    dssVendorId: string
}

export class CreateULConsentDO {

  @ApiProperty({
    type: 'string',
    description: 'Success Message for the create UL Consent',
    default: 'UL Consent created successfully'
  })
    message: string;

  @ApiProperty({
    type: () => CreateULConsent,
    description: 'UL Consent Data'
  })
    data: CreateULConsent;

}

export class DeleteULConsentDO {

  @ApiProperty({
    type: 'string',
    description: 'Success Message for the create UL Consent',
    default: 'UL Consent Deleted successfully'
  })
    message: string;

  @ApiProperty({
    type: 'number',
    description: 'Number of Records deleted',
    default: 1
  })
    data: number;

}

export class CreateConsentCatchErrorDO {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
      { type: ERROR_TYPE.TENANT, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED }
    ]
  })
    errors: string;

}

export class DeleteConsentCatchErrorDO {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { message: 'err.message', type: ERROR_TYPE.CATCH },
      { type: ERROR_TYPE.DELETE, message: ERROR_MESSAGE.NO_CONSENT + '{dssVendorId}' }
    ]
  })
    errors: string;
}