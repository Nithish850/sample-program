import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';

export class GetConsentListSuccess {

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'DSS Vendor ID',
    })
      dssVendorId: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Consent ID',
    })
      id: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Vendor Name',
    })
      partnerName: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Consent Message',
      required: true
    })
      consentMessage: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Current Active Version',
      required: true
    })
      consentVersion: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Current Active Version',
      required: true
    })
      currentActiveVersion: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: Date,
      description: 'created At',
      required: true
    })
      createdAt: Date;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: Date,
      description: 'updated At',
      required: true
    })
      updatedAt: Date;

    @IsString()
    @ApiProperty({
      type: 'string',
      description: 'logo',
    })
      logo: string;

}

export class GetConsentListSuccessRes {
    @ApiProperty({ type: () => GetConsentListSuccess })
      data: GetConsentListSuccess;

    @ApiProperty({
      type: 'string',
      description: 'consent list message',
      example: SUCCESS_RESPONSE_MESSAGE.CONSENT_LIST_FETCHED,
    })
      message: string;
}

export class GetConsentListErrorRes {
  @ApiProperty({
    default: { type: 'catch', message: 'Something went wrong, please try again' }
  })
    errors:any;
}

export class GetConsentListNoDataRes {
  @ApiProperty({
    default: { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_DATA_FOUND }
  })
    errors:any;
}
