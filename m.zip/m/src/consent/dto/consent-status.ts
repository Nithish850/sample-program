import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';
import { ERROR_MESSAGE, ERROR_TYPE } from '../../utils/constant';

export class GetConsentStatusSuccess {

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'latest Consent Version',
    })
      latestConsentVersion: string;

}

export class GetConsentStatusSuccessRes {
    @ApiProperty({ type: () => GetConsentStatusSuccess })
      data: GetConsentStatusSuccess;

    @ApiProperty({
      type: 'string',
      description: 'consent status message',
      example: ['Consent is accepted', 'Consent is not valid. Please accept the consent'],
    })
      message: string;
}

export class GetConsentStatusErrorRes {
  @ApiProperty({
    default: { type: 'catch', message: 'Something went wrong, please try again' }
  })
    errors:any;
}

export class GetConsentStatusNoDataRes {
  @ApiProperty({
    default: { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_CONSENT_AVAILABLE }
  })
    errors:any;
}
