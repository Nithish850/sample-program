import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, } from 'class-validator';
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';
export class VendorsSuccess {

    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Dss Vendor Id',
    })
      dssVendorId: string;

    @ApiProperty({
      type: 'string',
      description: 'Name',
      required: true
    })
      name: string;

    @ApiProperty({
      type: 'boolean',
      description: 'status',
      required: true
    })
      status: boolean;

    @ApiProperty({
      type: 'string',
      description: 'details',
      required: true
    })
      details: string;

    @ApiProperty({
      type: 'string',
      description: 'logo',
    })
      logo: string;

    @ApiProperty({
      type: 'boolean',
      description: 'Created At',
      required: true
    })
      createdAt: boolean;

    @ApiProperty({
      type: 'string',
      description: 'Updated At',
      required: true
    })
      updatedAt: string;

}

export class VendorsSuccessRes {
    @ApiProperty({ type: () => [ VendorsSuccess ] })
      data: VendorsSuccess;

    @ApiProperty({
      type: 'string',
      description: 'customer consent message',
      default: SUCCESS_RESPONSE_MESSAGE.VENDOR_CONSENT_FETCHED,
    })
      message: string;
}

export class VendorsNoDataRes {

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'type',
      default: ERROR_TYPE.VENDORS
    })
      type: string

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'message',
      default: ERROR_MESSAGE.NO_DATA_FOUND
    })
      message: string

}

export class VendorsNoDataFoundErrorDTO {

    @ApiProperty({ type: () => [ VendorsNoDataRes ] })
      errors: VendorsNoDataRes

}

export class VendorsErrorRes {
  @ApiProperty({
    default: [ { type: 'catch', message: 'Something went wrong, please try again' } ]
  })
    errors:any;
}
