import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';

export class GetConsentLogsSuccess {

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Consent Log Id',
    })
      consentLogId: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'tenant ID',
    })
      tenantId: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Customer Account Id',
    })
      customerAccountId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Partner Name',
      required: true
    })
      partnerName: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'namespace',
      required: true
    })
      namespace: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Current Version',
      required: true
    })
      consentVersion: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: Date,
      description: 'created At',
      required: true
    })
      createdAt: Date;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: Date,
      description: 'updated At',
      required: true
    })
      updatedAt: Date;

    @IsString()
    @ApiProperty({
      type: 'string',
      description: 'status',
    })
      status: string;

}

export class GetConsentLogsSuccessRes {
    @ApiProperty({ type: () => GetConsentLogsSuccess })
      data: GetConsentLogsSuccess;

    @ApiProperty({
      type: 'string',
      description: 'consent list message',
      example: SUCCESS_RESPONSE_MESSAGE.CONSENT_LIST_FETCHED,
    })
      message: string;
}

export class GetConsentLogsErrorRes {
  @ApiProperty({
    default: { type: 'catch', message: 'Something went wrong, please try again' }
  })
    errors:any;
}

export class GetConsentLogsNoDataRes {
  @ApiProperty({
    default: { type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_DATA_FOUND }
  })
    errors:any;
}
