import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, IsUUID, } from 'class-validator';
import { SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';

export class AddCustomerConsent {

    @IsUUID()
    @IsOptional()
    @ApiProperty({
      type: 'string',
      description: 'customerAccountId',
      required: false
    })
      customerAccountId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'dssVendorId',
      required: true
    })
      dssVendorId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'consent Status',
      default: 'ACCEPTED',
    })
      consentStatus: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'consent Version',
    })
      consentVersion: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'type',
      default: 'ACH'
    })
      type: string;

}

export class AddCustomerConsentRes {

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'customer Consent Id',
    })
      customerConsentId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'customerAccountId',
      required: true
    })
      customerAccountId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'dssVendorId',
      required: true
    })
      dssVendorId: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'consent Status',
      default: 'ACCEPTED',
    })
      consentStatus: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'consent Version',
    })
      consentVersion: string;

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Created At',
    })
      createdAt: Date;

    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Updated At',
    })
      updatedAt: Date;

}

export class AddCustomerConsentSuccess {
    @ApiProperty({ type: () => AddCustomerConsentRes })
      data: AddCustomerConsentRes;

    @ApiProperty({
      type: 'string',
      description: 'customer consent message',
      default: SUCCESS_RESPONSE_MESSAGE.CUSTOMER_CONSENT_SUCCESS,
    })
      message: string;
}

export class AddCustomerConsentErrorRes {
  @ApiProperty({
    default: { type: 'catch', message: 'Something went wrong, please try again' }
  })
    errors:any;
}
