import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";
import { ERROR_MESSAGE, ERROR_TYPE } from "../../utils/constant";

export class UpdateULConsentBody {

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'Consent Message',
    default: 'message'
  })
    consentMessage: string;

}

class UpdateULConsent {

  @ApiProperty({
    type: 'string',
    description: 'Vendor Name',
    default: 'Ash'
  })
    vendor_name: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Version',
    default: 'V1'
  })
    consent_version: string;

  @ApiProperty({
    type: 'string',
    description: 'Active Status',
    default: 'ACTIVE'
  })
    active_status: string;

  @ApiProperty({
    type: 'string',
    description: 'Current Active Version',
    default: 'V1'
  })
    current_active_version: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Message',
    default: 'message'
  })
    consent_message: string;

  @ApiProperty({
    type: 'string',
    description: 'Dss Id',
    default: '4e8e1e87-9410-4275-9f4c-53ceb58cd837'
  })
    dss_id: string;

  @ApiProperty({
    type: 'string',
    description: 'Consent Id',
    default: 'PR01'
  })
    consent_id: string;

  @ApiProperty({
    type: 'string',
    description: 'Dss Vendor Id',
    default: '990da60c-9ff5-4683-97ac-898e853d9126'
  })
    dssVendorId: string
}

export class UpdateULConsentDO {

  @ApiProperty({
    type: 'string',
    description: 'Success Message for the create UL Consent',
    default: 'UL Consent created successfully'
  })
    message: string;

  @ApiProperty({
    type: () => UpdateULConsent,
    description: 'UL Consent Data'
  })
    data: UpdateULConsent;

}

export class UpdateConsentCatchErrorDO {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
      { type: ERROR_TYPE.TENANT, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED },
      { type: ERROR_TYPE.UPDATE, message: ERROR_MESSAGE.NO_CONSENT + '{dssVendorId}' }
    ]
  })
    errors: string;

}

class Unauthorized {

  @ApiProperty({
    type: 'string',
    description: 'Error type',
    default: 'Tenant'
  })
    type: string;

  @ApiProperty({
    type: 'string',
    description: 'Error Message',
    default: 'This tenant has no access / unauthorized.'
  })
    message: string;

}

export class UnauthorizedDO {

  @ApiProperty({
    type: () => [Unauthorized],
    description: 'Success Message for the create UL Consent'
  })
    errors: Unauthorized;

}