import { ApiProperty } from "@nestjs/swagger";
import { ERROR_TYPE, ERROR_MESSAGE } from "../../utils/constant";
import { IsNotEmpty, IsString } from "class-validator";

export class FetchTCOrPPUnauthorized {

    @ApiProperty({
      type: () => 'string',
      description: 'type of error',
      default: [
        { type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED },
      ]
    })
      errors: string;

}

export class FetchTCOrPPCatchError {

    @ApiProperty({
      type: () => 'string',
      description: 'type of error',
      default: [
        { type: ERROR_TYPE.CATCH, message: 'error[1]' },
        { message: 'err.message', type: ERROR_TYPE.CATCH },
      ]
    })
      errors: string;

}

class FetchTCOrPPById {

  @ApiProperty({
    type: 'string',
    description: 'Agreement Template Id',
    default: '78367369-8074-4882-846c-54d6c1460897'
  })
    agreementTemplateId: string;

  @ApiProperty({
    type: 'string',
    description: 'Template',
    default: 'Content'
  })
    template: string;

  @ApiProperty({
    type: 'string',
    description: 'Type',
    default: 'PrivacyPolicy / TermsAndConditions'
  })
    type: string;

  @ApiProperty({
    type: 'string',
    description: 'Active Status',
    default: 'ACTIVE'
  })
    activeStatus: string;

  @ApiProperty({
    type: 'string',
    description: 'Id',
    default: 'PP01'
  })
    id: string;

  @ApiProperty({
    type: 'string',
    description: 'Version',
    default: 'V1.0'
  })
    version: string;

  @ApiProperty({
    type: 'string',
    description: 'Current Active Version',
    default: 'V1.0'
  })
    currentActiveVersion: string;

  @ApiProperty({
    type: 'string',
    description: 'Dss Vendor Id',
    default: '78367369-8074-4882-846c-54d6c1460897'
  })
    dssVendorId: string;

}

class FetchTCOrPP {

  @ApiProperty({
    type: 'string',
    description: 'Type',
    default: 'PrivacyPolicy / TermsAndConditions'
  })
    type: string;

  @ApiProperty({
    type: 'string',
    description: 'Active Status',
    default: 'ACTIVE'
  })
    activeStatus: string;

  @ApiProperty({
    type: 'string',
    description: 'Id',
    default: 'PP01'
  })
    id: string;

  @ApiProperty({
    type: 'string',
    description: 'Version',
    default: 'V1.0'
  })
    version: string;

  @ApiProperty({
    type: 'string',
    description: 'Current Active Version',
    default: 'V1.0'
  })
    currentActiveVersion: string;

}

export class FetchTCOrPPWithTotalDTO {

  @IsNotEmpty()
  @ApiProperty({
    type: () => [ FetchTCOrPP ],
    description: `Document details`,
  })
    results: FetchTCOrPP

  @IsString()
  @ApiProperty({
    type: `number`,
    description: `Total`,
    default: 1
  })
    total: number

}

export class FetchTCOrPPSuccess {

  @ApiProperty({
    type: 'string',
    description: 'Success Message',
    default: 'Fetched Terms & Conditions / Privacy Policy list successfully'
  })
    message: string;

  @ApiProperty({
    type: () => FetchTCOrPPWithTotalDTO,
    description: 'Data'
  })
    data: FetchTCOrPPWithTotalDTO;

}

export class FetchTCOrPPByIdSuccess {

  @ApiProperty({
    type: 'string',
    description: 'Success Message',
    default: 'Fetched Terms & Conditions / Privacy Policy list successfully'
  })
    message: string;

  @ApiProperty({
    type: () => FetchTCOrPPById,
    description: 'Data'
  })
    data: FetchTCOrPPById;

}

export class policyPayload {

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'Updated Policy',
  })
    template: string;

}

export class UpdatedTCOrPPByIdSuccess {

  @ApiProperty({
    type: 'string',
    description: 'Success Message',
    default: 'UL01 UL_PRIVACY_POLICY updated successfully'
  })
    message: string;

  @ApiProperty({
    type: () => FetchTCOrPP,
    description: 'Data'
  })
    data: FetchTCOrPP;

}

export class FetchLatestTCOrPP {

  @ApiProperty({
    type: 'string',
    description: 'Success Message',
    default: ' PRIVACY_POLICY / TERMS_CONDITIONS html content fetched successfully'
  })
    message: string;

  @ApiProperty({
    type: 'string',
    description: 'Data'
  })
    content: string;

}