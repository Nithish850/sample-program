import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, } from 'class-validator';
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';
export class VendorConsentDetailsSuccess {

    @IsNotEmpty()
    @ApiProperty({
      required: true,
      type: 'string',
      description: 'Vendor Name',
    })
      vendorName: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Current Active Version',
      required: true
    })
      currentActiveVersion: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'Consent Message',
      required: true
    })
      consentMessage: string;

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'dss Id',
      required: true
    })
      dssId: string;
}

export class VendorConsentDetailsSuccessRes {
    @ApiProperty({ type: () => VendorConsentDetailsSuccess })
      data: VendorConsentDetailsSuccess;

    @ApiProperty({
      type: 'string',
      description: 'customer consent message',
      default: SUCCESS_RESPONSE_MESSAGE.VENDOR_CONSENT_FETCHED,
    })
      message: string;
}

export class VendorConsentDetailsNoDataRes {

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'type',
      default: ERROR_TYPE.CONSENT
    })
      type: string

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
      type: 'string',
      description: 'message',
      default: ERROR_MESSAGE.NO_DATA_FOUND
    })
      message: string

}

export class VendorConsentDetailsErrorRes {
  @ApiProperty({
    default: { type: 'catch', message: 'Something went wrong, please try again' }
  })
    errors:any;
}
