import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsObject, IsOptional, IsString } from "class-validator";
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from "../../utils/constant";

export class CreatePartnerBody {

  @IsString()
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'Tenant id',
    default: '676726c8-ed1a-4010-8e91-91ea1c7f5b7d'
  })
    tenantId: string;

  @IsObject()
  @IsOptional()
  @ApiProperty({
    type: 'object',
    description: 'Details of the Partner',
    default: {},
    required: false
  })
    details: object;

  @IsObject()
  @IsOptional()
  @ApiProperty({
    type: 'object',
    description: 'Image for the Partner Logo',
    default: { logo: 'logo' },
    required: false
  })
    logo: object;

}

class CreatePartnerSuccess {

  @ApiProperty({
    type: 'string',
    description: 'Partner Name',
    default: 'CHECKOUT2'
  })
    name: string;

  @ApiProperty({
    type: 'string',
    description: 'Status of the Partner',
    default: 'ACTIVE'
  })
    status: string;

  @ApiProperty({
    type: 'object',
    description: 'Details of a Partner',
    default: {}
  })
    details: object;

  @ApiProperty({
    type: 'object',
    description: 'Image for the Partner Logo',
    default: { logo: 'logo' }
  })
    logo: object;

  @ApiProperty({
    type: 'string',
    description: 'Partner Id',
    default: 'f5629611-d645-4976-8241-f75f429c2e30'
  })
    dssVendorId: string;

}

export class CreatePartnerSuccessDTO {

  @ApiProperty({
    type: 'string',
    description: 'Success message',
    default: SUCCESS_RESPONSE_MESSAGE.PARTNER_CREATE
  })
    message: string;

  @ApiProperty({ type: () => CreatePartnerSuccess })
    data: CreatePartnerSuccess;

}

export class CreatePartnerCatchError {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;

}

export class CreatePartnerUnauthorized {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED },
      { type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.USER_UNAUTHORIZED },
    ]
  })
    errors: string;

}

export class CreatePartnerNotAcceptable {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.PARTNER, message: ERROR_MESSAGE.VALID_PARTNER_NAME },
      { type: ERROR_TYPE.PARTNER, message: ERROR_MESSAGE.PARTNER_ALREADY_EXIST },
    ]
  })
    errors: string;

}