import { ApiProperty } from "@nestjs/swagger";
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from "../../utils/constant";

class FetchedPartner {

  @ApiProperty({
    type: 'string',
    description: 'Vendor Id',
    default: 'c9901d45-b9d6-404b-baf6-13b2142e14b5'
  })
    dssVendorId: string;

  @ApiProperty({
    type: 'string',
    description: 'Name of a Partner',
    default: 'CHECKOUT'
  })
    name: string;

  @ApiProperty({
    type: 'string',
    description: 'Status of a Partner',
    default: 'ACTIVE'
  })
    status: string;

  @ApiProperty({
    type: 'object',
    description: 'Details of a Partner',
    default: { data: "data" }
  })
    details: object;

  @ApiProperty({
    type: 'object',
    description: 'Logo of a Partner',
    default: { logo: "logo" }
  })
    logo: object;
}

export class FetchedPartnerDTO {

  @ApiProperty({
    type: 'string',
    description: 'Success message',
    default: SUCCESS_RESPONSE_MESSAGE.FETCHED_PARTNER
  })
    message: string;

  @ApiProperty({
    type: () => [FetchedPartner],
    description: 'Response',
  })
    data: FetchedPartnerDTO;

  @ApiProperty({
    type: 'number',
    description: 'page',
    default: 1
  })
    page: number;

  @ApiProperty({
    type: 'number',
    description: 'page size',
    default: 10
  })
    pageSize: number;

}

export class FetchPartnerUnauthorized {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.NOT_AUTHORIZED, message: ERROR_MESSAGE.TENANT_UNAUTHORIZED },
    ]
  })
    errors: string;

}

export class FetchedPartnerCatchError {

  @ApiProperty({
    type: () => 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;

}