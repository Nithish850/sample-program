import { Logger } from '@nestjs/common';
import { DSSVendorConsent } from '../db/models/dss-vendor-consent';
import { Namespace } from '../db/models/namespace';
import { getPartnerDetails, isBelongToTenant } from '../utils/helper';
import { CustomerConsent } from '../db/models/customer-consent';
import { ERROR_MESSAGE, ERROR_TYPE } from '../utils/constant';
import { TenantConsent } from '../db/models/tenant-consent';
import { DSS } from '../db/models/dss';

const logger = new Logger();

export async function checkConsentValidity(customerConsent, dssId) {
  try {

    // Get the latest consent version for the given vendor
    const latestConsentVersion: any = await DSSVendorConsent.query()
      .select('*')
      .where('dss_id', dssId)
      .where('active_status', 'ACTIVE')
      .orderBy('updated_at', 'desc')
      .first();

    if (!latestConsentVersion) {
      return false;
    }

    // Condition 1: Approved/confirmed by user =< 1 year
    // Condition 2: If no new latest version is available

    const latestUpdatedAt : any = new Date(customerConsent.updatedAt);
    const currentDate : any= new Date();
    const yearDiff = (currentDate - latestUpdatedAt) / (1000 * 60 * 60 * 24 * 365.25);
    const consentUpdatedAt : any = new Date(latestConsentVersion.updatedAt);

    if (
      (yearDiff <= 1 && customerConsent.consentVersion === latestConsentVersion.consentVersion) ||
      (yearDiff <= 1 && customerConsent.consentVersion !== latestConsentVersion.consentVersion && latestUpdatedAt > consentUpdatedAt)

    ) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    logger.error('Inside catch :: ' + err.message);

    return false;
  }
}

export const getConsentId = async () => {
  try {
    let referenceId;

    const vendorConsent: any = await DSSVendorConsent.query()
      .select('consent_id')
      .orderBy('consent_id', 'desc')
      .first();

    if(vendorConsent){
      const { consentId } = vendorConsent;

      referenceId = consentId ? 'PR' + (Number(consentId.slice(2)) < 9 ? '0' + (Number(consentId.slice(2)) + 1) : Number(consentId.slice(2)) + 1 ) : 'PR01';
    } else {
      referenceId = 'PR01'
    }

    return referenceId;
  } catch (err) {
    logger.log(`Catch Error - Inside generating the Consent Id :: ${err.message}`);

    return { errors: [{ type: 'Catch Error', message: err.message }] };
  }
}

export async function checkConsent(subCategory, type, customerAccountId, tenantId) {
  let consent : any;
  let paymentPartnerType;

  // Get the customer's consent for the given vendor
  if (customerAccountId && customerAccountId != '') {

    const customer: any = await Namespace.query()
      .findOne({ customer_account_id: customerAccountId, tenant_id: tenantId, is_deleted: false, is_global: false });

    if (!customer) {
      return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_CUSTOMER_ACCOUNT }] };
    }

    // const customerNamespace = customer.namespace;
    // const isPresent = await isBelongToTenant(tenantId, customerNamespace, null);

    // if (!isPresent) {
    //   return { errors: [{ type: ERROR_TYPE.CONSENT, message: ERROR_MESSAGE.CUSTOMER_DOES_NOT_BELONGS_TO_TENANT, }] };
    // }
    consent = await CustomerConsent.query()
      .select('*')
      .where('customer_account_id', customerAccountId)
      .andWhere('tenant_id', tenantId)
      .orderBy('updated_at', 'desc')
      .first();

    paymentPartnerType = await getPartnerDetails(tenantId, 'Offchain Transactions', subCategory, type, 'Customer Wallet');
  }
  else{

    // Get the tenant's consent for the given vendor
    consent = await TenantConsent.query()
      .select('*')
      .where('tenant_id', tenantId)
      .orderBy('updated_at', 'desc')
      .first();

    paymentPartnerType = await getPartnerDetails(tenantId, 'Offchain Transactions', subCategory, type, 'Tenant Wallet');
  }

  if (!consent) {
    return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_CONSENT_AVAILABLE }] };
  }

  if (!paymentPartnerType) {
    return { errors: [{ type: ERROR_TYPE.NO_DATA, message: ERROR_MESSAGE.NO_PARTNER }] };
  }

  const dssTypeId = await DSS.query().findOne({ dss_type: paymentPartnerType }).select('dss_type_id');

  if(!dssTypeId){
    return { errors: [{ type: ERROR_TYPE.NO_DATA, message: `No partner details available: ${paymentPartnerType}` }] };
  }

  if (consent.consentStatus !== 'ACCEPTED') {
    return { errors: [{
      type: ERROR_TYPE.CONSENT,
      message: `Consent is not valid. Please accept the consent. Latest consent version is: ${consent.consentVersion}`
    }] };
  }

  const consentValidity = await checkConsentValidity(consent, dssTypeId?.dssTypeId);

  if (consentValidity) {

    return {
      data: {
        latestConsentVersion: consent.consentVersion
      },
      message: 'Consent is accepted'
    }
  }

  return { errors: [{
    type: ERROR_TYPE.CONSENT,
    message: `Consent is not valid. Please accept the consent. Latest consent version is: ${consent.consentVersion}`
  }] };
}

export async function getCurrentVendorConsentDetails(partner){
  const dssVendorConsentDetails = await DSSVendorConsent.query()
    .select('*')
    .where('vendor_name', partner)
    .andWhere('active_status', 'ACTIVE')
    .orderBy('updated_at', 'desc')
    .first();

  return dssVendorConsentDetails;
}