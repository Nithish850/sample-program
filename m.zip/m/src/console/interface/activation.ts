export interface ActivationI {
  email: string;
  leadStatus: string;
  activationCode: string;
  isActivated: boolean;
  deviceType: string;
  deviceToken: string;
}
