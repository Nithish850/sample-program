/* eslint-disable no-useless-catch */
import { Injectable, Logger } from '@nestjs/common';
import { CreateActivationDTO } from '../../db/dto/createActivation';
import { ModelClass, PartialModelObject } from 'objection';
import { UpdateAccessRequest } from '../helper/updateAccessRequest';
import { AccessRequests } from '../../db/models/access-requests';
import { ActivationDTO } from '../dto/Activation';
import { InjectModel } from 'nest-knexjs';
import { ACCESS_REQUEST_LEAD_STATUS } from '../../utils/constant';
import { azureMailer } from '../../utils/util.service';
import { AzureMailConfigDTO } from '../../utils/dto/main-config-dto';
import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';
import { EmailTemplates } from '../../db/models/email-templates';
import _ from 'lodash';
/**
 * ConsoleService class provides different functions:
 * updateAccessRequest,
 * fetchByDeviceToken,
 * updateLeadStatusGenerateActivationCode
 */
@Injectable()
export class ConsoleService {
  private readonly logger = new Logger(ConsoleService.name);
  @InjectModel('AccessRequests') private accessRequestsRepository: ModelClass<AccessRequests>;

  /**
   * Activate the access-requests and update the device details /console
   * @example Activate the access-requests and update the device details
   * @param {UpdateAccessRequest} payload  e.g.{ activationCode: '', deviceType: 'device-type', deviceToken: 'device-token'}
   * @returns Returns an object with updated details
   */
  async validateAndUpdatedAccessRequest(payload: UpdateAccessRequest): Promise<any> {
    try {
      const activationData: any = await this.accessRequestsRepository.query().findOne({ activationCode: payload.activationCode });

      if (activationData && activationData.isActivated) {
        return {
          message: 'Access request already activated',
          activationData,
        };
      }

      if (activationData && activationData.accessRequestsId) {
        const updatedActivationData = await this.accessRequestsRepository.query().patchAndFetchById(activationData.accessRequestsId, {
          deviceType: payload.deviceType,
          deviceToken: payload.deviceToken,
          isActivated: true,
        } as PartialModelObject<AccessRequests>);

        if (updatedActivationData) {
          return {
            message: 'Access requests activated',
            updatedActivationData,
          };
        }
      }

      return {
        errors: [ { message: ERROR_MESSAGE.NO_DATA_FOR_ACTIVATION_CODE, type: ERROR_TYPE.CONSOLE + '/activation' } ],
      };
    } catch (err) {
      this.logger.log('Catch Error - updateAccessRequests: ' + err);

      return {
        errors: [ { message: err.message, type: ERROR_TYPE.CATCH } ],
      };
    }
  }

  /**
   * Get the activation details through device token / deviceToken
   * @example Get the activation details through device token / deviceToken.
   * @param {string} deviceToken      e.g. adsfasfadsfaskfdjasd9fsdfsd
   * @returns Returns an object with details
   */
  async fetchByDeviceToken(deviceToken: string): Promise<any> {
    try {
      const data = await this.accessRequestsRepository.query().findOne({ device_token: deviceToken });

      if (data) {
        return { message: SUCCESS_RESPONSE_MESSAGE.FETCH_BY_DEVICE_TOKEN, data: data };
      }

      return { errors: [ { message: ERROR_MESSAGE.NO_DATA_FOR_GIVEN_DEVICE_TOKEN, type: ERROR_TYPE.NO_DATA } ] };
    } catch (err) {
      this.logger.log(`inside catch service :: {end}`);

      return { errors: [ { type: ERROR_TYPE.CATCH, message: ERROR_MESSAGE.NOT_ABLE_TO_FETCH_BY_DEVICE_TOKEN } ] };
    }
  }

  /**
   * Create activate access-requests /access-requests
   * @example Create activate access-requests and insert default values along with email
   * @param {CreateActivationDTO} activationPayload  e.g.{ email: ''}
   * @returns Returns an object with updated details
   */
  async createAccessRequest(activationPayload: CreateActivationDTO): Promise<any> {
    try {
      this.logger.log(`inside activation service :: {start}`);

      const { email } = activationPayload;

      const data = await this.accessRequestsRepository.query().insert({ email });

      this.logger.log(`inside activation service :: {end}`);

      if (data) {
        return { message: SUCCESS_RESPONSE_MESSAGE.CREATED_ACCESS_REQUEST, data: data };
      }

      return { errors: [ { type: ERROR_TYPE.CREATE, message: ERROR_MESSAGE.ACCESS_REQUEST_NOT_CREATED_CHECK } ] };
    } catch (e) {
      this.logger.log(`inside catch service :: {end}`);

      return { errors: [ { type: ERROR_TYPE.CATCH, message: ERROR_MESSAGE.NOT_ABLE_TO_CREATE_ACCESS_REQUEST } ] };
    }
  }

  /**
   * Generates an activation code for a user if the lead status is provided approved.
   * @example Get the activation code through activationId.
   * @param {ActivationDTO} activationPayload
   * @example activationId: "b7a9cd5c-fd9a-4c38-b848-29d8a2bd1087"
   * @example leadStatus: "ACCEPTED"
   * @returns Returns an object with activation code and lead status
   */
  async updateLeadStatusGenerateActivationCode(activationPayload: ActivationDTO): Promise<any> {
    const { leadStatus } = activationPayload;

    try {
      const activationData = await this.accessRequestsRepository.query().findById(activationPayload.activationId);

      if (!activationData) {
        return { errors: [ { type: ERROR_TYPE.ACCOUNT, message: ERROR_MESSAGE.ACCOUNT_NOT_FOUND } ] };
      }

      if (leadStatus === ACCESS_REQUEST_LEAD_STATUS.ACCEPTED) {
        const size = activationPayload.activationId.length;
        const activationCode = activationPayload.activationId.substr(size - 9, size - 1).toUpperCase();

        const data = await this.accessRequestsRepository.query().findById(activationPayload.activationId);

        const to: any[] = [
          {
            address: data.email,
            displayName: ''
          }
        ];
        const recipients= {
          to: to
        };
        const senderAddress =  process.env.AZURE_HOST;

        const emailTemplate: any= await EmailTemplates.query().findOne({ template_name: 'OnboardingActivationCode' });

        if(emailTemplate){
          const file_content = emailTemplate.html ;
          const template = _.template(file_content);
          const html = template({ activationCode: activationCode });

          const content = {
            subject: emailTemplate.subject,
            html: html,
            plainText: emailTemplate.text,

          };

          const message: AzureMailConfigDTO = { senderAddress, content, recipients };
          const response = await azureMailer(message);

          if (response.status=='Succeeded') {
            const updatedAccessData = await this.accessRequestsRepository.query().patchAndFetchById(activationPayload.activationId, {
              leadStatus: leadStatus,
              activationCode: activationCode,
            });

            return {
              message: SUCCESS_RESPONSE_MESSAGE.UPDATED_ACCESS_REQUEST_MESSAGE,
              updatedAccessData,
            };
          }
          if (response.status!='Succeeded') {
            return { errors: [ { type: ERROR_TYPE.UPDATE, message: ERROR_MESSAGE.ACCESS_REQUEST_UPDATE_FAIL } ] };
          }
        }
        else {
          return {
            errors: [ { message: 'no email template present', type: ERROR_TYPE.NO_DATA } ],
          };
        }

      }

      if(leadStatus === ACCESS_REQUEST_LEAD_STATUS.DECLINED){
        const updatedAccessData = await this.accessRequestsRepository.query().findById(activationPayload.activationId).patchAndFetchById(activationPayload.activationId, { leadStatus: leadStatus });

        return {
          message: ERROR_MESSAGE.LEAD_STATUS_DECLINED,
          updatedAccessData,
        }

      }

      this.logger.log(`inside activation service :: {end}`);

      return { errors: [ { message: ERROR_MESSAGE.WRONG_LEAD_STATUS, type: ERROR_TYPE.UPDATE } ] };
    } catch (err) {
      this.logger.log(`inside catch service :: {end}` + err.message);

      return { errors: [ { message: ERROR_MESSAGE.ACCESS_REQUEST_LEAD_STATUS_FAIL, type: ERROR_TYPE.CATCH } ] };
    }

  }

  /**
   *
   * @param { number } page
   * @example page : 1
   * @param { number } pagesize
   * @example pagesize : 20
   * @returns data
   */
  async fetchAllUsers(page: number, pagesize: number): Promise<any> {
    try {
      const data = await this.accessRequestsRepository.query().page(page, pagesize).orderBy('created_at', 'DESC');
      const leadStatusCount = {
        declined: 0,
        pending: 0,
        accepted: 0,
        total: 0,
      };
      const leadStatusData: any = await AccessRequests.query().select(AccessRequests.knex().raw('count(*) as counts'), 'leadStatus').groupBy('leadStatus');

      leadStatusData.forEach((c) => {
        if (c.leadStatus === ACCESS_REQUEST_LEAD_STATUS.DECLINED) leadStatusCount['declined'] = Number(c.counts);
        if (c.leadStatus === ACCESS_REQUEST_LEAD_STATUS.PENDING) leadStatusCount['pending'] = Number(c.counts);
        if (c.leadStatus === ACCESS_REQUEST_LEAD_STATUS.ACCEPTED) leadStatusCount['accepted'] = Number(c.counts);

        leadStatusCount['total'] += Number(c.counts);
      });

      if (data) {
        return {
          leadStatusCount: leadStatusCount,
          data: data.results,
          page: Number(page + 1),
          pageSize: Number(pagesize),
        };
      }

      return {
        errors: [ { type: ERROR_TYPE.CONSOLE, message: ERROR_MESSAGE.NO_DATA_FOUND } ],
      };
    } catch (err) {
      return {
        errors: [ { type: ERROR_TYPE.CONSOLE, message: ERROR_MESSAGE.WRONG_NUMBER } ],
      };
    }
  }
}
