import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty } from 'class-validator';

import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';

/**
 * Schema for the approve access request response body
 */
export class ActivationDTO {
  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'activation id of an account',
  })
    activationId: string;

  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'lead status of account',
  })
    leadStatus: string;
}

/**
 * Updated Access Data schema
 */
export class UpdatedAccessDataDTO {
  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `lead status`,
    example: `ACCEPTED`,
  })
    leadStatus: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `activation code`,
    example: `FA1EC255C`,
  })
    activationCode: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: 'access request id',
    example: `ca979737-0e48-4ab4-ac9d-f2dfa1ec255c`,
  })
    accessRequestsId: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `email`,
    example: `dg6@gmail.com`,
  })
    email: string;

  @IsBoolean()
  @IsNotEmpty()
  @ApiProperty({
    type: `boolean`,
    description: `is activated`,
    example: `true`,
  })
    isActivated: boolean;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `device type`,
    example: `phone`,
  })
    deviceType: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `device token`,
    example: `token`,
  })
    deviceToken: string;
}

/**
 * Update Lead Status Success Response With Message schema
 */
export class UpdateLeadStatusSuccessResponseWithMessageDTO {
  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `Success message of the update lead status`,
    example: SUCCESS_RESPONSE_MESSAGE.UPDATED_ACCESS_REQUEST_MESSAGE,
  })
    message: string;

  @ApiProperty({ type: () => UpdatedAccessDataDTO })
    UpdatedAccessData: UpdatedAccessDataDTO;
}

/**
 * Failure Response With Message And Type schema
 */
export class UpdateLeadStatusFailureResponseWithMessageDTO {

  @IsNotEmpty()
  @ApiProperty({
    type: 'string',
    description: 'type of error',
    default: [
      { type: ERROR_TYPE.CATCH, message: ERROR_MESSAGE.ACCESS_REQUEST_LEAD_STATUS_FAIL },
      { type: ERROR_TYPE.ACCOUNT, message: ERROR_MESSAGE.ACCOUNT_NOT_FOUND },
      { type: ERROR_TYPE.CATCH, message: ERROR_MESSAGE.LEAD_STATUS_DECLINED },
      { message: ERROR_MESSAGE.WRONG_LEAD_STATUS, type: ERROR_TYPE.UPDATE },
      { message: ERROR_MESSAGE.ACCESS_REQUEST_LEAD_STATUS_FAIL, type: ERROR_TYPE.CATCH }
    ],
  })
    errors: 'string';
}

/**
 * Get Access Request Total List Count schema
 */
export class AccessRequestListCountDTO {
  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `count of declined list`,
    default: 5,
  })
    declined: number;

  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `count of pending list`,
    default: 15,
  })
    pending: number;

  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `count of accepted list`,
    default: 30,
  })
    accepted: number;

  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `count of total list`,
    default: 50,
  })
    total: number;
}

/**
 * Get Access Request List schema
 */
export class GetAccessRequestListDTO {
  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `access request id`,
    default: `33699b5a-3b4b-4ef5-9013-44ec2a72c76a`,
  })
    accessRequestsId: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `email`,
    default: `838sivaji@gmail.com`,
  })
    email: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `lead status`,
    default: `ACCEPTED`,
  })
    leadStatus: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `activation code`,
    default: `C2A72C76A`,
  })
    activationCode: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `boolean`,
    description: `is activated`,
    default: true,
  })
    isActivated: boolean;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `device type`,
    default: `onePlus`,
  })
    deviceType: string;

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `device token`,
    default: `dummyToken`,
  })
    deviceToken: string;
}

/**
 * Get Access Request List Status Success Response schema
 */
export class GetAccessRequestListSuccessResponseWithMessageDTO {
  @ApiProperty({ type: () => AccessRequestListCountDTO })
    leadStatusCount: AccessRequestListCountDTO;

  @ApiProperty({ type: () => [ GetAccessRequestListDTO ] })
    data: GetAccessRequestListDTO;

  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `page`,
    default: 1,
  })
    page: number;

  @IsNotEmpty()
  @ApiProperty({
    type: `number`,
    description: `page size`,
    default: 2,
  })
    pageSize: number;
}

/**
 * Failure Response With Message And Type schema for get access request list with page and page size
 */
export class GetAccessRequestListFailureResponseWithMessageDTO {
  @IsNotEmpty()

  @IsNotEmpty()
  @ApiProperty({
    type: `string`,
    description: `error message`,
    default: [
      { type: ERROR_TYPE.CONSOLE, message: ERROR_MESSAGE.NO_DATA_FOUND },
      { type: ERROR_TYPE.CONSOLE, message: ERROR_MESSAGE.WRONG_NUMBER }
    ]
  })
    errors: string;
}
export class CatchErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: 'Catch', message: 'shows the error message while API failed in execution' },
      { message: ERROR_MESSAGE.NO_DATA_FOR_ACTIVATION_CODE, type: ERROR_TYPE.CONSOLE + '/activation' },
      { message: 'err.message', type: ERROR_TYPE.CATCH }
    ]
  })
    errors: string;
}

export class TenantCountErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { message: ERROR_MESSAGE.PROVIDE_VALID_TENANT_ID, type: ERROR_TYPE.CATCH }
    ]
  })
    errors: string;
}

export class WalletCountErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;
}

export class TransactionsCountErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { message: 'error while fetching transaction count', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;
}

export class TotalTransactedAmountErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { message: 'error while fetching transacted amount', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;
}

export class TotalAmountAcrossWallet {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { message: 'error while fetching total amount across wallet', type: ERROR_TYPE.CATCH } ,
    ]
  })
    errors: string;
}

export class CreateAccessRequest {
  @ApiProperty({
    type: 'string',
    description: 'email',
    default: 'test123@mygmail.com',
  })
    email: string;

  @ApiProperty({
    type: 'string',
    description: 'lead_status',
    default: 'PENDING',
  })
    lead_status: string;

  @ApiProperty({
    type: 'string',
    description: 'is_activated',
    default: false,
  })
    is_activated: boolean;

  @ApiProperty({
    type: 'string',
    description: 'accessRequestsId',
    default: 'de58d3b9-1949-4b4f-b913-995d1e0b3942',
  })
    accessRequestsId: string;
}

export class CreateAccessRequestDTO {
  @ApiProperty({
    type: 'string',
    description: 'success message',
    default: 'Access request created successfully',
  })
    message: string;

  @ApiProperty({ type: () => CreateAccessRequest })
    data: object;
}

export class AccessRequest {
  @ApiProperty({
    type: 'string',
    description: 'accessRequestsId',
    default: 'de58d3b9-1949-4b4f-b913-995d1e0b3942',
  })
    accessRequestsId: string;

  @ApiProperty({
    type: 'string',
    description: 'email',
    default: 'test123@mygmail.com',
  })
    email: string;

  @ApiProperty({
    type: 'string',
    description: 'leadStatus',
    default: 'PENDING',
  })
    leadStatus: string;

  @ApiProperty({
    type: 'string',
    description: 'activationCode',
    default: 'string',
  })
    activationCode: string;

  @ApiProperty({
    type: 'string',
    description: 'isActivated',
    default: false,
  })
    isActivated: boolean;

  @ApiProperty({
    type: 'string',
    description: 'deviceType',
    default: 'string',
  })
    deviceType: string;

  @ApiProperty({
    type: 'string',
    description: 'deviceToken',
    default: 'string',
  })
    deviceToken: string;
}

export class AccessRequestDTO {
  @ApiProperty({
    type: 'string',
    description: 'success message',
    default: 'Access details fetched successfully',
  })
    message: string;

  @ApiProperty({ type: () => AccessRequest })
    data: object;
}

export class UpdateAccessRequestDTO {
  @ApiProperty({
    type: 'string',
    description: 'success message',
    default: 'Access requests activated',
  })
    message: string;

  @ApiProperty({ type: () => AccessRequest })
    updatedActivationData: object;
}

export class KYCErrorDTO {
  @ApiProperty({
    type: 'string',
    description: 'Catch error message',
    default: [
      { type: ERROR_TYPE.CATCH, message: 'shows the error message while API failed in execution' },
      { type: ERROR_TYPE.CATCH, message: 'error[1]' },
      { message: 'err.message', type: ERROR_TYPE.CATCH },
    ]
  })
    errors: string;
}