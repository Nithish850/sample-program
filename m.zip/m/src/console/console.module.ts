import { Module } from '@nestjs/common';

import { ConsoleController } from './controller/console.controller';
import { ConsoleService } from './service/console.service';

@Module({
  imports: [],
  controllers: [ ConsoleController ],
  providers: [ ConsoleService ],
})
export class ConsoleModule {}
