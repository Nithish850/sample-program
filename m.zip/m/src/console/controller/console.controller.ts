import { Controller, Get, HttpStatus, Logger, Param, Res, Post, Put, Body, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiParam, ApiTags, ApiBody, ApiQuery, ApiOkResponse, ApiBadRequestResponse } from '@nestjs/swagger';
import { ConsoleService } from '../service/console.service';
import { Response } from 'express';
import { UpdateAccessRequest } from '../helper/updateAccessRequest';
import { AccessRequestDTO,
  ActivationDTO,
  CatchErrorDTO,
  CreateAccessRequestDTO,
  GetAccessRequestListFailureResponseWithMessageDTO,
  GetAccessRequestListSuccessResponseWithMessageDTO,
  UpdateAccessRequestDTO,
  UpdateLeadStatusFailureResponseWithMessageDTO,
  UpdateLeadStatusSuccessResponseWithMessageDTO } from '../dto/Activation';
import { CreateActivationDTO } from '../../db/dto/createActivation';

@ApiBearerAuth()
@Controller('/access-requests')
@ApiTags('Console')
export class ConsoleController {
  private readonly logger = new Logger(ConsoleController.name);
  constructor(private readonly consoleService: ConsoleService) {}

  /**
   * Generates an activation code for a user if the lead status is provided approved.
   * @example Get the activation code through activationId.
   * @param {ActivationDTO} activationPayload
   * @returns Returns an object with activation code and lead status
   */
  @Put('approve')
  @ApiOperation({ summary: 'Update activation status ' })
  @ApiOkResponse({
    description: 'will update the lead status for the given activation id',
    type: () => UpdateLeadStatusSuccessResponseWithMessageDTO,
    isArray: false,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if lead status updating get failed',
    isArray: false,
    type: () => UpdateLeadStatusFailureResponseWithMessageDTO,
  })
  @ApiBody({ type: ActivationDTO, required: true })
  async updateLeadStatusGenerateActivationCode(@Body() activationPayload: ActivationDTO, @Res() res: Response): Promise<any> {
    this.logger.log(`inside activation controller :: {start}`);

    const response = await this.consoleService.updateLeadStatusGenerateActivationCode(activationPayload);

    this.logger.log(`inside activation controller :: {end}`);

    if (response && !response.errors) {
      return res.status(HttpStatus.OK).send(response);
    } else {
      return res.status(HttpStatus.BAD_REQUEST).send(response);
    }
  }

  /**
   * Activate the access-requests and update the device details /console
   * @example Activate the access-requests and update the device details
   * @param {UpdateAccessRequest} payload  e.g.{ activationCode: '', deviceType: 'device-type', deviceToken: 'device-token'}
   * @returns Returns an object with updated details
   */
  @Put('activate')
  @ApiOperation({ summary: 'Activate the access-request and updating the device details' })
  @ApiOkResponse({
    description: 'will update an access request',
    type: () => UpdateAccessRequestDTO,
    isArray: false,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if update access request get failed',
    type: () =>  CatchErrorDTO,
    isArray: false,
  })
  @ApiBody({ type: UpdateAccessRequest, required: true })
  async validateAndUpdatedAccessRequest(@Body() payload: UpdateAccessRequest, @Res() res: Response): Promise<any> {
    this.logger.log(`Updating the access-requests to activate`);
    const response = await this.consoleService.validateAndUpdatedAccessRequest(payload);

    if (response && !response.errors) {
      return res.status(HttpStatus.OK).send(response);
    } else {
      return res.status(HttpStatus.BAD_REQUEST).send(response);
    }
  }

  /**
   * Get the activation details through device token / console
   * @example Get the activation details through device token /console.
   * @param {string} deviceToken      e.g. pdocndbwhwjd87cnc
   * @returns Returns an object with details
   */
  @Get('check-activation/:deviceToken')
  @ApiOkResponse({
    description: 'will create an access request',
    type: () => AccessRequestDTO,
    isArray: false,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if fetch by device token get failed',
    type: () =>  CatchErrorDTO,
    isArray: false,
  })
  @ApiParam({
    name: 'deviceToken',
    description: 'device Token of device',
    required: true,
  })
  @ApiOperation({ summary: 'Fetch Details by device token' })
  async fetchByDeviceToken(@Param('deviceToken') deviceToken: string, @Res() res: Response): Promise<any> {
    this.logger.log(`Inside activation controller :: {start}`);

    const response = await this.consoleService.fetchByDeviceToken(deviceToken);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   * Create activate access-requests /access-requests
   * @example Create activate access-requests and insert default values along with email
   * @param {CreateActivationDTO} payload  e.g.{ email: ''}
   * @returns Returns an object with updated details
   */
  @Post('')
  @ApiOperation({ summary: 'Create access request' })
  @ApiOkResponse({
    description: 'will create an access request',
    type: () => CreateAccessRequestDTO,
    isArray: false,
  })
  @ApiBadRequestResponse({
    description: 'Bad request response if creating an access request get failed',
    type: () =>  CatchErrorDTO,
    isArray: false,
  })
  @ApiBody({ type: CreateActivationDTO, required: true })
  async createAccessRequest(@Body() activationPayload: CreateActivationDTO, @Res() res: Response): Promise<any> {
    this.logger.log(`inside activation controller :: {start}`);

    const response = await this.consoleService.createAccessRequest(activationPayload);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }

  /**
   *
   * @param { Response } res
   * @example res : all users from waitList
   * @param { number } page
   * @example page : 1
   * @param { number } pagesize
   * @example pagesize : 10
   * @returns data
   */
  @Get('')
  @ApiOperation({ summary: `Fetch the details by page number and page size` })
  @ApiOkResponse({
    description: `will get the limited list with the help of page number and page size in descending order`,
    isArray: false,
    type: () => GetAccessRequestListSuccessResponseWithMessageDTO
  })
  @ApiBadRequestResponse({
    description: `Bad request response if no data found`,
    isArray: false,
    type: () => GetAccessRequestListFailureResponseWithMessageDTO
  })
  @ApiQuery({
    name: 'page',
    description: 'Page index',
    required: true,
  })
  @ApiQuery({
    name: 'pagesize',
    description: 'Page size',
    required: true,
  })
  async fetchAllUsers(@Res() res: Response, @Query('page') page: number, @Query('pagesize') pagesize: number): Promise<any> {
    this.logger.log(`/console/access-requests page: ${page - 1} pagesize: ${pagesize}`);
    const response = await this.consoleService.fetchAllUsers(page - 1, pagesize);

    if (response && response.data) {
      return res.status(HttpStatus.OK).send(response);
    }

    return res.status(HttpStatus.BAD_REQUEST).send(response);
  }
}
