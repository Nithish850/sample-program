import { ConsoleController } from '../controller/console.controller';
import { ConsoleService } from '../service/console.service';
import { CREATE_ACCESS_REQUEST, CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE, DEVICE_TOKEN, FETCH_USER_RESPONSE, GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE, FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE, PAGE, PAGESIZE, PAYLOAD, UPDATE_ACCESS_REQUEST_CODE_PAYLOAD } from './console.testConfig';

import { Test } from '@nestjs/testing';

const mockUpdateActivationStatus = {
  updateLeadStatusGenerateActivationCode: jest.fn(() => PAYLOAD),
  validateAndUpdatedAccessRequest: jest.fn(() => GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE),
  fetchByDeviceToken: jest.fn(() => FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE),
  createAccessRequest: jest.fn(() => CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE),
  fetchAllUsers: jest.fn(() => FETCH_USER_RESPONSE)
};

// Test cases to create primary name space
describe('ConsoleService', () => {
  let consoleService: ConsoleService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsoleController ],
      providers: [ ConsoleService ],
    })
      .overrideProvider(ConsoleService)
      .useValue(mockUpdateActivationStatus)
      .compile();

    consoleService = moduleRef.get<ConsoleService>(ConsoleService);
  });

  /**
   * Test Cases for the updateLeadStatusGenerateActivationCode() function SUCCESS
   * @param PAYLOAD { activationId: 'string', leadStatus: 'ACCEPTED' }
   */
  describe('Test case to check the functionality of the updateLeadStatusGenerateActivationCode() function: PUT / SUCCESS', () => {
    it('should be defined the service the file', () => {
      expect(consoleService).toBeDefined();
    });

    it('should check if it is getting proper response or not.', async () => {
      const res = await consoleService.updateLeadStatusGenerateActivationCode(PAYLOAD);

      expect(res).toEqual(PAYLOAD);
    });

    it('should check if response data key is not null', async () => {
      const res = await consoleService.updateLeadStatusGenerateActivationCode(PAYLOAD);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that console service gets called', () => {
      expect(consoleService.updateLeadStatusGenerateActivationCode).toBeCalled();
    });

    it('should be make sure that updateActivationStatus gets called with requested payload', () => {
      expect(consoleService.updateLeadStatusGenerateActivationCode).toHaveBeenCalledWith(PAYLOAD);
    });
  });

  /**
   * Test Cases for the validateAndUpdatedAccessRequest() function SUCCESS
   * @param PAYLOAD { activationCode: 'string', deviceType: 'ACCEPTED', deviceToken: 'string' }
   */
  describe('Test case to check the functionality of the validateAndUpdatedAccessRequest() function: PUT / SUCCESS', () => {
    it('should check if it is getting proper response or not.', async () => {
      const res = await consoleService.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD);

      expect(res).toEqual(GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE);
    });

    it('should check if response data key is not null', async () => {
      const res = await consoleService.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that data is returned after status updated', async () => {
      const res = await consoleService.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD);

      expect(res.data).toEqual(GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE.data);
    });

    it('should be make sure that access request status is true after status updated', async () => {
      const res = await consoleService.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD);

      expect(res.data.isActivated).toEqual(GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE.data.isActivated);
    });
  });

  /**
   * Test Cases for the fetchByDeviceToken() function SUCCESS
   * @param PAYLOAD deviceToken: 'string'
   */
  describe('Test case to check the functionality of the fetchByDeviceToken() function: GET / SUCCESS', () => {
    it('should check if it is getting proper response or not.', async () => {
      const res = await consoleService.fetchByDeviceToken(DEVICE_TOKEN);

      expect(res).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE);
    });

    it('should check if response data key is not null', async () => {
      const res = await consoleService.fetchByDeviceToken(DEVICE_TOKEN);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that fetched the device details by the device token', async () => {
      const res = await consoleService.fetchByDeviceToken(DEVICE_TOKEN);

      expect(res.data).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE.data);
    });

    it('should be make sure that access request status is present', async () => {
      const res = await consoleService.fetchByDeviceToken(DEVICE_TOKEN);

      expect(res.data.isActivated).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE.data.isActivated);
    });
  });

  /**
   * Test Cases for the createAccessRequest() function SUCCESS
   * @param PAYLOAD { email: 'test@gmail.com'}
   */
  describe('Test case to check the functionality of the createAccessRequest() function: POST / SUCCESS', () => {
    it('should check if it is getting proper response or not.', async () => {
      const res = await consoleService.createAccessRequest(CREATE_ACCESS_REQUEST);

      expect(res).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE);
    });

    it('should check if response data key is not null', async () => {
      const res = await consoleService.createAccessRequest(CREATE_ACCESS_REQUEST);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that fetched the device details by the device token', async () => {
      const res = await consoleService.createAccessRequest(CREATE_ACCESS_REQUEST);

      expect(res.data).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE.data);
    });

    it('should be make sure that access request status is present', async () => {
      const res = await consoleService.createAccessRequest(CREATE_ACCESS_REQUEST);

      expect(res.data.lead_status).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE.data.lead_status);
    });
  });

  /**
   * Test Cases for the fetchAllUsers() function SUCCESS
   * @param PAGE page: '1'
   * @param PAGESIZE pagesize: '10'
   */
  describe('Test case to check the functionality of the fetchAllUsers() function: GET / SUCCESS', () => {
    it('should check if it is getting proper response or not.', async () => {
      const res = await consoleService.fetchAllUsers(PAGE, PAGESIZE);

      expect(res).toEqual(FETCH_USER_RESPONSE);
    });

    it('should check if response data key is not null', async () => {
      const res = await consoleService.fetchAllUsers(PAGE, PAGESIZE);

      expect(res.data).not.toBeNull();
    });

    it('should be make sure that fetched all device details by the page size and number', async () => {
      const res = await consoleService.fetchAllUsers(PAGE, PAGESIZE);

      expect(res.data).toEqual(FETCH_USER_RESPONSE.data);
    });

    it('should be make sure that data has the valid details', async () => {
      const res = await consoleService.fetchAllUsers(PAGE, PAGESIZE);

      expect(res.data[0].email).toEqual(FETCH_USER_RESPONSE.data[0].email);
    });
  });
});
