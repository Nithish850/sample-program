import { ConsoleController } from '../controller/console.controller';
import { ConsoleService } from '../service/console.service';
import {
  CREATE_ACCESS_REQUEST,
  CREATE_ACCESS_REQUEST_FAILURE_RESPONSE,
  CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE,
  FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE,
  FETCH_BY_DEVICE_TOKEN_REQUEST,
  FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE,
  FETCH_USER_FAILURE_RESPONSE,
  FETCH_USER_RESPONSE,
  GET_DETAILS_BY_ACCESS_REQUEST_CODE_FAILURE_RESPONSE,
  GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE,
  GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE,
  PAGE,
  PAGESIZE,
  PAYLOAD,
  UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD,
  UPDATE_ACCESS_REQUEST_CODE_PAYLOAD,
  UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE,
} from './console.testConfig';

import { Test } from '@nestjs/testing';
import { mockResponse } from 'jest-mock-req-res';

const mockConsoleService = {
  updateLeadStatusGenerateActivationCode: jest.fn(() => GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE),
  validateAndUpdatedAccessRequest: jest.fn(() => GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE),
  fetchByDeviceToken: jest.fn(() => FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE),
  createAccessRequest: jest.fn(() => CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE),
  fetchAllUsers: jest.fn(() => FETCH_USER_RESPONSE),
};

// Test cases to create primary name space
describe('Console Controller', () => {
  let consoleController: ConsoleController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsoleController ],
      providers: [ ConsoleService ],
    })
      .overrideProvider(ConsoleService)
      .useValue(mockConsoleService)
      .compile();

    consoleController = moduleRef.get<ConsoleController>(ConsoleController);
  });

  /** Success Test cases for the updateLeadStatusGenerateActivationCode() PUT api */
  describe('should be able to test access requests are approved or denied', () => {

    const response = mockResponse({
      HttpStatus: 200,
      body: GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });

    it('should check if we are access request is getting proper response or not.', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res).toEqual(response);
    });

    it('should check if response body is not null', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are access request is getting success status code or not.', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if response body has data or not', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body).toEqual(GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE);
    });

    it('should check if response data has requires fields or not', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body.data).toEqual(GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE.data);
    });
  });

  /** Success Test cases for the validateAndUpdatedAccessRequest() PUT api  */
  describe('should be able to test update device details or already updated endpoint PUT /success', () => {
    const response = mockResponse({
      HttpStatus: 200,
      body: GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });

    it('should check if we are getting the success status code for response of update the device', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if we are getting the proper response of update the device type and token or not', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.body).toEqual(GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE);
    });

    it('should check if in fetchDetailsByDeviceToken response data key is not null', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.body.data).not.toBeNull();
    });

    it('should check if we are getting the device active status true in response', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.body.data.isActivated).toEqual(true);
    });

    it('should check if we are getting the device type in response', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.body.data.deviceType).toEqual('device-type');
    });

    it('should check if we are getting the device token in response', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_PAYLOAD, response);

      expect(res.body.data.deviceToken).toEqual('device-token');
    });
  });

  /** Success Test cases for the fetchByDeviceToken() GET api  */
  describe('should be able to test get device details by device token: GET /success', () => {
    const response = mockResponse({
      HttpStatus: 200,
      body: FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE,
    });

    it('should check if we are getting the success status code for response of get the device details', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if we are getting the body for the given device token', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting the proper response of get the device details or not by device token', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE);
    });

    it('should check if in fetchByDeviceToken response data key object is not null', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.data).not.toBeNull();
    });

    it('should check if we are getting the device active status true in response', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.data).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE.data);
    });

    it('should check if we are getting the device type in response', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.message).toEqual(FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE.message);
    });
  });

  /** Success Test cases for the createAccessRequest() POST api  */
  describe('should be able to test get device details by device token: POST /success', () => {
    const response = mockResponse({
      HttpStatus: 200,
      body: CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE,
    });

    it('should check if we are getting the success status code for create new access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.HttpStatus).toEqual(200);
    });

    it('should check if we are getting the body for the newly created access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting the proper response for creating new access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE);
    });

    it('should check if in createAccessRequest response data key object is not null', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.data).not.toBeNull();
    });

    it('should check if we are getting the device access request details in response', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.data).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE.data);
    });

    it('should check if we are getting success message in response', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.message).toEqual(CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE.message);
    });
  });

  /** Success Test cases for the fetchAllUsers() GET api */
  describe('Should be able to fetch users successfully ', () => {
    const RESPONSE = mockResponse({
      HttpStatus: 200,
      body: FETCH_USER_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });
    it('should check if we are getting all user activation requests successfully as a response or not.', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body).toEqual(FETCH_USER_RESPONSE);
    });

    it('should check if in activation user request email is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.email).not.toBeNull();
    });

    it('should check if in activation user request is_activated is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.is_activated).not.toBeNull();
    });

    it('should check if in activation user request lead_status is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.lead_status).not.toBeNull();
    });

    it('should check if in activation user request activation_code is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.activation_code).not.toBeNull();
    });

    it('should check if in activation user request device_type is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.device_type).not.toBeNull();
    });

    it('should check if in activation user request device_token is not null', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data.device_token).not.toBeNull();
    });

    it('should check if in activation user request lead_status is PENDING', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data[0].lead_status).toEqual('PENDING');
    });

    it('should check if in activation user request is_activated is false', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.data[0].is_activated).toEqual(false);
    });
  });
});

/**
 * FAILURE test cases which are result with 400 status code
 */
const mockConsoleFailureService = {
  updateLeadStatusGenerateActivationCode: jest.fn(() => UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE),
  validateAndUpdatedAccessRequest: jest.fn(() => GET_DETAILS_BY_ACCESS_REQUEST_CODE_FAILURE_RESPONSE),
  fetchByDeviceToken: jest.fn(() => FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE),
  createAccessRequest: jest.fn(() => CREATE_ACCESS_REQUEST_FAILURE_RESPONSE),
  fetchAllUsers: jest.fn(() => FETCH_USER_FAILURE_RESPONSE),
};

// Test cases to create primary name space
describe('Console Controller', () => {
  let consoleController: ConsoleController;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      controllers: [ ConsoleController ],
      providers: [ ConsoleService ],
    })
      .overrideProvider(ConsoleService)
      .useValue(mockConsoleFailureService)
      .compile();

    consoleController = moduleRef.get<ConsoleController>(ConsoleController);
  });

  /** Failure Test cases for the updateLeadStatusGenerateActivationCode() PUT api*/
  describe('should be able to test update device details or already updated endpoint PUT / failure', () => {
    const response = mockResponse({
      HttpStatus: 400,
      body: UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });

    it('should check if we are getting the failure status code for response of update the device', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if we are getting the proper error response of update the device', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body).toEqual(UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE);
    });

    it('should check that we are getting failure response type for the given activation code in response', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body.errors[0].type).toEqual(UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE.errors[0].type);
    });

    it('should check that something went wrong while updating the lead status of the access request', async () => {
      const res = await consoleController.updateLeadStatusGenerateActivationCode(PAYLOAD, response);

      expect(res.body.errors[0].message).toEqual(UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE.errors[0].message);
    });
  });

  /** Failure Test cases for the validateAndUpdatedAccessRequest() PUT api */
  describe('should be able to test update device details or already updated endpoint PUT / failure', () => {
    const response = mockResponse({
      HttpStatus: 400,
      body: GET_DETAILS_BY_ACCESS_REQUEST_CODE_FAILURE_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });

    it('should check if we are getting the failure status code for response of update the device', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if we are getting the proper error response of update the device', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD, response);

      expect(res.body).toEqual(GET_DETAILS_BY_ACCESS_REQUEST_CODE_FAILURE_RESPONSE);
    });

    it('should check that we are not getting data for the given activation code in response', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD, response);

      expect(res.body.errors.noDataFoundError).toEqual('Data not found with given activation code');
    });

    it('should check that something went wrong ', async () => {
      const res = await consoleController.validateAndUpdatedAccessRequest(UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD, response);

      expect(res.body.errors.catchError).toEqual('Something went wrong');
    });
  });

  /** Failure Test cases for the fetchByDeviceToken() GET api */
  describe('should be able to test get device details by device token endpoint GET / failure', () => {
    const response = mockResponse({
      HttpStatus: 400,
      body: FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE,
    });

    it('should check if we are getting the failure status code for response of update the device', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if we are getting the proper error response of get the device', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting the proper error response of get the device details', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body).toEqual(FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE);
    });

    it('should check that we are getting error array with the object message and type for the given device token', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.errors).toEqual(FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE.errors);
    });

    it('should check that we are getting error message for the given wrong device token', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.errors[0].message).toEqual(FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE.errors[0].message);
    });

    it('should check that what type of error we receive ', async () => {
      const res = await consoleController.fetchByDeviceToken(FETCH_BY_DEVICE_TOKEN_REQUEST, response);

      expect(res.body.errors[0].type).toEqual(FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE.errors[0].type);
    });
  });

  /** Failure Test cases for the createAccessRequest() POST api */
  describe('should be able to test create access request endpoint POST / failure', () => {
    const response = mockResponse({
      HttpStatus: 400,
      body: CREATE_ACCESS_REQUEST_FAILURE_RESPONSE,
    });

    it('should check if we are getting the failure status code for response to create new access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if we are getting the proper error response of creating new access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body).not.toBeNull();
    });

    it('should check if we are getting the proper error response body of creating new access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body).toEqual(CREATE_ACCESS_REQUEST_FAILURE_RESPONSE);
    });

    it('should check that we are getting error array for the given wrong body of access request', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.errors).toEqual(CREATE_ACCESS_REQUEST_FAILURE_RESPONSE.errors);
    });

    it('should check that we are getting error message for the given wrong email', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.errors[0].message).toEqual(CREATE_ACCESS_REQUEST_FAILURE_RESPONSE.errors[0].message);
    });

    it('should check that what type of error we are receiving ', async () => {
      const res = await consoleController.createAccessRequest(CREATE_ACCESS_REQUEST, response);

      expect(res.body.errors[0].type).toEqual(CREATE_ACCESS_REQUEST_FAILURE_RESPONSE.errors[0].type);
    });
  });

  /** Failure Test cases for the fetchAllUsers() GET api */
  describe('Should be able to fetch users successfully ', () => {
    const RESPONSE = mockResponse({
      HttpStatus: 400,
      body: FETCH_USER_FAILURE_RESPONSE,
    });

    it('should be able to check if console controller is defined or not', () => {
      expect(consoleController).toBeDefined();
    });

    it('should check if we are getting all user activation requests failure status code.', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.HttpStatus).toEqual(400);
    });

    it('should check if we are getting all user activation requests failure response.', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body).toEqual(FETCH_USER_FAILURE_RESPONSE);
    });

    it('should check if errors is returned or not', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.errors).toEqual(FETCH_USER_FAILURE_RESPONSE.errors);
    });

    it('should check if errors have the message', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.errors[0].message).toEqual(FETCH_USER_FAILURE_RESPONSE.errors[0].message);
    });

    it('should check if errors have the type', async () => {
      const res = await consoleController.fetchAllUsers(RESPONSE, PAGE, PAGESIZE);

      expect(res.body.errors[0].type).toEqual(FETCH_USER_FAILURE_RESPONSE.errors[0].type);
    });
  });
});