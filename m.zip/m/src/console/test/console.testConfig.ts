export const PAYLOAD = {
  activationId: 'e1db5371-fe3a-4866-ac03-a113debde674',
  leadStatus: 'PENDING',
};

import { ERROR_MESSAGE, ERROR_TYPE, SUCCESS_RESPONSE_MESSAGE } from '../../utils/constant';
import { UpdateAccessRequest } from '../helper/updateAccessRequest';

export const GET_DETAILS_BY_DEVICE_TOKEN_RESPONSE = {
  message: 'Access Request gets updated successfully',
  data: {
    accessRequestId: 'e1db5371-fe3a-4866-ac03-a113debde674',
    email: 'test@gmail.com',
    leadStatus: 'DECLINED',
    activationCode: '',
    isActivated: false,
    deviceType: 'device-type',
    deviceToken: 'device-token',
    createdAt: '2022-11-01T06:04:29.998Z',
    updatedAt: '2022-11-01T06:04:29.998Z',
  },
};
export const DEVICE_TOKEN = 'device-token';

export const UPDATE_ACCESS_REQUEST_CODE_PAYLOAD: UpdateAccessRequest = {
  activationCode: 'activationCode',
  deviceType: 'device-type',
  deviceToken: 'device-token',
};

export const UPDATE_ACCESS_REQUEST_CODE_FAILURE_PAYLOAD: UpdateAccessRequest = {
  activationCode: '',
  deviceType: 'device-type',
  deviceToken: 'device-token',
};

export const GET_DETAILS_BY_ACCESS_REQUEST_CODE_RESPONSE = {
  data: {
    activationId: 'e1db5371-fe3a-4866-ac03-a113debde674',
    email: 'test@gmail.com',
    leadStatus: 'DECLINED',
    activationCode: 'activationCode',
    isActivated: true,
    deviceType: 'device-type',
    deviceToken: 'device-token',
    createdAt: '2022-11-01T06:04:29.998Z',
    updatedAt: '2022-11-01T06:04:29.998Z',
  },
};

export const GET_DETAILS_BY_ACCESS_REQUEST_CODE_FAILURE_RESPONSE = {
  errors: {
    noDataFoundError: 'Data not found with given activation code',
    catchError: 'Something went wrong',
  },
};
export const FETCH_USER_RESPONSE = {
  data:
     [
       {
         email: 'abc@gmail.com',
         lead_status: 'PENDING',
         activation_code: 'activationCode',
         is_activated: false,
         device_type: 'android',
         device_token: 'deviceToken',
       }
     ],
}

export const FETCH_USER_FAILURE_RESPONSE = {
  errors: [ { message: ERROR_MESSAGE.NO_DATA_FOUND, type: ERROR_TYPE.CATCH } ]
}

export const PAGE = 1;
export const PAGESIZE = 10;

export const UPDATE_ACCESS_REQUEST_LEAD_STATUS_FAILURE_RESPONSE = {
  errors: [
    {
      message: ERROR_MESSAGE.ACCESS_REQUEST_LEAD_STATUS_FAIL,
      type: ERROR_TYPE.CATCH
    }
  ]
}

export const FETCH_BY_DEVICE_TOKEN_REQUEST = 'dummyToken';

export const FETCH_BY_DEVICE_TOKEN_SUCCESS_RESPONSE = {
  message: SUCCESS_RESPONSE_MESSAGE.FETCH_BY_DEVICE_TOKEN,
  data: {
    accessRequestsId: "bc471b80-d751-4dbd-a02b-d65cebb57331",
    email: "334sivaji@gmail.com",
    leadStatus: "ACCEPTED",
    activationCode: "CEBB57331",
    isActivated: true,
    deviceType: "onePlus",
    deviceToken: "dummyToken",
    createdAt: "2022-11-22T07:52:09.121Z",
    updatedAt: "2022-11-22T07:52:09.121Z"
  }
}

export const FETCH_BY_DEVICE_TOKEN_FAILURE_RESPONSE = {
  errors: [
    {
      message: ERROR_MESSAGE.NOT_ABLE_TO_FETCH_BY_DEVICE_TOKEN,
      type: ERROR_TYPE.CATCH
    }
  ]
}

export const CREATE_ACCESS_REQUEST = { email: 'test@gmail.com' }

export const CREATE_ACCESS_REQUEST_SUCCESS_RESPONSE = {
  message: SUCCESS_RESPONSE_MESSAGE.CREATED_ACCESS_REQUEST,
  data: {
    email: "testerjava13@dgmail.com",
    lead_status: "PENDING",
    is_activated: false,
    accessRequestsId: "3defc0fb-8d71-4da2-a097-4b44a7b47a7e"
  }
}

export const CREATE_ACCESS_REQUEST_FAILURE_RESPONSE = {
  errors: [ { message: ERROR_MESSAGE.NOT_ABLE_TO_CREATE_ACCESS_REQUEST, type: ERROR_TYPE.CATCH } ]
}