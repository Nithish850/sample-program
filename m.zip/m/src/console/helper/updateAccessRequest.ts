import { ApiProperty } from '@nestjs/swagger';

/**
 * This class is for update access request payload
 */
export class UpdateAccessRequest {
  /**
   * @param {string} activationCode
   * @example activationCode : ''
   */
  @ApiProperty({
    type: 'string',
    description: 'Activation code of user',
  })
    activationCode: string;

  /**
   * @param {string} activationCode
   * @example deviceType : 'device-type'
   */
  @ApiProperty({
    type: 'string',
    description: 'Device type of user ',
  })
    deviceType: string;

  /**
   * @param {string} activationCode
   * @example deviceToken : 'device-token'
   */
  @ApiProperty({
    type: 'string',
    description: 'Device token of user device ',
  })
    deviceToken: string;
}
