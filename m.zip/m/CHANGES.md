# Changes

1. Added Paypal Envs ; to get this check developer account of paypal.
        a. PAYPAL_CLIENT_ID
        b. PAYPAL_CLIENT_ID
        c. PAYPAL_URL
2. /digital-wallet/deposit new API end point has been created under new module digital wallet.
3. Added migration file: 20240718131626_add-digital-and-paypal-payments.ts for adding paypal for digital payment.
